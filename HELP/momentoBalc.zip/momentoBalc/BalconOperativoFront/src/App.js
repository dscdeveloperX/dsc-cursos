import "./App.css";
import { Route, Switch, withRouter } from "react-router-dom";
import { Fragment, useState, useContext, useCallback, useEffect } from "react";
import { Row, Col } from "react-bootstrap";
import Header from "./components/Header";

//import classes from "./App.module.css";

import AuthPage from "./pages/AuthPage";
import AuthContext from "./store/auth-context";
import Sidebar from "./components/Layout/Sidebar";

import classes from "./App.module.css";
import TableProductCreation from "./pages/TableProductCreation";
import TableChangeRequest from "./pages/TableChangeRequest";
import TableContacts from "./pages/TableContacts";

import TableServiceAP from "./pages/TableServiceAP";
import ExternalSite from "./pages/ExternalSite";

function App() {
  const [loaded, setLoaded] = useState(false);

  const authCtx = useContext(AuthContext);

  const getData = useCallback(() => {
    fetch("settings.json", {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (myJson) {
        authCtx.setConfig(myJson);
        setLoaded(true);
      });
  }, [authCtx]);

  useEffect(() => {
    getData();
  }, [getData]);

  let content = <AuthPage />;

  const RouterSideNav = withRouter(Sidebar);

  if (authCtx.isLoggedIn) {
    content = (
      <Fragment>
        <div className="containter-fluid font-face-custom">
          <Row>
            <Header />
          </Row>
          <Row style={{ marginBottom: "50px", marginTop: "50px" }}>
            <Col sm="2" style={{ marginRight: "5%" }}>
              <RouterSideNav />
            </Col>
            <Col sm="9">
              <main className={classes.main}>
                <Switch>
                  <Route path="/creacion" exact>
                    <TableProductCreation />
                  </Route>
                  <Route path="/solicitudes" exact>
                    <TableChangeRequest />
                  </Route>
                  <Route path="/contactabilidad" exact>
                    <TableContacts />
                  </Route>
                  <Route path="/AhorroProgramado" exact>
                    <TableServiceAP />
                  </Route>
                  <Route path="/external/:externalUrl">
                    <ExternalSite />
                  </Route>
                </Switch>
              </main>
            </Col>
          </Row>
        </div>
      </Fragment>
    );
  }

  return <Fragment>{loaded && authCtx.REACT_APP_BASE_URL && content}</Fragment>;
}

export default App;
