import { Navbar, Container, Row, Col, Image } from "react-bootstrap";
import { Fragment, useContext } from "react";
import { useHistory } from "react-router-dom";
import classes from "./Header.module.css";
import "./Header.css";
import { COLORS } from "../values/colors.js";
import AuthContext from "../store/auth-context";
import CustomButton from "./UI/buttons/CustomButton";

const Header = () => {
  const authCtx = useContext(AuthContext);
  let history = useHistory();
  const logoutHandler = () => {
    history.replace("/");
    authCtx.logout();
  };

  const dateFormatter = (value) => {
    if (value === null) return "";
    const date = new Date(value);
    var year = date.getFullYear();

    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : "0" + month;

    var day = date.getDate().toString();
    day = day.length > 1 ? day : "0" + day;

    var hour = date.getHours().toString();
    hour = hour.length > 1 ? hour : "0" + hour;

    var minutes = date.getMinutes().toString();
    minutes = minutes.length > 1 ? minutes : "0" + minutes;

    var seconds = date.getSeconds().toString();
    seconds = seconds.length > 1 ? seconds : "0" + seconds;

    return (
      day +
      "/" +
      month +
      "/" +
      year +
      " " +
      hour +
      ":" +
      minutes +
      ":" +
      seconds
    );
  };

  const navbar = (
    <Navbar
      className={classes.header}
      collapseOnSelect
      style={{ background: COLORS.white, padding: "1rem 0" }}
      expand="sm"
      activekey="1"
    >
      <Row className="m-1 w-100">
        <Container as={Col} md={4} className="justify-content-start">
          <Image src="/assets/logo_entrada.png" style={{maxHeight: "2.8rem", width: "191px"}} />
        </Container>
        <Container as={Col} />
        <Container
          as={Col}
          md={2}
          style={{
            flexDirection: "row",
            justifyContent: "flex-end",
            textAlign: "right",
          }}
        >
          <Row
            style={{
              flexDirection: "row",
              justifyContent: "flex-end",
              textAlign: "right",
              color: COLORS.black,
              fontSize: "0.75rem",
            }}
          >
            Último acceso{" "}
            {authCtx.lastLoginDate ? dateFormatter(authCtx.lastLoginDate) : ""}
          </Row>
          <Row
            style={{
              flexDirection: "row",
              justifyContent: "flex-end",
              textAlign: "right",
              color: COLORS.grey,
              fontSize: "0.6rem",
            }}
          >
            IP {authCtx.ip ? authCtx.ip : ""}
          </Row>
        </Container>
        <Container
          as={Col}
          md={2}
          style={{
            flexDirection: "row",
            justifyContent: "flex-end",
            textAlign: "right",
          }}
        >
          <CustomButton
            size=""
            class={classes["header-buttons"]}
            label="Cerrar Sesión"
            icon="faCircleXmark"
            iconLeft={true}
            iconColor={COLORS.alert}
            eventHandler={logoutHandler}
            fontFamily="Lato"
            bold={true}
          />
        </Container>
      </Row>
    </Navbar>
  );

  return <Fragment>{navbar}</Fragment>;
};

export default Header;
