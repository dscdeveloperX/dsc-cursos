import React from "react";

const Footer = () => {
  return (
    <div
      className="footer"
      style={{ whiteSpace: "pre-wrap", overflowWrap: "break-word", fontSize: "0.75rem" }}
    >
      <p>Banco de Machala © 2022. Todos los derechos reservados.</p>
    </div>
  );
};
export default Footer;
