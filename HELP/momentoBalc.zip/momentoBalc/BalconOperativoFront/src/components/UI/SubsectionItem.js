import { Fragment, useState } from "react";
import DynamicField from "./DynamicField";
import { Row, Col, Container } from "react-bootstrap";

import HeaderTitle from "./fields/HeaderTitle";
import { useSelector } from "react-redux";

const SubsectionItem = (props) => {
    var entry = props.subsection;
    var sectionCode = props.modelo + "|" + props.sectionIndex + "|" + props.subsectionIndex;

    const visible = useSelector(
        (state) => state.field.sectionIsVisible[sectionCode] !== undefined ? state.field.sectionIsVisible[sectionCode] : true
    );

    return (
        <Fragment key={entry.nombre + props.sectionIndex + props.subsectionIndex}>
            {visible && <HeaderTitle label={entry.nombre} key={"h" + entry.nombre + props.sectionIndex + props.subsectionIndex} />}
            {entry.campos !== null &&
                entry.campos.map((entry2, idx2) => {
                    return (
                        <DynamicField
                            field={entry2}
                            key={entry2.codigo + idx2}
                            modelo={props.modelo}
                            sectionIndex={props.sectionIndex}
                            subSectionIndex={props.subsectionIndex}
                            fieldIndex={idx2}
                        />
                    );
                })}
        </Fragment>
    );
};

export default SubsectionItem;
