import { Fragment, useState, useEffect } from "react";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../values/colors";

const SelectValues = (props) => {
  const [selectedValue, setSelectedValue] = useState(
    props.selected ? props.selected : ""
  );

  const values = props.values ? [{ codigo: "", descripcion: "", complemento: "" }, ...props.values] : [];

  const onChangeHandler = (event) => {
    setSelectedValue(event.target.value);
    props.parentCallback(event.target.value);
  };

  useEffect(() => {
    var valor = props.selected ? props.selected : "";
    if (valor !== selectedValue) {
      setSelectedValue(props.selected);
    }
  }, [props.selected]);

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-2">
        <Form.Select
          value={selectedValue}
          disabled={props.disabled}
          onChange={onChangeHandler}
          onBlur={(event) => {
            if (props.blurApiCallback) {
              props.blurApiCallback(selectedValue);
            }
          }}
          size="sm"
        >
          {values.map((entry) => {
            return (
              <option
                key={`${entry.codigo}+${entry.descripcion}`}
                value={entry.codigo}
              >
                {props.labelOrigin?.trim() === "CODIGO" && entry.codigo}
                {props.labelOrigin?.trim() === "ETIQUETA" && entry.descripcion}
                {props.labelOrigin?.trim() === "COMPLEMENTO" &&
                  entry.complemento}
                {props.labelOrigin?.trim() === "CODETIQUETA" && entry.codigo !== "" &&
                  entry.codigo + " - " + entry.descripcion}
                {props.labelOrigin?.trim() === "CODETIQUETA" && entry.codigo === "" &&
                  entry.codigo + " " + entry.descripcion}
              </option>
            );
          })}
        </Form.Select>
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.required ? (
            <Fragment>
              {props.label}{" "}
              <span
                style={{
                  color: "red",
                }}
              >
                *
              </span>
            </Fragment>
          ) : (
            props.label
          )}
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default SelectValues;
