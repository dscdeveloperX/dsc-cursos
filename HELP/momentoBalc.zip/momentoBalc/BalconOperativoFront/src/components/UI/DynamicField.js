import { Fragment, useContext, useEffect, useState } from "react";
import { Col } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import FormInput from "./fields/FormInput";
//import SelectCatalogue from "./fields/SelectCatalogue";
import CustomDatePicker from "./fields/CustomDatePicker";
import CalculatedField from "./fields/CalculatedField";
import SelectValues from "./SelectValues";
import TableField from "./fields/TableField";
import TableReadOnly from "./fields/TableReadOnly";
import { fieldActions } from "../../store/field-helper";
import { checkValidation } from "../../store/field-actions";
import {
  checkVisible,
  checkRequired,
  checkEditable,
} from "../../store/field-actions";
import AuthContext from "../../store/auth-context";
import TypeAheadValues from "./fields/TypeAheadValues";
import OnlineCalculationField from "./fields/OnlineCalculationField";

const DynamicField = (props) => {
  const authCtx = useContext(AuthContext);
  const dispatch = useDispatch();
  const [field, setField] = useState(props.field);
  const [isValid, setIsValid] = useState(true);

  let fieldsInit = useSelector((state) => state.field.fields);

  const visible = checkVisible(fieldsInit, field.codigo);
  const required = checkRequired(fieldsInit, field.codigo);
  const editable = checkEditable(fieldsInit, field.codigo);

  const calcState = useSelector((state) => state.field.loadingFields[field.codigo]);

  const fieldStore = useSelector(
    (state) => state.field.fields[field.codigo]?.field
  );

  var tipodato = field.tipoDato;

  const valoresCombobox = useSelector((state) =>
    state.field.catalogueValues[field.codigo]
      ? state.field.catalogueValues[field.codigo]
      : state.field.fields[field.codigo]?.field.valoresCombobox
  );

  const value = useSelector(
    (state) => state.field.fields[field.codigo]?.field.valor
  );

  useEffect(() => {
    var tempField = { ...field };
    if (tempField.tipoValor === "VALOR") {
      tempField.valor = fieldStore?.valor;
    } else {
      tempField.valoresLista = fieldStore?.valoresLista;      
    }

    if(field.codigo === "CORREO1_DOMICILIO"){
      console.log("fieldsInit: " + fieldsInit);
      console.log("field.codigo: " + field.codigo);
    }
    const isvalidcheck = checkValidation(fieldsInit, field.codigo);
    if(field.codigo === "CORREO1_DOMICILIO"){
      console.log("isvalidcheck: " + isvalidcheck);
    }

    setIsValid(isvalidcheck);
    setField(tempField);
  }, [fieldStore]);

  const onChangeHandler = (valueIn) => {
    var tempField = { ...field };
    if (tempField.tipoValor === "VALOR") {
      tempField.valor = valueIn;
    } else {
      tempField.valoresLista = valueIn;
    }

    dispatch(
      fieldActions.updateField({
        modelo: props.modelo,
        code: field.codigo,
        sectionIndex: props.sectionIndex,
        subSectionIndex: props.subSectionIndex,
        fieldIndex: props.fieldIndex,
        value: tempField,
        agencyCode: authCtx.agencyCode,
        user: authCtx.user,
        executiveCode: authCtx.executiveCode,
        vatId: authCtx.vatId,
        area: authCtx.area,
      })
    );
  };

  const onBlurHandler = (value) => {
    dispatch(
      fieldActions.updateFieldApiCall({
        code: field.codigo,
        value: value
      })
    );
  };

  const onChangeApiHandler = (values) => {
    dispatch(
      fieldActions.updateFieldApiRes({
        model: props.modelo,
        code: field.codigo,
        values: values,
        agencyCode: authCtx.agencyCode,
        user: authCtx.user,
        executiveCode: authCtx.executiveCode,
        vatId: authCtx.vatId,
        area: authCtx.area,
      })
    );
  };

  return (
    <Fragment>
      {visible && (
        <Col md={field.anchoColumna}>
          <Fragment>
            {field.tipoValor === "VALOR" && (
              <Fragment>
                {field.tipoCampo === "COMBOBOX" && (
                  <Fragment>
                    {valoresCombobox?.length <= 2 && (
                      <SelectValues
                        selected={(value !== undefined && value !== null) ? value : ""}
                        disabled={!editable}
                        label={field.etiquetaDetalle}
                        values={valoresCombobox}
                        parentCallback={onChangeHandler}
                        blurApiCallback={onBlurHandler}
                        labelOrigin={field.origenEtiqueta}
                        required={required}
                      />
                    )}
                    {valoresCombobox?.length > 2 && (
                      <TypeAheadValues
                        selected={(value !== undefined && value !== null) ? value : ""}
                        disabled={!editable}
                        label={field.etiquetaDetalle}
                        values={valoresCombobox}
                        parentCallback={onChangeHandler}
                        blurApiCallback={onBlurHandler}
                        labelOrigin={field.origenEtiqueta}
                        required={required}
                        code={field.codigo}
                      />
                    )}
                  </Fragment>
                )}
                {field.tipoCampo === "TEXTFIELD" && (
                  <Fragment>
                    <FormInput
                      value={(value !== undefined && value !== null) ? value : ""}
                      label={field.etiquetaDetalle}
                      disabled={!editable}
                      parentCallback={onChangeHandler}
                      blurApiCallback={onBlurHandler}
                      maxLength={field.longitudMaximaDetalle}
                      dataType={tipodato}
                      required={required}
                      isValid={isValid}
                    />
                  </Fragment>
                )}
                {field.tipoCampo === "CALCULADO" &&
                  field.tipoCalculado !== "API" && (
                    <CalculatedField
                      disabled={!editable}
                      value={(value !== undefined && value !== null) ? value : ""}
                      label={field.etiquetaDetalle}
                      parentCallback={onChangeHandler}
                      tipoCalculado={field.tipoCalculado}
                      nombreCalculo={field.nombreCalculo}
                      required={required}
                      field={field}
                    />
                  )}
                {field.tipoCampo === "CALCULADO" &&
                  field.tipoCalculado === "API" && (
                    <OnlineCalculationField
                      disabled={!editable}
                      value={(value !== undefined && value !== null) ? value : ""}
                      label={field.etiquetaDetalle}
                      parentCallback={onChangeApiHandler}
                      tipoCalculado={field.tipoCalculado}
                      nombreCalculo={field.nombreCalculo}
                      valores={fieldsInit}
                      calcState={calcState}
                      required={required}
                      field={field}
                    />
                  )}
                {field.tipoCampo === "CHECKBOX" && <Fragment></Fragment>}
                {field.tipoCampo === "DATEPICKER" && (
                  <Fragment>
                    <CustomDatePicker
                      label={field.etiquetaDetalle}
                      value={(value !== undefined && value !== null) ? value : ""}
                      disabled={!editable}
                      eventHandler={onChangeHandler}
                      required={required}
                    />
                  </Fragment>
                )}
              </Fragment>
            )}
            {field.tipoValor === "LISTA" && (
              <Fragment>
                {field.tipoCampo === "TABLA" && (
                  <Fragment>
                    <TableField
                      formatoModeloLista={field.formatoModeloLista}
                      valoresLista={field.valoresLista}
                      etiquetaDetalle={field.etiquetaDetalle}
                      onModifyTable={onChangeHandler}
                      fieldsParent={fieldsInit}
                      longitudMinimaDetalle={field.longitudMinimaDetalle}
                    />
                  </Fragment>
                )} 
                  {field.tipoCampo === "TABLAREADONLY" && (
                    <Fragment>
                      <TableReadOnly
                        formatoModeloLista={field.formatoModeloLista}
                        valoresLista={field.valoresLista}
                        etiquetaDetalle={field.etiquetaDetalle}
                        onModifyTable={onChangeHandler}
                        fieldsParent={fieldsInit}
                        longitudMinimaDetalle={field.longitudMinimaDetalle}
                      />
                    </Fragment>
                  )} 
              </Fragment>


            )}
          </Fragment>
        </Col>
      )}
    </Fragment>
  );
};

export default DynamicField;
