import classes from "./css/LoadingSpinner.module.css";

const LoadingSpinner = (props) => {
  const classSpinner =
    props.size === "sm" ? classes["spinner-sm"] : classes["spinner"];
  return <div className={classSpinner}></div>;
};

export default LoadingSpinner;
