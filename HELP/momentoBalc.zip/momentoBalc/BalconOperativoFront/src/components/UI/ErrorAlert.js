import { Alert } from "react-bootstrap";
import { Link } from "react-router-dom";
import { COLORS } from "../../values/colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmarkCircle } from "@fortawesome/free-solid-svg-icons";

const ErrorAlert = (props) => {
  var points = [];
  var errors = props.text?.split("||");
  var message = errors[0];
  if (errors.length > 1) {
    points = errors[1].split("\n");
  }

  return (
    <Alert style={{ backgroundColor: COLORS.alert, color: COLORS.white }}>
      <FontAwesomeIcon
        icon={faXmarkCircle}
        onClick={props?.hideError}
        color={COLORS.white}
        size="lg"
        className="me-2"
      />
      {message}
      {points !== undefined && points !== null && points.length > 0 && <ul>
        {points.map(err => {
          return <li>{err}</li>
        })}
      </ul>}
    </Alert>
  );
};

export default ErrorAlert;
