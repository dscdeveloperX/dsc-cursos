import { Col, Row } from "react-bootstrap";

import { dateCalendarFormatter } from "../../../store/utils-actions";

import store from "../../../store/index";
import { formatValue } from "react-currency-input-field";

const FormField = (props) => {
  const fields = store.getState().field.fields;
  var valores = [];
  var columns = [];

  if (props.valueType === "LISTA") {
    columns =
      props.listHeaders !== null &&
      props.listHeaders.map((entry) => {
        if (entry.formularioVisible === true) {
          return {
            dataField: entry.codigo, text: entry.etiquetaDetalle, tipoDato: entry.tipoDato,
            tipoCampo: entry.tipoCampo, valoresCombobox: entry.valoresCombobox, origenEtiqueta: entry.origenEtiqueta
          };
        }
        else {
          return { dataField: entry.codigo, text: entry.etiquetaDetalle, hidden: true };
        }
      });

    columns = columns.filter((x) => x.hidden !== true);

    valores =
      props.listValues !== null &&
        props.listValues !== undefined &&
        props.listValues.length > 0
        ? props.listValues.map((valor, index) => {
          var campos = [];

          columns.forEach((element) => {
            var item = valor.campos.find(
              (x) => x.codigo === element.dataField
            );
            campos.push({
              valor: item?.valor,
              tipoDato: element.tipoDato,
              tipoCampo: element.tipoCampo,
              valoresCombobox: element.valoresCombobox,
              origenEtiqueta: element.origenEtiqueta
            });
          });
          return campos;
        })
        : [];
  }

  const ObtenerValorMostrar = (entry, justDescription) => {
    if (entry.tipoCampo?.trim() === "COMBOBOX") {
      var value = entry.valoresCombobox?.find(
        (x) => x.codigo === entry.valor?.trim()
      );
      if (value !== undefined) {
        var origin = entry.origenEtiqueta?.trim();
        if (justDescription) origin = "ETIQUETA";
        if (origin === "CODIGO")
          return value.codigo;
        else if (origin === "ETIQUETA")
          return value.descripcion;
        else if (origin === "COMPLEMENTO")
          return value.complemento;
        else if (origin === "CODETIQUETA")
          return value.codigo + " - " + value.descripcion;
      } else {
        return "";
      }
    } else if (entry.tipoDato === "MONEDA") {

      var valorFormateo = "0";
      if (
        entry.valor !== undefined &&
        entry.valor !== null
      ) {
        valorFormateo = entry.valor + "";
      }

      return formatValue({
        value: valorFormateo,
        groupSeparator: ",",
        decimalSeparator: ".",
        prefix: "$",
        decimalScale: 2,
      });
    } else if (entry.tipoDato === "PORCENTAJE") {

      var valorFormateo = "0";
      if (
        entry.valor !== undefined &&
        entry.valor !== null
      ) {
        valorFormateo = entry.valor + "";
      }

      return formatValue({
        value: valorFormateo,
        groupSeparator: ",",
        decimalSeparator: ".",
        suffix: "%",
        decimalScale: 2,
      });
    } else if (entry.tipoDato === "FECHA") {
      return dateCalendarFormatter(entry.valor);
    }
    return entry.valor;
  };
  return (
    <Col
      md={props.columnW}
      style={{
        margin: "0px",
        padding: "0px"
      }}
      className="h-100"
    >
      {props.valueType === "VALOR" && (
        <Row
          style={{
            width: "100%",
            padding: "0px",
            margin: "0px",
          }}
          className="h-100"
        >
          <Col
            style={{                            
              fontWeight: "bold",
              marginBottom: "0px",
              marginTop: "0px",
              padding: "2px",
              lineHeight: "90%",
              borderLeft: "1px solid black"
            }} 
            className="align-middle h-100 d-inline-block"
            md={props.labelW}
          >
            {props.label}
          </Col>
          {(+props.labelW) != 12 && <Col
            style={{
              borderLeft: "1px solid black",           
              margin: "0px",
              padding: "2px",
              lineHeight: "90%"
            }}
            className="align-middle h-100 d-inline-block"
          >
            {ObtenerValorMostrar(fields[props.code]?.field, true)}
          </Col>}

        </Row>
      )}
      {props.valueType === "LISTA" && (
        <Row
          style={{
            width: "100%",
            borderLeft: "1px solid black",
            padding: "2px",
            margin: "0px"
          }}
        >
          <table>
            <thead>
              <tr className="form-print-row">
                {columns?.map((entry) => {
                  return <th style={{lineHeight: "90%"}}>{entry.text}</th>;
                })}
              </tr>
            </thead>
            <tbody>
              {valores?.map((entry) => {
                return (
                  <tr className="form-print-row">
                    {entry?.map((val) => {
                      return <td style={{lineHeight: "90%"}}>{ObtenerValorMostrar(val, false)}</td>;
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Row>
      )}
    </Col>
  );
};

export default FormField;
