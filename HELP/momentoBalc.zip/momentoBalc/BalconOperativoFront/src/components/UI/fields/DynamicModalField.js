import { Fragment, useContext, useEffect, useState } from "react";
import FormInput from "./FormInput";
import CustomDatePicker from "./CustomDatePicker";
import CalculatedField from "./CalculatedField";
import TypeAheadValues from "./TypeAheadValues";
import { Col } from "react-bootstrap";
import ModalContext from "../../../store/modal-context";
import OnlineCalculationField from "./OnlineCalculationField"
import SelectValues from "../SelectValues";
import { checkValidation } from "../../../store/field-actions";
import store from "../../../store/index";
const DynamicModalField = (props) => {
  const modalCtx = useContext(ModalContext);
  //const [field, setField] = useState(props.field);
  const field = props.field;
  const visible = modalCtx.checkVisible(field.codigo);
  const required = modalCtx.checkRequired(field.codigo);
  const editable = modalCtx.checkEditable(field.codigo);

  const calcState = modalCtx.loadingFields[field.codigo];

  const valoresCombobox = modalCtx.catalogueValues[field.codigo]
    ? modalCtx.catalogueValues[field.codigo]
    : modalCtx.fields[field.codigo]?.field.valoresCombobox;
  const value = modalCtx.fields[field.codigo]?.field.valor;

  const [isValid, setIsValid] = useState(true);

  const onChangeHandler = (valueIn) => {
    //var tempField = { ...field };
    //tempField.valor = valueIn;
    let fieldsParent = store.getState().field.fields;
    var edit = modalCtx.updateModalFields(field.codigo, valueIn, props.fieldsValues, fieldsParent);

    const isvalidcheck = checkValidation(modalCtx.fields, field.codigo);

    setIsValid(isvalidcheck);

    if (props.parentCallback) {
      props.parentCallback(valueIn, edit);
    }
  };

  const onChangeApiHandler = (values) => {
    var edit = modalCtx.updateApiModalFields(values, field.codigo, props.fieldsValues);

    if (props.onGetApiValues) {
      props.onGetApiValues(values, edit);
    }
  };

  const onBlurHandler = (value) => {
    modalCtx.updateFieldApiCall(field.codigo, value);
  };

  return (
    <Fragment>
      {visible && (
        <Col md={field.anchoColumna}>
          {field.tipoValor === "VALOR" && (
            <Fragment>
              {field.tipoCampo === "COMBOBOX" && (
                <Fragment>
                  {valoresCombobox?.length <= 2 && (
                    <SelectValues
                      selected={(value !== undefined && value !== null) ? value : ""}
                      disabled={!editable}
                      label={field.etiquetaDetalle}
                      values={valoresCombobox}
                      parentCallback={onChangeHandler}
                      blurApiCallback={onBlurHandler}
                      labelOrigin={field.origenEtiqueta}
                      required={required}
                    />
                  )}
                  {valoresCombobox?.length > 2 && (
                    <TypeAheadValues
                      selected={(value !== undefined && value !== null) ? value : ""}
                      disabled={!editable}
                      label={field.etiquetaDetalle}
                      values={valoresCombobox}
                      parentCallback={onChangeHandler}
                      blurApiCallback={onBlurHandler}
                      labelOrigin={field.origenEtiqueta}
                      required={required}
                      code={field.codigo}
                    />
                  )}
                </Fragment>
              )}
              {field.tipoCampo === "TEXTFIELD" && (
                <Fragment>
                  <FormInput
                    value={(value !== undefined && value !== null) ? value : ""}
                    label={field.etiquetaDetalle}
                    disabled={!editable}
                    parentCallback={onChangeHandler}
                    blurApiCallback={onBlurHandler}
                    maxLength={field.longitudMaximaDetalle}
                    dataType={field.tipoDato}
                    required={required}
                    isValid={isValid}
                  />
                </Fragment>
              )}
              {field.tipoCampo === "CALCULADO" &&
                field.tipoCalculado !== "API" && (
                  <CalculatedField
                    disabled={!editable}
                    value={(value !== undefined && value !== null) ? value : ""}
                    label={field.etiquetaDetalle}
                    parentCallback={onChangeHandler}
                    tipoCalculado={field.tipoCalculado}
                    nombreCalculo={field.nombreCalculo}
                    required={required}
                    field={field}
                  />
                )}
              {field.tipoCampo === "CALCULADO" &&
                field.tipoCalculado === "API" && (
                  <OnlineCalculationField
                    disabled={!editable}
                    value={(value !== undefined && value !== null) ? value : ""}
                    label={field.etiquetaDetalle}
                    parentCallback={onChangeApiHandler}
                    tipoCalculado={field.tipoCalculado}
                    nombreCalculo={field.nombreCalculo}
                    valores={modalCtx.fields}
                    calcState={calcState}
                    field={field}
                  />
                )}
              {field.tipoCampo === "CHECKBOX" && <Fragment></Fragment>}
              {field.tipoCampo === "DATEPICKER" && (
                <Fragment>
                  <CustomDatePicker
                    label={field.etiquetaDetalle}
                    value={(value !== undefined && value !== null) ? value : ""}
                    eventHandler={onChangeHandler}
                    disabled={!editable}
                    required={required}
                  />
                </Fragment>
              )}
            </Fragment>
          )}
        </Col>
      )}
    </Fragment>
  );
};

export default DynamicModalField;
