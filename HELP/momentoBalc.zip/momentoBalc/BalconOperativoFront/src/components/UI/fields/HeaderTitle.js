import { Fragment } from "react";
import { COLORS } from "../../../values/colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import formClasses from "../../UI/css/Form.module.css";
import { Row } from "react-bootstrap";
const FormInput = (props) => {
  return (
    <Fragment>
      <Row>
        {props.icon && <FontAwesomeIcon icon={props.icon} />}
        <h1 className={formClasses.title}>{props.label}</h1>
      </Row>
      <hr style={{ color: COLORS.secondaryLight, height: "2px", margin: "0.5rem 0" }} />
    </Fragment>
  );
};

export default FormInput;
