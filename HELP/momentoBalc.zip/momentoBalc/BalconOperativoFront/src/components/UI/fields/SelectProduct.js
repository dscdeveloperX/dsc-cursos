import { Fragment, useState, useEffect, useCallback, useContext } from "react";
import AuthContext from "../../../store/auth-context";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";

const SelectProduct = (props) => {
  const [selectedValue, setSelectedValue] = useState(props.selected);
  const [appList, setAppList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const authCtx = useContext(AuthContext);

  const {
    selected,
    allowNone,
    tipo: modelType,
    parentCallback,
  } = props;

  const onChangeHandler = (event) => {
    setSelectedValue(event.target.value);
    props.parentCallback(event.target.value);
  };

  const fetchAppListHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1000,
          pageRequested: 1,
        },
        bodyRequest: {
          estado: "ACTIVO",
          ordenarPor: "name",
          ordenDesc: false,
          filtrarPor: "",
          valorFiltro: "",
          tipo: modelType,
          menuId: localStorage.getItem('menuId'),
        },
      };

      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "modelos/Listar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      ).catch(_ => {
        throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
      });

      const resText = await response.text();
      const data = resText && JSON.parse(resText);
      if (!response.ok) {
        if ([401, 403].includes(response.status)) {
          throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
        }
        if (data?.headerResponse !== undefined) {
          const errorMessage = data.headerResponse.returnMessage.split("|");
          throw Error(errorMessage[0]);
        } else {
          throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
        }
      }

      let location = window.location.pathname;
      
      setAppList(data.bodyResponse.modelos);
      if (allowNone !== undefined && allowNone === true) {
        if (location === "/AhorroProgramado") {
          setAppList([
            ...data.bodyResponse.modelos,
          ]);
        }
        else{
          setAppList([
            { modeloId: 0, codigo: "NA", nombre: "Ninguno" },
              ...data.bodyResponse.modelos,
            ]);
        }
      }

      if (selected === undefined) {
        setSelectedValue(data.bodyResponse.modelos[0].modeloId);
        parentCallback(data.bodyResponse.modelos[0].modeloId);
      } else {
        setSelectedValue(selected);
        parentCallback(selected);
      }
    } catch (error) {
      setError(error.message);
    }
    setIsLoading(false);
  }, [
    authCtx.REACT_APP_BASE_URL,
    authCtx.ip,
    authCtx.token,
    authCtx.user,
    modelType,
    selected,
    allowNone,
    parentCallback,
  ]);

  useEffect(() => {
    fetchAppListHandler();
  }, [fetchAppListHandler]);

  useEffect(() => {
    if (props.selected !== selectedValue) {
      setSelectedValue(props.selected);
    }
  }, [props.selected]);

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-2">
        <Form.Select
          value={selectedValue}
          disabled={props.disabled}
          onChange={onChangeHandler}
          size="sm"
        >
          {!isLoading &&
            appList.map((entry) => {
              return (
                <option
                  key={`${entry.modeloId}+${entry.nombre}`}
                  value={entry.modeloId}
                >
                  {entry.nombre}
                </option>
              );
            })}
        </Form.Select>
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label}
        </Form.Label>
        {error && <p className="error-text">{error}</p>}
      </Form.Group>
    </Fragment>
  );
};

export default SelectProduct;
