import { Fragment, useState, useEffect, useRef } from "react";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";
import classes from "../css/InputField.module.css";
import FormInput from "./FormInput";

const TypeAheadValues = (props) => {
  const values = props.values ? props.values : [];

  var inicial = values.find((x) => x.codigo === props.selected);

  if (inicial === undefined) {
    inicial = { codigo: "", descripcion: "", complemento: "" };
  }

  const ref = useRef();

  const [selectedValue, setSelectedValue] = useState([inicial]);

  const onChangeHandler = (event) => {
    setSelectedValue(event);
    var valor = event.length > 0 ? event[0].codigo : "";

    props.parentCallback(valor);
  };

  const inputChangeHandler = (text, event) => {
    const result = text.replace(/[^-A-Za-zÀ-Úà-ú0-9., ]/gi,
      "");
    ref.current.state.text = result;
  }

  useEffect(() => {
    var inicialD = values.find((x) => x.codigo === props.selected);

    if (inicialD === undefined && values.length > 0) {
      inicialD = { codigo: "", descripcion: "", complemento: "" };
    }

    if (inicialD?.codigo !== selectedValue?.codigo) {
      setSelectedValue([inicialD]);
    }
  }, [props.selected]);

  const getLabel = (entry) => {
    if (entry !== null && entry.codigo !== "") {
      if (props.labelOrigin?.trim() === "CODIGO") return entry.codigo;
      else if (props.labelOrigin?.trim() === "ETIQUETA")
        return entry.descripcion;
      else if (props.labelOrigin?.trim() === "COMPLEMENTO")
        return entry.complemento;
      else if (props.labelOrigin?.trim() === "CODETIQUETA")
        return entry.codigo + " - " + entry.descripcion;
    } else {
      return "";
    }
  }

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-2">
        <Typeahead
          ref={ref}
          id={"typeahead-" + props.code}
          clearButton
          className={classes["bottom-line-input"]}
          labelKey={getLabel}
          emptyLabel="No se encontraron resultados"
          onBlur={(event) => {
            var valor = selectedValue.length > 0 ? selectedValue[0].codigo : "";
            var inicialD = values.find((x) => x.codigo === valor);
            if (inicialD !== undefined) {
              ref.current.inputNode.value = getLabel(inicialD)
            }
            else {
              ref.current?.clear();
            }

            if (props.blurApiCallback) {
              props.blurApiCallback(valor);
            }
          }}
          onInputChange={
            inputChangeHandler
          }
          onChange={onChangeHandler}
          options={values}
          placeholder={props.label}
          selected={selectedValue}
          disabled={props.disabled}
          size="sm"
        />
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.required ? (
            <Fragment>
              {props.label}{" "}
              <span
                style={{
                  color: "red",
                }}
              >
                *
              </span>
            </Fragment>
          ) : (
            props.label
          )}
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default TypeAheadValues;
