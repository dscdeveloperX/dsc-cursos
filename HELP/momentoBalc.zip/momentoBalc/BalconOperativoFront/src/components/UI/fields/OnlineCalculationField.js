import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import classes from "../css/InputField.module.css";
import { COLORS } from "../../../values/colors";
import { ObtenerValorCalculadoApi } from "../../../store/field-actions";
import { Fragment } from "react";
import AuthContext from "../../../store/auth-context";
import { useContext } from "react";
import CustomButton from "../buttons/CustomButton";
import LoadingSpinner from "../LoadingSpinner";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck, faX } from "@fortawesome/free-solid-svg-icons";

const OnlineCalculatedField = (props) => {
  const authCtx = useContext(AuthContext);
  const field = props.field;

  const [error, setError] = useState("");

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (props.calcState === true && loading === false) {
      getApiValues();
    }
  }, [props.calcState]);

  const getApiValues = async () => {
    setLoading(true);
    setError("");
    var valores = {};
    try {
      valores = await ObtenerValorCalculadoApi(props.valores, field.codigo, {
        user: authCtx.user,
        ip: authCtx.ip,
        REACT_APP_BASE_URL: authCtx.REACT_APP_BASE_URL,
        token: authCtx.token,
      });
    } catch (error) {
      setError(error.message);
    }
    if (props.parentCallback) {
      props.parentCallback(valores);
    }

    setLoading(false);
  };

  return (
    <Fragment>
      {!loading && error === "" && (
        <FontAwesomeIcon
          color={COLORS.primaryLight}
          icon={faCheck}
          size="lg"
          className="ms-1"
        />
        // <CustomButton
        //   disabled={props.disabled}
        //   class={classes["btn-custom-inverse"]}
        //   color={COLORS.primaryLight}
        //   iconColor={COLORS.primaryLight}
        //   icon="faMagnifyingGlass"
        //   eventHandler={getApiValues}
        // />
      )}
      {/* {!loading && error !== "" && <p className="error-text">{error}</p>} */}
      {!loading && error !== "" && <FontAwesomeIcon
        color={COLORS.alert}
        icon={faX}
        size="lg"
        className="ms-1"
      />}
      {loading && <LoadingSpinner size="sm" />}
    </Fragment>
  );
};

export default OnlineCalculatedField;
