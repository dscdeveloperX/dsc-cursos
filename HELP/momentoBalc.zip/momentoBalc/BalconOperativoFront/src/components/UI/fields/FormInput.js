import { Fragment, useEffect, useState } from "react";
import { Form, Col } from "react-bootstrap";
import CurrencyInput from "react-currency-input-field";
import classes from "../css/InputField.module.css";
import { COLORS } from "../../../values/colors";

const FormInput = (props) => {
  const [enteredValue, setEnteredValue] = useState(props.value);
  const [enteredValueTouched, setEnteredValueTouched] = useState(false);
  const [rulesIsValid, setRulesIsValid] = useState(
    props.isValid ? props.isValid : true
  );

  //const enteredValueIsNotEmpty = enteredValue !== "";
  //const enteredValueIsValid = rulesIsValid ? rulesIsValid : true;
  //const valueInputIsInvalid = !enteredValueIsValid && enteredValueTouched;

  useEffect(() => {
    if (props.value !== enteredValue) {
      setEnteredValue(props.value);
    }
  }, [props.value]);

  useEffect(() => {
    if (props.isValid !== rulesIsValid) {
      setRulesIsValid(props.isValid);
    }
  }, [props.isValid]);

  const handleFocus = (event) => {
    event.target.select();
  };

  const valueInputChangeHandler = (event) => {
    if (props.dataType === "NUMERICO") {
      const re = /^[0-9\b]+$/;
      if (event.target.value === "" || re.test(event.target.value)) {
        setEnteredValue(event.target.value);
        if (props.parentCallback) {
          props.parentCallback(event.target.value);
        }
      }
    } else if (props.dataType === "ALFABETICO") {
      const result = event.target.value.replace(/[^A-Za-zÀ-Úà-ú ]/gi, "").toUpperCase();
      setEnteredValue(result);
      if (props.parentCallback) {
        props.parentCallback(result);
      }
    } else if (props.dataType === "NUMERICOST") {
      const result = event.target.value.replace(
        /[^0-9]/gi,
        ""
      ).toUpperCase();
      setEnteredValue(result);
      if (props.parentCallback) {
        props.parentCallback(result);
      }
    }else if (props.dataType === "ALFANUMERICO") {
      const result = event.target.value.replace(
        /[^-A-Za-zÀ-Úà-ú0-9.,#()/@_ ]/gi,
        ""
      ).toUpperCase();
      setEnteredValue(result);
      if (props.parentCallback) {
        props.parentCallback(result);
      }
    } else if (props.dataType === "ALFANUMERICOSOLO") {
      const result = event.target.value.replace(
        /[^A-Za-zÀ-Úà-ú0-9]/gi,
        ""
      ).toUpperCase();
      setEnteredValue(result);
      if (props.parentCallback) {
        props.parentCallback(result);
      }
    } else {
      setEnteredValue(event.target.value);
      if (props.parentCallback) {
        props.parentCallback(event.target.value);
      }
    }
  };

  const valueInputMonedaChangeHandler = (value, name) => {
    setEnteredValue(value);
  };

  const valueInputCurrencyBlurHandler = (event) => {
    var number = (enteredValue ? enteredValue.replace(",", ".") : "0,00");
    var parsedNum = parseFloat(number).toFixed(2);

    setEnteredValueTouched(true);
    if (props.parentCallback) {
      props.parentCallback(parsedNum);
    }
  };

  const valueInputBlurHandler = (event) => {
    setEnteredValueTouched(true);
    if (props.parentCallback) {
      props.parentCallback(enteredValue);
    }

    if (props.blurApiCallback)
    {
      props.blurApiCallback(enteredValue);
    }

    /*if (props.parentIsValidCallback) {
      props.parentIsValidCallback(!valueInputIsInvalid);
    }*/
  };

  const requiredWarningMessage = "Ingrese un valor válido.";

  return (
    <Form.Group as={Col}>
      {props.dataType !== "MONEDA" && props.dataType !== "PORCENTAJE" && (
        <Form.Control
          className={classes["bottom-line-input"]}
          disabled={props.disabled}
          value={enteredValue}
          defaultValue={0.0}
          onChange={valueInputChangeHandler}
          onBlur={valueInputBlurHandler}
          type="text"
          placeholder={props.label}
          style={{ marginBottom: 0 }}
          maxLength={props.maxLength}
          size="sm"
        />
      )}
      {props.dataType === "PORCENTAJE" && (
        <CurrencyInput
          className={classes["bottom-line-input"] + " form-control"}
          disabled={true}
          placeholder={props.label}
          value={enteredValue}
          defaultValue={0.0}
          decimalScale={2}
          style={{ marginBottom: 0 }}
          suffix="%"
          size="sm"
          onValueChange={valueInputMonedaChangeHandler}
          onBlur={valueInputCurrencyBlurHandler}
          onFocus={handleFocus}
          decimalSeparator=","
          groupSeparator="."
          allowDecimals={true}
        />
      )}
      {props.dataType === "MONEDA" && (
        <CurrencyInput
          className={classes["bottom-line-input"] + " form-control"}
          disabled={props.disabled}
          placeholder={props.label}
          defaultValue={0.0}
          value={enteredValue}
          style={{ marginBottom: 0 }}
          prefix="$"
          maxLength={props.maxLength}
          decimalScale={2}
          onValueChange={valueInputMonedaChangeHandler}
          onBlur={valueInputCurrencyBlurHandler}
          onFocus={handleFocus}
          size="sm"
          decimalSeparator=","
          groupSeparator="."
          allowDecimals={true}
        />
      )}
      <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
        {props.required ? (
          <Fragment>
            {props.label}{" "}
            <span
              style={{
                color: "red",
              }}
            >
              *
            </span>
          </Fragment>
        ) : (
          props.label
        )}
      </Form.Label>
      {/* {props.parentIsValidCallback && */}
      {props.isValid !== undefined && !rulesIsValid && enteredValueTouched && (
        <p className="error-text">{requiredWarningMessage}</p>
      )}
    </Form.Group>
  );
};

export default FormInput;
