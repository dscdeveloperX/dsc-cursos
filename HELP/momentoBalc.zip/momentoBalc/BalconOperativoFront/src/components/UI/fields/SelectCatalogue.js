import { Fragment, useState, useEffect, useCallback, useContext } from "react";
import AuthContext from "../../../store/auth-context";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";

const SelectCatalogue = (props) => {
  const [selectedValue, setSelectedValue] = useState(props.selected);
  const [appList, setAppList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const origenEtiqueta = props.origenEtiqueta ? props.origenEtiqueta : "ETIQUETA";

  const authCtx = useContext(AuthContext);

  const catalogueName = props.catalogo;

  const onChangeHandler = (event) => {
    setSelectedValue(event.target.value);
    props.parentCallback(event.target.value);
  };

  const fetchAppListHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1000,
          pageRequested: 1,
        },
        bodyRequest: {
          nombreCatalogo: catalogueName,
          estado: "ACTIVO",
          ordenarPor: "value",
          ordenDesc: false,
          filtrarPor: "",
          valorFiltro: "",
        },
      };

      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "catalogos/Listar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      ).catch(_ => {
        throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
      });

      const resText = await response.text();
      const data = resText && JSON.parse(resText);
      if (!response.ok) {
        if ([401, 403].includes(response.status)) {
          throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
        }
        if (data?.headerResponse !== undefined) {
          const errorMessage = data.headerResponse.returnMessage.split("|");
          throw Error(errorMessage[0]);
        } else {
          throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
        }
      }

      if (props.selected === undefined) {
        setSelectedValue(data.bodyResponse.catalogos[0].codigo);
        props.parentCallback(data.bodyResponse.catalogos[0].codigo);
      } else {
        setSelectedValue(props.selected);
        props.parentCallback(props.selected);
      }
      var catalogosVals = [...data.bodyResponse.catalogos]
      if (props.includeOnly !== undefined && props.includeOnly !== null && props.includeOnly.length > 0) {
        catalogosVals = catalogosVals.filter(x => props.includeOnly.includes(x.codigo));
      }
      setAppList(catalogosVals);
    } catch (error) {
      setError(error.message);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchAppListHandler();
  }, [fetchAppListHandler]);

  useEffect(() => {
    if (props.selected !== selectedValue) {
      setSelectedValue(props.selected);
    }
  }, [props.selected]);

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-2">
        <Form.Select
          value={selectedValue}
          disabled={props.disabled}
          onChange={onChangeHandler}
          size="sm"
        >
          {!isLoading &&
            appList.map((entry) => {
              return (
                <option
                  key={`${entry.codigo}+${entry.descripcion}`}
                  value={entry.codigo}
                >
                  {origenEtiqueta == "ETIQUETA" && entry.descripcion}
                  {origenEtiqueta == "CODIGO" && entry.codigo}
                  {origenEtiqueta == "COMPLEMENTO" && entry.complemento}
                </option>
              );
            })}
        </Form.Select>
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label}
        </Form.Label>
        {error && <p className="error-text">{error}</p>}
      </Form.Group>
    </Fragment>
  );
};

export default SelectCatalogue;
