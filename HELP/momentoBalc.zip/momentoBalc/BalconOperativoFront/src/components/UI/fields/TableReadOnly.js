import { faTrashCan } from "@fortawesome/free-regular-svg-icons";
import { faInfoCircle, faPencil } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Fragment, useEffect, useRef, useState } from "react";
import { Alert, Col, Row, Stack } from "react-bootstrap";
import { COLORS } from "../../../values/colors";
import DynamicModal from "../../Forms/DynamicModal";
import CustomTable from "../../Layout/CustomTable";
import CustomButton from "../buttons/CustomButton";
import { formatValue } from "react-currency-input-field";

import classes from "../css/SearchBar.module.css";
import { ModalContextProvider } from "../../../store/modal-context";
import { dateCalendarFormatter } from "../../../store/utils-actions";
import CustomStaticTable from "../../Layout/CustomStaticTable";

const TableField = (props) => {
  const formatoModeloLista = props.formatoModeloLista;
  const [selectedEdit, setSelectedEdit] = useState(null);
  const modalRef = useRef();
  const [show, setShow] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [sizePerPage, setSizePerPage] = useState(5);
  const [total, setTotal] = useState(0);

  //ocultar botones
  const [isHidden, setIsHidden] = useState(false);

  useEffect(() => {
    const valoresll =
      props.valoresLista !== null &&
        props.valoresLista !== undefined &&
        props.valoresLista.length > 0
        ? props.valoresLista.map((valor, index) => {
          var campos = {};
          valor.campos.forEach((element) => {
            campos[element.codigo] = element.valor;
          });
          return campos;
        })
        : [];
    if (valoresll !== valoresTabla) {
      setValoresTable(valoresll);
      setValoresMostrar(getValoresMostrar(valores));
    }
  }, [props.valoresLista]);

  const onPageChange = (page, sizePerPage) => {
    setCurrentPage(page);
    setSizePerPage(sizePerPage);
  };

  var visibleCols = 0;
  var columns =
    formatoModeloLista !== null &&
    formatoModeloLista.map((entry) => {
      if (entry.formularioVisible !== true) {
        return { dataField: entry.codigo, text: entry.etiquetaDetalle, hidden: true };
      }
      else {
        visibleCols++;
        return { dataField: entry.codigo, text: entry.etiquetaDetalle };
      }
    });
  if (columns === undefined || columns === null || columns?.length === 0)
    columns = [
      { dataField: "key", text: "key", hidden: true },
      { dataField: "action", text: "" },
    ];
  else
    columns = [
      { dataField: "key", text: "key", hidden: true },
      ...columns,
      { dataField: "action", text: "" }
    ];

  function cancelField(entry, index) {
    //let temp = valoresTabla.splice(index, 1);
    let temp = [...valoresTabla];
    var dato = temp[index];
    dato["ACCION_CRUD"] = "D";
    temp[index] = dato;
    setValoresTable(temp);
    setValoresMostrar(getValoresMostrar(temp));
    CallParentCallback(temp);
    setIsHidden(true);
    
  }

 /* function editField(entry, index) {
    setSelectedEdit(entry);
    modalRef.current.setEditItem(entry, index);
    setShow(true);
  }*/

  const saveFieldHandler = (entry, index) => {
    let temp = [...valoresTabla];
    if (selectedEdit === null) {
      temp.push(entry);
    } else {
      temp[index] = entry;
    }
    setValoresTable(temp);
    setValoresMostrar(getValoresMostrar(temp));
    setSelectedEdit(null);
    CallParentCallback(temp);
  };

  const CallParentCallback = (temp) => {
    if (props.onModifyTable) {
      let valoresSection = [];
      temp.forEach((item) => {
        let camposItem = [];
        formatoModeloLista.forEach((entry) => {
          camposItem.push({ codigo: entry.codigo, valor: item[entry.codigo] });
        });
        valoresSection.push({ campos: camposItem });
      });
      props.onModifyTable(valoresSection);
    }
  };

  const actionButtons = (entry, index) => {
    return (
      <Stack direction="horizontal" gap={3}>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={cancelField.bind(this, entry, index)}
          icon={faPencil}
          color={COLORS.alert}
          size="lg"
          style={ isHidden ? {display : 'none'} : '' }
          
        />
        {/* <FontAwesomeIcon
          className="link-cursor"
          onClick={editField.bind(this, entry, index)}
          icon={faPencil}
          color={COLORS.highlight}
          size="lg"
        /> */}
      </Stack>
    );
  };

  function addField() {
    var nextOrder = valoresTabla === null ? 1 : valoresTabla.length + 1;
    setSelectedEdit(null);
    modalRef.current.setEditItem(null, nextOrder);
    setShow(true);
  }

  const valores =
    props.valoresLista !== null &&
      props.valoresLista !== undefined &&
      props.valoresLista.length > 0
      ? props.valoresLista.map((valor, index) => {
        var campos = {};
        valor.campos.forEach((element) => {
          campos[element.codigo] = element.valor;
        });
        return campos;
      })
      : [];

  const getValoresMostrar = (vals) => {
    return vals.map((entry1, index) => {
      return { ...entry1, indexPosition: index }
    })
      .filter((valor) => valor["ACCION_CRUD"] !== "D")
      .map((entry) => {
        var mapaValores = { ...entry };

        if (formatoModeloLista !== null) {
          formatoModeloLista.forEach((entry) => {
            if (entry.tipoCampo === "COMBOBOX") {
              var value = entry.valoresCombobox?.find(
                (x) => x.codigo === mapaValores[entry.codigo]
              );
              if (value !== undefined) {
                if (entry.origenEtiqueta?.trim() === "CODIGO")
                  mapaValores[entry.codigo] = value.codigo;
                else if (entry.origenEtiqueta?.trim() === "ETIQUETA")
                  mapaValores[entry.codigo] = value.descripcion;
                else if (entry.origenEtiqueta?.trim() === "COMPLEMENTO")
                  mapaValores[entry.codigo] = value.complemento;
                else if (entry.origenEtiqueta?.trim() === "CODETIQUETA")
                  mapaValores[entry.codigo] =
                    value.codigo + " - " + value.descripcion;
              } else {
                mapaValores[entry.codigo] = "";
              }
            } else if (entry.tipoDato === "MONEDA") {

              var valorFormateo = "0";
              if (
                mapaValores[entry.codigo] !== undefined &&
                mapaValores[entry.codigo] !== null
              ) {
                valorFormateo = mapaValores[entry.codigo] + "";
              }

              mapaValores[entry.codigo] = formatValue({
                value: valorFormateo,
                groupSeparator: ",",
                decimalSeparator: ".",
                prefix: "$",
                decimalScale: 2,
              });
            } else if (entry.tipoDato === "PORCENTAJE") {

              var valorFormateo = "0";
              if (
                mapaValores[entry.codigo] !== undefined &&
                mapaValores[entry.codigo] !== null
              ) {
                valorFormateo = mapaValores[entry.codigo] + "";
              }

              mapaValores[entry.codigo] = formatValue({
                value: valorFormateo,
                groupSeparator: ",",
                decimalSeparator: ".",
                suffix: "%",
                decimalScale: 2,
              });
            } else if (entry.tipoDato === "FECHA") {
              mapaValores[entry.codigo] = dateCalendarFormatter(mapaValores[entry.codigo]);
            }
          });
        }
        mapaValores["VALOR"] = entry;
        return mapaValores;
      });
  };

  const [valoresTabla, setValoresTable] = useState(valores);
  const [valoresMostrar, setValoresMostrar] = useState(
    getValoresMostrar(valores)
  );

  return (
    <Fragment>
      <Row xs="auto" className="justify-content-end m-3">
        {props.longitudMinimaDetalle > 0 && <Col md={9}>
          <Alert
            style={{
              backgroundColor: COLORS.whiteBone,
              color: COLORS.primaryLight,
              border: "none"
            }}
          >
            <FontAwesomeIcon
              icon={faInfoCircle}
              color={COLORS.primaryLight}
              size="xl"
              className="me-2"
            />
            {/* Ingrese al menos {props.longitudMinimaDetalle} {props.etiquetaDetalle}. */}
          </Alert></Col>}
        {/* <Col><CustomButton
          size=""
          class={classes["btn-custom-inverse"]}
          color={COLORS.primaryLight}
          iconColor={COLORS.primaryLight}
          label="Agregar Nuevo"
          icon="faPlus"
          eventHandler={addField}
        /></Col> */}

      </Row>
      <CustomStaticTable
        columns={columns}
        items={valoresMostrar.map((entry, index) => {
          return {
            ...entry,
            key: index + props.etiquetaDetalle,
            action: actionButtons(entry["VALOR"], entry.indexPosition),
          };
        })}
        page={currentPage}
        sizePerPage={sizePerPage}
        totalSize={total}
        onChangePage={onPageChange}
        static={true}
      />
      {formatoModeloLista !== null && (
        <ModalContextProvider>
          <DynamicModal
            formatoModeloLista={formatoModeloLista}
            ref={modalRef}
            show={show}
            setShow={setShow}
            onSaveField={saveFieldHandler}
            editItem={selectedEdit}
            etiquetaDetalle={props.etiquetaDetalle}
            fieldsParent={props.fieldsParent}
          />
        </ModalContextProvider>
      )}
    </Fragment>
  );
};

export default TableField;
