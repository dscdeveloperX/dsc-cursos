import { Fragment, useEffect, useState } from "react";
import { Form, Col } from "react-bootstrap";
import CurrencyInput from "react-currency-input-field";

import classes from "../css/InputField.module.css";
import { COLORS } from "../../../values/colors";

const CalculatedField = (props) => {
  const [enteredValue, setEnteredValue] = useState(props.value);

  useEffect(() => {
    if (props.value !== enteredValue) {
      setEnteredValue(props.value);
    }
  }, [props.value]);

  var inicial = enteredValue;

  if (inicial !== null && inicial !== undefined && inicial !== "") {
    if (props.field.tipoDato === "FECHA") {
      const [dateValues, timeValues] = inicial.split("T");
      const [year, month, day] = dateValues.split("-");
      inicial = day + "/" + month + "/" + year;
    } else if (props.field.tipoDato === "HORA") {
      const [dateValues, timeValues] = inicial.split("T");
      if (timeValues !== undefined) {
        const [hour, minute, second] = timeValues.split(":");
        inicial = hour + ":" + minute + ":" + second.split(".")[0];
      }
    }
  }

  return (
    <Form.Group as={Col}>
      {props.field.tipoDato === "MONEDA" && (
        <CurrencyInput
          className={classes["bottom-line-input"] + " form-control"}
          disabled={true}
          placeholder={props.label}
          value={inicial}
          defaultValue={0.0}
          decimalScale={2}
          style={{ marginBottom: 0 }}
          prefix="$"
          size="sm"
          decimalSeparator=","
          groupSeparator="."
          allowDecimals={true}
        />
      )}
      {props.field.tipoDato === "PORCENTAJE" && (
        <CurrencyInput
          className={classes["bottom-line-input"] + " form-control"}
          disabled={true}
          placeholder={props.label}
          value={inicial}
          defaultValue={0.0}
          decimalScale={2}
          style={{ marginBottom: 0 }}
          suffix="%"
          size="sm"
          decimalSeparator=","
          groupSeparator="."
          allowDecimals={true}
        />
      )}
      {props.field.tipoDato !== "MONEDA" && props.field.tipoDato !== "PORCENTAJE" && (
        <Form.Control
          className={classes["bottom-line-input"]}
          disabled={true}
          value={inicial}
          type="text"
          placeholder={props.label}
          style={{ marginBottom: 0 }}
          maxLength={props.maxLength}
          size="sm"
        />
      )}
      <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
        {props.required ? (
          <Fragment>
            {props.label}{" "}
            <span
              style={{
                color: "red",
              }}
            >
              *
            </span>
          </Fragment>
        ) : (
          props.label
        )}
      </Form.Label>
    </Form.Group>
  );
};

export default CalculatedField;
