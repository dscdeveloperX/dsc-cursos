import { Fragment } from "react";
import { Form, Col } from "react-bootstrap";

import classes from "../css/InputField.module.css";
import { COLORS } from "../../../values/colors";
import ReactDatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import { registerLocale, setDefaultLocale } from "react-datepicker";
import es from 'date-fns/locale/es';
registerLocale('es', es)

const CustomDatePicker = (props) => {
  var dateformat = props.value ? Date.parse(props.value) : undefined;

  return (
    <Fragment>
      <Form.Group controlId="date" as={Col} className="mb-2">
        {/* <Form.Control
          className={classes["bottom-line-input"]}
          disabled={props.disabled}
          type="date"
          name="date"
          value={
            props.value !== null && props.value.length > 0
              ? props.value.split("T")[0]
              : undefined
          }
          size="sm"
          onChange={(event) => {
            props.eventHandler(event.target.value);
          }}
          placeholder={props.label ? props.label : "Seleccione Fecha"}
          style={{ marginBottom: 0 }}
        /> */}
        <ReactDatePicker
          locale="es"
          style={{ width: "100%" }}
          className={classes["bottom-line-input"] + " form-control-sm"}
          disabled={props.disabled}
          peekNextMonth
          showMonthDropdown
          showYearDropdown
          dropdownMode="select"
          strictParsing
          selected={dateformat}
          onChange={(event) => {
            props.eventHandler(event);
          }}
          dateFormat="dd/MM/yyyy" />
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.required ? (
            <Fragment>
              {(props.label ? props.label : "Seleccione Fecha")}{" "}
              <span
                style={{
                  color: "red",
                }}
              >
                *
              </span>
            </Fragment>
          ) : (
            (props.label ? props.label : "Seleccione Fecha")
          )}
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default CustomDatePicker;
