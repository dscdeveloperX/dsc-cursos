import { useState } from "react";
import DynamicField from "./DynamicField";
import { Row, Container } from "react-bootstrap";
import SubsectionItem from "./SubsectionItem";

const SectionItem = (props) => {
  const [section, setSection] = useState(props.section);

  return (
    <Container>
      {section.campos !== null && (
        <Row>
          {section.campos.map((entry, idx) => {
            return (
              <DynamicField
                field={entry}
                key={entry.codigo + idx}
                modelo={props.modelo}
                sectionIndex={props.sectionIndex}
                subSectionIndex={props.subsectionIndex}
                fieldIndex={idx}
              />
            );
          })}
        </Row>
      )}
      {section.secciones !== null && (
        <Row>
          {section.secciones?.map((entry, idx) => {
            return (
              <SubsectionItem key={entry.nombre + idx}
                subsection={entry}
                modelo={props.modelo}
                sectionIndex={props.sectionIndex}
                subsectionIndex={idx}
              />
              // <Fragment key={entry.nombre + idx}>
              //   <HeaderTitle label={entry.nombre} key={entry.nombre + idx} />
              //   {entry.campos !== null &&
              //     entry.campos.map((entry2, idx2) => {
              //       return (
              //         <DynamicField
              //           field={entry2}
              //           key={entry2.codigo + idx2}
              //           modelo={props.modelo}
              //           sectionIndex={props.sectionIndex}
              //           subSectionIndex={idx}
              //           fieldIndex={idx2}
              //         />
              //       );
              //     })}
              // </Fragment>
            );
          })}
        </Row>
      )}
    </Container>
  );
};

export default SectionItem;
