import { useState, useRef, useContext, useCallback } from "react";
import { Form, Row, Col, Image } from "react-bootstrap";
import AuthContext from "../../store/auth-context";
import CustomButton from "../UI/buttons/CustomButton";
import classes from "./AuthForm.module.css";
import buttonClasses from "../UI/css/SearchBar.module.css";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser, faLock } from "@fortawesome/free-solid-svg-icons";

import { COLORS } from "../../values/colors";
import LoadingSpinner from "../UI/LoadingSpinner";
import ErrorAlert from "../UI/ErrorAlert";
import ip from "ip";

const AuthForm = () => {
  const [isLoading, setIsLoading] = useState(false);
  const userInputRef = useRef();
  const passwordInputRef = useRef();

  const [error, setError] = useState();
  const [showError, setShowError] = useState(false);

  const authCtx = useContext(AuthContext);

  const fetchAppListHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    const enteredUser = userInputRef.current.value;
    const enteredPassword = passwordInputRef.current.value;

    try {
      var ipLocal = ip.address();
      const request = {
        headerRequest: {
          username: "auth",
          stationIp: ipLocal,
          dateTime: new Date().toISOString(),
          pageSize: 1,
          pageRequested: 1,
        },
        bodyRequest: {
          aplicacion: authCtx.REACT_APP_SECURITY_APP_ID,
          usuario: enteredUser,
          credenciales: enteredPassword,
        },
      };

      const response = await fetch(
        authCtx.REACT_APP_SECURITY_BASE_URL + "usuarios/Autenticar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
          },
        }
      ).catch(_ => {
        throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
      });

      const resText = await response.text();
      const data = resText && JSON.parse(resText);
      if (!response.ok) {
        if ([401, 403].includes(response.status)) {
          // throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          const errorMessage = data.headerResponse.returnMessage.split("|");
          throw Error(errorMessage[0]);
        }
        if (data?.headerResponse !== undefined) {
          const errorMessage = data.headerResponse.returnMessage.split("|");
          throw Error(errorMessage[0]);
        } else {
          throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
        }
      }

      if (
        // data.bodyResponse.usuario.codigoEjecutivo !== null &&
        // data.bodyResponse.usuario.zona !== null &&
        data.bodyResponse.usuario.agencia !== null
      ) {
        authCtx.login(
          data.bodyResponse.token,
          data.bodyResponse.usuario.usuario,
          data.bodyResponse.usuario.ultimaSesionIP,
          data.bodyResponse.usuario.agencia,
          data.bodyResponse.usuario.ultimoFechaSesion,
          data.bodyResponse.fechaExpiracion,
          data.bodyResponse.usuario.acceso,
          data.bodyResponse.usuario.rol,
          data.bodyResponse.usuario.codigoEjecutivo,
          data.bodyResponse.usuario.email,
          data.bodyResponse.usuario.cedula,
          data.bodyResponse.usuario.zona
        );
      } else {
        throw Error("El usuario que está intentando utilizar no se encuentra dentro de los oficiales registrados.");
      }

    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }, [authCtx]);

  const submitHandler = (event) => {
    event.preventDefault();

    fetchAppListHandler();
  };

  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );

  return (
    <section className={classes.auth}>
      <div className="centered">
        <Image src="/assets/logo_entrada.png" width={358} fluid />
      </div>
      <div className="d-flex justify-content-center align-items-center">
        <Form className="rounded p-4 p-sm-3" onSubmit={submitHandler}>
          <Form.Group className="mb-3" controlId="formBasicUser">
            <Form.Label></Form.Label>
            <Row className="d-flex justify-content-center align-items-center">
              <Col sm="2">
                <FontAwesomeIcon
                  icon={faUser}
                  color={COLORS.highlight}
                  size="xl"
                />
              </Col>
              <Col sm="10">
                <Form.Control
                  className={classes["bottom-line-input"]}
                  type="text"
                  placeholder="INGRESE USUARIO"
                  required
                  ref={userInputRef}
                />
              </Col>
            </Row>
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Row className="d-flex justify-content-center align-items-center">
              <Col sm="2">
                <FontAwesomeIcon
                  icon={faLock}
                  color={COLORS.highlight}
                  size="xl"
                />
              </Col>
              <Col sm="10">
                <Form.Label></Form.Label>
                <Form.Control
                  className={classes["bottom-line-input"]}
                  type="password"
                  placeholder="INGRESE CONTRASEÑA"
                  required
                  ref={passwordInputRef}
                />
              </Col>
            </Row>
          </Form.Group>
          {showError && errorAlert}
          {!isLoading && (
            <div className="centered">
              <CustomButton
                size="md"
                class={buttonClasses["btn-custom"]}
                label="CONTINUAR"
                icon="faArrowRight"
                eventHandler={submitHandler}
              ></CustomButton>
            </div>
          )}
          {isLoading && loading}
        </Form>
        <div className="footer">
          Banco de Machala © 2022. Todos los derechos reservados.
        </div>
      </div>
    </section>
  );
};

export default AuthForm;
