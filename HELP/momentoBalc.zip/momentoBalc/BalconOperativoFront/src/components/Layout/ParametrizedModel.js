import { Fragment, useState } from "react";
import { Accordion } from "react-bootstrap";
import SectionItem from "../UI/SectionItem";

const ParametrizedModel = (props) => {
  const [model, setModel] = useState(props.model);

  // const onChangeSectionFieldHandler = (value, index) => {
  //   var temp = model;
  //   temp.secciones[index] = value;
  //   setModel(temp);
  //   if (props.parentCallback) {
  //     props.parentCallback(temp);
  //   }
  // };

  const onSelectHeaderToggle = (eventkey, event) => {
    const elementt = document.getElementById(eventkey);
    if (elementt) {
      // 👇 Will scroll smoothly to the top of the next section
      setTimeout(() => {
        elementt.scrollIntoView({
          behavior: "smooth",
          block: "start",
          inline: "nearest",
        });
        window.scrollBy({
          top: -60,
          behavior: 'smooth'
        });
      }, 50);
    }
  }

  return (
    <Accordion className="mb-4" onSelect={onSelectHeaderToggle}>
      {model.secciones &&
        model.secciones?.map((entry, idx) => {
          return (
            <Fragment key={entry.orden + entry.nombre + idx}>
              <Accordion.Item eventKey={entry.orden + entry.nombre + idx} id={entry.orden + entry.nombre + idx}>
                <Accordion.Header>{entry.nombre}</Accordion.Header>
                <Accordion.Body>
                  <SectionItem
                    section={entry}
                    key={entry.orden + entry.nombre + idx}
                    modelo={props.tipo}
                    sectionIndex={idx}
                    subsectionIndex={-1}
                  // parentCallback={(value) => {
                  //   onChangeSectionFieldHandler(value, idx);
                  // }}
                  />
                </Accordion.Body>
              </Accordion.Item>
            </Fragment>
          );
        })}
    </Accordion>
  );
};

export default ParametrizedModel;
