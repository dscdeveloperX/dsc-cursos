import { Card, Form, Row, Col, Alert } from "react-bootstrap";
import { Fragment, useState } from "react";
import { useHistory } from "react-router-dom";
import CustomButton from "../UI/buttons/CustomButton";
import CustomDatePicker from "../UI/fields/CustomDatePicker";
import classes from "../UI/css/SearchBar.module.css";
import { COLORS } from "../../values/colors";

import FormSelect from "../UI/fields/FormSelect";
import FormInput from "../UI/fields/FormInput";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";

const SearchBar = (props) => {
  const [value, setValue] = useState("");
  const [selectedValue, setSelectedValue] = useState(
    props.searchByValues !== undefined && props.searchByValues.length > 0
      ? props.searchByValues[0].value
      : null
  );
  const [selectedState, setSelectedState] = useState(props.searchStateValues !== undefined && props.searchStateValues.length > 0
    ? props.searchStateValues[0].value
    : "");
  const [initDate, setInitDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  let history = useHistory();
  const formSubmissionHandler = (event) => {
    event.preventDefault();
    props.onClick();
  };

  const createButtonHandler = (route) => {
    history.push(route);
  };

  const onChangeSearchByHandler = (event) => {
    setValue(event);
    if (props.filterValue) {
      props.filterValue(event);
    }
  };

  const onChangeSearchByValuesHandler = (event) => {
    setSelectedValue(event);
    if (props.filterBy) {
      props.filterBy(event);
    }
  };

  const onChangeStateHandler = (event) => {
    setSelectedState(event);
    if (props.filterState) {
      props.filterState(event);
    }
  };

  const initDateHandler = (event) => {
    setInitDate(event.target.value);
  };

  const endDateHandler = (event) => {
    setEndDate(event.target.value);
  };

  const fetchHandler = () => {
    props.fetchHandler();
  };

  const datePicker = (
    <Row className="mb-2">
      <CustomDatePicker
        label="Fecha Desde"
        value={initDate}
        eventHandler={initDateHandler}
      />
      <CustomDatePicker
        label="Fecha Hasta"
        value={endDate}
        eventHandler={endDateHandler}
      />
    </Row>
  );

  const statusField = (
    <Row className="mb-2">
      <Form.Group as={Col} className="mb-2" controlId="formBasicCheckbox">
        <FormSelect
          value={selectedState}
          label="Estado"
          parentCallback={onChangeStateHandler}
        >
          {props.searchStateValues !== undefined &&
            props.searchStateValues.length > 0 &&
            props.searchStateValues.map((entry) => {
              return (
                <option key={entry.value} value={entry.value}>
                  {entry.label}
                </option>
              );
            })}
        </FormSelect>
      </Form.Group>
      <Form.Group as={Col} className="mb-2" />
    </Row>
  );

  const SearchByFilterOptions = props.searchByValues;

  const filterByField = (
    <Form.Group as={Col} className="mb-2" controlId="formBasicCheckbox">
      <FormSelect
        value={selectedValue}
        label="Filtrar Por"
        parentCallback={onChangeSearchByValuesHandler}
      >
        {SearchByFilterOptions !== undefined &&
          SearchByFilterOptions.length > 0 &&
          SearchByFilterOptions.map((entry) => {
            return (
              <option key={entry.value} value={entry.value}>
                {entry.label}
              </option>
            );
          })}
      </FormSelect>
    </Form.Group>
  );

  return (
    <Fragment>
      <Alert
        style={{
          backgroundColor: COLORS.whiteBone,
          color: COLORS.primaryLight,
          border: "none",
        }}
      >
        <FontAwesomeIcon
          icon={faInfoCircle}
          color={COLORS.primaryLight}
          size="lg"
          className="me-2"
        />
        Elija el criterio de consulta y haga click en "Buscar"
      </Alert>
      <Card
        className="p-3 mb-2"
        style={{ boxShadow: "0 0 10px 0px " + COLORS.highlight }}
      >
        <Form onSubmit={formSubmissionHandler}>
          <p style={{ color: COLORS.primaryLight, fontWeight: "bold" }}>
            Elija criterios de consulta
          </p>
          <Row className="mb-2">
            {props.filterBy !== undefined && filterByField}
            <Form.Group as={Col} className="mb-2" controlId="formBasicId">
              <FormInput
                value={value}
                label={props.searchBy ? props.searchBy : "Nombre"}
                parentCallback={onChangeSearchByHandler}
              />
            </Form.Group>
          </Row>
          {props.filterState !== undefined && statusField}
          {(props.date ? true : false) && datePicker}
          <Row xs="auto" className="justify-content-end">
            <div>
              {(props.createRoute ? true : false) && (
                <CustomButton
                  size=""
                  class={classes["btn-custom"]}
                  label="AGREGAR"
                  icon="faPlus"
                  eventHandler={
                    props.createRoute
                      ? createButtonHandler.bind(this, props.createRoute)
                      : null
                  }
                ></CustomButton>
              )}
            </div>
            <div>
              <CustomButton
                class={classes["btn-custom-inverse"]}
                color={COLORS.primaryLight}
                iconColor={COLORS.primaryLight}
                label="BUSCAR"
                icon="faMagnifyingGlass"
                eventHandler={fetchHandler}
              ></CustomButton>
            </div>
          </Row>
        </Form>
      </Card>
    </Fragment>
  );
};

export default SearchBar;
