import { Card, Form, Row, Col, Alert } from "react-bootstrap";
import { Fragment, useState } from "react";
import CustomButton from "../UI/buttons/CustomButton";
import classes from "../UI/css/SearchBar.module.css";
import { COLORS } from "../../values/colors";

import SelectCatalogue from "../UI/fields/SelectCatalogue";
import FormInput from "../UI/fields/FormInput";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";

const SearchBarContacts = (props) => {
  const [vatId, setVatId] = useState("");
  const [idType, setIdType] = useState("N");
  const formSubmissionHandler = (event) => {
    event.preventDefault();
    props.onClick();
  };

  const onIdTypeHandler = (event) => {
    setIdType(event);
    props.onChangeIdType(event);
    onChangeVatIdHandler("");
  };

  const onChangeVatIdHandler = (event) => {
    setVatId(event);
    props.onChangeVatId(event);
  };

  const fetchHandler = () => {
    props.fetchHandler(idType, vatId);
  };

  return (
    <Fragment>
      <Alert
        style={{
          backgroundColor: COLORS.whiteBone,
          color: COLORS.primaryLight,
          border: "none",
        }}
      >
        <FontAwesomeIcon
          icon={faInfoCircle}
          color={COLORS.primaryLight}
          size="xl"
          className="me-2"
        />
        Elija el criterio de consulta y haga click en "Buscar"
      </Alert>
      <Card
        className="p-4 mb-4"
        style={{ boxShadow: "0 0 10px 0px " + COLORS.highlight }}
      >
        <Form onSubmit={formSubmissionHandler}>
          <p style={{ color: COLORS.primaryLight, fontWeight: "bold" }}>
            Elija criterios de consulta
          </p>
          <Row className="mb-3">
            <Form.Group as={Col} className="mb-3" controlId="formBasicCheckbox">
              <SelectCatalogue
                selected={idType}
                parentCallback={onIdTypeHandler}
                label="Tipo Identificación"
                catalogo="TIPO_DOCUMENTO"
              />
            </Form.Group>
            <Form.Group as={Col} className="mb-3" controlId="formBasicId">
              <FormInput
                value={vatId}
                label={"Número de Identificación"}
                dataType={
                  idType
                    ? idType === "N"
                      ? "NUMERICO"
                      : idType === "R"
                        ? "NUMERICO"
                        : "ALFANUMERICOSOLO"
                    : "NUMERICO"
                }
                maxLength={
                  idType ? (idType === "N" ? 10 : idType === "R" ? 13 : 20) : 10
                }
                parentCallback={onChangeVatIdHandler}
              />
            </Form.Group>
          </Row>
          <Row xs="auto" className="justify-content-end">
            <div>
              <CustomButton
                class={classes["btn-custom-inverse"]}
                color={COLORS.primaryLight}
                iconColor={COLORS.primaryLight}
                label="BUSCAR"
                icon="faMagnifyingGlass"
                eventHandler={fetchHandler}
              ></CustomButton>
            </div>
          </Row>
        </Form>
      </Card>
    </Fragment>
  );
};

export default SearchBarContacts;
