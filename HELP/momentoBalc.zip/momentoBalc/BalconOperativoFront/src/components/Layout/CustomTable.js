import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory, {
  PaginationProvider,
  PaginationListStandalone,
} from "react-bootstrap-table2-paginator";
import Classes from "./CustomTable.module.css";

const CustomTable = (props) => {
  const selectRow = {
    mode: "checkbox",
    clickToSelect: false,
  };

  /*   const options = {
    // pageStartIndex: 0,
    totalSize: props.totalSize? props.totalSize : 1,
    sizePerPage: props.pageSize ? props.pageSize : 5,
    hideSizePerPage: true,
    hidePageListOnlyOnePage: true,
  }; */

  const handleTableChange = (type, { page, sizePerPage }) => {
    props.onChangePage(page, sizePerPage);
  };

  return (
    <PaginationProvider
      pagination={paginationFactory({
        custom: true,
        page: props.page ? props.page : 1,
        sizePerPage: props.sizePerPage ? props.sizePerPage : 5,
        totalSize: props.totalSize ? props.totalSize : 5,
        //hideSizePerPage: true,
        hidePageListOnlyOnePage: props.hidePage ? true : false,
      })}
    >
      {({ paginationProps, paginationTableProps }) => (
        <div>
          <BootstrapTable
            remote
            classes={`${props.classes} ${Classes.pagination}`}
            keyField={props.columns[0].dataField}
            data={props.items}
            columns={props.columns}
            onTableChange={handleTableChange}
            selectRow={props.selectable ? selectRow : undefined}
            hover
            condensed
            borderless
            noDataIndication={
              <p
                style={{
                  textAlign: "center",
                }}
              >
                No hay datos para mostrar.
              </p>
            }
            {...paginationTableProps}
          />
          <div>
            <PaginationListStandalone {...paginationProps} />
          </div>
        </div>
      )}
    </PaginationProvider>
  );
};

export default CustomTable;
