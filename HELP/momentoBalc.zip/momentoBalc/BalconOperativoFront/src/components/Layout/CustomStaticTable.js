import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";

import Classes from "./CustomTable.module.css";

const CustomStaticTable = (props) => {
  return (
    <BootstrapTable
      keyField={props.columns[0].dataField}
      data={props.items}
      columns={props.columns}
      classes={`${props.classes} ${Classes.pagination}`}
      hover
      condensed
      borderless
      noDataIndication={
        <p
          style={{
            textAlign: "center",
          }}
        >
          No hay datos para mostrar.
        </p>
      }
      pagination={paginationFactory({
        page: props.page,
        sizePerPage: props.sizePerPage,
      })}
    />
  );
};

export default CustomStaticTable;
