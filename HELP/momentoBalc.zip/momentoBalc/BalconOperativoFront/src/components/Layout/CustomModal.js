import { Modal } from "react-bootstrap";
import CustomButton from "../UI/buttons/CustomButton";
import FormInput from "../UI/fields/FormInput";

import classes from "../UI/css/SearchBar.module.css";

const CustomModal = (props) => {
  const {
    show,
    modalTitle,
    handleAction,
    handleClose,
    disable
  } = props;

  return (
    <Modal show={show} onHide={handleClose} centered size={props.size}>
      <Modal.Header closeButton>
        <Modal.Title style={{ fontSize: "1rem" }}>{modalTitle}</Modal.Title>
      </Modal.Header>
      <Modal.Body style={{ fontSize: "0.8rem" }}>
        {/* {modalDescription}
        <FormInput
          value={rejectionReason}
          parentCallback={rejectionReasonHandler}
        /> */}
        {props.children}
      </Modal.Body>
      <Modal.Footer>
        <CustomButton
          size=""
          class={classes["btn-custom-close"]}
          label="Cancelar"
          eventHandler={handleClose}
        />
        <CustomButton
          size=""
          class={classes["btn-custom"]}
          label="Aceptar"
          eventHandler={handleAction}
          disabled = {disable}
        />
      </Modal.Footer>
    </Modal>
  );
};
export default CustomModal;
