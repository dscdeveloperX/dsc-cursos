import { Fragment, useState, useImperativeHandle, forwardRef } from "react";
import { Form, Row, Col, Card, Alert } from "react-bootstrap";

import classes from "../UI/css/SearchBar.module.css";
import { COLORS } from "../../values/colors";
import FormInput from "../UI/fields/FormInput";
import CustomButton from "../UI/buttons/CustomButton";
import SelectCatalogue from "../UI/fields/SelectCatalogue";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";
import SelectProduct from "../UI/fields/SelectProduct";

const ParametrizationBarAP = (props, ref) => {
  const [disableFields, setDisableFields] = useState(false);

  const [personType, setPersonType] = useState("N");
  const [idType, setIdType] = useState("N");
  const [idNumber, setIdNumber] = useState("");
  const [clientType, setClientType] = useState("01");
  const [selectedProduct, setSelectedProduct] = useState();

  const onChangeIdNumberHandler = (event) => {
    setIdNumber(event);
  };

  const formSubmissionHandler = () => { };

  useImperativeHandle(
    ref,
    () => ({
      clear: () => clearSearchData(),
    }),
    []
  );

  const clearSearchData = () => {
    setPersonType("N");
    setIdType("N");
    setIdNumber("");
    setClientType("01");
    setSelectedProduct(0);
  }

  const fetchHandler = () => {
    props.fetchHandler({
      tipoPersona: personType,
      tipoIdentificacion: idType,
      identificacion: idNumber,
      tipoCliente: clientType,
      producto: selectedProduct,
    });
  };

  const content = (
    <Fragment>
      {/* <Alert
        style={{
          backgroundColor: COLORS.whiteBone,
          color: COLORS.primaryLight,
          border: "none",
        }}
      >
        <FontAwesomeIcon
          icon={faInfoCircle}
          color={COLORS.primaryLight}
          size="xl"
          className="me-2"
        />
        Elija el criterio de consulta y haga click en "Buscar"
      </Alert> */}
      <Card
        className="p-3 mb-2"
        style={{ boxShadow: "0 0 10px 0px " + COLORS.highlight }}
      >
        <Form onSubmit={formSubmissionHandler}>
          <p style={{ color: COLORS.primaryLight, fontWeight: "bold" }}>
            Elija criterios de consulta
          </p>
          <Row className="mb-2">
            <Form.Group as={Col} className="mb-2" controlId="formBasicId">
              <SelectCatalogue
                selected={personType}
                disabled={disableFields}
                label="Tipo Persona"
                catalogo="CLASE_PERSONA"
                parentCallback={(e) => {
                  setPersonType(e);
                  if (e === "N") {
                    setIdType("N");
                  } else if (e === "J") {
                    setIdType("R");
                  }
                  setClientType("01");
                  setIdNumber("");
                }}
              />
            </Form.Group>
            <Form.Group as={Col} className="mb-2" controlId="formBasicId">
              <SelectCatalogue
                selected={clientType}
                disabled={personType === "J" || personType === "N"}
                label="Tipo Cliente"
                catalogo="TIPO_CLIENTE"
                includeOnly={["01", "02", "03", "06"]}
                parentCallback={setClientType}
              />
            </Form.Group>
          </Row>
          <Row className="mb-2">
            <Form.Group as={Col} className="mb-2" controlId="formBasicId">
              <SelectCatalogue
                selected={idType}
                disabled={personType === "J" || personType === 'N'}
                label="Tipo Identificación"
                catalogo="TIPO_DOCUMENTO"
                parentCallback={(e) => {
                  setIdType(e);
                  setIdNumber("");
                }}
              />
            </Form.Group>
            <Form.Group as={Col} className="mb-2" controlId="formBasicId">
              <FormInput
                value={idNumber}
                label="Número de Identificación"
                dataType={
                  idType
                    ? idType === "N"
                      ? "NUMERICO"
                      : idType === "R"
                      ? "NUMERICO"
                      : "ALFANUMERICOSOLO"
                    : "NUMERICO"
                }
                maxLength={
                  idType ? (idType === "N" ? 10 : idType === "R" ? 13 : 20) : 10
                }
                parentCallback={onChangeIdNumberHandler}
              />
            </Form.Group>
          </Row>
          <Row className="mb-2">
            <Form.Group as={Col} className="mb-2" controlId="formBasicId">
              <SelectProduct
                allowNone={true}
                selected={selectedProduct}
                disabled={disableFields}
                label="Servicios"
                tipo="PRODUCTO"
                parentCallback={setSelectedProduct}
              />
            </Form.Group>
          </Row>
          <Row xs="auto" className="justify-content-end">
            <div>
              <CustomButton
                class={classes["btn-custom-inverse"]}
                color={COLORS.primaryLight}
                iconColor={COLORS.primaryLight}
                label="BUSCAR"
                icon="faMagnifyingGlass"
                eventHandler={fetchHandler}
              ></CustomButton>
            </div>
          </Row>
        </Form>
      </Card>
    </Fragment>
  );

  return <Fragment>{content}</Fragment>;
};

export default forwardRef(ParametrizationBarAP);
