import { forwardRef, useContext, useImperativeHandle, useState } from "react";
import { Fragment } from "react";
import { Row } from "react-bootstrap";
import { checkEditable, checkRequired, checkVisible } from "../../store/field-actions";
import ModalContext from "../../store/modal-context";
import CustomModal from "../Layout/CustomModal";
import DynamicModalField from "../UI/fields/DynamicModalField";
import store from "../../store/index";
import ErrorAlert from "../UI/ErrorAlert";
const DynamicModal = (props, ref) => {
  const modalCtx = useContext(ModalContext);

  const [error, setError] = useState(null);
  const [showError, setShowError] = useState(false);

  const formatoModeloLista = props.formatoModeloLista;

  const [fields, setFields] = useState({});
  const [selectedIndex, setSelectedIndex] = useState(-1);

  var initialValue = {};

  if (formatoModeloLista !== null) {
    formatoModeloLista.forEach((entry) => {
      if (entry.codigo === "CODIGO_REFERENCIA") {
        initialValue[entry.codigo] = "0";
      } else if (entry.codigo === "ACCION_CRUD") {
        initialValue[entry.codigo] = "C";
      } else {
        initialValue[entry.codigo] = "";
      }
    });
  }

  const handleClose = () => {
    props.setShow(false);
    setError(null);
    setShowError(false);
  };

  const setModalItem = (editItem, index) => {
    var editInit = {};
    if (editItem === null) {
      editInit = { ...initialValue };
    } else {
      editInit = { ...editItem };
    }

    let fieldsParent = store.getState().field.fields;
    var edit = modalCtx.setModalFields(formatoModeloLista, editInit, fieldsParent);
    setFields(edit);
    setSelectedIndex(index);
  };

  useImperativeHandle(
    ref,
    () => ({
      setEditItem: (editItem, index) => setModalItem(editItem, index),
    }),
    []
  );

  const fieldChangeHandler = (value, codigo, edit) => {
    //var temp = { ...fields };
    //temp[codigo] = value;
    setFields(edit);
  };

  const fieldChangeValuesHandler = (values, edit) => {
    /*var temp = { ...fields };
    if (values != null) {
      for (const [key, value] of Object.entries(fields)) {
        temp[key] = value;
      }
    }*/
    setFields(edit);
  };

  const saveField = () => {
    var existsEmpty = false;
    let checkRes = [];
    for (const [key, value] of Object.entries(fields)) {
      if (value === undefined || value === null || value === "") {
        var requerido = checkRequired(modalCtx.fields, key);
        var editable = checkEditable(modalCtx.fields, key);
        var visible = checkVisible(modalCtx.fields, key);
        if (requerido === true && editable === true && visible == true) {
          existsEmpty = true;
          var errorDetalle = modalCtx.fields[key].field.etiquetaDetalle;
          checkRes.push(errorDetalle);
        }
      }
    }
    if (!existsEmpty) {
      props.onSaveField(fields, selectedIndex);
      handleClose();
    } else {
      let msgString = checkRes.join(", \n");
      setError("Por favor revise los campos: ||" + msgString);
      setShowError(true);
    }
  };

  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const form =
    formatoModeloLista !== null ? (
      <Row>
        {showError && errorAlert}
        {formatoModeloLista.map((entry, idx) => {
          if (entry.codigo === "CODIGO_REFERENCIA") {
            return <Fragment key={idx}></Fragment>;
          } else if (entry.codigo === "ACCION_CRUD") {
            return <Fragment key={idx}></Fragment>;
          } else {
            return (
              <DynamicModalField
                field={entry}
                key={props.etiquetaDetalle + entry.etiqueta + idx}
                parentCallback={(value, edit) => {
                  fieldChangeHandler(value, entry.codigo, edit);
                }}
                onGetApiValues={fieldChangeValuesHandler}
                fieldsValues={fields}
              />
            );
          }
        })}
      </Row>
    ) : (
      <Fragment></Fragment>
    );

  return (
    <Fragment>
      <CustomModal
        show={props.show}
        modalTitle={"Agregar " + props.etiquetaDetalle}
        handleAction={saveField}
        handleClose={handleClose}
        size="lg"
      >
        {form}
      </CustomModal>
    </Fragment>
  );
};

export default forwardRef(DynamicModal);
