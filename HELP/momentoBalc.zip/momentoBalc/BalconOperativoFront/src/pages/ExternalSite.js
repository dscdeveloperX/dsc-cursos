import Iframe from 'react-iframe';
import React from "react";
import { useContext } from "react";
import { useParams } from 'react-router-dom';
import AuthContext from "../store/auth-context";

const ExternalSite = () => {

    const authCtx = useContext(AuthContext);

    let { externalUrl } = useParams();

    React.useEffect(() => {
        window.addEventListener(
        "message",
        listener
        );
        return () => {
            // remove the event listener
            window.removeEventListener("message", listener);
        };
      }, []);

    const listener = (event) => {
        if (!event.data.type) return;
        if (event.data.type !== "requestUserInfo") return;

        const message = {
            type: "responseUserInfo",
            authData : {
                token: authCtx.token,
                ip: authCtx.ip,
                user: authCtx.user,
                role: authCtx.role,
                executiveCode: authCtx.executiveCode,
                vatId: authCtx.vatId,
                area: authCtx.area,
                email: authCtx.email,
                agencyCode: authCtx.agencyCode,
                expirationTime: authCtx.expirationTime,
                lastLoginDate: authCtx.lastLoginDate
            }            
        }

        event.source.postMessage(message, event.origin);
    };
    
    return (
        <Iframe url={decodeURIComponent(externalUrl)} className="externalSiteIframe"
            display="block"
            position="relative" />
    );
}

export default ExternalSite;