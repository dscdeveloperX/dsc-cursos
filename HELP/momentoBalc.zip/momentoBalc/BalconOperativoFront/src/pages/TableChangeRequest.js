import { Fragment, useCallback, useEffect, useState, useContext } from "react";
import AuthContext from "../store/auth-context";
import { Container, Stack } from "react-bootstrap";

import { COLORS } from "../values/colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck, faX, faEye } from "@fortawesome/free-solid-svg-icons";

import SearchBar from "../components/Layout/SearchBar";
import CustomTable from "../components/Layout/CustomTable";
import ErrorAlert from "../components/UI/ErrorAlert";
import LoadingSpinner from "../components/UI/LoadingSpinner";

import {
  changeRequest,
  acceptChangeRequest,
  rejectChangeRequest,
} from "../store/change-request-actions";
import { dateFormatter } from "../store/utils-actions";
import CustomModal from "../components/Layout/CustomModal";
import ChangeRequestModalDetail from "./ChangeRequestModalDetail";
import FormInput from "../components/UI/fields/FormInput";
import SuccessAlert from "../components/UI/SuccessAlert";

const TableChangeRequest = () => {
  const [changeRequestList, setChangeRequestList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showError, setShowError] = useState(false);

  const [status, setStatus] = useState("PENDIENTE");
  const [orderBy, setOrderBy] = useState("");
  const [filterBy, setFilterBy] = useState("");
  const [filterValue, setFilterValue] = useState("");
  const [functionality, setFunctionality] = useState("");

  const [currentPage, setCurrentPage] = useState(1);
  const [sizePerPage, setSizePerPage] = useState(5);
  const [total, setTotal] = useState(0);

  const authCtx = useContext(AuthContext);

  const { user, ip, token, REACT_APP_BASE_URL: url, agencyCode } = authCtx;

  const [show, setShow] = useState(false);
  const [modalFormShow, setModalFormShow] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const modalTitle = "Rechazo de Solicitud";
  const modalDescription = "Ingrese Razón de Rechazo de solicitud";

  const [showMessage, setShowMessage] = useState(false);
  const [message, setMessage] = useState("");

  const fetchChangeRequestListHandler = useCallback(
    
    changeRequest.bind({
      params: {
        status: status,
        orderBy: orderBy,
        filterBy: filterBy,
        filterValue: filterValue,
        functionality: functionality,
        sizePerPage: sizePerPage,
        currentPage: currentPage, 
        agenciaSolicitud: agencyCode
      },
      user,
      ip,
      token,
      url,
      setIsLoading,
      setError,
      setShowError,
      setChangeRequestList,
      setTotal
    }),
    [changeRequest, currentPage, sizePerPage]
  );
  /*console.log("fetchChangeRequestListHandler " + agencyCode);*/
  useEffect(() => {
    fetchChangeRequestListHandler({
      params: {
        status: status,
        orderBy: orderBy,
        filterBy: filterBy,
        filterValue: filterValue,
        functionality: functionality,
        sizePerPage: sizePerPage,
        currentPage: currentPage,
        agenciaSolicitud: agencyCode,
      },
      user,
      ip,
      token,
      url,
      setIsLoading,
      setError,
      setShowError,
      setChangeRequestList,
      setTotal
    });
  }, [fetchChangeRequestListHandler]);

  const searchByValues = [
    { label: "Acción", value: "action" },
    { label: "Identificación", value: "vatid" },
    { label: "Descripción", value: "description" },
  ];

  const searchStateValues = [
    { label: "Todos", value: "" },
    { label: "Pendiente", value: "PENDIENTE" }
  ];

  const searchBar = (
    <SearchBar
      filterBy={setFilterBy}
      filterValue={setFilterValue}
      filterState={setStatus}
      fetchHandler={() => {
        fetchChangeRequestListHandler({
          params: {
            status: status,
            orderBy: orderBy,
            filterBy: filterBy,
            filterValue: filterValue,
            functionality: functionality,
            sizePerPage: sizePerPage,
            currentPage: currentPage,
            agenciaSolicitud: agencyCode,
          },
          user,
          ip,
          token,
          url,
          setIsLoading,
          setError,
          setShowError,
          setChangeRequestList,
          setTotal
        });
      }}
      searchStateValues={searchStateValues}
      searchByValues={searchByValues}
      searchBy="Filtro de Búsqueda"
    />
  );

  const columns = [
    { dataField: "key", text: "id", hidden: true },
    { dataField: "reqUsername", text: "Usuario Solicitud" },
    { dataField: "reqDate", text: "Fecha Solicitud" },
    { dataField: "functionality", text: "Funcionalidad" },
    { dataField: "roleType", text: "Tipo Rol" },
    { dataField: "changeId", text: "Id. Cambio" },
    { dataField: "changeDesc", text: "Desc. Cambio" },
    { dataField: "actionDesc", text: "Acción" },
    { dataField: "action", text: "" },
  ];

  const onPageChange = (page, sizePerPage) => {
    setCurrentPage(page);
    setSizePerPage(sizePerPage);
  };

  const actionButtons = (entry, id) => {
    return (
      <Stack direction="horizontal" gap={3}>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={selectRequest.bind(this, entry)}
          icon={faX}
          color={COLORS.alert}
          size="lg"
        />
        <FontAwesomeIcon
          className="link-cursor"
          onClick={acceptRequest.bind(this, entry)}
          icon={faCheck}
          color={COLORS.highlight}
          size="lg"
        />
        <FontAwesomeIcon
          className="link-cursor"
          onClick={viewRequestDetail.bind(this, entry)}
          icon={faEye}
          color={COLORS.highlight}
          size="lg"
        />
      </Stack>
    );
  };

  function selectRequest(entry) {
    setSelectedRequest(entry);
    setShow(true);
    setRejectionReason("");
  }

  function acceptRequest(entry) {
    setSelectedRequest(entry);
    acceptChangeRequest({
      params: {
        id: entry.idCambio,
        sizePerPage: sizePerPage,
        currentPage: currentPage, 
      },
      user,
      ip,
      token,
      url,
      setIsLoading,
      setError,
      setShowError,
      setMessage,
      showSuccessMessage
    }).then((res) => {
      if (res === 0) {
        fetchChangeRequestListHandler({
          params: {
            status: status,
            orderBy: orderBy,
            filterBy: filterBy,
            filterValue: filterValue,
            functionality: functionality,
            sizePerPage: sizePerPage,
            currentPage: currentPage,
            agenciaSolicitud: agencyCode,
          },
          user,
          ip,
          token,
          url,
          setIsLoading,
          setError,
          setShowError,
          setChangeRequestList,
          setTotal
        });
      }
      setIsLoading(false);
    });
  }

  function viewRequestDetail(entry) {
    setSelectedRequest(entry);
    setModalFormShow(true);
  }

  function handleClose() {
    setShow(false);
    setSelectedRequest(null);
  }

  function showSuccessMessage() {
    setShowMessage(true);
    setTimeout(HideSuccessMessage, 5000);
  }

  function HideSuccessMessage() {
    setMessage("");
    setShowMessage(false);
  }

  function handleAction() {
    if (rejectionReason !== null && rejectionReason.length > 0) {
      //Rechazar
      rejectChangeRequest({
        params: {
          id: selectedRequest.idCambio,
          razon: rejectionReason,
          sizePerPage: sizePerPage,
          currentPage: currentPage,
        },
        user,
        ip,
        token,
        url,
        setIsLoading,
        setError,
        setShowError,
        setMessage,
        showSuccessMessage
      }).then(() => {
        fetchChangeRequestListHandler({
          params: {
            status: status,
            orderBy: orderBy,
            filterBy: filterBy,
            filterValue: filterValue,
            functionality: functionality,
            sizePerPage: sizePerPage,
            currentPage: currentPage,
            agenciaSolicitud: agencyCode,
          },
          user,
          ip,
          token,
          url,
          setIsLoading,
          setError,
          setShowError,
          setChangeRequestList,
          setTotal
        });
      });
      setShow(false);
      setRejectionReason("");
    }

  }

  let parsedChangeRequestList = [];

  changeRequestList.map((entry) => {
    return parsedChangeRequestList.push({
      key: entry.idCambio,
      reqUsername: entry.usuarioSolicitante,
      appUsername: entry.usuarioAprobador,
      reqDate: dateFormatter(entry.fechaSolicitud),
      appDate: dateFormatter(entry.fechaAprobacion),
      status: entry.estado,
      actionDesc: entry.accion,
      functionality: entry.funcionalidad,
      roleType: entry.tipoRol,
      funcId: entry.identificadorFuncionalidad,
      funcDesc: entry.descripcionFuncionalidad,
      changeId: entry.identificadorCambio,
      changeDesc: entry.descripcionCambio,
      rejectionReason: entry.razonRechazo,
      action: actionButtons(entry, entry.idCambio),
    });
  });

  const table = (
    <CustomTable
      columns={columns}
      items={parsedChangeRequestList ? parsedChangeRequestList : []}
      page={currentPage}
      sizePerPage={sizePerPage}
      totalSize={total}
      onChangePage={onPageChange}
    />
  );

  const modalConfirmation = (
    <CustomModal
      show={show}
      modalTitle={modalTitle}
      handleAction={handleAction}
      handleClose={handleClose}
    >
      <Fragment>
        {modalDescription}
        <FormInput
          value={rejectionReason}
          parentCallback={setRejectionReason}
          isValid={rejectionReason !== null && rejectionReason !== ""}
        />
      </Fragment>
    </CustomModal>
  );

  const modalDetail = (
    <ChangeRequestModalDetail
      value={selectedRequest}
      ctx={authCtx}
      show={modalFormShow}
      modalTitle={"Cambios"}
      modalDescription={"modalDescription"}
      handleClose={() => {
        setModalFormShow(!modalFormShow);
      }}
    />
  );

  const messageAlert = <SuccessAlert text={message} />;

  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );

  return (
    <Fragment>
      <Container fluid>
        {showMessage && messageAlert}
        {showError && errorAlert}
        {searchBar}
        {modalConfirmation}
        {modalDetail}
        {!isLoading && table}
        {isLoading && loading}
      </Container>
    </Fragment>
  );
};

export default TableChangeRequest;
