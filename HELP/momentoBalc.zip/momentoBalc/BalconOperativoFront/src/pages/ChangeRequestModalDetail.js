import { useState, useEffect, Fragment } from "react";
import { Modal, Row, Col } from "react-bootstrap";
import CustomButton from "../components/UI/buttons/CustomButton";

import classes from "../components/UI/css/SearchBar.module.css";

import LoadingSpinner from "../components/UI/LoadingSpinner";

import { fetchRequestById } from "../store/change-request-actions";
import CustomStaticTable from "../components/Layout/CustomStaticTable";
import { dateFormatter } from "../store/utils-actions";
import { COLORS } from "../values/colors";

const ChangeRequestModalDetail = (props) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [sizePerPage, setSizePerPage] = useState(5);
  const [total, setTotal] = useState(5);
  const [error, setError] = useState(null);
  const [showError, setShowError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [request, setRequest] = useState(null);
  const [requestDetailList, setRequestDetailList] = useState([]);

  let parsedInfo = [];

  const { value, show, modalTitle, handleClose, ctx } = props;

  const { user, ip, token, REACT_APP_BASE_URL: url } = ctx;

  useEffect(() => {
    if (value && value.idCambio !== 0 && show) {
      fetchData();
    }
  }, [value]);

  const fetchData = () => {
    const params = {
      params: {
        id: value ? value.idCambio : 0,
        sizePerPage: sizePerPage,
        currentPage: currentPage,
      },
      user,
      ip,
      token,
      url,
      setIsLoading,
      setError,
      setShowError,
      setRequestDetailList,
      setRequest,
      setTotal,
    };
    fetchRequestById(params).then(() => {
      setIsLoading(false);
    });
  };

  const onPageChange = (page, sizePerPage) => {
    setCurrentPage(page);
    setSizePerPage(sizePerPage);
  };

  requestDetailList?.detalles?.map((entry, index) => {
    if (entry.campo.endsWith('*')){
      return parsedInfo.push({
        key: index,
        field: entry.campo,
        oldValue: entry.valorAnterior,
        newValue: entry.valorDespues,
      });
    }else{
      return;
    }
  });

  const formHeader = (
    <Fragment>
      <Row>
        <Col>
          <p>
            <span>Fecha Solicitud: </span> {dateFormatter(requestDetailList?.fechaSolicitud)}
          </p>
        </Col>
        <Col>
          {/* <p>
            <span>Fecha Aprobación: </span> {dateFormatter(requestDetailList?.fechaAprobacion)}
          </p> */}
        </Col>
      </Row>
      <Row>
        <Col>
          <p>
            <span>Usuario Solicitante: </span>{" "}
            {requestDetailList?.usuarioSolicitante}
          </p>
        </Col>
        <Col>
          <p>
            <span>Usuario Aprobador: </span>{" "}
            <span style={{ color: COLORS.primaryLight }}>{user}</span>
          </p>
        </Col>
      </Row>
      <Row>
        <Col>
          <p>
            <span>Acción: </span> {requestDetailList?.accion}
          </p>
        </Col>
        <Col>
          <p>
            <span>Funcionalidad: </span> {requestDetailList?.funcionalidad}
          </p>
        </Col>
      </Row>
      <Row>
        <Col>
          <p>
            <span>Estado: </span> {requestDetailList?.estado}
          </p>
        </Col>
      </Row>
    </Fragment>
  );

  const columns = [
    { dataField: "key", text: "id", hidden: true },
    { dataField: "field", text: "Campo" },
    { dataField: "oldValue", text: "Valor Anterior" },
    { dataField: "newValue", text: "Valor Actual" },
  ];

  const changeRequestTable = (
    <CustomStaticTable
      columns={columns}
      items={parsedInfo}
      page={currentPage}
      sizePerPage={sizePerPage}
      totalSize={total}
      onChangePage={onPageChange}
      static={true}
    />
  );

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );

  return (
    <Modal show={show} onHide={handleClose} centered size="lg">
      <Modal.Header closeButton>
        <Modal.Title style={{ fontSize: "1rem" }}>{modalTitle}</Modal.Title>
      </Modal.Header>
      <Modal.Body style={{ fontSize: "0.8rem" }}>
        {!isLoading && formHeader}
        {!isLoading && changeRequestTable}
        {isLoading && loading}
      </Modal.Body>
      <Modal.Footer>
        <CustomButton
          size=""
          class={classes["btn-custom-close"]}
          label="Cerrar"
          eventHandler={handleClose}
        />
      </Modal.Footer>
    </Modal>
  );
};

export default ChangeRequestModalDetail;
