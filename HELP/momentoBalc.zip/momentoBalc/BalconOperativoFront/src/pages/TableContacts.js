import { Fragment, useCallback, useContext, useEffect, useState } from "react";
import { Container, Stack, Modal, Row, Col, Card } from "react-bootstrap";
import CustomModal from "../components/Layout/CustomModal";
import CustomButton from "../components/UI/buttons/CustomButton";
import SearchBarContacts from "../components/Layout/SearchBarContacts";
import ErrorAlert from "../components/UI/ErrorAlert";
import LoadingSpinner from "../components/UI/LoadingSpinner";
import AuthContext from "../store/auth-context";
import classes from "../components/UI/css/SearchBar.module.css";
import SelectCatalogue from "../components/UI/fields/SelectCatalogue";
import { formatValue, CurrencyInput } from "react-currency-input-field";
import { COLORS } from "../values/colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faTrashCan } from "@fortawesome/free-solid-svg-icons";

import {
  contactsRequest,
  contactsEditRequest,
} from "../store/contacts-request-actions";
import { checkVatId } from "../store/field-actions";
import FormInput from "../components/UI/fields/FormInput";
import CustomStaticTable from "../components/Layout/CustomStaticTable";
import SuccessAlert from "../components/UI/SuccessAlert";

const TableContacts = () => {
  const [tableContactsList, setTableContactsList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showError, setShowError] = useState(false);

  const [idType, setIdType] = useState("N");
  const [vatId, setVatId] = useState("");

  const [clientTypeId, setClientTypeId] = useState("");
  const [clientVatId, setClientVatId] = useState("");
  const [clientName, setClientName] = useState("");

  const [showRes, setShowRes] = useState(false);
  //selected Contact info
  const [cVatId, setCVatId] = useState("");
  const [cIdType, setCIdType] = useState("N");
  const [cMobile, setCMobile] = useState("");
  const [cEmail, setCEmail] = useState("");
  const [cName, setCName] = useState("");
  const [cSeqNumber, setCSeqNumber] = useState("0");
  const [cOfficeDir, setCOfficeDir] = useState("");
  const [cHomeDir, setCHomeDir] = useState("");
  const [cWorkLongevity, setCWorkLongevity] = useState("");
  const [cMonthlyIncome, setCMonthlyIncome] = useState(0);
  const [cMonthlyExpense, setCMonthlyExpense] = useState(0);

  const [vatIdIsValid, setVatIdIsValid] = useState(true);
  const [emailIsValid, setEmailIsValid] = useState(true);

  const [currentPage, setCurrentPage] = useState(1);
  const [sizePerPage, setSizePerPage] = useState(5);
  const [total, setTotal] = useState(0);

  const authCtx = useContext(AuthContext);

  const { user, ip, token, REACT_APP_BASE_URL: url } = authCtx;

  const [showMessage, setShowMessage] = useState(false);
  const [message, setMessage] = useState("");

  const [show, setShow] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [selectedContactIndex, setSelectedContactIndex] = useState(null);
  const [modalFormShow, setModalFormShow] = useState(false);

  const fetchTableContactsHandler = useCallback(
    contactsRequest.bind({
      params: {
        idType: idType,
        vatId: vatId,
        sizePerPage: sizePerPage,
        currentPage: currentPage,
      },
      user,
      ip,
      token,
      url,
      setIsLoading,
      setError,
      setShowError,
      setTableContactsList,
      setClientTypeId,
      setClientVatId,
      setClientName,
      setShowRes
    }),
    [contactsRequest]
  );

  const apiCall = (idType, vatId) => {
    fetchTableContactsHandler({
      params: {
        idType: idType,
        vatId: vatId,
        sizePerPage: sizePerPage,
        currentPage: currentPage,
      },
      user,
      ip,
      token,
      url,
      setIsLoading,
      setError,
      setShowError,
      setTableContactsList,
      setClientTypeId,
      setClientVatId,
      setClientName,
      setShowRes
    });
  };

  const searchBar = (
    <SearchBarContacts
      onChangeIdType={setIdType}
      onChangeVatId={setVatId}
      params={{
        idType: idType,
        vatId: vatId,
        sizePerPage: sizePerPage,
        currentPage: currentPage,
      }}
      fetchHandler={apiCall}
    />
  );

  const columns = [
    { dataField: "key", text: "id", hidden: true },
    { dataField: "idType", text: "Tipo Id." },
    { dataField: "vatId", text: "Identificación" },
    { dataField: "name", text: "Nombre" },
    { dataField: "mobile", text: "Celular" },
    { dataField: "email", text: "Correo Electrónico" },
    { dataField: "officeDir", text: "Dir. Ofi." },
    { dataField: "homeDir", text: "Dir. Dom." },
    { dataField: "workLongevity", text: "Tiempo" },
    { dataField: "monthlyIncome", text: "Ingresos M." },
    { dataField: "monthlyExpense", text: "Egresos M." },
    { dataField: "action", text: "" },
  ];

  const onPageChange = (page, sizePerPage) => {
    setCurrentPage(page);
    setSizePerPage(sizePerPage);
  };

  const actionButtons = (entry, id) => {
    return (
      <Stack direction="horizontal" gap={3}>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={selectContact.bind(this, entry, id)}
          icon={faTrashCan}
          color={COLORS.alert}
          size="lg"
        />
        <FontAwesomeIcon
          className="link-cursor"
          onClick={viewContactDetail.bind(this, entry, id)}
          icon={faPencil}
          color={COLORS.highlight}
          size="lg"
        />
      </Stack>
    );
  };

  function selectContact(entry, id) {
    setSelectedContact(entry);
    setSelectedContactIndex(id);
    setShow(true);
  }

  function viewContactDetail(entry, index) {
    setSelectedContact(entry);
    setSelectedContactIndex(index);
    setCVatId(entry?.numero_Identidad);
    setCIdType(entry?.tipo_Identidad);
    setCMobile(entry?.celular);
    setCEmail(entry?.correo_Electronico);
    setCName(entry?.nombre);
    setCOfficeDir(entry?.direccion_Oficina);
    setCHomeDir(entry?.direccion_Domicilio);
    setCWorkLongevity(entry?.tiempo_Actual_Trabajo);
    setCMonthlyIncome(entry?.ingresos_Mensuales);
    setCMonthlyExpense(entry?.egresos_Mensuales);
    setCSeqNumber(entry?.numeroSecuencia);
    setModalFormShow(true);
  }

  function markDeleteContact(index) {
    var updatedList = [...tableContactsList];
    updatedList[index].accionCRUD = "D";
    setTableContactsList(updatedList);
  }

  function handleClose() {
    setShow(false);
    setSelectedContact(null);
  }

  function handleAction() {
    markDeleteContact(selectedContactIndex);
    setShow(false);
  }

  function handleEditClose() {
    setModalFormShow(false);
    setSelectedContact(null);
  }

  function handleEditAction() {

    if (cMobile !== "" && cEmail !== "" && cHomeDir !== "" && cOfficeDir !== "" && cMonthlyExpense !== ""
      && cMonthlyIncome !== "" && cName !== "" && cVatId !== "" && cWorkLongevity !== "" && cIdType !== "") {
      //setear lista de contactos con cambios?
      var tempList = [...tableContactsList];
      var params = {
        accionCRUD: selectedContact?.accionCRUD,
        celular: cMobile,
        correo_Electronico: cEmail,
        direccion_Domicilio: cHomeDir,
        direccion_Oficina: cOfficeDir,
        egresos_Mensuales: cMonthlyExpense,
        ingresos_Mensuales: cMonthlyIncome,
        nombre: cName,
        numeroSecuencia: cSeqNumber,
        numero_Identidad: cVatId,
        tiempo_Actual_Trabajo: cWorkLongevity,
        tipo_Identidad: cIdType,
      };
      if (
        selectedContact?.accionCRUD === undefined ||
        selectedContact?.accionCRUD === null
      ) {
        params.accionCRUD = "C";
        params.numeroSecuencia = "0";
      }
      if (selectedContactIndex !== null && selectedContactIndex !== undefined) {
        tempList[selectedContactIndex] = params;
      } else {
        tempList.push(params);
      }
      setTableContactsList(tempList);
      setSelectedContactIndex(null);
      setModalFormShow(false);
    }
  }

  const addContact = () => {
    setSelectedContact(null);
    setCVatId("");
    setCIdType("N");
    setCMobile("");
    setCEmail("");
    setCName("");
    setCOfficeDir("");
    setCHomeDir("");
    setCSeqNumber("0");
    setCWorkLongevity("");
    setCMonthlyIncome(0);
    setCMonthlyExpense(0);
    setModalFormShow(true);
  };

  const saveContactsEditionHandler = () => {
    const params = {
      clientTypeId,
      clientVatId,
      clientName,
      tableContactsList,
      sizePerPage,
      currentPage,
    };
    contactsEditRequest({
      params,
      user,
      ip,
      token,
      url,
      setIsLoading,
      setError,
      setShowError,
      setMessage,
      showSuccessMessage,
      setVatId,
      setSelectedContact,
      setSelectedContactIndex,
      setShowRes
    }).then(function () {
      setTableContactsList([]);
      window.scrollTo(0, 0);
    });
  };

  let parsedContactsList = [];

  parsedContactsList = tableContactsList
    ?.map((entry, index) => {

      var income = "0";
      if (
        entry.ingresos_Mensuales !== undefined &&
        entry.ingresos_Mensuales !== null
      ) {
        income = entry.ingresos_Mensuales + "";
      }

      var expense = "0";
      if (
        entry.egresos_Mensuales !== undefined &&
        entry.egresos_Mensuales !== null
      ) {
        expense = entry.egresos_Mensuales + "";
      }

      var tipoIde = "R";
      if (entry.tipo_Identidad === "N") tipoIde = "C"
      else if (entry.tipo_Identidad === "E") tipoIde = "P"

      return {
        key: index,
        vatId: entry.numero_Identidad,
        idType: tipoIde,
        mobile: entry.celular,
        email: entry.correo_Electronico,
        name: entry.nombre,
        actionCRUD: entry.accionCRUD,
        seqNumber: entry.numeroSecuencia,
        officeDir: entry.direccion_Oficina,
        homeDir: entry.direccion_Domicilio,
        workLongevity: entry.tiempo_Actual_Trabajo,
        monthlyIncome: formatValue({
          value: income,
          groupSeparator: ",",
          decimalSeparator: ".",
          prefix: "$",
          decimalScale: 2,
        }),
        monthlyExpense: formatValue({
          value: expense,
          groupSeparator: ",",
          decimalSeparator: ".",
          prefix: "$",
          decimalScale: 2,
        }),
        action: actionButtons(entry, index),
      };
    })
    .filter((item) => item.actionCRUD !== "D");

  const modalConfirmation = (
    <Modal show={show} onHide={handleClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>ELIMINACIÓN DE CONTACTO</Modal.Title>
      </Modal.Header>
      <Modal.Body>¿Está seguro que desea eliminar el contacto?</Modal.Body>
      <Modal.Footer>
        <CustomButton
          size=""
          class={classes["btn-custom-close"]}
          label="Cancelar"
          eventHandler={handleClose}
        />
        <CustomButton
          size=""
          class={classes["btn-custom"]}
          label="Aceptar"
          eventHandler={handleAction}
        />
      </Modal.Footer>
    </Modal>
  );
  const contactHeader = (
    <Row>
      <Row className="ma-2">
        <Col>
          <SelectCatalogue
            selected={clientTypeId}
            disabled={true}
            label="Tipo Identificación"
            catalogo="TIPO_DOCUMENTO"
            parentCallback={setClientTypeId}
            origenEtiqueta="COMPLEMENTO"
          />
        </Col>
        <Col>
          <FormInput
            value={clientVatId}
            label="Número de Identificación"
            parentCallback={setClientVatId}
            disabled={true}
          />
        </Col>
      </Row>
      <Row>
        <Col>
          <FormInput
            value={clientName}
            label="Nombre Cliente"
            parentCallback={setClientName}
            disabled={true}
          />
        </Col>
      </Row>
    </Row>
  );

  const table = (
    <Fragment>
      <Row xs="auto" className="justify-content-end m-3">
        <CustomButton
          size=""
          class={classes["btn-custom-inverse"]}
          color={COLORS.primaryLight}
          iconColor={COLORS.primaryLight}
          label="Agregar Nuevo"
          icon="faPlus"
          eventHandler={addContact}
        />
      </Row>
      <CustomStaticTable
        columns={columns}
        items={parsedContactsList}
        page={currentPage}
        sizePerPage={sizePerPage}
        totalSize={total}
        onChangePage={onPageChange}
        static={true}
      />
    </Fragment>
  );

  const saveButton = (
    <Row xs="auto" className="justify-content-end">
      <CustomButton
        size=""
        class={classes["btn-custom"]}
        label="Guardar"
        eventHandler={saveContactsEditionHandler}
      />
    </Row>
  );

  const modalForm = (
    <Row>
      <Row>
        <Col>
          <SelectCatalogue
            selected={cIdType}
            parentCallback={setCIdType}
            label="Tipo Identificación"
            catalogo="TIPO_DOCUMENTO"
            origenEtiqueta="COMPLEMENTO"
          />
        </Col>
        <Col>
          <FormInput
            value={cVatId}
            label="Número de Identificación"
            parentCallback={(e) => {
              setCVatId(e);
              const isValid = checkVatId(e);
              setVatIdIsValid(isValid);
            }}
            dataType={
              cIdType
                ? cIdType === "N"
                  ? "NUMERICO"
                  : cIdType === "R"
                    ? "NUMERICO"
                    : "ALFANUMERICOSOLO"
                : "NUMERICO"
            }
            maxLength={
              cIdType ? (cIdType === "N" ? 10 : cIdType === "R" ? 13 : 20) : 10
            }
            /*isValid={vatIdIsValid}*/
          />
        </Col>
      </Row>
      <Row>
        <Col>
          <FormInput
            value={cName}
            label="Nombre"
            parentCallback={setCName}
            maxLength={100}
            dataType="ALFABETICO"
          />
        </Col>
      </Row>
      <Row>
        <Col>
          <FormInput
            value={cEmail}
            label="Correo Electrónico"
            parentCallback={(e) => {
              setCEmail(e);
              let regex = new RegExp('[-a-zA-Z0-9._]+@[a-zA-Z]+\.[a-zA-Z]{2,3}');
              const valid = regex.test(e + "");
              setEmailIsValid(valid);
            }}
            dataType="ALFANUMERICO"
            maxLength={50}
            isValid={emailIsValid}
          />
        </Col>
      </Row>

      <Row>
        <Col>
          <FormInput
            value={cHomeDir}
            label="Dirección Domicilio"
            parentCallback={setCHomeDir}
            maxLength={200}
            dataType="ALFANUMERICO"
          />
        </Col>
      </Row>
      <Row>
        <Col>
          <FormInput
            value={cOfficeDir}
            label="Dirección Oficina"
            parentCallback={setCOfficeDir}
            maxLength={200}
            dataType="ALFANUMERICO"
          />
        </Col>
      </Row>
      <Row>
        <Col>
          <FormInput
            value={cMobile}
            label="Celular"
            parentCallback={setCMobile}
            dataType="NUMERICO"
            maxLength={20}
          />
        </Col>
        <Col>
          <FormInput
            value={cWorkLongevity}
            label="Tiempo Actual Trabajo (Años)"
            parentCallback={setCWorkLongevity}
            dataType="NUMERICO"
            maxLength={100}
          />
        </Col>
      </Row>
      <Row>
        <Col>
          <FormInput
            value={cMonthlyIncome}
            label="Ingresos Mensual"
            parentCallback={setCMonthlyIncome}
            dataType="MONEDA"
          />
        </Col>
        <Col>
          <FormInput
            value={cMonthlyExpense}
            label="Egresos Mensual"
            parentCallback={setCMonthlyExpense}
            dataType="MONEDA"
          />
        </Col>
      </Row>
    </Row>
  );

  const modalView = (
    <CustomModal
      show={modalFormShow}
      modalTitle={"Editar Contacto"}
      handleAction={handleEditAction}
      handleClose={handleEditClose}
      size="lg"
    >
      {modalForm}
    </CustomModal>
  );

  const messageAlert = <SuccessAlert text={message} />;

  function showSuccessMessage() {
    setShowMessage(true);
    setTimeout(HideSuccessMessage, 5000);
  }

  function HideSuccessMessage() {
    setMessage("");
    setShowMessage(false);
  }

  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );

  return (
    <Fragment>
      <Container fluid>
        {showError && errorAlert}
        {showMessage && messageAlert}
        {searchBar}
        {modalConfirmation}
        {modalView}
        {showRes && (
          <Card className="p-4">
            {contactHeader}
            {table}
            {saveButton}
          </Card>
        )}
        {isLoading && loading}
      </Container>
    </Fragment>
  );
};

export default TableContacts;
