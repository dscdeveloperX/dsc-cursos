import { Fragment, useState, useContext, useEffect, useRef } from "react";
import Stepper from "react-stepper-horizontal";
import AuthContext from "../store/auth-context";
import { Col, Row } from "react-bootstrap";

import ErrorAlert from "../components/UI/ErrorAlert";
import LoadingSpinner from "../components/UI/LoadingSpinner";
import ParametrizationBarAP from "../components/Layout/ParametrizationBarAP";
import ParametrizedModel from "../components/Layout/ParametrizedModel";
import CustomButton from "../components/UI/buttons/CustomButton";
import HeaderTitle from "../components/UI/fields/HeaderTitle";

import buttonClasses from "../components/UI/css/SearchBar.module.css";
import FormClientAccountCreation from "./FormClientAccountCreation";
import store from "../store/index";
import { fieldActions } from "../store/field-helper";
import { ValidarCamposRequeridos } from "../store/field-actions";
import { useDispatch, useSelector } from "react-redux";
import CustomModal from "../components/Layout/CustomModal";
import SuccessAlert from "../components/UI/SuccessAlert";

const TableServiceAP = () => {
    let varbt64 = "";

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null); 
  const [showError, setShowError] = useState(false);

  const [activeStep, setActiveStep] = useState(0);
  const [formatHeader, setFormatHeader] = useState(null);
  const [stepperObj, setStepperObj] = useState([
    { title: "Ingreso Cliente" },
    { title: "Confirmación" },
    { title: "Resultado" },
  ]);

  const clientModel = useSelector((state) => state.field.client);
  const [client, setClient] = useState(clientModel);

  const productModel = useSelector((state) => state.field.product);
  const [product, setProduct] = useState(productModel);

  const [summary, setSummary] = useState([]);
  const [signatures, setSignatures] = useState({});

  const [headerInfo, setHeaderInfo] = useState(null);

  const [show, setShow] = useState(false);
  const [showCancelAP, setShowCancelAP] = useState(false);
  const [showProduct, setShowProduct] = useState(false);
  const [showCancelation, setShowCancelation] = useState(false);

  const [showMessage, setShowMessage] = useState(false);
  const [message, setMessage] = useState("");

  const [pendingRequest, setPendingRequest] = useState(false);
 
  useEffect(() => {
    const clientStore = store.getState().field.client;
    setClient({ ...clientStore });
  }, [clientModel]);

  useEffect(() => {
    const productStore = store.getState().field.product;
    setProduct({ ...productStore });
  }, [productModel]);

  const searchBarRef = useRef();

  const dispatch = useDispatch();

  const authCtx = useContext(AuthContext);

  const handleAction = () => {
    sendClientDataHandler();
    setShow(false);
  };
  const handleClose = () => {
    setShow(false);
  };

  const handleCancelacionAPAction = () => {
    sendContractDataHandler();
    setShowCancelAP(false);
  };

  const handleCancelacionAPClose = () => {
    setShowCancelAP(false);
  };

  const handleProductAction = () => {
    sendProductDataHandler();
    setShowProduct(false);
  };
  const handleProductClose = () => {
    setShowProduct(false);
  };

  const handleCancelationAction = () => {
    sendCancelationDataHandler();
    setShowCancelation(false);
  };
  const handleCancelationClose = () => {
    setShowCancelation(false);
  };

  const cleanData = () => {
    setPendingRequest(false);
    setShowError(false);
    HideSuccessMessage();
    setActiveStep(0);
    setFormatHeader(null);
    setSummary([]);
    dispatch(
      fieldActions.cleanFields({})
    );
  };

  const mapModelIntoMap = (
    tipo,
    model,
    fieldsMap,
    calculated,
    calculatedApi,
    defaultValue,
    filterValues,
    catalogueValues,
    checkSection,
    parentDependentCalculated
  ) => {

    if (model !== null && model !== undefined) {
      if (model.secciones !== null) {
        for (
          var sectionIndex = 0;
          sectionIndex < model.secciones.length;
          sectionIndex++
        ) {
          var section = model.secciones[sectionIndex];
          if (section.campos !== null) {
            for (
              var fieldIndex = 0;
              fieldIndex < section.campos.length;
              fieldIndex++
            ) {
              var field = section.campos[fieldIndex];
              fieldsMap[field.codigo] = {
                field: field,
                sectionIndex: sectionIndex,
                subSectionIndex: -1,
                fieldIndex: fieldIndex,
                tipo: tipo,
              };

              var sectionKey = tipo + "|" + sectionIndex + "|" + "-1";

              if (field.visible === true) {
                if (field.dependenciaVisibilidad !== null
                  && field.dependenciaVisibilidad !== "") {
                  if (sectionKey in checkSection && checkSection[sectionKey] === false) {
                    if (field.dependenciaVisibilidad.trim() in checkSection[sectionKey]) {
                      checkSection[sectionKey][field.dependenciaVisibilidad.trim()].push(field.valoresDependenciaVisibilidad);
                    }
                    else {
                      var depen = {}
                      depen[field.dependenciaVisibilidad.trim()] = [field.valoresDependenciaVisibilidad];
                      checkSection[sectionKey] = depen;
                    }
                  }
                  else if (!(sectionKey in checkSection)) {
                    var depen = {}
                    depen[field.dependenciaVisibilidad.trim()] = [field.valoresDependenciaVisibilidad];
                    checkSection[sectionKey] = depen;
                  }
                } else {
                  checkSection[sectionKey] = true;
                }
              }
              else {
                if (!(sectionKey in checkSection)) {
                  checkSection[sectionKey] = false;
                }
              }

              if (
                field.tipoCampo === "COMBOBOX" &&
                field.origenCombobox === "MODELOS"
              ) {
                fieldsMap[field.codigo].convertList = [
                  ...field.valoresCombobox,
                ];
                fieldsMap[field.codigo].field.valoresCombobox = [];
              }
              if (field.tipoCampo?.trim() === "CALCULADO") {
                if (field.tipoCalculado?.trim() === "FRONT") {
                  calculated.push(field.codigo);
                }
                else if (field.tipoCalculado?.trim() === "API") {
                  calculatedApi.push(field.codigo);
                }
              }
              if (field.tipoValorDefecto?.trim() === "ONCHANGE") {
                if (field.dependenciaValorDefecto?.trim() in defaultValue) {
                  defaultValue[field.dependenciaValorDefecto.trim()].push(
                    field.codigo
                  );
                } else {
                  var array = [];
                  array.push(field.codigo);
                  defaultValue[field.dependenciaValorDefecto.trim()] = array;
                }
              }

              if (field.tipoValor === "LISTA") {
                if (field.formatoModeloLista !== undefined && field.formatoModeloLista !== null && field.formatoModeloLista.length > 0) {
                  var dependent = field.formatoModeloLista.find(x => x.tipoCampo?.trim() === "CALCULADO" && x.tipoCalculado?.trim() === "FRONT" && x.nombreCalculo?.trim() === "ObtenerValorCampoModeloRef");

                  if (dependent !== undefined) {
                    parentDependentCalculated.push(field.codigo);
                  }
                }
              }

              if (
                field.tipoFiltro !== null &&
                field.dependenciaFiltro !== null
              ) {
                if (field.dependenciaFiltro?.trim() in filterValues) {
                  filterValues[field.dependenciaFiltro.trim()].push(
                    field.codigo
                  );
                } else {
                  var array = [];
                  array.push(field.codigo);
                  filterValues[field.dependenciaFiltro.trim()] = array;
                }
                catalogueValues[field.codigo] = field.valoresCombobox;
              } else if (
                field.tipoCampo === "COMBOBOX" &&
                field.origenCombobox === "MODELOS"
              ) {
                catalogueValues[field.codigo] = [];
              }
            }
          }
          if (section.secciones !== null) {
            for (
              var subSectionIndex = 0;
              subSectionIndex < section.secciones.length;
              subSectionIndex++
            ) {
              var subsection = section.secciones[subSectionIndex];
              if (subsection.campos !== null) {
                for (
                  var fieldIndex2 = 0;
                  fieldIndex2 < subsection.campos.length;
                  fieldIndex2++
                ) {
                  var field = subsection.campos[fieldIndex2];
                  fieldsMap[field.codigo] = {
                    field: field,
                    sectionIndex: sectionIndex,
                    subSectionIndex: subSectionIndex,
                    fieldIndex: fieldIndex2,
                    tipo: tipo,
                  };
                  var subsectionKey = tipo + "|" + sectionIndex + "|" + subSectionIndex;

                  if (field.visible === true) {
                    if (field.dependenciaVisibilidad !== null
                      && field.dependenciaVisibilidad !== "") {
                      if (subsectionKey in checkSection && checkSection[subsectionKey] === false) {
                        if (field.dependenciaVisibilidad.trim() in checkSection[subsectionKey]) {
                          checkSection[subsectionKey][field.dependenciaVisibilidad.trim()].push(field.valoresDependenciaVisibilidad);
                        }
                        else {
                          var depen = {}
                          depen[field.dependenciaVisibilidad.trim()] = [field.valoresDependenciaVisibilidad];
                          checkSection[subsectionKey] = depen;
                        }
                      }
                      else if (!(subsectionKey in checkSection)) {
                        var depen = {}
                        depen[field.dependenciaVisibilidad.trim()] = [field.valoresDependenciaVisibilidad];
                        checkSection[subsectionKey] = depen;
                      }
                    } else {
                      checkSection[subsectionKey] = true;
                    }
                  }
                  else {
                    if (!(subsectionKey in checkSection)) {
                      checkSection[subsectionKey] = false;
                    }
                  }

                  if (
                    field.tipoCampo === "COMBOBOX" &&
                    field.origenCombobox === "MODELOS"
                  ) {
                    fieldsMap[field.codigo].convertList = [
                      ...field.valoresCombobox,
                    ];
                    fieldsMap[field.codigo].field.valoresCombobox = [];
                  }
                  if (field.tipoCampo?.trim() === "CALCULADO") {
                    if (field.tipoCalculado?.trim() === "FRONT") {
                      calculated.push(field.codigo);
                    }
                    else if (field.tipoCalculado?.trim() === "API") {
                      calculatedApi.push(field.codigo);
                    }
                  }
                  if (field.tipoValorDefecto?.trim() === "ONCHANGE") {
                    if (field.dependenciaValorDefecto?.trim() in defaultValue) {
                      defaultValue[field.dependenciaValorDefecto.trim()].push(
                        field.codigo
                      );
                    } else {
                      var array = [];
                      array.push(field.codigo);
                      defaultValue[field.dependenciaValorDefecto.trim()] =
                        array;
                    }
                  }

                  if (field.tipoValor === "LISTA") {
                    if (field.formatoModeloLista !== undefined && field.formatoModeloLista !== null && field.formatoModeloLista.length > 0) {
                      var dependent = field.formatoModeloLista.find(x => x.tipoCampo?.trim() === "CALCULADO" && x.tipoCalculado?.trim() === "FRONT" && x.nombreCalculo?.trim() === "ObtenerValorCampoModeloRef");

                      if (dependent !== undefined) {
                        parentDependentCalculated.push(field.codigo);
                      }
                    }
                  }

                  if (
                    field.tipoFiltro !== null &&
                    field.dependenciaFiltro !== null
                  ) {
                    if (field.dependenciaFiltro?.trim() in filterValues) {
                      filterValues[field.dependenciaFiltro.trim()].push(
                        field.codigo
                      );
                    } else {
                      var array = [];
                      array.push(field.codigo);
                      filterValues[field.dependenciaFiltro.trim()] = array;
                    }
                    catalogueValues[field.codigo] = field.valoresCombobox;
                  } else if (
                    field.tipoCampo === "COMBOBOX" &&
                    field.origenCombobox === "MODELOS"
                  ) {
                    catalogueValues[field.codigo] = [];
                  }
                }
              }
            }
          }
        }
      }
    }
  };

  const mapFieldsState = (cliente, producto) => {
    var fieldsMap = {};
    var calculated = [];
    var calculatedApi = [];
    var defaultValues = {};
    var catalogueValues = {};
    var filterValues = {};
    var checkSection = {};
    var parentDependentCalculated = [];

    mapModelIntoMap(
      "CLIENTE",
      cliente,
      fieldsMap,
      calculated,
      calculatedApi,
      defaultValues,
      filterValues,
      catalogueValues,
      checkSection,
      parentDependentCalculated
    );
    mapModelIntoMap(
      "PRODUCTO",
      producto,
      fieldsMap,
      calculated,
      calculatedApi,
      defaultValues,
      filterValues,
      catalogueValues,
      checkSection,
      parentDependentCalculated
    );
    dispatch(
      fieldActions.setFields({
        fields: fieldsMap,
        client: cliente,
        product: producto,
        calculated: calculated,
        calculatedApi: calculatedApi,
        parentDependentCalculated: parentDependentCalculated,
        defaultValues: defaultValues,
        filterValues: filterValues,
        catalogueValues: catalogueValues,
        agencyCode: authCtx.agencyCode,
        user: authCtx.user,
        executiveCode: authCtx.executiveCode,
        vatId: authCtx.vatId,
        area: authCtx.area,
        checkSection: checkSection
      })
    );
  };

  async function apiCall({
    tipoPersona,
    tipoIdentificacion,
    identificacion,
    tipoCliente,
    producto,
  }) {
    setShowMessage(false);
    setIsLoading(true);
    setError(null);
    setShowError(false);
    cleanData();
    var message = "";
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          tipoPersona: tipoPersona,
          tipoIdentificacion: tipoIdentificacion,
          identificacion: identificacion,
          tipoCliente: tipoCliente,
          producto: +producto,
        },
      };
      if (authCtx.executiveCode === null &&
        authCtx.area === null) {
      throw Error("El usuario que está intentando utilizar no se encuentra dentro de los oficiales registrados.");
    }
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "balcon/ObtenerFormulario",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      ).catch(_ => {
        throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
      });

      const resText = await response.text();
      const data = resText && JSON.parse(resText);
      if (!response.ok) {
        if ([401, 403].includes(response.status)) {
          throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
        }
        if (data?.headerResponse !== undefined) {
          const errorMessage = data.headerResponse.returnMessage.split("|");
          throw Error(errorMessage[0]);
        } else {
          throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
        }
      }

      if (data.headerResponse.returnMessage !== "OK") {
        message = data.headerResponse.returnMessage;
        setMessage(message);
      }

      if (data.bodyResponse?.formato) {
        const {
          cliente: clienteForm,
          codigo: codigoForm,
          descripcion: descripcionForm,
          formatoId: formatoIdForm,
          nombre: nombreForm,
          producto: productoForm,
          tipoCliente: tipoClienteForm,
          tipoIdentificacion: tipoIdentificacionForm,
          tipoPersona: tipoPersonaForm,
        } = data.bodyResponse.formato;
 
        mapFieldsState(clienteForm, productoForm);

        setHeaderInfo({
          tipoPersona,
          tipoIdentificacion,
          identificacion,
          tipoCliente,
          producto,
        });

        //setClient(clienteForm);
        //setProduct(productoForm);
        setFormatHeader({
          codigo: codigoForm,
          descripcion: descripcionForm,
          formatoId: formatoIdForm,
          nombre: nombreForm,
          tipoCliente: tipoClienteForm,
          tipoIdentificacion: tipoIdentificacionForm,
          tipoPersona: tipoPersonaForm,
        });
        setActiveStep(0);
        
        if (producto !== null && producto > 0) {
          setStepperObj([
            { title: "Ingreso Cliente" },
            { title: "Ingreso Producto" },
            { title: "Resultado" },
          ]);  
        } else {
          setStepperObj([
            { title: "Ingreso Cliente" }, 
            { title: "Resultado" }
          ]);
        }
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    if (message !== null && message.length > 0) showSuccessMessage(false);
    setIsLoading(false);
  }

  async function sendClientDataHandler() {
    var message = "";
    var pending = false;
    setIsLoading(true);
    setError(null);
    setShowError(false);
    setShowMessage(false);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          formulario: {
            formatoId: formatHeader.formatoId,
            tipoPersona: formatHeader.tipoPersona.codigo,
            tipoIdentificacion: formatHeader.tipoIdentificacion.codigo,
            tipoCliente: formatHeader.tipoCliente.codigo,
            formulario: client,
          },
          infoUsuario: {
            rol: authCtx.role,
            correo: authCtx.email,
            executiveCode: authCtx.executiveCode,
            agencyCode: authCtx.agencyCode,
            agenciasolicitud: authCtx.agencyCode,
          },
        },
      };

      //chequear si existen campos requeridos vacios
      let checkRes = ValidarCamposRequeridos(
        client,
        store.getState().field.fields
      );

      if (checkRes.length > 0) {
        //mensaje de campos obligatorios no rellenados
        let msgString = checkRes.join(", \n");
        setError("Por favor revise los campos: ||" + msgString);
        setShowError(true);
      } else {

        const response = await fetch(
          authCtx.REACT_APP_BASE_URL + "balcon/EnviarFormularioPersona",
          {
            method: "POST",
            body: JSON.stringify(request),
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + authCtx.token,
            },
          }
        ).catch(_ => {
          throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
        });
        const resText = await response.text();
        const data = resText && JSON.parse(resText);
        if (!response.ok) {
          if ([401, 403].includes(response.status)) {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
          if (data?.headerResponse !== undefined) {
            const errorMessage = data.headerResponse.returnMessage.split("|");
            throw Error(errorMessage[0]);
          } else {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
        }
        if (data.bodyResponse !== undefined && data.bodyResponse !== null) {
          setActiveStep(1);
          if (
            data.bodyResponse.detalles !== null &&
            data.bodyResponse.detalles.length > 0
          ) {
            setSummary(data.bodyResponse.detalles);
          }

          if (
            data.bodyResponse.resultado !== null &&
            Object.keys(data.bodyResponse.resultado).length > 0
          ) {
            dispatch(
              fieldActions.updateFieldApiRes({
                model: "CLIENTE",
                values: data.bodyResponse.resultado,
                agencyCode: authCtx.agencyCode,
                user: authCtx.user,
                executiveCode: authCtx.executiveCode,
                vatId: authCtx.vatId,
                area: authCtx.area,
              })
            );
          }

          setSignatures(data.bodyResponse.firmantes);

          message = data.bodyResponse.mensaje;
          if (data.headerResponse.returnCode === "PENDING") {
            pending = true;
            setPendingRequest(true);
          }
          setMessage(message);
        } else {
          throw new Error(
            "No se pudo enviar el formulario de Cliente, por favor intente más tarde"
          );
        }
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    if (message !== null && message.length > 0) showSuccessMessage(pending);
    setIsLoading(false);

    window.scrollTo(0, 0);
  }
  async function sendContractDataHandler() {
    var message = "";
    var pending = false;
    setIsLoading(true);
    setError(null);
    setShowError(false);
    setShowMessage(false);

    let contrato  = 0;
    client.secciones[0].secciones[0].campos[1].valoresLista.forEach(e => { 
      if(e.campos[0].valor === 'D'){
        contrato = e.campos[1].valor.toString();
      }
    });

    try { 
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          contrato: contrato,
        },
      };

      //chequear si existen campos requeridos vacios
      let checkRes = ValidarCamposRequeridos(
        client,
        store.getState().field.fields
      );

      if (checkRes.length > 0) {
        //mensaje de campos obligatorios no rellenados
        let msgString = checkRes.join(", \n");
        setError("Por favor revise los campos: ||" + msgString);
        setShowError(true);
      } else {
        const response = await fetch(
          authCtx.REACT_APP_BASE_URL + "balcon/SimuladorCancelacionContratoAhorroProgramado",
          {
            method: "POST",
            body: JSON.stringify(request),
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + authCtx.token,
            },
          }
        ).catch(_ => {
          throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
        });
        const resText = await response.text();
        const data = resText && JSON.parse(resText);
        if (!response.ok) {
          if ([401, 403].includes(response.status)) {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
          if (data?.headerResponse !== undefined) {
            const errorMessage = data.headerResponse.returnMessage.split("|");
            throw Error(errorMessage[0]);
          } else {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
        }
        
        if (data.bodyResponse !== undefined && data.bodyResponse !== null) {
          setActiveStep(1);

          
          if (data.bodyResponse.resultado.length > 0) 
          {
            setSummary([...summary, data.bodyResponse.resultado.Documento]);
          } 
          else
          {
            varbt64 = "" ;
          } 
          
          // if (
          //   data.bodyResponse.detalles !== null &&
          //   data.bodyResponse.detalles.length > 0
          // ) {
          //   setSummary(data.bodyResponse.detalles);
          // }

          if (
            data.bodyResponse.resultado !== null &&
            Object.keys(data.bodyResponse.resultado).length > 0
          ) {
            dispatch(
              fieldActions.updateFieldApiRes({
                model: "PRODUCTO",
                values: data.bodyResponse.resultado,
                agencyCode: authCtx.agencyCode,
                user: authCtx.user,
                executiveCode: authCtx.executiveCode,
                vatId: authCtx.vatId,
                area: authCtx.area,
              })
            );
          }

          // setSignatures(data.bodyResponse.firmantes);

          message = data.bodyResponse.mensaje;
          // if (data.headerResponse.returnCode === "PENDING") {
          //   pending = true;
          //   setPendingRequest(true);
          // }
          setMessage(message);
        } else {
          throw new Error(
            "No se pudo enviar el contrato a cancelar, por favor intente más tarde"
          );
        }
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    if (message !== null && message.length > 0) showSuccessMessage(pending);
    setIsLoading(false);

    window.scrollTo(0, 0);
  }


  async function sendCancelationDataHandler() {
    var message = "";
    setShowMessage(false);
    setIsLoading(true);
    setError(null);
    setShowError(false); 
    let contrato  = 0;
    let tipdoc  = "0";
    let documento  = "0";
    let cuenta = "0";
    let canal = "0";
    let oficial = "0";

    let motivocancelacion = "";   
    
    

    contrato =  product.secciones[0].campos[2].valor;
    tipdoc =  product.secciones[0].campos[4].valor;
    documento =  product.secciones[0].campos[5].valor.toString();
    cuenta =  product.secciones[0].campos[8].valor;
    canal =  product.secciones[0].campos[21].valor;
    oficial =  product.secciones[0].campos[27].valor;
    motivocancelacion =  product.secciones[1].campos[8].valor;
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          contrato : contrato,
          tipoDocumento : tipdoc,
          documento : documento,
          cuenta : cuenta,
          canal : '22',
          oficial : oficial,
          motivoCancelacion: motivocancelacion,
          userAS : 'BALCONAP',
          correoElectronico : authCtx.email,
        },
      };

      //chequear si existen campos requeridos vacios
      let checkRes = ValidarCamposRequeridos(
        product,
        store.getState().field.fields
      );

      if (checkRes.length > 0) {
        //mensaje de campos obligatorios no rellenados
        let msgString = checkRes.join(", \n");
        setError("Por favor revise los campos: ||" + msgString);
        setShowError(true);
      } else {
        const response = await fetch(
          authCtx.REACT_APP_BASE_URL + "balcon/CancelarContratoAhorroProgramado",
          {
            method: "POST",
            body: JSON.stringify(request),
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + authCtx.token,
            },
          }
        ).catch(_ => {
          throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
        });

        const resText = await response.text();
        const data = resText && JSON.parse(resText);
        if (!response.ok) {
          if ([401, 403].includes(response.status)) {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
          if (data?.headerResponse !== undefined) {
            const errorMessage = data.headerResponse.returnMessage.split("|");
            throw Error(errorMessage[0]);
          } else {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
        } 
        if (data.bodyResponse !== undefined && data.bodyResponse !== null) {
          setActiveStep((prevActiveStep) => prevActiveStep + 1);
          message = data.bodyResponse.mensaje;
          setMessage(message); 
          if (data.bodyResponse.resultado.Documento.length > 0)
          {
            varbt64 = data.bodyResponse.resultado.Documento;   
            localStorage.setItem('pdfContentToDownload',varbt64);
          }
          else
          {
            varbt64 = "";   
          }
         // The Base64 string of a simple PDF file
         
          if (
            data.bodyResponse !== null &&
            data.bodyResponse.length > 0
          ) {
             
          }
          if (
            data.bodyResponse.resultado !== null &&
            Object.keys(data.bodyResponse.resultado).length > 0
          ) {
            dispatch(
              fieldActions.updateFieldApiRes({
                model: "PRODUCTO",
                values: data.bodyResponse.resultado,
                agencyCode: authCtx.agencyCode,
                user: authCtx.user,
                executiveCode: authCtx.executiveCode,
                vatId: authCtx.vatId,
                area: authCtx.area,
              })
            );
          }

          // let indigrab = data.bodyResponse.formulario.indicadorGraba;
        } else {
          throw new Error(
            "No se pudo enviar el formulario de Producto, por favor intente más tarde"
          );
        }
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    if (message !== null && message.length > 0) showSuccessMessage(false);
    setIsLoading(false);
    window.scrollTo(0, 0);
  }

  async function sendProductDataHandler() {
    var message = "";
    setShowMessage(false);
    setIsLoading(true);
    setError(null);
    setShowError(false);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          formulario: {
            formatoId: formatHeader.formatoId,
            tipoPersona: formatHeader.tipoPersona.codigo,
            tipoIdentificacion: formatHeader.tipoIdentificacion.codigo,
            tipoCliente: formatHeader.tipoCliente.codigo,
            formulario: product,
            agenciaSolicitud: authCtx.agencyCode,
          },
          infoUsuario: {
            rol: authCtx.role,
            correo: authCtx.email,
            executiveCode: authCtx.executiveCode,
            agencyCode: authCtx.agencyCode,
            agenciaSolicitud: authCtx.agencyCode,
          },
        },
      };

      //chequear si existen campos requeridos vacios
      let checkRes = ValidarCamposRequeridos(
        product,
        store.getState().field.fields
      );

      if (checkRes.length > 0) {
        //mensaje de campos obligatorios no rellenados
        let msgString = checkRes.join(", \n");
        setError("Por favor revise los campos: ||" + msgString);
        setShowError(true);
      } else {
        const response = await fetch(
          authCtx.REACT_APP_BASE_URL + "balcon/EnviarFormularioProducto",
          {
            method: "POST",
            body: JSON.stringify(request),
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + authCtx.token,
            },
          }
        ).catch(_ => {
          throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
        });

        const resText = await response.text();
        const data = resText && JSON.parse(resText);
        if (!response.ok) {
          if ([401, 403].includes(response.status)) {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
          if (data?.headerResponse !== undefined) {
            const errorMessage = data.headerResponse.returnMessage.split("|");
            throw Error(errorMessage[0]);
          } else {
            throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
          }
        }
 
        if (data.bodyResponse !== undefined && data.bodyResponse !== null) {
          if (data.bodyResponse.resultado.Documento.length > 0)
          {
            varbt64 = data.bodyResponse.resultado.Documento;   
            localStorage.setItem('pdfContentToDownload',varbt64);
          }
          else
          {
            varbt64 = "";   
          }
 

          

          setActiveStep((prevActiveStep) => prevActiveStep + 1);
          message = data.bodyResponse.mensaje;
          setMessage(message);
          if (
            data.bodyResponse.detalles !== null &&
            data.bodyResponse.detalles.length > 0
          ) {
            setSummary([...summary, ...data.bodyResponse.detalles]);
          }
          if (
            data.bodyResponse.resultado !== null &&
            Object.keys(data.bodyResponse.resultado).length > 0
          ) {
            dispatch(
              fieldActions.updateFieldApiRes({
                model: "PRODUCTO",
                values: data.bodyResponse.resultado,
                agencyCode: authCtx.agencyCode,
                user: authCtx.user,
                executiveCode: authCtx.executiveCode,
                vatId: authCtx.vatId,
                area: authCtx.area,
              })
            );
          }
        } else {
          throw new Error(
            "No se pudo enviar el formulario de Producto, por favor intente más tarde"
          );
        }
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    if (message !== null && message.length > 0) showSuccessMessage(false);
    setIsLoading(false);
    window.scrollTo(0, 0);
  }

  const nextPage = () => {
    if (activeStep === 0) {
      
       setShow(true);
    } else { 
        setShowProduct(true);
    }
  };
 
  const messageAlert = <SuccessAlert text={message} />;

  function showSuccessMessage(isStatic) {
    setShowMessage(true);
    if (isStatic !== true) setTimeout(HideSuccessMessage, 5000);
  }

  function HideSuccessMessage() {
    setMessage("");
    setShowMessage(false);
  }

  const stepper = <Stepper steps={stepperObj} activeStep={activeStep} />;

  const stepButton = (
    <Col>
      <CustomButton
        size="md"
        class={buttonClasses["btn-custom"]}
        label="GUARDAR Y CONTINUAR"
        icon="faArrowRight"
        eventHandler={nextPage}
      />
    </Col>
  );

  const formOutput = (
    <FormClientAccountCreation
      client={client}
      product={product}
      disablePrint={pendingRequest}
      signatures={signatures}
      summary={summary}
      cleanData={() => {
        searchBarRef.current.clear();
        cleanData();
      }}
    />
  );

  const searchBar = (
    <div>
      <ParametrizationBarAP fetchHandler={apiCall} ref={searchBarRef} />
    </div>
  );

  const confirmationModal = (
    <CustomModal
      show={show}
      modalTitle={"Confirmación Guardar Datos Cliente"}
      handleAction={handleAction}
      handleClose={handleClose}
    >
      <Fragment>
        {"¿Está seguro que desea guardar los datos del cliente?"}
      </Fragment>
    </CustomModal>
  );

  const confirmationCancelAPModal = (
    <CustomModal
      show={showCancelAP}
      modalTitle={"Confirmación de Cancelacion de Contrato"}
      handleAction={handleCancelacionAPAction}
      handleClose={handleCancelacionAPClose}
    >
      <Fragment>
        {"¿Está seguro que desea continuar a la cancelacion del contrato?"}
      </Fragment>
    </CustomModal>
  );

  const confirmationProductModal = (
    <CustomModal
      show={showProduct}
      modalTitle={"Confirmación Guardar Datos Producto"}
      handleAction={handleProductAction}
      handleClose={handleProductClose}
    >
      <Fragment>
        {"¿Está seguro que desea guardar los datos del producto?"}
      </Fragment>
    </CustomModal>
  );

  const confirmationCancelModal = (
    <CustomModal
      show={showCancelation}
      modalTitle={"Confirmación de la cancelacioón del contrato "}
      handleAction={handleCancelationAction}
      handleClose={handleCancelationClose}
    >
      <Fragment>
        {"¿Está seguro que desea cancelar el contrato?"}
      </Fragment>
    </CustomModal>
  );

  const cleanButton = (
    <Col>
      <CustomButton
        size="md"
        class={buttonClasses["btn-custom"]}
        label="SALIR"
        eventHandler={() => {
          searchBarRef.current.clear();
          cleanData();
        }}
      />
    </Col>
  );

  const content = (
    <Fragment>
      {formatHeader !== null && (
        <Fragment>
          {stepper}
          {activeStep === 0 && client !== null && (
            <Fragment>
              <HeaderTitle label="Cliente" />
              <ParametrizedModel
                model={client}
                tipo={"CLIENTE"}
              // parentCallback={(valor) => {
              //   setClient(valor);
              // }}
              />
              <Row xs="auto" className="justify-content-end m-4 ">
                {cleanButton}{stepButton}
              </Row>

            </Fragment>
          )}
          {product !== null &&
            Object.keys(product).length > 0 &&
            activeStep === 1 && (
              <Fragment>
                {!pendingRequest && <HeaderTitle label="Producto" />}
                {!pendingRequest && <ParametrizedModel
                  model={product}
                  tipo={"PRODUCTO"}
                // parentCallback={(valor) => {
                //   setProduct(valor);
                // }}
                />}
                <Row xs="auto" className="justify-content-end m-4 ">
                  {cleanButton}{!pendingRequest && stepButton}
                </Row>
              </Fragment>
            )}
          {/* {client !== null &&
            (product === null ? activeStep === 1 : activeStep === 2) &&
            formOutput} */}
          {client !== null &&
            (product === null || Object.keys(product).length === 0
              ? activeStep === 1
              : activeStep === 2) &&
            formOutput}
        </Fragment>
      )}
    </Fragment>
  );

  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );

  return (
    <Fragment>
      {showError && errorAlert}
      {searchBar}
      {showMessage && messageAlert}
      {!isLoading && content}
      {isLoading && loading}
      {confirmationModal}
      {confirmationCancelAPModal}
      {confirmationProductModal}
      {confirmationCancelModal}
    </Fragment>
  );

};

export default TableServiceAP;