import { Fragment, useState, useEffect } from "react";
import { Row, Col, Container, Image, Form } from "react-bootstrap";
import html2pdf from "html2pdf.js";
import HeaderTitle from "../components/UI/fields/HeaderTitle";
import FormField from "../components/UI/fields/FormField";
import CustomButton from "../components/UI/buttons/CustomButton";
import buttonClasses from "../components/UI/css/SearchBar.module.css";

const FormClientAccountCreation = (props) => {
  
  const [textValue, setTextValue] = useState("");
  const [textArray, setTextArray] = useState([]);
  
  const [RutaDoc, setRutaDoc] = useState(1);

  //const clientes = props.client;
  //const productos = props.product;
  const summary = props.summary;
  const signatures = props.signatures;

  const tipoPersona = signatures["TIPO"];

  useEffect(() => {
    fetch("/assets/text_formulario.txt")
      .then((r) => r.text())
      .then((text) => {
        setTextValue(text);
        setTextArray(text.split('\n'));
      });
  }, []);

  const formHeader = (
    <Container
      style={{
        width: "100% !important",
        borderCollapse: "collapse",
        fontSize: "10px",
        fontFamily: "Verdana",
      }}
    >
      <Row
        className="form-print-header"
        style={{
          width: "100% !important",
          border: "1px solid black",
        }}
      >
        <Col style={{ borderRight: "1px solid black" }} md="10" className="h-100">
          <br />
          <p>FORMULARIO DE CREACIÓN DE CLIENTES Y APERTURA DE CUENTAS</p>
          <br />
        </Col>
        <Col style={{ margin: "0px", padding: "0px", paddingLeft: "8px" }} md="2" className="h-100">
          <Image
            src="/assets/logo_entrada.png"
            style={{
              maxWidth: "75%",
              height: "auto",
              display: "block",
              padding: "0px",
              paddingTop: "0px",
              margin: "auto"
            }}
          />
        </Col>
      </Row>
    </Container>
  );

  const formDisclaimer = (
    <Container
      style={{
        width: "100% !important",
        borderCollapse: "collapse",
        fontSize: "10px",
        fontFamily: "Verdana",
      }}
    >
      <Row
        style={{
          width: "100% !important",
          border: "1px solid black",
        }}
      >
        <Col>DECLARACIÓN Y AUTORIZACIONES</Col>
      </Row>
      <Row
        style={{
          width: "100% !important",
          borderLeft: "1px solid black",
          borderBottom: "1px solid black",
        }}
      >
        <Col
          style={{
            borderRight: "1px solid black",
            wordSpacing: "0px",
            textAlign: "left",
            textJustify: "distribute",
            fontSize: "9px",
            padding: "2px",
          }}
        >
          <br />
          {textArray.map((entry) => {
            return <p style={{ padding: "0px", margin: "0px" }}>{entry}</p>
          })}
          <br />
        </Col>
      </Row>
      <Container style={{ fontSize: "10px", margin: "0px", padding: "0px" }}>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col style={{ textAlign: "center", padding: "2px", fontWeight: "bold" }}>
            GUAYAQUIL,{" "}
            {new Date(Date.now()).toLocaleString("es-ES", {
              year: "numeric",
              month: "long",
              day: "2-digit",
            })}
          </Col>
        </Row>
        
        {tipoPersona === "J" && <Fragment>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "0px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="12"
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="12"
          >
            Firma
          </Col>
        </Row>
          <Row
            style={{
              width: "100% !important",
              borderLeft: "1px solid black",
              borderBottom: "1px solid black",
              borderRight: "1px solid black",
            }}
          >
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                fontWeight: "bold",
                borderRight: "1px solid black",
              }}
              md="2"
            >
              Representante Legal:
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                borderRight: "1px solid black",
              }}
              md="10"
            >
              {signatures["FIRMANTE"]}
            </Col>
          </Row>
          <Row
            style={{
              width: "100% !important",
              borderLeft: "1px solid black",
              borderBottom: "1px solid black",
              borderRight: "1px solid black",
            }}
          >
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                fontWeight: "bold",
                borderRight: "1px solid black",
              }}
              md="2"
            >
              RUC:
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                borderRight: "1px solid black",
              }}
              md="10"
            >
              {signatures["FIRMANTE_DOC"]}
            </Col>
          </Row></Fragment>}
        {tipoPersona === "N" && <Fragment>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "0px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="6"
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "0px",
              fontWeight: "bold",
              textAlign: "center",
            }}
            md="6"
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="6"
          >
            Firma
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
            }}
            md="6"
          >
            Firma Cónyugue
          </Col>
        </Row>
          <Row
            style={{
              width: "100% !important",
              borderLeft: "1px solid black",
              borderBottom: "1px solid black",
              borderRight: "1px solid black",
            }}
          >
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                fontWeight: "bold",
                borderRight: "1px solid black",
              }}
              md="2"
            >
              Nombres:
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                borderRight: "1px solid black",
              }}
              md="4"
            >
              {signatures["FIRMANTE"]}
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                fontWeight: "bold",
                borderRight: "1px solid black",
              }}
              md="2"
            >
              Nombres:
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
              }}
              md="4"
            >
              {signatures["FIRMANTE_CONYUGE"]}
            </Col>
          </Row>
          <Row
            style={{
              width: "100% !important",
              borderLeft: "1px solid black",
              borderBottom: "1px solid black",
              borderRight: "1px solid black",
            }}
          >
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                fontWeight: "bold",
                borderRight: "1px solid black",
              }}
              md="2"
            >
              Cédula/Pasaporte:
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                borderRight: "1px solid black",
              }}
              md="4"
            >
              {signatures["FIRMANTE_DOC"]}
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
                fontWeight: "bold",
                borderRight: "1px solid black",
              }}
              md="2"
            >
              Cédula/Pasaporte:
            </Col>
            <Col
              style={{
                margin: "0px",
                padding: "2px",
              }}
              md="4"
            >
              {signatures["FIRMANTE_CONYUGE_DOC"]}
            </Col>
          </Row></Fragment>}
        <div class="html2pdf__page-break"></div>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
            borderTop: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="2"
          >
            Confirmación del Pago del Impuesto a la Renta:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            SI
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            <span></span>
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            NO
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            <span></span>
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="2"
          >
            Revisado en las Lista Internacionales:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            SI
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            <span></span>
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            NO
          </Col>
          <Col style={{ margin: "0px", padding: "2px" }} md="1">
            <span></span>
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="2"
          >
            Verificación de Direcciones:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Correcto
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            <span></span>
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Incorrecto
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            <span></span>
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="2"
          >
            Verificación de Referencias:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Correcto
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            <span></span>
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Incorrecto
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
            }}
            md="1"
          >
            <span></span>
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderRight: "1px solid black",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
          }}
        >
          <Col>PARA USO EXCLUSIVO DEL BANCO</Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="4"
          >
            Ingresado por:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="4"
          >
            Revisado por:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
            }}
            md="4"
          >
            Aprobado por:
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="4"
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="4"
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
            }}
            md="4"
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="4"
          >
            Firma Responsable
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="4"
          >
            Firma Responsable
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              textAlign: "center",
            }}
            md="4"
          >
            Firma Responsable
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Nombre:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="3"
          >
            <br />
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Nombre:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="3"
          >
            <br />
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Nombre:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
            }}
            md="3"
          >
            <br />
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Fecha:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="3"
          >
            <br />
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Fecha:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              borderRight: "1px solid black",
            }}
            md="3"
          >
            <br />
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="1"
          >
            Fecha:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
            }}
            md="3"
          >
            <br />
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="12"
          >
            Revisión del Departamento Legal:
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="12"
          >
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
              textAlign: "center",
            }}
            md="12"
          >
            Firma Responsable
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="2"
          >
            Nombre:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
            }}
            md="10"
          >
            <br />
          </Col>
        </Row>
        <Row
          style={{
            width: "100% !important",
            borderLeft: "1px solid black",
            borderBottom: "1px solid black",
            borderRight: "1px solid black",
          }}
        >
          <Col
            style={{
              margin: "0px",
              padding: "2px",
              fontWeight: "bold",
              borderRight: "1px solid black",
            }}
            md="2"
          >
            Fecha:
          </Col>
          <Col
            style={{
              margin: "0px",
              padding: "2px",
            }}
            md="10"
          >
            <br />
          </Col>
        </Row>
      </Container>
    </Container>
  );

  const printPdf = () => {
    
    const dataToPrint = localStorage.getItem('pdfContentToDownload');
    
    if (dataToPrint) {
      
      var b64 = dataToPrint;

          // Embed the PDF into the HTML page and show it to the user
          var obj = document.createElement('object');
          obj.style.width = '100%';
          obj.style.height = '842pt';
          obj.style.display = 'none';
          obj.type = 'application/pdf';
          obj.data = 'data:application/pdf;base64,' + b64;
          document.body.appendChild(obj);

            // Insert a link that allows the user to download the PDF file
          var link = document.createElement('a');
          link.style.display = 'none';
          link.innerHTML = 'Download PDF file';
          link.download =  'AhorroProgramado_' + `${new Date().toISOString()}.pdf`;
          link.href = 'data:application/octet-stream;base64,' + b64;
          document.body.appendChild(link);
          link.click();
          
    }
    else {
      var elem = document.getElementById("pdf");
      var opt = {
        margin: 0,
        filename: `${new Date().toISOString()}.pdf`,
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
      };
      html2pdf().from(elem).set(opt).save();
    } 
  };

  const parseTableRowPDF = (value) => {
    var rows = [];
    if (value.secciones !== undefined && value.secciones !== null) {
      value.secciones?.forEach((entry) => {
        if (entry.campos !== null) {
          var header = { tipo: "TITULO", cols: [{ col: '12', valor: entry.nombre.toUpperCase() }], height: 1 };
          var rowCampos = [];

          var totalFila = 0;
          var cols = [];
          entry.campos.forEach((item) => {
            if (item.formularioVisible) {
              if (item.tipoValor?.trim() === "VALOR") {
                if ((+item.anchoColumnaFormulario) === 12 && (+item.anchoEtiquetaFormulario) === 12) {
                  if (cols.length > 0) {
                    rowCampos.push({ tipo: "CAMPOS", cols: [...cols], height: 1 });
                  }
                  rowCampos.push({ tipo: "TITULO", cols: [{ col: '12', valor: item.etiquetaFormulario }], height: 2 });
                  cols = [];
                  totalFila = 0;
                }
                else {
                  if (totalFila + (+item.anchoColumnaFormulario) <= 12) {
                    cols.push({ col: item.anchoColumnaFormulario + "", valor: item });
                    totalFila += (+item.anchoColumnaFormulario);
                  }
                  else {
                    cols.push({ col: (12 - totalFila) + "", valor: item });
                    totalFila = 12;
                  }
                  if (totalFila === 12) {
                    rowCampos.push({ tipo: "CAMPOS", cols: [...cols], height: 1 });
                    cols = [];
                    totalFila = 0;
                  }
                }

              } else if (item.tipoValor?.trim() === "LISTA") {
                var valLista = item.valoresLista?.filter(x => x.campos.find(f => f.codigo === "ACCION_CRUD" && f.valor !== "D") !== undefined)?.length;
                if (valLista === undefined || valLista === null) valLista = 0;
                var height = valLista + 1;
                rowCampos.push({ tipo: "CAMPOS", cols: [{ col: "12", valor: item }], height: height });
                cols = [];
                totalFila = 0;
              }
            }
          });

          if (rowCampos.length > 0) {
            rows.push(header);
            rows = [...rows, ...rowCampos];
          }
        }
        if (entry.secciones !== null && entry.secciones?.length > 0) {
          entry.secciones.forEach((subentry) => {
            var header = { tipo: "TITULO", cols: [{ col: '12', valor: subentry.nombre.toUpperCase() }], height: 1 };
            var rowCampos = [];

            var totalFila = 0;
            var cols = [];
            subentry?.campos?.forEach((item) => {
              if (item.formularioVisible) {

                if (item.tipoValor?.trim() === "VALOR") {
                  if ((+item.anchoColumnaFormulario) === 12 && (+item.anchoEtiquetaFormulario) === 12) {
                    if (cols.length > 0) {
                      rowCampos.push({ tipo: "CAMPOS", cols: [...cols], height: 1 });
                    }
                    rowCampos.push({ tipo: "TITULO", cols: [{ col: '12', valor: item.etiquetaFormulario }], height: 2 });
                    cols = [];
                    totalFila = 0;
                  }
                  else {
                    if (totalFila + (+item.anchoColumnaFormulario) <= 12) {
                      cols.push({ col: item.anchoColumnaFormulario + "", valor: item });
                      totalFila += (+item.anchoColumnaFormulario);
                    }
                    else {
                      cols.push({ col: (12 - totalFila) + "", valor: item });
                      totalFila = 12;
                    }
                    if (totalFila === 12) {
                      rowCampos.push({ tipo: "CAMPOS", cols: [...cols], height: 1 });
                      cols = [];
                      totalFila = 0;
                    }
                  }
                } else if (item.tipoValor?.trim() === "LISTA") {
                  var valLista = item.valoresLista?.filter(x => x.campos.find(f => f.codigo === "ACCION_CRUD" && f.valor !== "D") !== undefined)?.length;
                  if (valLista === undefined || valLista === null) valLista = 0;
                  var height = valLista + 1;
                  rowCampos.push({ tipo: "CAMPOS", cols: [{ col: "12", valor: item }], height: height });
                  cols = [];
                  totalFila = 0;
                }
              }
            });

            if (rowCampos.length > 0) {
              rows.push(header);
              rows = [...rows, ...rowCampos];
            }
          });
        }
      });
    }
    return rows;
  };

  const parseCLient = parseTableRowPDF(props.client);
  const parseProduct = parseTableRowPDF(props.product);

  var totalCampos = [...parseCLient];
  if (parseProduct.length > 0) {
    totalCampos = [...parseCLient, ...parseProduct];
  }

  var heightTotal = 2;

  return (
    <div className="shipping">
      <HeaderTitle label="Resumen" />
      <div style={{ display: "none" }}>
        <div id="pdf">
          {formHeader}
          {<Container
            style={{
              width: "100% !important",
              borderCollapse: "collapse",
              fontSize: "9px",
              fontFamily: "Verdana",
            }}
          >
            {totalCampos?.map((row, k) => {
              heightTotal += row.height;
              var breakP = false;
              if (heightTotal >= 48) {
                breakP = true;
                heightTotal = 0;
              }
              if (row.tipo === "TITULO") {
                return (<Fragment>
                  {breakP && (<Fragment>
                    <div class="html2pdf__page-break"></div>
                    <Row
                      key={k + row.cols[0].valor}
                      className={row.height === 1 ? "form-print-row" : "form-print-header"}
                      style={{
                        width: "100% !important",
                        borderRight: "1px solid black",
                        borderLeft: "1px solid black",
                        borderBottom: "1px solid black",
                        borderTop: "1px solid black",
                        fontWeight: "bold",
                        wordSpacing: "0.2rem",
                        margin: "0px",
                        padding: "0px",
                      }}
                    >
                      <Col>{row.cols[0].valor}</Col>
                    </Row>
                  </Fragment>)}
                  {!breakP && <Fragment>
                    <Row
                      key={k + row.cols[0].valor}
                      className={row.height === 1 ? "form-print-row" : "form-print-header"}
                      style={{
                        width: "100% !important",
                        borderRight: "1px solid black",
                        borderLeft: "1px solid black",
                        borderBottom: "1px solid black",
                        fontWeight: "bold",
                        wordSpacing: "0.2rem",
                        margin: "0px",
                        padding: "0px",
                      }}
                    >
                      <Col>{row.cols[0].valor}</Col>
                    </Row>
                  </Fragment>}
                </Fragment>);
              } else {
                return (<Fragment>
                  {breakP && <Fragment>
                    <div class="html2pdf__page-break"></div>
                    <Row
                      className={row.height === 1 ? "form-print-row" : ""}
                      style={{
                        width: "100% !important",
                        borderRight: "1px solid black",
                        borderTop: "1px solid black",
                        borderBottom: "1px solid black",
                      }}>
                      {row.cols?.map((col, idx) => {
                        const item = col.valor;
                        var valLista = item.valoresLista?.filter(x => x.campos.find(f => f.codigo === "ACCION_CRUD" && f.valor !== "D") !== undefined);
                        if (valLista === undefined) valLista = [];
                        return (
                          <FormField
                            key={idx}
                            columnW={item.anchoColumnaFormulario}
                            labelW={item.anchoEtiquetaFormulario}
                            label={item.etiquetaFormulario}
                            value={item.valor}
                            dataType={item.tipoDato}
                            fieldType={item.tipoCampo}
                            code={item.codigo}
                            valueType={item.tipoValor}
                            listHeaders={item.formatoModeloLista}
                            listValues={valLista}
                          />
                        );
                      })}
                    </Row>
                  </Fragment>}
                  {!breakP && <Row
                    className={row.height === 1 ? "form-print-row" : ""}
                    style={{
                      width: "100% !important",
                      borderRight: "1px solid black",
                      borderBottom: "1px solid black"
                    }}>
                    {row.cols?.map((col, idx) => {
                      const item = col.valor;
                      var valLista = item.valoresLista?.filter(x => x.campos.find(f => f.codigo === "ACCION_CRUD" && f.valor !== "D") !== undefined);
                      if (valLista === undefined) valLista = [];
                      return (
                        <FormField
                          key={idx}
                          columnW={item.anchoColumnaFormulario}
                          labelW={item.anchoEtiquetaFormulario}
                          label={item.etiquetaFormulario}
                          value={item.valor}
                          dataType={item.tipoDato}
                          fieldType={item.tipoCampo}
                          code={item.codigo}
                          valueType={item.tipoValor}
                          listHeaders={item.formatoModeloLista}
                          listValues={valLista}
                        />
                      );
                    })}
                  </Row>}
                </Fragment>);
              }
            })}
          </Container>
          }
          {/* {tablerowsPDF}
          {productos?.secciones !== undefined && productrowsPDF} */}
          <div class="html2pdf__page-break"></div>
          {/* {productos?.secciones !== undefined && (
            <div class="html2pdf__page-break"></div>
          )} */}
          {formDisclaimer}
        </div>
      </div>
      {summary !== null &&
        summary.length > 0 &&
        summary?.map((x) => {
          return (
            <Row className="justify-content-md-center">
              <Col xs lg="4" style={{ fontSize: "1rem" }}>
                <span style={{ fontWeight: "bold" }}>
                  {" "}
                  {x.etiqueta.toUpperCase()}:{" "}
                </span>
              </Col>
              <Col xs lg="4" style={{ fontSize: "1rem" }}>
                {x.valor}
              </Col>
            </Row>
          );
        })}
      <Row xs="auto" className="justify-content-end">
        <Col>
          <CustomButton
            size="md"
            class={buttonClasses["btn-custom"]}
            label="SALIR"
            eventHandler={props.cleanData}
          />
        </Col>
        <Col>
          <CustomButton
            size="md"
            class={buttonClasses["btn-custom"]}
            label="Descargar"
            icon="faDownload"
            eventHandler={printPdf}
             
            /*RF-2023-046
            SE MODIFICO PARA VISUALIZAR EN NINGUNO
            disabled={props.disablePrint}*/
            
          //eventHandler={() => {window.print()}}
          />
        </Col>
        {/* <Col>
          <CustomButton
            size="md"
            class={buttonClasses["btn-custom"]}
            label="Continuar"
            icon="faArrowRight"
            eventHandler={props.parentCallback}
          />
        </Col> */}
      </Row>
    </div>
  );
};

export default FormClientAccountCreation;
