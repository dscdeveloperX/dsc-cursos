import React, { useState } from "react";

const AuthContext = React.createContext({
  token: "",
  ip: "",
  user: "",
  role: "",
  executiveCode: "",
  vatId: "",
  area: "",
  email: "",
  agencyCode: "",
  menu: null,
  expirationTime: null,
  lastLoginDate: null,
  isLoggedIn: false,
  REACT_APP_BASE_URL: "",
  REACT_APP_SECURITY_BASE_URL: "",
  REACT_APP_SECURITY_APP_ID: 0,
  login: (
    token,
    user,
    ip,
    lastLoginDate,
    expirationTime,
    menu,
    role,
    executiveCode,
    email,
    vatId,
    area
  ) => { },
  logout: () => { },
  setConfig: (config) => { },
});

const calculateRemainingTime = (expirationTime) => {
  if (expirationTime === null) return -1;

  const date = new Date();
  const now_utc = Date.UTC(
    date.getUTCFullYear(),
    date.getUTCMonth(),
    date.getUTCDate(),
    date.getUTCHours(),
    date.getUTCMinutes(),
    date.getUTCSeconds()
  );
  const currentTime = new Date(now_utc).getTime();
  const adjExpirationTime = new Date(expirationTime).getTime();

  const remainingDuration = adjExpirationTime - currentTime;

  return remainingDuration;
};

export const AuthContextProvider = (props) => {
  const initialToken = localStorage.getItem("token");
  const initialUser = localStorage.getItem("user");
  const initialIp = localStorage.getItem("ip");
  const initialMenu = localStorage.getItem("menu");
  const initialUrl = localStorage.getItem("link");
  const initialRole = localStorage.getItem("role");
  const initialExecutiveCode = localStorage.getItem("executiveCode");
  const initialVatId = localStorage.getItem("vatId");
  const initialArea = localStorage.getItem("area");
  const initialEmail = localStorage.getItem("email");
  const initialSecurityUrl = localStorage.getItem("securitylink");
  const initialApp = localStorage.getItem("app");
  const initialExpiration = localStorage.getItem("expiration");
  const initialLoginDate = localStorage.getItem("lastLoginDate");
  const initialAgencyCode = localStorage.getItem("agencyCode");
  const [token, setToken] = useState(initialToken);
  const [expirationTime, setExpirationTime] = useState(initialExpiration);
  const [user, setUser] = useState(initialUser);
  const [role, setRole] = useState(initialRole);
  const [executiveCode, setExecutiveCode] = useState(initialExecutiveCode);
  const [vatId, setVatId] = useState(initialVatId);
  const [area, setArea] = useState(initialArea);
  const [email, setEmail] = useState(initialEmail);
  const [ip, setIp] = useState(initialIp);
  const [agencyCode, setAgencyCode] = useState(initialAgencyCode);
  const [menu, setMenu] = useState(initialMenu);
  const [lastLoginDate, setLastLoginDate] = useState(initialLoginDate);

  const userIsLoggedIn = !!token && calculateRemainingTime(expirationTime) > 0;

  const [isLoggedIn, setIsLoggedIn] = useState(userIsLoggedIn);
  const [REACT_APP_SECURITY_BASE_URL, setSecurityUrl] = useState(
    initialSecurityUrl
  );
  const [REACT_APP_BASE_URL, setUrl] = useState(initialUrl);
  const [REACT_APP_SECURITY_APP_ID, setApp] = useState(initialApp);

  const logoutHandler = () => {
    setToken(null);
    setUser(null);
    setRole(null);
    setExecutiveCode(null);
    setVatId(null);
    setArea(null);
    setEmail(null);
    setIp(null);
    setAgencyCode(null);
    setMenu(null);
    setExpirationTime(null);
    setLastLoginDate(null);
    setIsLoggedIn(false);
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("role");
    localStorage.removeItem("executiveCode");
    localStorage.removeItem("executiveCodeOK");
    localStorage.removeItem("vatId");
    localStorage.removeItem("area");
    localStorage.removeItem("email");
    localStorage.removeItem("agencyCode");
    localStorage.removeItem("agencyCodeOk");
    localStorage.removeItem("ip");
    localStorage.removeItem("menu");
    localStorage.removeItem("expiration");
    localStorage.removeItem("lastLoginDate");
    localStorage.removeItem('pdfContentToDownload');
  };  

  if (isLoggedIn && lastLoginDate !== undefined && lastLoginDate !== null) {
    const date = new Date();
    const now_utc = Date.UTC(
      date.getUTCFullYear(),
      date.getUTCMonth(),
      date.getUTCDate(),
      date.getUTCHours(),
      date.getUTCMinutes(),
      date.getUTCSeconds()
    );
    const today = new Date(now_utc);
    const lastLoginDay = new Date(lastLoginDate);

    if (
      lastLoginDay.getFullYear() === today.getFullYear() &&
      lastLoginDay.getMonth() === today.getMonth() &&
      lastLoginDay.getDate() === today.getDate()
    ) {
      //valid token
    } else {
      logoutHandler();
    }
  }

  const configHandler = (config) => {
    const confUrl =
      (config ? config.REACT_APP_BASE_URL : "") + "/api/v1/parametrizacion/";
    const confSecurityUrl =
      (config ? config.REACT_APP_SECURITY_BASE_URL : "") + "/api/v1/seguridad/";
    const confApp = config ? config.REACT_APP_SECURITY_APP_ID : 0;
    setUrl(confUrl);
    setSecurityUrl(confSecurityUrl);
    setApp(confApp);
    localStorage.setItem("app", REACT_APP_SECURITY_APP_ID);
    localStorage.setItem("link", REACT_APP_BASE_URL);
    localStorage.setItem("securitylink", REACT_APP_SECURITY_BASE_URL);
  };

  const loginHandler = (
    token,
    user,
    ip,
    agencyCode,
    lastLoginDate,
    expirationTime,
    menu,
    role,
    executiveCode,
    email,
    vatId,
    area
  ) => {
    setToken(token);
    setUser(user);
    setIp(ip);
    setMenu(JSON.stringify(menu));
    setExpirationTime(expirationTime);
    setLastLoginDate(lastLoginDate);
    setAgencyCode(agencyCode);
    setRole(role);
    setExecutiveCode(executiveCode);
    setEmail(email);
    setVatId(vatId);
    setArea(area);
    setIsLoggedIn(true);
    localStorage.setItem("token", token);
    localStorage.setItem("user", user);
    localStorage.setItem("ip", ip);
    localStorage.setItem("agencyCode", agencyCode);
    localStorage.setItem("expiration", expirationTime);
    localStorage.setItem("lastLoginDate", lastLoginDate);
    localStorage.setItem("menu", JSON.stringify(menu));
    localStorage.setItem("role", role);
    localStorage.setItem("executiveCode", executiveCode);
    localStorage.setItem("email", email);
    localStorage.setItem("vatId", vatId);
    localStorage.setItem("area", area);

    const remainingTime = calculateRemainingTime(expirationTime);
    setTimeout(logoutHandler, remainingTime);
  };

  const contextValue = {
    token: token,
    user: user,
    role: role,
    executiveCode: executiveCode,
    vatId: vatId,
    area: area,
    email: email,
    ip: ip,
    agencyCode: agencyCode,
    menu: menu,
    expirationTime: expirationTime,
    lastLoginDate: lastLoginDate,
    isLoggedIn: isLoggedIn,
    REACT_APP_BASE_URL: REACT_APP_BASE_URL,
    REACT_APP_SECURITY_BASE_URL: REACT_APP_SECURITY_BASE_URL,
    REACT_APP_SECURITY_APP_ID: REACT_APP_SECURITY_APP_ID,
    login: loginHandler,
    logout: logoutHandler,
    setConfig: configHandler,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
