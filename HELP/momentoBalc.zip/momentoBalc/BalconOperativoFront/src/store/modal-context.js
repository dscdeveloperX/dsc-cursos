import React, { useState } from "react";
import {
  checkRequired,
  checkVisible,
  checkEditable,
  filterCombobox,
  getDefaultValue,
  ObtenerValorCalculadoFront,
} from "./field-actions";

const ModalContext = React.createContext({
  fields: {},
  calculated: [],
  calculatedApi: {},
  loadingFields: {},
  defaultValues: {},
  filterValues: {},
  catalogueValues: {},

  setModalFields: (fieldsFormat, fieldsValues, fieldsParent) => { },
  updateModalFields: (code, value, fieldIndex) => { },
  updateApiModalFields: (values) => { },
  updateFieldApiCall: (codigo, value) => { },

  checkVisible: (code) => { },
  checkRequired: (code) => { },
  checkEditable: (code) => { },
});

export const ModalContextProvider = (props) => {
  const [fields, setFields] = useState({});
  const [calculated, setCalculated] = useState([]);
  const [calculatedApi, setCalculatedApi] = useState({});
  const [loadingFields, setLoadingFields] = useState({});
  const [defaultValues, setDefaultValues] = useState({});
  const [filterValues, setFilterValues] = useState({});
  const [catalogueValues, setCatalogueValues] = useState({});

  const setModalFieldsHandler = (fieldsFormat, fieldsValues, fieldsParent) => {
    var fieldDict = {};
    var calcl = [];
    var calclApi = [];

    var calcApi = {};
    var loadFields = {};

    var defaultVal = {};
    var filters = {};
    var catalogues = {};
    if (fieldsFormat !== null && fieldsFormat.length > 0) {
      for (var i = 0; i < fieldsFormat.length; i++) {
        var field = { ...fieldsFormat[i] };
        var code = field.codigo;

        //search value field
        var fieldValue = "";
        if (fieldsValues !== null) {
          var res = fieldsValues[code];
          if (res !== undefined) {
            fieldValue = res;
          }
        }
        field.valor = fieldValue;


        if (field.tipoCampo?.trim() === "CALCULADO") {
          if (field.tipoCalculado?.trim() === "FRONT") {
            calcl.push(field.codigo);
          }
          else if (field.tipoCalculado?.trim() === "API") {
            calclApi.push(field.codigo);
          }
        }

        if (field.valor === null || field.valor === "") {
          if (field.tipoValorDefecto?.trim() === "INICIAL") {
            if ("DEFAULT" in field.valoresDependenciaValorDefecto) {
              fieldsValues[code] = field.valoresDependenciaValorDefecto["DEFAULT"];
              field.valor = field.valoresDependenciaValorDefecto["DEFAULT"];
            }
          }
        }

        if (field.tipoValorDefecto?.trim() === "ONCHANGE") {
          if (field.dependenciaValorDefecto.trim() in defaultVal) {
            defaultVal[field.dependenciaValorDefecto.trim()].push(field.codigo);
          } else {
            var array = [];
            array.push(field.codigo);
            defaultVal[field.dependenciaValorDefecto.trim()] = array;
          }
        }

        //add field to dict
        fieldDict[code] = {
          field: field,
          fieldIndex: i,
        };

        if (field.tipoFiltro !== null && field.dependenciaFiltro !== null) {
          if (field.dependenciaFiltro.trim() in filters) {
            filters[field.dependenciaFiltro.trim()].push(field.codigo);
          } else {
            var array = [];
            array.push(field.codigo);
            filters[field.dependenciaFiltro.trim()] = array;
          }
          catalogues[field.codigo] = field.valoresCombobox;
        }
      }

      //VALORES POR DEFECTO
      if (code in defaultVal) {
        var dependentFields = defaultVal[code];
        dependentFields.forEach((fieldCode) => {
          var defaultFieldData = fieldDict[fieldCode];
          if (defaultFieldData !== null && defaultFieldData !== undefined) {
            const { defaultValue: valorDefault } = getDefaultValue(
              fieldDict,
              fieldCode
            );
            fieldsValues[fieldCode] = valorDefault;
            fieldDict[fieldCode].field.valor = valorDefault;
          }
        });
      }

      //VALORES CALCULADOS
      calcl.forEach((fieldCode) => {
        var calculatedFieldData = fieldDict[fieldCode];

        if (calculatedFieldData !== null && calculatedFieldData !== undefined) {
          var valorCal = ObtenerValorCalculadoFront(fieldDict, fieldCode, {
            agencyCode: "",
            user: "",
            executiveCode: "",
            vatId: "",
            area: "",
          }, fieldsParent);

          fieldsValues[fieldCode] = valorCal;
          fieldDict[fieldCode].field.valor = valorCal;
          if (fieldCode in defaultVal) {
            var dependentFields = defaultVal[fieldCode];
            dependentFields.forEach((fieldCodeDep) => {
              var defaultFieldData = fieldDict[fieldCodeDep];
              if (defaultFieldData !== null && defaultFieldData !== undefined) {
                const { defaultValue: valorDefault } = getDefaultValue(
                  fieldDict,
                  fieldCodeDep
                );

                fieldsValues[fieldCodeDep] = valorDefault;
                fieldDict[fieldCodeDep].field.valor = valorDefault;
              }
            });
          }
        }
      });

      //ACTUALIZAR FILTRO
      for (const [key, value] of Object.entries(catalogues)) {
        var fieldCode = key;
        var filterData = fieldDict[fieldCode];

        if (filterData !== null && filterData !== undefined) {
          const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
            fieldDict,
            fieldCode
          );
          catalogues[fieldCode] = valorFilter;
        }
      }

      //VALORES CALCULADOS FIELD
      if (calclApi.length > 0) {
        calclApi.forEach((fieldCodeApi) => {
          var calculatedApiFieldData = fieldDict[fieldCodeApi];

          if (calculatedApiFieldData !== null && calculatedApiFieldData !== undefined) {
            if (calculatedApiFieldData.field.valoresCalculo !== null && calculatedApiFieldData.field.valoresCalculo.length > 0) {
              for (var i = 0; i < calculatedApiFieldData.field.valoresCalculo.length; i++) {
                const codigo = calculatedApiFieldData.field.valoresCalculo[i];
                if (fieldDict[codigo] !== undefined) {
                  if (codigo in calcApi) {
                    calcApi[codigo] = [...calcApi[codigo], fieldCodeApi];
                  }
                  else {
                    calcApi[codigo] = [fieldCodeApi];
                  }
                }
                loadFields[fieldCodeApi] = false;
              }
            }
          }
        });
      }
    }
    setCalculatedApi(calcApi);
    setLoadingFields(loadFields);
    setFilterValues(filters);
    setDefaultValues(defaultVal);
    setCatalogueValues(catalogues);
    setCalculated(calcl);
    setFields(fieldDict);
    return fieldsValues;
  };

  const updateModalFieldsHandler = (code, field, fieldsValues, fieldsParent) => {
    var tempFieds = { ...fields };
    var tempCat = { ...catalogueValues };
    tempFieds[code].field.valor = field;
    fieldsValues[code] = field;

    //ACTUALIZAR FILTRO
    for (const [key, value] of Object.entries(tempCat)) {
      var fieldCode = key;
      var filterData = tempFieds[fieldCode];

      if (filterData !== null && filterData !== undefined) {
        const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
          tempFieds,
          fieldCode
        );
        tempCat[fieldCode] = valorFilter;

        if (!itemInArray && valorFilter.length > 0) {
          fieldsValues[fieldCode] = "";
          tempFieds[fieldCode].field.valor = "";
        }
      }
    }

    //VALORES POR DEFECTO
    if (code in defaultValues) {
      var dependentFields = defaultValues[code];
      dependentFields.forEach((fieldCode) => {
        var defaultFieldData = tempFieds[fieldCode];
        if (defaultFieldData !== null && defaultFieldData !== undefined) {
          const { defaultValue: valorDefault } = getDefaultValue(
            tempFieds,
            fieldCode
          );
          fieldsValues[fieldCode] = valorDefault;
          tempFieds[fieldCode].field.valor = valorDefault;
        }
      });
    }

    //VALORES CALCULADOS
    calculated.forEach((fieldCode) => {
      var calculatedFieldData = tempFieds[fieldCode];

      if (calculatedFieldData !== null && calculatedFieldData !== undefined) {
        var valorCal = ObtenerValorCalculadoFront(tempFieds, fieldCode, {
          agencyCode: "",
          user: "",
          executiveCode: "",
          vatId: "",
          area: "",
        }, fieldsParent);
        fieldsValues[fieldCode] = valorCal;
        tempFieds[fieldCode].field.valor = valorCal;

        if (fieldCode in defaultValues) {
          var dependentFields = defaultValues[fieldCode];
          dependentFields.forEach((fieldCodeDep) => {
            var defaultFieldData = tempFieds[fieldCodeDep];
            if (defaultFieldData !== null && defaultFieldData !== undefined) {
              const { defaultValue: valorDefault } = getDefaultValue(
                tempFieds,
                fieldCodeDep
              );
              fieldsValues[fieldCodeDep] = valorDefault;
              tempFieds[fieldCodeDep].field.valor = valorDefault;
            }
          });
        }
      }
    });
    setFields(tempFieds);
    setCatalogueValues(tempCat);
    return fieldsValues;
  };

  const updateFieldApiResHandler = (dictValues, code, fieldsValues) => {
    var tempFieds = { ...fields };
    var loadFields = { ...loadingFields };

    loadFields[code] = false;

    for (const [key, value] of Object.entries(dictValues)) {
      var fieldCode = key;
      var fieldValue = value;

      var updateDta = tempFieds[fieldCode];

      if (updateDta !== null && updateDta !== undefined) {
        fieldsValues[fieldCode] = fieldValue;
        updateDta.field.valor = fieldValue;
      }
    }
    setLoadingFields(loadFields);
    setFields(tempFieds);
    return fieldsValues;
  };

  const updateFieldApiCallHandler = (code, value) => {
    if (code in calculatedApi) {
      var valoresCalc = [...calculatedApi[code]];
      var loadFields = { ...loadingFields };

      valoresCalc.forEach((codeField) => {
        loadFields[codeField] = true;
      });
      setLoadingFields(loadFields);
    }
  };

  const checkVisibleHandler = (code) => {
    return checkVisible(fields, code);
  };
  const checkRequiredHandler = (code) => {
    return checkRequired(fields, code);
  };
  const checkEditableHandler = (code) => {
    return checkEditable(fields, code);
  };

  const contextValue = {
    fields: fields,
    calculated: calculated,
    loadingFields: loadingFields,
    defaultValues: defaultValues,
    filterValues: filterValues,
    catalogueValues: catalogueValues,
    //values set
    setModalFields: setModalFieldsHandler,
    updateModalFields: updateModalFieldsHandler,
    updateApiModalFields: updateFieldApiResHandler,
    updateFieldApiCall: updateFieldApiCallHandler,
    //field check
    checkVisible: checkVisibleHandler,
    checkRequired: checkRequiredHandler,
    checkEditable: checkEditableHandler,
  };

  return (
    <ModalContext.Provider value={contextValue}>
      {props.children}
    </ModalContext.Provider>
  );
};

export default ModalContext;
