const evalCondition = (condition, fields) => {
  var res = false;
  if (condition.includes(">=")) {
    var [fieldName, val] = condition.split(">=");

    fieldName = fieldName.replace("[", "").replace("]", "").trim();
    var fieldVal = fields[fieldName]?.field?.valor;

    return +fieldVal >= +val;
  }
  else if (condition.includes("<=")) {
    var [fieldName, val] = condition.split("<=");

    fieldName = fieldName.replace("[", "").replace("]", "").trim();
    var fieldVal = fields[fieldName]?.field?.valor;

    return +fieldVal <= +val;
  }
  if (condition.includes(">")) {
    var [fieldName, val] = condition.split(">");

    fieldName = fieldName.replace("[", "").replace("]", "").trim();
    var fieldVal = fields[fieldName]?.field?.valor;

    return +fieldVal > +val;
  }
  else if (condition.includes("<")) {
    var [fieldName, val] = condition.split("<");

    fieldName = fieldName.replace("[", "").replace("]", "").trim();
    var fieldVal = fields[fieldName]?.field?.valor;

    return +fieldVal < +val;
  }
  else if (condition.includes("=")) {
    var [fieldName, val] = condition.split("=");

    fieldName = fieldName.replace("[", "").replace("]", "").trim();
    var fieldVal = fields[fieldName]?.field?.valor;

    return fieldVal === val;
  }
  return res;
}

export const checkOperationType = (rule, enteredValue, fields) => {
  let operation = rule.operacion;
  let opValues = rule.valores;
  if (operation === "IN") {
    return opValues.includes(enteredValue);
  } else if (operation === "NOT IN") {
    return !opValues.includes(enteredValue);
  } else if (operation === "AND") {
    var evalRes = opValues.map((cond) => {
      return evalCondition(cond, fields);
    });
    return evalRes.every(x => x === true);
  } else if (operation === "OR") {
    var evalRes = opValues.map((cond) => {
      return evalCondition(cond, fields);
    });
    return evalRes.some(x => x === true);
  } else if (operation === ">") {
    var valRule = opValues[0];
    return +enteredValue > +valRule;
  } else if (operation === "<") {
    var valRule = opValues[0];
    return +enteredValue < +valRule;
  }
  else if (operation === ">=") {
    var valRule = opValues[0];
    return +enteredValue >= +valRule;
  } else if (operation === "<=") {
    var valRule = opValues[0];
    return +enteredValue <= +valRule;
  }
  return false;
};

const filterValues = (rule, valuesCombobox, dependencyValue) => {
  let operation = rule.operacion;
  let opValues = rule.valores;
  if (operation === "IN") {
    return valuesCombobox.filter((x) => opValues.includes(x.codigo));
  } else if (operation === "NOT IN") {
    return valuesCombobox.filter((x) => !opValues.includes(x.codigo));
  } else if (operation === "NONE") {
    return valuesCombobox;
  } else if (operation === "INI") {
    var ini = opValues[0];
    if (ini === "${VALUE}") {
      ini = dependencyValue + "";
    }
    return valuesCombobox.filter((x) => x.codigo.startsWith(ini.trim()));
  }
  return [];
};

export const checkEditable = (fields, code) => {
  if (fields[code] === undefined) {
    return false;
  }
  var selectedField = fields[code].field;

  if (selectedField.editable) {
    if (selectedField.dependenciaEditable === null) {
      return true;
    } else {
      if (selectedField.reglaDependenciaEditable === "OPERACION") {
        let dependencyField = fields[selectedField.dependenciaEditable].field;
        let rule = {};
        if (dependencyField.valor in selectedField.valoresDependenciaEditable) {
          rule =
            selectedField.valoresDependenciaEditable[dependencyField.valor];
        } else {
          rule = selectedField.valoresDependenciaEditable["DEFAULT"];
        }
        return checkOperationType(rule, dependencyField.valor, fields);
      } else if (selectedField.reglaDependenciaEditable === "NOTEMPTY") {
        if (selectedField.valor === null && selectedField.valor === "") {
          return true;
        }
      }
    }
  }
  return false;
};



export const checkVatRuc = (x) => {
  if (
    x === "2222222222" ||
    x === "4444444444" ||
    x === "5555555555" ||
    x === "7777777777" ||
    x === "9999999999"
  ) {
    return false;
  }
  if (x === null || x === "" || parseInt(x) === undefined || x.length < 13) {
    return false;
  }else{
    return dsc_esRucValido(x);//valida ruc
  }

  
};




export const checkVatId = (x) => {
  if (
    x === "2222222222" ||
    x === "4444444444" ||
    x === "5555555555" ||
    x === "7777777777" ||
    x === "9999999999"
  ) {
    return false;
  }
  if (x === null || x === "" || parseInt(x) === undefined || x.length !== 10) {
    return false;
  }
  var suma = 0;
  var a = Array(5).fill(0);
  var b = Array(5).fill(0);
  var c = 0;
  var d = 1;
  for (var i = 0; i < 5; i++) {
    a[i] = parseInt(x.charAt(c) + "");
    c += 2;
    if (i < 5 - 1) {
      b[i] = parseInt(x.charAt(d) + "");
      d += 2;
    }
  }
  for (var i = 0; i < a.length; i++) {
    a[i] *= 2;
    if (a[i] > 9) {
      a[i] -= 9;
    }
    suma = suma + a[i] + b[i];
  }

  var aux = Math.trunc(suma / 10);
  var dec = (aux + 1) * 10;
  if (dec - suma === parseInt(x[x.length - 1] + "")) {
    return true;
  }
  return suma % 10 === 0 && x[x.length - 1] === "0";
};

export const getFieldLocation = (fields, model, code) => {
  if (fields[code] === undefined) {
    return '';
  }

  let sectionIndex = fields[code].sectionIndex;
  let subSectionIndex = fields[code].subSectionIndex;

  if (model.secciones !== null && model.secciones.length > 0 && model.secciones.length > sectionIndex) {
    let section = model.secciones[sectionIndex];
    let sectionName = section.nombre;

    if (subSectionIndex !== -1 && section.secciones !== null && section.secciones.length > 0 && section.secciones.length > subSectionIndex) {
      let subsection = section.secciones[subSectionIndex];
      let subsectionName = subsection.nombre;

      return sectionName + "/" + subsectionName + "/" + fields[code].field.etiquetaDetalle;
    }
    return sectionName + "/" + fields[code].field.etiquetaDetalle;
  }
  return fields[code].field.etiquetaDetalle
}

export const checkValidation = (fields, code) => {
  if (fields[code] === undefined) {
    return false;
  }

  let selectedField = fields[code].field;

  let isValidationRequired = false;

  //RUTINA, REGEX, REGLA
  if (selectedField.dependenciaValidacion === null) {
    isValidationRequired = true;
  } else {
    if (selectedField.reglaDependenciaValidacion?.trim() === "OPERACION") {
      let dependencyField =
        fields[selectedField.dependenciaValidacion?.trim()].field;
      let rule = {};
      if (dependencyField.valor in selectedField.valoresDependenciaValidacion) {
        rule =
          selectedField.valoresDependenciaValidacion[dependencyField.valor];
      } else {
        rule = selectedField.valoresDependenciaValidacion["DEFAULT"];
      }
      isValidationRequired = checkOperationType(rule, dependencyField.valor, fields);
    }
  }

  if (isValidationRequired === true) {
    if (selectedField.tipoValidacion?.trim() === "RUTINA") {
      if (selectedField.validacionRutina?.trim() === "ValidarCedula") {
        return checkVatId(selectedField.valor);
      }
      if (selectedField.validacionRutina?.trim() === "ValidarRuc") {
        return checkVatRuc(selectedField.valor);
      }
    } else if (selectedField.tipoValidacion?.trim() === "REGEX") {
      let regex = new RegExp(selectedField.validacionRegex?.trim());
      console.log("regex: " + regex);
      console.log("valor: " + selectedField.valor);
      console.log("return: " + regex.test(selectedField.valor + ""));
      return regex.test(selectedField.valor + "");
    } else if (selectedField.tipoValidacion?.trim() === "REGLA") {
      let valrule = { ...selectedField.validacionReglas["DEFAULT"] };
      valrule.valores = valrule.valores.map(x => ObtenerValorDependencia(
        fields,
        x
      ));
      return checkOperationType(valrule, selectedField.valor, fields);
    }
  } else {
    return true;
  }
};

export const checkRequired = (fields, code) => {
  if (fields[code] === undefined) {
    return false;
  }
  let selectedField = fields[code].field;

  if (selectedField.requerido) {
    if (
      selectedField.dependenciaRequerido === null ||
      selectedField.dependenciaRequerido === ""
    ) {
      return true;
    } else {
      if (selectedField.reglaDependenciaRequerido === "OPERACION") {
        let dependencyField = fields[selectedField.dependenciaRequerido].field;
        let rule = {};
        if (
          dependencyField.valor in selectedField.valoresDependenciaRequerido
        ) {
          rule =
            selectedField.valoresDependenciaRequerido[dependencyField.valor];
        } else {
          rule = selectedField.valoresDependenciaRequerido["DEFAULT"];
        }
        return checkOperationType(rule, dependencyField.valor, fields);
      } else if (selectedField.reglaDependenciaRequerido === "NOTEMPTY") {
        if (selectedField.valor === null && selectedField.valor === "") {
          return true;
        }
      }
    }
  }
  return false;
};

export const checkVisible = (fields, code) => {
  if (fields[code] === undefined) {
    return false;
  }
  let selectedField = fields[code].field;

  if (selectedField.visible) {
    if (selectedField.dependenciaVisibilidad === null) {
      return true;
    } else {
      if (selectedField.reglaDependenciaVisibilidad === "OPERACION") {
        let dependencyField =
          fields[selectedField.dependenciaVisibilidad].field;
        let rule = {};
        if (
          dependencyField.valor in selectedField.valoresDependenciaVisibilidad
        ) {
          rule =
            selectedField.valoresDependenciaVisibilidad[dependencyField.valor];
        } else {
          rule = selectedField.valoresDependenciaVisibilidad["DEFAULT"];
        }
        var valor = checkOperationType(rule, dependencyField.valor, fields);
        return valor;
      } else if (selectedField.reglaDependenciaVisibilidad === "NOTEMPTY") {
        if (selectedField.valor === null && selectedField.valor === "") {
          return true;
        }
      }
    }
  }
  return false;
};

export const filterCombobox = (fields, code) => {
  if (fields[code] === undefined) {
    return { valuesCombo: [], updatedInfo: false, itemInArray: true };
  }
  let selectedField = fields[code].field;

  if (selectedField.tipoFiltro?.trim() === "ONCHANGE") {
    if (selectedField.dependenciaFiltro === null) {
      return {
        valuesCombo: selectedField.valoresCombobox,
        updatedInfo: false,
        itemInArray: true,
      };
    } else {
      let rule = {};
      let dependencyField = null;
      if (selectedField.reglaDependenciaFiltro === "CONDICIONAL") {
        dependencyField = fields[selectedField.dependenciaFiltro].field;
        if (dependencyField.valor in selectedField.valoresDependenciaFiltro) {
          rule = selectedField.valoresDependenciaFiltro[dependencyField.valor];
        } else {
          rule = selectedField.valoresDependenciaFiltro["DEFAULT"];
        }
      } else if (selectedField.reglaDependenciaFiltro === "VALOR") {
        rule = selectedField.valoresDependenciaFiltro["DEFAULT"];
      }
      var filtrados = filterValues(
        rule,
        selectedField.valoresCombobox,
        dependencyField?.valor
      );

      const findItem = filtrados.find((x) => x.codigo === selectedField.valor);

      return {
        valuesCombo: filtrados,
        updatedInfo: true,
        itemInArray: findItem !== undefined,
      };
    }
  }
  return {
    valuesCombo: selectedField.valoresCombobox,
    updatedInfo: false,
    itemInArray: true,
  };
};
export const getDefaultValue = (fields, code) => {
  if (fields[code] === undefined) {
    return { defaultValue: "", updatedValue: false };
  }
  let selectedField = fields[code].field;

  if (selectedField.tipoValorDefecto?.trim() === "ONCHANGE") {
    if (selectedField.dependenciaValorDefecto === null) {
      return { defaultValue: selectedField.valor, updatedValue: false };
    } else {
      let rule = {};
      let dependencyField = null;
      if (
        selectedField.reglaDependenciaValorDefecto?.trim() === "CONDICIONAL"
      ) {
        dependencyField = fields[selectedField.dependenciaValorDefecto].field;
        if (
          dependencyField.valor in selectedField.valoresDependenciaValorDefecto
        ) {
          rule =
            selectedField.valoresDependenciaValorDefecto[dependencyField.valor];
        } else {
          rule = selectedField.valoresDependenciaValorDefecto["DEFAULT"];
          if (rule === "") rule = selectedField.valor;
        }
      } else if (selectedField.reglaDependenciaValorDefecto === "VALOR") {
        rule = selectedField.valoresDependenciaValorDefecto["DEFAULT"];
        if (rule === "") rule = selectedField.valor;
      }
      if (typeof rule === 'string') {
        if (rule?.trim() === "${VALUE}") {
          rule = dependencyField.valor + "";
        } else if (rule?.trim() === "${CMPL}") {
          const findItem = dependencyField.valoresCombobox?.find(
            (x) => x.codigo === dependencyField.valor
          );
          rule = findItem ? findItem.complemento + "" : "";
        } else if (rule?.trim() === "${DESCR}") {
          const findItem = dependencyField.valoresCombobox?.find(
            (x) => x.codigo === dependencyField.valor
          );
          rule = findItem ? findItem.descripcion + "" : "";
        } else if (rule?.trim() === "${TODAY}") {
          if (
            selectedField.valor === null ||
            selectedField.valor === "" ||
            selectedField === undefined
          ) {
            rule = new Date(Date.now()).toISOString();
          } else {
            rule = selectedField.valor;
          }
        } else if (rule?.trim() === "${EMPTY}") {
          rule = "";
        } else if (rule[0] === "[" && rule[rule.length - 1] === "]") {
          var codeField = rule.replace("[", "").replace("]", "");
          var refField = fields[codeField]?.field;
          rule = refField?.valor;
        } else if (rule[0] === "?") {
          //CONDICIONAL OTRO CAMPO
          //?[RELACION_LABORAL]=02?I:${EMPTY}
          const [spce, depen, valores] = rule.split("?");

          const [fielddepen, fielddepenvalue] = depen.split("=");
          const [valtrue, valfalse] = valores.split(":");

          var codeField = fielddepen.replace("[", "").replace("]", "");
          var refField = fields[codeField]?.field?.valor;
          if (refField === fielddepenvalue) {
            rule = valtrue?.trim() === "${EMPTY}" ? "" : valtrue;
          }
          else {
            rule = valfalse?.trim() === "${EMPTY}" ? "" : valfalse;
          }
        }
      }

      return { defaultValue: rule, updatedValue: selectedField.valor !== rule };
    }
  }
  return { defaultValue: selectedField.valor, updatedValue: false };
};

export const getComboboxRefValues = (fields, code) => {
  var values = [];

  if (fields[code] === undefined) {
    return [];
  }

  let convertList = fields[code].convertList;

  const [codigo, complement, descripcion, modelo] = convertList;

  const valoresCombo = fields[modelo.descripcion]?.field.valoresLista?.filter(x => x.campos.find(f => f.codigo === "ACCION_CRUD" && f.valor !== "D") !== undefined);

  if (
    valoresCombo !== undefined &&
    valoresCombo !== null &&
    valoresCombo?.length > 0
  ) {
    for (var i = 0; i < valoresCombo.length; i++) {
      var valCodigo = valoresCombo[i].campos.find(
        (x) => x.codigo === codigo.descripcion
      );
      var valDescr = valoresCombo[i].campos.find(
        (x) => x.codigo === descripcion.descripcion
      );
      var valComplemento = valoresCombo[i].campos.find(
        (x) => x.codigo === complement.descripcion
      );
      values.push({
        codigo: valCodigo.valor,
        descripcion: valDescr.valor,
        complemento: valComplemento.valor,
      });
    }
  }
  return values;
};

export const ObtenerDescripcionCombobox = (
  fieldsInit,
  codigoCampo,
  codigoValor
) => {
  var descripcion = codigoValor;
  if (fieldsInit[codigoCampo?.trim()] !== undefined) {
    var valores = fieldsInit[codigoCampo?.trim()].field.valoresCombobox;
    var found = valores.find((x) => x.codigo?.trim() === codigoValor?.trim());
    if (found !== undefined) {
      descripcion = found.descripcion;
    }
  }
  return descripcion;
};

export const ObtenerValorDependencia = (fieldsInit, nombreDepen) => {
  if (nombreDepen === "${TODAY}") {
    return new Date(Date.now()).toISOString();
  } else if (nombreDepen?.startsWith("$[")) {
    var valor = nombreDepen?.replace("$[", "").replace("]", "");
    return valor;
  } else {
    if (fieldsInit[nombreDepen] === undefined) {
      return "";
    }
    var field = fieldsInit[nombreDepen]?.field;

    if (field.tipoValor === "VALOR") {
      return field?.valor;
    } else {
      return field?.valoresLista;
    }
  }
};

export const ObtenerValorCalculadoFront = (
  fieldsInit,
  codigo,
  authCtx,
  fieldsParent
) => {
  let field = fieldsInit[codigo]?.field;

  if (field === undefined || field === null) return "";

  var inicial = field.valor;
  const valoresCalculo = field.valoresCalculo;

  if (field.tipoCalculado === "FRONT") {
    switch (field.nombreCalculo) {
      case "VerificadorFATCA":
        const [
          nacionalidad,
          tieneOtraNacionalidad,
          otraNacionalidad,
          paisNacimientoPadresEEUU,
          tarjetaResidenciaEEUU,
          EstuvoMas183dias,
        ] = valoresCalculo;

        const nac = ObtenerValorDependencia(fieldsInit, nacionalidad);
        const tieneOtraNac = ObtenerValorDependencia(
          fieldsInit,
          tieneOtraNacionalidad
        );
        const otraNac = ObtenerValorDependencia(fieldsInit, otraNacionalidad);
        const nacPadres = ObtenerValorDependencia(
          fieldsInit,
          paisNacimientoPadresEEUU
        );
        const tarjeta = ObtenerValorDependencia(
          fieldsInit,
          tarjetaResidenciaEEUU
        );
        const masDias = ObtenerValorDependencia(fieldsInit, EstuvoMas183dias);
        inicial = "N";
        if (
          nac?.trim() === "US" ||
          (tieneOtraNac?.trim() === "1" && otraNac?.trim() === "US") ||
          nacPadres?.trim() === "1" ||
          tarjeta?.trim() === "1" ||
          masDias?.trim() === "1"
        ) {
          inicial = "S";
        }
        break;
      case "ObtenerIdentificacionUsuario":
        inicial = authCtx.vatId;
        break;
      case "ObtenerZona":
        inicial = authCtx.area;
        break;
      case "ConcatenarCampos":
        if (valoresCalculo !== null && valoresCalculo.length > 0) {
          var cadena = "";
          for (var i = 0; i < valoresCalculo.length; i++) {
            var valorConsulta = ObtenerValorDependencia(
              fieldsInit,
              valoresCalculo[i]
            );
            cadena = cadena + valorConsulta;
          }
          inicial = cadena;
        } else {
          inicial = field.valor;
        }
        break;
      case "ObtenerAgencia":
         /*if(inicial === null || inicial === ''){
           inicial = authCtx.agencyCode;
         }*/
        if((inicial === null || inicial === '') && (localStorage.getItem('agencyCodeOK') === '' || localStorage.getItem('agencyCodeOK') === null)){
          inicial = authCtx.agencyCode;
          localStorage.setItem("agencyCodeOK", inicial);
        }else{
          if(inicial !== ""){
            localStorage.setItem("agencyCodeOK", inicial);
            /* inicial = localStorage.getItem("agencyCodeOK");           */
          }else{
            inicial = localStorage.getItem("agencyCodeOK"); 
          }
        }
        break;
        case "ObtenerAgencia2": 
        inicial = localStorage.getItem("agencyCode");  
        break;
      case "ObtenerCodEjecutivo":
          if((inicial === null || inicial === '') && (localStorage.getItem('executiveCodeOK') === '' || localStorage.getItem('executiveCodeOK') === null)){
            inicial = authCtx.executiveCode;
            localStorage.setItem("executiveCodeOK", inicial);
          }else{
            if(inicial !== ""){
              localStorage.setItem("executiveCodeOK", inicial);
              // inicial = localStorage.getItem("executiveCodeOK");           
            }else{
              inicial = localStorage.getItem("executiveCodeOK");
            }
          }
        //--------------------------------------
        // if(inicial === null || inicial === ''){
        //   inicial = authCtx.executiveCode;
        //   localStorage.setItem("executiveCodeOK", inicial);
        // }else{
        //   localStorage.setItem("executiveCodeOK", inicial);
        // }
        break;
      case "ObtenerFechaHoraSistema":
        var tzoffset = (new Date()).getTimezoneOffset() * 60000; //offset in milliseconds
        var localISOTime = (new Date(Date.now() - tzoffset)).toISOString().slice(0, -1);
        inicial = localISOTime;
        break;
      case "ObtenerUsuario":
        inicial = authCtx.user;
        break;
      case "ObtenerValorCampo":
        if (valoresCalculo !== null && valoresCalculo.length > 0) {
          var valorConsulta = ObtenerValorDependencia(
            fieldsInit,
            valoresCalculo[0]
          );
          inicial = valorConsulta;
        } else {
          inicial = field.valor;
        }
        break;
      case "CalcularSuma":
        if (valoresCalculo !== null && valoresCalculo.length > 0) {
          var suma = 0.0;
          for (var i = 0; i < valoresCalculo.length; i++) {
            suma += +ObtenerValorDependencia(fieldsInit, valoresCalculo[i]);
          }
          inicial = suma;
        } else {
          inicial = "0.00";
        }
        break;
      case "CalcularMultiplicacion":
        if (valoresCalculo !== null && valoresCalculo.length > 0) {
          var multiplicacion = 1;
          for (var i = 0; i < valoresCalculo.length; i++) {
            multiplicacion *= +ObtenerValorDependencia(
              fieldsInit,
              valoresCalculo[i]
            );
          }
          inicial = multiplicacion;
        } else {
          inicial = "0.00";
        }
        break;
      case "CalcularDivision":
        if (valoresCalculo !== null && valoresCalculo.length > 0) {
          var division = ObtenerValorDependencia(fieldsInit, valoresCalculo[0]);
          for (var i = 1; i < valoresCalculo.length; i++) {
            var divisor = +ObtenerValorDependencia(fieldsInit, valoresCalculo[i]);
            if (divisor === 0) return "0.00";
            division /= divisor
          }
          inicial = division;
        } else {
          inicial = "0.00";
        }
        break;
      case "CalcularDiferenciaFecha":
        var fecha1 = ObtenerValorDependencia(fieldsInit, valoresCalculo[0]);
        var fecha2 = ObtenerValorDependencia(fieldsInit, valoresCalculo[1]);

        if (
          fecha1 !== null &&
          fecha1 !== "" &&
          fecha2 !== null &&
          fecha2 !== ""
        ) {
          var date1 = new Date(fecha1);
          var date2 = new Date(fecha2);

          var ynew = date1.getFullYear();
          var mnew = date1.getMonth();
          var dnew = date1.getDate();
          var yold = date2.getFullYear();
          var mold = date2.getMonth();
          var dold = date2.getDate();
          var diff = ynew - yold;
          if (mold > mnew) diff--;
          else {
            if (mold == mnew) {
              if (dold > dnew) diff--;
            }
          }
          inicial = "" + diff;
        } else {
          inicial = "0";
        }

        break;
      case "CalcularDiferencia":
        if (valoresCalculo !== null && valoresCalculo.length > 0) {
          var diferencia = ObtenerValorDependencia(
            fieldsInit,
            valoresCalculo[0]
          );
          for (var i = 1; i < valoresCalculo.length; i++) {
            diferencia -= +ObtenerValorDependencia(
              fieldsInit,
              valoresCalculo[i]
            );
          }
          inicial = diferencia;
        } else {
          inicial = "0.00";
        }
        break;
      case "ObtenerSubCadena":
        const [campo, init, length] = valoresCalculo;

        const stringField = "" + ObtenerValorDependencia(fieldsInit, campo);
        const initSub = +ObtenerValorDependencia(fieldsInit, init);
        const lengthSub = +ObtenerValorDependencia(fieldsInit, length);
        inicial = stringField.substring(initSub, initSub + lengthSub);
        break;
      case "ObtenerEstacionTrabajo":
        inicial = "BALCON";
        break;
      case "ObtenerValorCampoModeloRef":
        if (valoresCalculo !== null && valoresCalculo.length > 0) {
          var valorConsulta = ObtenerValorDependencia(
            fieldsParent,
            valoresCalculo[0]
          );
          inicial = valorConsulta;
        } else {
          inicial = field.valor;
        }
        break;
      case "VerificadorFATCAAccionistas":
        inicial = "N";
        const [valorCalculo, campoParticipacion, porcentaje, campoEstadoFatca] =
          valoresCalculo;

        var valoresLista = ObtenerValorDependencia(fieldsInit, valorCalculo);
        var campPart = ObtenerValorDependencia(fieldsInit, campoParticipacion);
        var porcentajeMin = ObtenerValorDependencia(fieldsInit, porcentaje);
        var campFatca = ObtenerValorDependencia(fieldsInit, campoEstadoFatca);

        if (valoresLista !== undefined && valoresLista !== null && valoresLista.length > 0) {
          for (var i = 0; i < valoresLista.length; i++) {
            var accionista = valoresLista[i];
            var participacion = accionista.campos.find(
              (x) => x.codigo === campPart
            );
            if (participacion !== undefined && porcentajeMin !== undefined) {
              var valorPart = +participacion.valor;
              if (valorPart > +porcentajeMin) {
                var estadoFatca = accionista.campos.find(
                  (x) => x.codigo === campFatca
                );
                if (estadoFatca !== undefined) {
                  var valorEstado = estadoFatca.valor;
                  if (valorEstado === "S") {
                    inicial = "S";
                    return inicial;
                  }
                }
              }
            }
          }
        }

        break;
      default:
        break;
    }
  }
  return inicial;
};

export const ObtenerValorCalculadoApi = async (fieldsInit, codigo, authCtx) => {
  let field = fieldsInit[codigo]?.field;

  if (field === undefined || field === null) return "";
  var inicial = {};
  const valoresCalculo = field.valoresCalculo;

  if (field.tipoCalculado === "API") {
    var valores = {};
    if (valoresCalculo !== null && valoresCalculo.length > 0) {
      for (var i = 0; i < valoresCalculo.length; i++) {
        const codigo = valoresCalculo[i];
        const valor = ObtenerValorDependencia(fieldsInit, codigo);

        if (valor === undefined || valor === null || valor?.trim() === "") {
          return "";
        }

        valores[codigo] = valor;
      }
    }
    const request = {
      headerRequest: {
        username: authCtx.user,
        stationIp: authCtx.ip,
        dateTime: new Date().toISOString(),
        pageSize: 10,
        pageRequested: 1,
      },
      bodyRequest: {
        campoCalculado: codigo,
        nombreCalculo: field.nombreCalculo,
        valoresCalculo: valores,
      },
    };
    const response = await fetch(
      authCtx.REACT_APP_BASE_URL + "balcon/CalcularCampoEnLinea",
      {
        method: "POST",
        body: JSON.stringify(request),
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + authCtx.token,
        },
      }
    ).catch(_ => {
      throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
    });

    const resText = await response.text();
    const data = resText && JSON.parse(resText);
    if (!response.ok) {
      if ([401, 403].includes(response.status)) {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
      if (data?.headerResponse !== undefined) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      } else {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
    }

    if (data.bodyResponse?.resultado) {
      return data.bodyResponse.resultado;
    }
  }
  return inicial;
};

export const AsignarValor = (
  tempClt,
  sectionIndex,
  subSectionIndex,
  fieldIndex,
  field
) => {
  if (subSectionIndex > -1) {
    tempClt.secciones[sectionIndex].secciones[subSectionIndex].campos[
      fieldIndex
    ] = field;
  } else {
    tempClt.secciones[sectionIndex].campos[fieldIndex] = field;
  }
};

export const ValidarCamposRequeridos = (fields, fieldsState) => {
  //funcion que valida que los campos requeridos se encuentran llenos
  let errors = [];
  for (const seccionIdx in fields?.secciones) {
    let seccion = fields.secciones[seccionIdx];
    if (seccion.secciones !== null) {
      for (const subsectionIdx in seccion.secciones) {
        let subsection = seccion.secciones[subsectionIdx];
        if (subsection.campos !== null) {
          for (const campoIdx in subsection.campos) {
            let campo = subsection.campos[campoIdx];
            if (campo.tipoValor === "VALOR") {
              var requerido = checkRequired(fieldsState, campo.codigo);
              var editable = checkEditable(fieldsState, campo.codigo);
              var visible = checkVisible(fieldsState, campo.codigo);
              if (requerido === true && editable === true && visible == true) {
                if (
                  campo.valor === null ||
                  campo.valor === undefined ||
                  campo.valor === "" ||
                  (campo.valor + "").length < campo.longitudMinimaDetalle
                ) {
                  var errorDetalle = seccion.nombre + "/" + subsection.nombre + "/" + campo.etiquetaDetalle;
                  errors.push(errorDetalle);
                }
              }
            } else if (campo.tipoValor === "LISTA") {
              var requerido = checkRequired(fieldsState, campo.codigo);
              var editable = checkEditable(fieldsState, campo.codigo);
              var visible = checkVisible(fieldsState, campo.codigo);
              if (requerido === true && editable === true && visible == true) {
                if (
                  campo.valoresLista === null ||
                  campo.valoresLista === undefined ||
                  campo.valoresLista?.length < campo.longitudMinimaDetalle ||
                  campo.valoresLista.filter(x => x.campos.find(f => f.codigo === "ACCION_CRUD" && f.valor !== "D") !== undefined)?.length < campo.longitudMinimaDetalle) {
                  var errorDetalle = seccion.nombre + "/" + subsection.nombre + "/" + campo.etiquetaDetalle;
                  errors.push(errorDetalle);
                }
              }
            }
          }
        }
      }
    }
    if (seccion.campos !== null) {
      for (const campoIdx in seccion.campos) {
        let campo = seccion.campos[campoIdx];
        if (campo.tipoValor === "VALOR") {
          var requerido = checkRequired(fieldsState, campo.codigo);
          var editable = checkEditable(fieldsState, campo.codigo);
          var visible = checkVisible(fieldsState, campo.codigo);
          if (requerido === true && editable === true && visible == true) {
            if (
              campo.valor === null ||
              campo.valor === undefined ||
              campo.valor === "" ||
              (campo.valor + "").length < campo.longitudMinimaDetalle
            ) {
              var errorDetalle = seccion.nombre + "/" + campo.etiquetaDetalle;
              errors.push(errorDetalle);
            }
          }
        } else if (campo.tipoValor === "LISTA") {
          var requerido = checkRequired(fieldsState, campo.codigo);
          var editable = checkEditable(fieldsState, campo.codigo);
          var visible = checkVisible(fieldsState, campo.codigo);
          if (requerido === true && editable === true && visible == true) {
            if (
              campo.valoresLista === null ||
              campo.valoresLista === undefined ||
              campo.valoresLista?.length < campo.longitudMinimaDetalle ||
              campo.valoresLista.filter(x => x.campos.find(f => f.codigo === "ACCION_CRUD" && f.valor !== "D") !== undefined)?.length < campo.longitudMinimaDetalle
            ) {
              var errorDetalle = seccion.nombre + "/" + campo.etiquetaDetalle;
              errors.push(errorDetalle);
            }
          }
        }
      }
    }
  }
  return errors;
};



export const dsc_esRucValido = (ruc)=> {
  if (typeof ruc === 'number') {
      ruc = ruc.toString();
  }
  if (typeof ruc !== 'string') {
      throw new Error('El RUC debe ser un string');
  }
  if (!(!isNaN(parseInt(ruc)))) return false;

  const code = parseInt(ruc.substring(0, 2));
  const lastDigit = parseInt(ruc.substring(12, 13));

  if (lastDigit <= 0 ) return false;
  if (code <= 0 || (code >= 25 && code !== 30)) return false;

  return ruc.length === 13;
};   