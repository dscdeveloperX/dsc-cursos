export const dateFormatter = (value) => {
  if (value === null || value === undefined || value === "") return "";

  try {
    const date = new Date(value);

    if (date === null || date === undefined) return "";

    var year = date.getFullYear();

    if (year === null || year === undefined) return "";

    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : "0" + month;

    var day = date.getDate().toString();
    day = day.length > 1 ? day : "0" + day;

    var hour = date.getHours().toString();
    hour = hour.length > 1 ? hour : "0" + hour;

    var minutes = date.getMinutes().toString();
    minutes = minutes.length > 1 ? minutes : "0" + minutes;

    var seconds = date.getSeconds().toString();
    seconds = seconds.length > 1 ? seconds : "0" + seconds;

    return (
      day +
      "/" +
      month +
      "/" +
      year +
      " " +
      hour +
      ":" +
      minutes +
      ":" +
      seconds
    );
  } catch (error) {
    return "";
  }
};

export const dateCalendarFormatter = (value) => {
  if (value === null || value === undefined || value === "") return "";
  try {
    const date = new Date(value);

    if (date === null || date === undefined) return "";
    var year = date.getFullYear();
    if (year === null || year === undefined) return "";

    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : "0" + month;

    var day = date.getDate().toString();
    day = day.length > 1 ? day : "0" + day;

    return (
      day +
      "/" +
      month +
      "/" +
      year +
      " "
    );
  } catch (error) {
    return "";
  }
};