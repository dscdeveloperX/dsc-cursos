import {
  AsignarValor,
  ObtenerValorCalculadoFront,
  getDefaultValue,
  filterCombobox,
  getComboboxRefValues,
  checkVisible,
  checkOperationType,
} from "./field-actions";

const { createSlice } = require("@reduxjs/toolkit");

const initState = {
  fields: {},
  client: null,
  product: null,
  calculated: [],
  calculatedApi: {},
  loadingFields: {},
  defaultValues: {},
  filterValues: {},
  catalogueValues: {},
  sectionChangeVisible: {}
};

const fieldSlice = createSlice({
  name: "field",
  initialState: initState,
  reducers: {
    cleanFields(state, action) {
      state.fields = {};
      state.client = null;
      state.product = null;
      state.calculated = [];
      state.calculatedApi = {};
      state.loadingFields = {};
      state.parentDependentCalculated = [];
      state.defaultValues = {};
      state.filterValues = {};
      state.catalogueValues = {};
      state.sectionIsVisible = {};
      state.sectionVisibleDepen = {};
    },
    setFields(state, action) {
      state.calculated = action.payload.calculated;
      state.defaultValues = action.payload.defaultValues;
      state.filterValues = action.payload.filterValues;
      state.parentDependentCalculated = action.payload.parentDependentCalculated;
      var checkSection = action.payload.checkSection;
      var agencyCode = action.payload.agencyCode;
      var user = action.payload.user;
      var executiveCode = action.payload.executiveCode;
      var vatId = action.payload.vatId;
      var area = action.payload.area;

      var calculatedApiCCodes = action.payload.calculatedApi;

      var tempClt = { ...action.payload.client };
      var tempProd = { ...action.payload.product };
      var tempFieds = { ...action.payload.fields };
      var tempCat = { ...action.payload.catalogueValues };

      var sectionIsVisible = {};
      var sectionVisibleDepen = {};

      var calculatedApi = {};
      var loadingFields = {};

      //VALORES CALCULADOS
      var calculated = [...state.calculated];
      calculated.forEach((fieldCode) => {
        var calculatedFieldData = tempFieds[fieldCode];

        if (calculatedFieldData !== null && calculatedFieldData !== undefined) {
          var valorCal = ObtenerValorCalculadoFront(tempFieds, fieldCode, {
            agencyCode: agencyCode,
            user: user,
            executiveCode: executiveCode,
            vatId: vatId,
            area: area,
          });
          var fieldCal = { ...calculatedFieldData.field };
          fieldCal.valor = valorCal;
          var temp =
            calculatedFieldData.tipo === "CLIENTE" ? tempClt : tempProd;
          AsignarValor(
            temp,
            calculatedFieldData.sectionIndex,
            calculatedFieldData.subSectionIndex,
            calculatedFieldData.fieldIndex,
            fieldCal
          );
          if (calculatedFieldData.tipo === "CLIENTE") {
            tempClt = temp;
          } else {
            tempProd = temp;
          }
          tempFieds[fieldCode].field.valor = valorCal;
        }
      });

      //SECCION VISIBLE CONDICIONADO
      for (const [key, value] of Object.entries(checkSection)) {
        if (value !== true && value !== false) {
          var depenVals = [];
          for (const [keydep, valuedep] of Object.entries(value)) {
            var depDta = valuedep;

            var temp = tempFieds;

            let dependencyField = temp[keydep]?.field;

            for (var i = 0; i < depDta.length; i++) {
              let rule = {};
              if (dependencyField.valor in depDta[i]) {
                rule = depDta[i][dependencyField.valor];
              } else {
                rule = depDta[i]["DEFAULT"];
              }
              var valor = checkOperationType(rule, dependencyField.valor, tempFieds);
              depenVals.push(valor);
            }

          }
          sectionVisibleDepen[key] = value;
          sectionIsVisible[key] = depenVals.find(x => x === true) !== undefined;
        }
        else {
          sectionIsVisible[key] = value;
        }
      }

      //ACTUALIZAR FILTRO
      for (const [key, value] of Object.entries(tempCat)) {
        var fieldCode = key;
        var filterData = tempFieds[fieldCode];

        if (filterData !== null && filterData !== undefined) {
          if (filterData.field.origenCombobox?.trim() === "MODELOS") {
            const valoresCombo = getComboboxRefValues(tempFieds, fieldCode);
            tempCat[fieldCode] = valoresCombo;
            tempFieds[fieldCode].field.valoresCombobox = valoresCombo;
          } else {
            const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
              tempFieds,
              fieldCode
            );
            tempCat[fieldCode] = valorFilter;

            if (!itemInArray) {
              filterData.field.valor = "";
              var temp = filterData.tipo === "CLIENTE" ? tempClt : tempProd;
              AsignarValor(
                temp,
                filterData.sectionIndex,
                filterData.subSectionIndex,
                filterData.fieldIndex,
                filterData.field
              );
              if (filterData.tipo === "CLIENTE") {
                tempClt = temp;
              } else {
                tempProd = temp;
              }
              tempFieds[fieldCode].field.valor = "";
            }
          }
        }
      }

      //VALORES CALCULADOS FIELD
      if (calculatedApiCCodes.length > 0) {
        calculatedApiCCodes.forEach((fieldCodeApi) => {
          var calculatedApiFieldData = tempFieds[fieldCodeApi];

          if (calculatedApiFieldData !== null && calculatedApiFieldData !== undefined) {
            if (calculatedApiFieldData.field.valoresCalculo !== null && calculatedApiFieldData.field.valoresCalculo.length > 0) {
              for (var i = 0; i < calculatedApiFieldData.field.valoresCalculo.length; i++) {
                const codigo = calculatedApiFieldData.field.valoresCalculo[i];
                if (tempFieds[codigo] !== undefined) {
                  if (codigo in calculatedApi) {
                    calculatedApi[codigo] = [...calculatedApi[codigo], fieldCodeApi];
                  }
                  else {
                    calculatedApi[codigo] = [fieldCodeApi];
                  }
                }
                loadingFields[fieldCodeApi] = false;
              }
            }
          }
        });
      }

      //VALORES CALCULADOS DEPEN HIJOS
      /*var parentDependentCalculated = [...state.parentDependentCalculated];
      parentDependentCalculated.forEach((fieldCode) => {
        var calculatedFieldData = tempFieds[fieldCode];

        if (calculatedFieldData !== null && calculatedFieldData !== undefined) {

          var calcfield = calculatedFieldData.field;
          //get all fields that take value from parent
          var depenRef = calcfield.formatoModeloLista.filter(x => x.tipoCampo === "CALCULADO" && x.tipoCalculado === "FRONT" && x.nombreCalculo === "ObtenerValorCampoModeloRef");
          //get other calculateed field
          var notDepen = calcfield.formatoModeloLista.filter(x => x.tipoCampo === "CALCULADO" && x.tipoCalculado === "FRONT" && x.nombreCalculo !== "ObtenerValorCampoModeloRef");
          var fieldDict = {};

          if (calcfield.formatoModeloLista !== null && calcfield.formatoModeloLista.length > 0) {
            for (var i = 0; i < calcfield.formatoModeloLista.length; i++) {
              var field = { ...calcfield.formatoModeloLista[i] };
              var code = field.codigo;
              //add field to dict
              fieldDict[code] = {
                field: field,
                fieldIndex: i,
              };
            }
          }


          if (calcfield.valoresLista !== undefined && calcfield.valoresLista !== null && calcfield.valoresLista.length > 0) {
            var calcFict = calcfield.valoresLista.map((valor) => {
              var campos = {};
              var valores = { ...valor }
              valores.campos.forEach((element) => {
                campos[element.codigo] = element.valor;
                fieldDict[element.codigo].field.valor = element.valor;
              });


              depenRef.forEach((dep) => {
                var valorCal = ObtenerValorCalculadoFront(fieldDict, dep.codigo, {
                  agencyCode: agencyCode,
                  user: user,
                  executiveCode: executiveCode,
                  vatId: vatId,
                  area: area,
                }, tempFieds);
                campos[dep.codigo] = valorCal;
                fieldDict[dep.codigo].field.valor = valorCal;
              });

              notDepen.forEach((dep) => {
                var valorCal = ObtenerValorCalculadoFront(fieldDict, dep.codigo, {
                  agencyCode: agencyCode,
                  user: user,
                  executiveCode: executiveCode,
                  vatId: vatId,
                  area: area,
                }, tempFieds);
                campos[dep.codigo] = valorCal;
                fieldDict[dep.codigo].field.valor = valorCal;
              });

              valores.campos = valores.campos.map((element) => {
                var camp = { ...element };
                camp.valor = campos[camp.codigo];
                return camp;
              });

              return valores;
            });
          }

          var fieldCal = { ...calculatedFieldData.field };
          fieldCal.valoresLista = calcFict;
          if (calculatedFieldData.tipo === "CLIENTE") {
            AsignarValor(
              tempClt,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          } else {
            AsignarValor(
              tempProd,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          }
          tempFieds[fieldCode].field = fieldCal;
        }
      });*/

      state.sectionIsVisible = sectionIsVisible;
      state.sectionVisibleDepen = sectionVisibleDepen;

      state.calculatedApi = calculatedApi;
      state.loadingFields = loadingFields;

      state.client = tempClt;
      state.product = tempProd;
      state.fields = tempFieds;
      state.catalogueValues = tempCat;
    },
    updateField(state, action) {
      var modelo = action.payload.modelo;
      var code = action.payload.code;
      var sectionIndex = action.payload.sectionIndex;
      var subSectionIndex = action.payload.subSectionIndex;
      var fieldIndex = action.payload.fieldIndex;
      var field = action.payload.value;
      var agencyCode = action.payload.agencyCode;
      var user = action.payload.user;
      var executiveCode = action.payload.executiveCode;
      var vatId = action.payload.vatId;
      var area = action.payload.area;

      var tempClt = {};
      var tempAlt = {};
      var tempFieds = { ...state.fields };
      var tempCat = { ...state.catalogueValues };

      if (modelo === "CLIENTE") {
        tempClt = { ...state.client };
        tempAlt = { ...state.product };
      } else {
        tempClt = { ...state.product };
        tempAlt = { ...state.client };
      }

      AsignarValor(tempClt, sectionIndex, subSectionIndex, fieldIndex, field);

      if (field.tipoValor === "VALOR") {
        tempFieds[code].field.valor = field.valor;
      } else {
        tempFieds[code].field.valoresLista = field.valoresLista;
      }


      //VALORES POR DEFECTO
      if (code in state.defaultValues) {
        var dependentFields = state.defaultValues[code];
        dependentFields.forEach((fieldCode) => {
          var defaultFieldData = tempFieds[fieldCode];
          if (defaultFieldData !== null && defaultFieldData !== undefined) {
            const { defaultValue: valorDefault } = getDefaultValue(
              tempFieds,
              fieldCode
            );

            var fielddEF = { ...defaultFieldData.field };
            fielddEF.valor = valorDefault;

            if (defaultFieldData.tipo === modelo) {
              AsignarValor(
                tempClt,
                defaultFieldData.sectionIndex,
                defaultFieldData.subSectionIndex,
                defaultFieldData.fieldIndex,
                fielddEF
              );
            } else {
              AsignarValor(
                tempAlt,
                defaultFieldData.sectionIndex,
                defaultFieldData.subSectionIndex,
                defaultFieldData.fieldIndex,
                fielddEF
              );
            }

            tempFieds[fieldCode].field.valor = valorDefault;

            //ACTUALIZAR FILTRO
            if (fieldCode in state.filterValues) {
              var filterFields = state.filterValues[fieldCode];

              filterFields.forEach((fieldCodeFilter) => {
                var filterData = tempFieds[fieldCodeFilter];

                if (filterData !== null && filterData !== undefined) {
                  if (filterData.field.origenCombobox === "MODELOS") {
                    const valoresCombo = getComboboxRefValues(tempFieds, fieldCodeFilter);
                    tempCat[fieldCodeFilter] = valoresCombo;
                    tempFieds[fieldCodeFilter].field.valoresCombobox = valoresCombo;
                  } else {
                    const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
                      tempFieds,
                      fieldCodeFilter
                    );
                    tempCat[fieldCodeFilter] = valorFilter;

                    if (!itemInArray) {
                      filterData.field.valor = "";
                      if (filterData.tipo === modelo) {
                        AsignarValor(
                          tempClt,
                          filterData.sectionIndex,
                          filterData.subSectionIndex,
                          filterData.fieldIndex,
                          filterData.field
                        );
                      } else {
                        AsignarValor(
                          tempAlt,
                          filterData.sectionIndex,
                          filterData.subSectionIndex,
                          filterData.fieldIndex,
                          filterData.field
                        );
                      }
                      tempFieds[fieldCodeFilter].field.valor = "";

                    }
                  }
                }
              });
            }

            //afectar segundo nivel dependencia            
            if (fieldCode in state.defaultValues) {
              var dependentFieldsBranch = state.defaultValues[fieldCode];
              dependentFieldsBranch.forEach((fieldCodeBranch) => {
                var defaultFieldDataBranch = tempFieds[fieldCodeBranch];
                if (defaultFieldDataBranch !== null && defaultFieldDataBranch !== undefined && fieldCodeBranch !== code) {
                  const { defaultValue: valorDefaultBranch } = getDefaultValue(
                    tempFieds,
                    fieldCodeBranch
                  );

                  var fielddEFBranch = { ...defaultFieldDataBranch.field };
                  fielddEFBranch.valor = valorDefaultBranch;

                  if (defaultFieldDataBranch.tipo === modelo) {
                    AsignarValor(
                      tempClt,
                      defaultFieldDataBranch.sectionIndex,
                      defaultFieldDataBranch.subSectionIndex,
                      defaultFieldDataBranch.fieldIndex,
                      fielddEFBranch
                    );
                  } else {
                    AsignarValor(
                      tempAlt,
                      defaultFieldDataBranch.sectionIndex,
                      defaultFieldDataBranch.subSectionIndex,
                      defaultFieldDataBranch.fieldIndex,
                      fielddEFBranch
                    );
                  }
                  tempFieds[fieldCodeBranch].field.valor = valorDefaultBranch;

                  //ACTUALIZAR FILTRO
                  if (fieldCodeBranch in state.filterValues) {
                    var filterFields = state.filterValues[fieldCodeBranch];

                    filterFields.forEach((fieldCodeFilter) => {
                      var filterDataS = tempFieds[fieldCodeFilter];

                      if (filterDataS !== null && filterDataS !== undefined) {
                        if (filterDataS.field.origenCombobox === "MODELOS") {
                          const valoresCombo = getComboboxRefValues(tempFieds, fieldCodeFilter);
                          tempCat[fieldCodeFilter] = valoresCombo;
                          tempFieds[fieldCodeFilter].field.valoresCombobox = valoresCombo;
                        } else {
                          const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
                            tempFieds,
                            fieldCodeFilter
                          );
                          tempCat[fieldCodeFilter] = valorFilter;

                          if (!itemInArray) {
                            filterDataS.field.valor = "";
                            if (filterDataS.tipo === modelo) {
                              AsignarValor(
                                tempClt,
                                filterDataS.sectionIndex,
                                filterDataS.subSectionIndex,
                                filterDataS.fieldIndex,
                                filterDataS.field
                              );
                            } else {
                              AsignarValor(
                                tempAlt,
                                filterDataS.sectionIndex,
                                filterDataS.subSectionIndex,
                                filterDataS.fieldIndex,
                                filterDataS.field
                              );
                            }
                            tempFieds[fieldCodeFilter].field.valor = "";

                          }
                        }
                      }
                    });
                  }
                }
              });
            }
          }
        });
      }

      //VALORES CALCULADOS
      var calculated = [...state.calculated];
      calculated.forEach((fieldCode) => {
        var calculatedFieldData = tempFieds[fieldCode];

        if (calculatedFieldData !== null && calculatedFieldData !== undefined) {
          var valorCal = ObtenerValorCalculadoFront(tempFieds, fieldCode, {
            agencyCode: agencyCode,
            user: user,
            executiveCode: executiveCode,
            vatId: vatId,
            area: area,
          });
          var fieldCal = { ...calculatedFieldData.field };
          fieldCal.valor = valorCal;
          if (calculatedFieldData.tipo === modelo) {
            AsignarValor(
              tempClt,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          } else {
            AsignarValor(
              tempAlt,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          }
          tempFieds[fieldCode].field.valor = valorCal;

          //ACTUALIZAR FILTRO
          if (fieldCode in state.filterValues) {
            var filterFields = state.filterValues[fieldCode];

            filterFields.forEach((fieldCodeFilter) => {
              var filterDataCal = tempFieds[fieldCodeFilter];

              if (filterDataCal !== null && filterDataCal !== undefined) {
                if (filterDataCal.field.origenCombobox === "MODELOS") {
                  const valoresCombo = getComboboxRefValues(tempFieds, fieldCodeFilter);
                  tempCat[fieldCodeFilter] = valoresCombo;
                  tempFieds[fieldCodeFilter].field.valoresCombobox = valoresCombo;
                } else {
                  const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
                    tempFieds,
                    fieldCodeFilter
                  );
                  tempCat[fieldCodeFilter] = valorFilter;

                  if (!itemInArray) {
                    filterDataCal.field.valor = "";
                    if (filterDataCal.tipo === modelo) {
                      AsignarValor(
                        tempClt,
                        filterDataCal.sectionIndex,
                        filterDataCal.subSectionIndex,
                        filterDataCal.fieldIndex,
                        filterDataCal.field
                      );
                    } else {
                      AsignarValor(
                        tempAlt,
                        filterDataCal.sectionIndex,
                        filterDataCal.subSectionIndex,
                        filterDataCal.fieldIndex,
                        filterDataCal.field
                      );
                    }
                    tempFieds[fieldCodeFilter].field.valor = "";
                  }
                }
              }
            });
          }

          //afectar segundo nivel dependencia  
          if (fieldCode in state.defaultValues) {
            var dependentFieldsBranch = state.defaultValues[fieldCode];
            dependentFieldsBranch.forEach((fieldCodeBranch) => {
              var defaultFieldDataBranch = tempFieds[fieldCodeBranch];
              if (defaultFieldDataBranch !== null && defaultFieldDataBranch !== undefined && fieldCodeBranch !== code) {
                const { defaultValue: valorDefaultBranch } = getDefaultValue(
                  tempFieds,
                  fieldCodeBranch
                );

                var fielddEFBranch = { ...defaultFieldDataBranch.field };
                fielddEFBranch.valor = valorDefaultBranch;

                if (defaultFieldDataBranch.tipo === modelo) {
                  AsignarValor(
                    tempClt,
                    defaultFieldDataBranch.sectionIndex,
                    defaultFieldDataBranch.subSectionIndex,
                    defaultFieldDataBranch.fieldIndex,
                    fielddEFBranch
                  );
                } else {
                  AsignarValor(
                    tempAlt,
                    defaultFieldDataBranch.sectionIndex,
                    defaultFieldDataBranch.subSectionIndex,
                    defaultFieldDataBranch.fieldIndex,
                    fielddEFBranch
                  );
                }

                tempFieds[fieldCodeBranch].field.valor = valorDefaultBranch;

                //ACTUALIZAR FILTRO
                if (fieldCodeBranch in state.filterValues) {
                  var filterFields = state.filterValues[fieldCodeBranch];

                  filterFields.forEach((fieldCodeFilter) => {
                    var filterData = tempFieds[fieldCodeFilter];

                    if (filterData !== null && filterData !== undefined) {
                      if (filterData.field.origenCombobox === "MODELOS") {
                        const valoresCombo = getComboboxRefValues(tempFieds, fieldCodeFilter);
                        tempCat[fieldCodeFilter] = valoresCombo;
                        tempFieds[fieldCodeFilter].field.valoresCombobox = valoresCombo;
                      } else {
                        const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
                          tempFieds,
                          fieldCodeFilter
                        );
                        tempCat[fieldCodeFilter] = valorFilter;

                        if (!itemInArray) {
                          filterData.field.valor = "";
                          if (filterData.tipo === modelo) {
                            AsignarValor(
                              tempClt,
                              filterData.sectionIndex,
                              filterData.subSectionIndex,
                              filterData.fieldIndex,
                              filterData.field
                            );
                          } else {
                            AsignarValor(
                              tempAlt,
                              filterData.sectionIndex,
                              filterData.subSectionIndex,
                              filterData.fieldIndex,
                              filterData.field
                            );
                          }
                          tempFieds[fieldCodeFilter].field.valor = "";

                        }
                      }
                    }
                  });
                }
              }
            });
          }
        }
      });

      //VALORES CALCULADOS DEPEN HIJOS
      var parentDependentCalculated = [...state.parentDependentCalculated];
      parentDependentCalculated.forEach((fieldCode) => {
        var calculatedFieldData = tempFieds[fieldCode];

        if (calculatedFieldData !== null && calculatedFieldData !== undefined) {

          var calcfield = calculatedFieldData.field;
          //get all fields that take value from parent
          var depenRef = calcfield.formatoModeloLista.filter(x => x.tipoCampo === "CALCULADO" && x.tipoCalculado === "FRONT" && x.nombreCalculo === "ObtenerValorCampoModeloRef");
          //get other calculateed field
          var notDepen = calcfield.formatoModeloLista.filter(x => x.tipoCampo === "CALCULADO" && x.tipoCalculado === "FRONT" && x.nombreCalculo !== "ObtenerValorCampoModeloRef");
          var fieldDict = {};

          if (calcfield.formatoModeloLista !== null && calcfield.formatoModeloLista.length > 0) {
            for (var i = 0; i < calcfield.formatoModeloLista.length; i++) {
              var field = { ...calcfield.formatoModeloLista[i] };
              var code = field.codigo;
              //add field to dict
              fieldDict[code] = {
                field: field,
                fieldIndex: i,
              };
            }
          }


          if (calcfield.valoresLista !== undefined && calcfield.valoresLista !== null && calcfield.valoresLista.length > 0) {
            var calcFict = calcfield.valoresLista.map((valor) => {
              var campos = {};
              var valores = { ...valor }
              valores.campos.forEach((element) => {
                campos[element.codigo] = element.valor;
                fieldDict[element.codigo].field.valor = element.valor;
              });


              depenRef.forEach((dep) => {
                var valorCal = ObtenerValorCalculadoFront(fieldDict, dep.codigo, {
                  agencyCode: agencyCode,
                  user: user,
                  executiveCode: executiveCode,
                  vatId: vatId,
                  area: area,
                }, tempFieds);
                campos[dep.codigo] = valorCal;
                fieldDict[dep.codigo].field.valor = valorCal;
              });

              notDepen.forEach((dep) => {
                var valorCal = ObtenerValorCalculadoFront(fieldDict, dep.codigo, {
                  agencyCode: agencyCode,
                  user: user,
                  executiveCode: executiveCode,
                  vatId: vatId,
                  area: area,
                }, tempFieds);
                campos[dep.codigo] = valorCal;
                fieldDict[dep.codigo].field.valor = valorCal;
              });

              valores.campos = valores.campos.map((element) => {
                var camp = { ...element };
                camp.valor = campos[camp.codigo];
                return camp;
              });

              return valores;
            });
          }

          var fieldCal = { ...calculatedFieldData.field };
          fieldCal.valoresLista = calcFict;
          if (calculatedFieldData.tipo === modelo) {
            AsignarValor(
              tempClt,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          } else {
            AsignarValor(
              tempAlt,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          }
          tempFieds[fieldCode].field = fieldCal;
        }
      });

      //ACTUALIZAR FILTRO
      if (code in state.filterValues) {
        var filterFields = state.filterValues[code];

        filterFields.forEach((fieldCode) => {
          var filterData = tempFieds[fieldCode];

          if (filterData !== null && filterData !== undefined) {
            if (filterData.field.origenCombobox?.trim() === "MODELOS") {
              const valoresCombo = getComboboxRefValues(tempFieds, fieldCode);
              tempCat[fieldCode] = valoresCombo;
              tempFieds[fieldCode].field.valoresCombobox = valoresCombo;
            } else {
              const { valuesCombo: valorFilter, itemInArray } = filterCombobox(
                tempFieds,
                fieldCode
              );
              tempCat[fieldCode] = valorFilter;

              if (!itemInArray) {
                filterData.field.valor = "";
                if (filterData.tipo === modelo) {
                  AsignarValor(
                    tempClt,
                    filterData.sectionIndex,
                    filterData.subSectionIndex,
                    filterData.fieldIndex,
                    filterData.field
                  );
                } else {
                  AsignarValor(
                    tempAlt,
                    filterData.sectionIndex,
                    filterData.subSectionIndex,
                    filterData.fieldIndex,
                    filterData.field
                  );
                }
                tempFieds[fieldCode].field.valor = "";

              }
            }
          }
        });
      }

      var sectionIsVisible = { ...state.sectionIsVisible }
      //SECCION VISIBLE CONDICIONADO
      for (const [key, value] of Object.entries(state.sectionVisibleDepen)) {
        var depenVals = [];
        for (const [keydep, valuedep] of Object.entries(value)) {
          var depDta = valuedep;
          let dependencyField = tempFieds[keydep]?.field;

          for (var i = 0; i < depDta.length; i++) {
            let rule = {};
            if (dependencyField.valor in depDta[i]) {
              rule = depDta[i][dependencyField.valor];
            } else {
              rule = depDta[i]["DEFAULT"];
            }
            var valor = checkOperationType(rule, dependencyField.valor, tempFieds);
            depenVals.push(valor);
          }
        }
        sectionIsVisible[key] = depenVals.find(x => x === true) !== undefined;
      }

      if (modelo === "CLIENTE") {
        state.client = tempClt;
        state.product = tempAlt;
      } else {
        state.product = tempClt;
        state.client = tempAlt;
      }
      state.sectionIsVisible = sectionIsVisible;
      state.fields = tempFieds;
      state.catalogueValues = tempCat;
    },
    updateFieldApiCall(state, action) {
      var code = action.payload.code;

      if (code in state.calculatedApi) {
        var valoresCalc = [...state.calculatedApi[code]];
        var loadingFields = { ...loadingFields };

        valoresCalc.forEach((codeField) => {
          loadingFields[codeField] = true;
        });

        state.loadingFields = loadingFields;
      }
    },
    updateFieldApiRes(state, action) {
      var modelo = action.payload.model;
      var dictValues = action.payload.values;
      var code = action.payload.code;
      var agencyCode = action.payload.agencyCode;
      var user = action.payload.user;
      var executiveCode = action.payload.executiveCode;
      var vatId = action.payload.vatId;
      var area = action.payload.area;

      var loadingFields = { ...loadingFields };

      var tempClt = {};
      var tempAlt = {};
      var tempFieds = { ...state.fields };

      loadingFields[code] = false;

      if (modelo === "CLIENTE") {
        tempClt = { ...state.client };
        tempAlt = { ...state.product };
      } else {
        tempClt = { ...state.product };
        tempAlt = { ...state.client };
      }

      for (const [key, value] of Object.entries(dictValues)) {
        var fieldCode = key;
        var fieldValue = value;

        var updateDta = tempFieds[fieldCode];

        if (updateDta !== null && updateDta !== undefined) {
          updateDta.field.valor = fieldValue;
          if (updateDta.tipo === modelo) {
            AsignarValor(
              tempClt,
              updateDta.sectionIndex,
              updateDta.subSectionIndex,
              updateDta.fieldIndex,
              updateDta.field
            );
          } else {
            AsignarValor(
              tempAlt,
              updateDta.sectionIndex,
              updateDta.subSectionIndex,
              updateDta.fieldIndex,
              updateDta.field
            );
          }
          if (updateDta.field.tipoValor === "VALOR") {
            tempFieds[fieldCode].field.valor = updateDta.field.valor;
          } else {
            tempFieds[fieldCode].field.valoresLista =
              updateDta.field.valoresLista;
          }
        }

        //VALORES POR DEFECTO
        if (fieldCode in state.defaultValues) {
          var dependentFields = state.defaultValues[fieldCode];
          dependentFields.forEach((code) => {
            var defaultFieldData = tempFieds[code];
            if (defaultFieldData !== null && defaultFieldData !== undefined) {
              const { defaultValue: valorDefault } = getDefaultValue(
                tempFieds,
                code
              );

              var fielddEF = { ...defaultFieldData.field };
              fielddEF.valor = valorDefault;

              if (defaultFieldData.tipo === modelo) {
                AsignarValor(
                  tempClt,
                  defaultFieldData.sectionIndex,
                  defaultFieldData.subSectionIndex,
                  defaultFieldData.fieldIndex,
                  fielddEF
                );
              } else {
                AsignarValor(
                  tempAlt,
                  defaultFieldData.sectionIndex,
                  defaultFieldData.subSectionIndex,
                  defaultFieldData.fieldIndex,
                  fielddEF
                );
              }

              tempFieds[code].field.valor = valorDefault;
            }
          });
        }
      }

      //VALORES CALCULADOS
      var calculated = [...state.calculated];
      calculated.forEach((fieldCode) => {
        var calculatedFieldData = tempFieds[fieldCode];

        if (calculatedFieldData !== null && calculatedFieldData !== undefined) {
          var valorCal = ObtenerValorCalculadoFront(tempFieds, fieldCode, {
            agencyCode: agencyCode,
            user: user,
            executiveCode: executiveCode,
            vatId: vatId,
            area: area,
          });
          var fieldCal = { ...calculatedFieldData.field };
          fieldCal.valor = valorCal;
          if (calculatedFieldData.tipo === modelo) {
            AsignarValor(
              tempClt,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          } else {
            AsignarValor(
              tempAlt,
              calculatedFieldData.sectionIndex,
              calculatedFieldData.subSectionIndex,
              calculatedFieldData.fieldIndex,
              fieldCal
            );
          }
          tempFieds[fieldCode].field.valor = valorCal;
        }
      });

      if (modelo === "CLIENTE") {
        state.client = tempClt;
      } else {
        state.product = tempClt;
      }
      state.loadingFields = loadingFields;
      state.fields = tempFieds;
    },
  },
});

export const fieldActions = fieldSlice.actions;

export default fieldSlice.reducer;
