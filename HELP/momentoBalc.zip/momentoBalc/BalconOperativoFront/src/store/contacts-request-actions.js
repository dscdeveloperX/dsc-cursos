export async function contactsRequest({
  params,
  user,
  ip,
  token,
  url,
  setIsLoading,
  setError,
  setShowError,
  setTableContactsList,
  setClientTypeId,
  setClientVatId,
  setClientName,
  setShowRes
}) {
  setShowRes(false);
  setError(null);
  setShowError(false);
  setIsLoading(true);
  try {
    const request = {
      headerRequest: {
        username: user,
        stationIp: ip,
        dateTime: new Date().toISOString(),
        pageSize: params.sizePerPage,
        pageRequested: params.currentPage,
      },
      bodyRequest: {
        tipoIdentificacion: params.idType,
        identificacion: params.vatId,
      },
    };
    
    const response = await fetch(url + "contactabilidad/Consultar", {
      method: "POST",
      body: JSON.stringify(request),
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    }).catch(_ => {
      throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
    });

    const resText = await response.text();
    const data = resText && JSON.parse(resText);
    if (!response.ok) {
      if ([401, 403].includes(response.status)) {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
      if (data?.headerResponse !== undefined) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      } else {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
    }

    setClientTypeId(data.bodyResponse?.contactabilidad?.tipo_Identidad_Cliente);
    setClientVatId(data.bodyResponse?.contactabilidad?.dcto_Identidad_Cliente);
    setClientName(data.bodyResponse?.contactabilidad?.nombre_Cliente);
    setTableContactsList(data.bodyResponse?.contactabilidad?.contactClientes);
    setShowRes(true);
  } catch (error) {
    setError(error.message);
    setShowError(true);
  }
  setIsLoading(false);
}

export async function contactsEditRequest({
  params,
  user,
  ip,
  token,
  url,
  setIsLoading,
  setError,
  setShowError,
  setMessage,
  showSuccessMessage,
  setVatId,
  setSelectedContact,
  setSelectedContactIndex,
  setShowRes
}) {
  var message = "";
  setError(null);
  setShowError(false);
  setIsLoading(true);
  try {
    const request = {
      headerRequest: {
        username: user,
        stationIp: ip,
        dateTime: new Date().toISOString(),
        pageSize: params.sizePerPage,
        pageRequested: params.currentPage,
      },
      bodyRequest: {
        contactabilidad: {
          tipo_Identidad_Cliente: params.clientTypeId,
          dcto_Identidad_Cliente: params.clientVatId,
          nombre_Cliente: params.clientName,
          contactClientes: params.tableContactsList,
        },
      },
    };

    const response = await fetch(url + "contactabilidad/Editar", {
      method: "POST",
      body: JSON.stringify(request),
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    }).catch(_ => {
      throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
    });

    const resText = await response.text();
    const data = resText && JSON.parse(resText);
    if (!response.ok) {
      if ([401, 403].includes(response.status)) {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
      if (data?.headerResponse !== undefined) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      } else {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
    }

    if (data.bodyResponse?.editado === true) {
      setShowRes(false);
      //message = data.bodyResponse.mensaje;
      message = "¡Actualización exitosa!";
      setMessage(message);
    }
    //setTableContactsList([]);
    setVatId("");
    setSelectedContact(null);
    setSelectedContactIndex(null);
  } catch (error) {
    setError(error.message);
    setShowError(true);
  }
  if (message !== null && message.length > 0) showSuccessMessage();
  setIsLoading(false);
}
