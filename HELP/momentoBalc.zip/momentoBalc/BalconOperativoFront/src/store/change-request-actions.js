export async function changeRequest({
  params,
  user,
  ip,
  token,
  url,
  setIsLoading,
  setError,
  setShowError,
  setChangeRequestList,
  setTotal
}) {
  setError(null);
  setShowError(false);
  setIsLoading(true);
  try {
    
    const request = {
      headerRequest: {
        username: user,
        stationIp: ip,
        dateTime: new Date().toISOString(),
        pageSize: params.sizePerPage,
        pageRequested: params.currentPage,
      },
      bodyRequest: {
        estado: params.status,
        ordenarPor: params.orderBy,
        ordenDesc: true,
        filtrarPor: params.filterBy,
        valorFiltro: params.filterValue,
        funcionalidad: params.functionality,
        agenciaSolicitud: params.agenciaSolicitud ,
      },
    };
    
    var response =  null;
    /*if ( request.bodyRequest.valorFiltro.length > 0)
    {*/
      response = await fetch(url + "solicitud/Listar", {
        method: "POST",
        body: JSON.stringify(request),
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
      }).catch(_ => {
        throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
      });  
    const resText = await response.text();
    const data = resText && JSON.parse(resText); 
    if (!response.ok) {
      if ([401, 403].includes(response.status)) {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
      if (data?.headerResponse !== undefined) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      } else {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
    }
    setTotal(data.headerResponse.totalRecords);
    setChangeRequestList(data.bodyResponse.solicitudCambios);
  /*}*/
  } catch (error) {
    setError(error.message);
    setShowError(true);
  }
  setIsLoading(false);
}

export async function acceptChangeRequest({
  params,
  user,
  ip,
  token,
  url,
  setIsLoading,
  setError,
  setShowError,
  setMessage,
  showSuccessMessage
}) {
  var res = 0;
  setError(null);
  setShowError(false);
  setIsLoading(true);
  var message = "";
  try {
    const request = {
      headerRequest: {
        username: user,
        stationIp: ip,
        dateTime: new Date().toISOString(),
        pageSize: params.sizePerPage,
        pageRequested: params.currentPage,
      },
      bodyRequest: {
        cambioId: params.id,
      },
    };
    const response = await fetch(url + "solicitud/AprobarSolicitud", {
      method: "POST",
      body: JSON.stringify(request),
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    }).catch(_ => {
      throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
    });

    const resText = await response.text();
    const data = resText && JSON.parse(resText);
    if (!response.ok) {
      if ([401, 403].includes(response.status)) {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
      if (data?.headerResponse !== undefined) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      } else {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
    }

    if (data.headerResponse.returnMessage !== "OK") {
      message = data.headerResponse.returnMessage;
      setMessage(message);
    }
  } catch (error) {
    setError(error.message);
    setShowError(true);
    return -1;
  }
  if (message !== null && message.length > 0) showSuccessMessage();
  setIsLoading(false);
  return res;
}

export async function rejectChangeRequest({
  params,
  user,
  ip,
  token,
  url,
  setIsLoading,
  setError,
  setShowError,
  setMessage,
  showSuccessMessage
}) {
  setError(null);
  setShowError(false);
  setIsLoading(true);
  var message = "";
  try {
    const request = {
      headerRequest: {
        username: user,
        stationIp: ip,
        dateTime: new Date().toISOString(),
        pageSize: params.sizePerPage,
        pageRequested: params.currentPage,
      },
      bodyRequest: {
        cambioId: params.id,
        razonRechazo: params.razon,
      },
    };
    const response = await fetch(url + "solicitud/RechazarSolicitud", {
      method: "POST",
      body: JSON.stringify(request),
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    }).catch(_ => {
      throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
    });

    const resText = await response.text();
    const data = resText && JSON.parse(resText);
    if (!response.ok) {
      if ([401, 403].includes(response.status)) {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
      if (data?.headerResponse !== undefined) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      } else {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
    }

    if (data.headerResponse.returnMessage !== "OK") {
      message = data.headerResponse.returnMessage;
      setMessage(message);
    }
  } catch (error) {
    setError(error.message);
    setShowError(true);
  }
  if (message !== null && message.length > 0) showSuccessMessage();
  setIsLoading(false);
}

export async function fetchRequestById({
  params,
  user,
  ip,
  token,
  url,
  setIsLoading,
  setError,
  setShowError,
  setRequestDetailList,
  setRequest,
  setTotal,
}) {
  setError(null);
  setShowError(false);
  setIsLoading(true);
  try {
    const request = {
      headerRequest: {
        username: user,
        stationIp: ip,
        dateTime: new Date().toISOString(),
        pageSize: params.sizePerPage,
        pageRequested: params.currentPage,
      },
      bodyRequest: {
        cambioId: params.id,
      },
    };
    const response = await fetch(url + "solicitud/ObtenerPorId", {
      method: "POST",
      body: JSON.stringify(request),
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    }).catch(_ => {
      throw Error("No se encuentra disponible el servicio. Por favor comuníquese con sistemas.");
    });

    const resText = await response.text();
    const data = resText && JSON.parse(resText);
    if (!response.ok) {
      if ([401, 403].includes(response.status)) {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
      if (data?.headerResponse !== undefined) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      } else {
        throw Error(response.status + " No se pudo enviar la petición al servicio. Por favor intente más tarde.");
      }
    }

    //setData
    setRequestDetailList(data.bodyResponse.solicitudCambio);
    setTotal(data.headerResponse.totalRecords);
  } catch (error) {
    setError(error.message);
    setShowError(true);
  }
  setIsLoading(false);
}
