import { configureStore } from "@reduxjs/toolkit";

import fieldReducer from "./field-helper";

const store = configureStore({ reducer: { field: fieldReducer } });

export default store;
