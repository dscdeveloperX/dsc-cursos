export const COLORS = {
  primary: "#265F30",
  secondary: "#C8951A",
  white: "#FFFFFF",
  primaryLight: "#009845",
  secondaryLight: "#FCB316",
  black: "#000000",
  grey: "#707070",
  darkGrey: "#4D504E",
  alert: "#920808",
  info: "#268CB2",
  whiteBone: "#E7E3E2",
  highlight: "#7cc140",
};
