import { Fragment, useState, useEffect, useCallback, useContext } from "react";
import AuthContext from "../store/auth-context";
import { Link, useLocation } from "react-router-dom";
import { Modal, Stack } from "react-bootstrap";

import SearchBar from "../components/Layout/SearchBar";
import CustomTable from "../components/Layout/CustomTable";
import CustomButton from "../components/UI/buttons/CustomButton";
import ErrorAlert from "../components/UI/ErrorAlert";
import LoadingSpinner from "../components/UI/LoadingSpinner";
import classes from "../components/UI/css/SearchBar.module.css";

import { COLORS } from "../values/colors";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faTrashCan, faPencil } from "@fortawesome/free-solid-svg-icons";
import SuccessAlert from "../components/UI/SuccessAlert";

const TableModels = (props) => {
  const [isLoading, setIsLoading] = useState(false);
  const [modelList, setModelList] = useState([]);
  const [filterBy, setFilterBy] = useState("");
  const [filterValue, setFilterValue] = useState("");
  const [state, setState] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [sizePerPage, setSizePerPage] = useState(5);
  const [total, setTotal] = useState(0);

  const [action, setAction] = useState(props.action);
  const [show, setShow] = useState(false);
  const [selectedModel, setSelectedModel] = useState(null);

  const [error, setError] = useState(null);
  const [showError, setShowError] = useState(false);

  const authCtx = useContext(AuthContext);

  const location = useLocation();

  const [showMessage, setShowMessage] = useState(location.state ? true : false);
  const [message, setMessage] = useState(location.state ? location.state : "");

  function HideSuccessMessage() {
    setMessage("");
    setShowMessage(false);
  }

  async function apiCall({ filterBy, filterValue, state }) {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: sizePerPage,
          pageRequested: currentPage,
        },
        bodyRequest: {
          estado: state,
          ordenarPor: "",
          ordenDesc: false,
          filtrarPor: filterBy ? filterBy : "",
          valorFiltro: filterValue,
          tipo: "",
          menuId: localStorage.getItem('menuId'),
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "modelos/Listar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();
      if (!response.ok) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }

      setModelList(data.bodyResponse.modelos);
      setTotal(data.headerResponse.totalRecords);
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }

  const fetchModelsHandler = useCallback(
    apiCall.bind(this, {
      filterBy: filterBy,
      filterValue: filterValue,
      state: state,
    }),
    [action, currentPage, sizePerPage]
  );

  useEffect(() => {
    fetchModelsHandler({
      filterBy: filterBy,
      filterValue: filterValue,
      state: state,
    });
  }, [fetchModelsHandler]);

  useEffect(() => {
    //setAction(props.action);
    setCurrentPage(1);
    setShowMessage(location.state ? true : false);
    setMessage(location.state ? location.state : "");

    if (location.state) setTimeout(HideSuccessMessage, 5000);
  }, []);

  const onPageChange = (page, sizePerPage) => {
    setCurrentPage(page);
    setSizePerPage(sizePerPage);
  };

  async function DeleteModelHandler(model) {
    setIsLoading(true);
    setError(null);
    setShowError(false);

    let parsedModelId = [model];

    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1,
          pageRequested: 1,
        },
        bodyRequest: {
          modelosIds: parsedModelId,
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "modelos/Eliminar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );
      const data = await response.json();
      if (data.headerResponse.returnMessage === "OK") {
        fetchModelsHandler();
        setShowMessage(true);
        setMessage(data.headerResponse.returnMessage);
        setTimeout(HideSuccessMessage, 5000);
      } else {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }

  const columns = [
    { dataField: "key", text: "", hidden: true },
    { dataField: "codigo", text: "Código", hidden: true },
    { dataField: "nombre", text: "Nombre" },
    { dataField: "descripcion", text: "Descripción" },
    { dataField: "tipoModelo", text: "Tipo de Modelo" },
    { dataField: "action", text: "" },
  ];

  let parsedModelList = [];

  const actionButtons = (entry, id) => {
    return (
      <Stack direction="horizontal" gap={3}>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={selectModel.bind(this, entry)}
          icon={faTrashCan}
          color={COLORS.alert}
          size="lg"
        />
        <Link className="m-1" to={`/lista_modelos/${id}`}>
          <FontAwesomeIcon icon={faPencil} color={COLORS.highlight} size="lg" />
        </Link>
      </Stack>
    );
  };

  function selectModel(entry) {
    setSelectedModel(entry);
    setShow(true);
  }

  modelList.map((entry) => {
    return parsedModelList.push({
      key: entry.modeloId,
      codigo: entry.modeloId,
      nombre: entry.nombre,
      descripcion: entry.descripcion,
      tipoModelo: entry.tipoModelo,
      action: actionButtons(entry, entry.modeloId),
    });
  });

  function handleClose() {
    setShow(false);
    setSelectedModel(null);
  }

  function handleAction() {
    DeleteModelHandler(selectedModel.modeloId);
    setShow(false);
  }

  const modalConfirmation = (
    <Modal show={show} onHide={handleClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>ELIMINACIÓN DE MODELO</Modal.Title>
      </Modal.Header>
      <Modal.Body>¿Está seguro que desea eliminar el modelo?</Modal.Body>
      <Modal.Footer>
        <CustomButton
          size=""
          class={classes["btn-custom-close"]}
          label="Cancelar"
          eventHandler={handleClose}
        />
        <CustomButton
          size=""
          class={classes["btn-custom"]}
          label="Aceptar"
          eventHandler={handleAction}
        />
      </Modal.Footer>
    </Modal>
  );

  const table = (
    <CustomTable
      columns={columns}
      items={parsedModelList}
      page={currentPage}
      sizePerPage={sizePerPage}
      totalSize={total}
      onChangePage={onPageChange}
    />
  );

  const searchByValues = [
    { label: "Código", value: "code" },
    { label: "Nombre", value: "name" },
    { label: "Descripción", value: "description" },
  ];

  const search = (
    <SearchBar
      filterBy={setFilterBy}
      filterValue={setFilterValue}
      filterState={setState}
      fetchHandler={apiCall}
      searchByValues={searchByValues}
      searchBy="Filtro de Búsqueda"
      createRoute="/modelo/formulario"
    />
  );
  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const messageAlert = <SuccessAlert text={message} />;

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );
  const content = (
    <div>
      {showError && errorAlert}
      {showMessage && messageAlert}
      {search}
      {modalConfirmation}
      {!isLoading && table}
      {isLoading && loading}
    </div>
  );

  return <Fragment>{content}</Fragment>;
};

export default TableModels;
