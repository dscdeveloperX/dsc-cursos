import React from 'react';
import { BrowserRouter } from "react-router-dom";
import "./index.css";
import App from "./App";
import { createGlobalStyle } from "styled-components";
import "bootstrap/dist/css/bootstrap.min.css";
import "./fonts/Lato/Lato-Bold.ttf";
import { AuthContextProvider } from "./store/auth-context";
import ReactDOM from 'react-dom/client';
import './index.css';

const GlobalStyles = createGlobalStyle`
  html {
    --color-primary: #265F30;
    --color-secondary: #C8951A;
    --color-white: #FFFFFF;
    --color-primary-light: #009845;
    --color-secondary-light: #FCB316;
    --color-black: #000000;
    --color-grey: #707070;
    --color-darkGrey: #4D504E;
    --color-alert: #920808;
    --color-info: #268CB2;
    --color-whiteBone: #E7E3E2;
    --color-primary-light-opaque: #00984525;
    --color-highlight: #7cc140;
  }
`;

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <AuthContextProvider>
    <BrowserRouter>
      <React.StrictMode>
        <GlobalStyles />
        <App />
      </React.StrictMode>
    </BrowserRouter>
  </AuthContextProvider>
);
