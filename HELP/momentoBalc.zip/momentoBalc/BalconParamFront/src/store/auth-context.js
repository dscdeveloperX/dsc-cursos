import React, { useState } from "react";

const AuthContext = React.createContext({
  token: "",
  ip: "",
  user: "",
  menu: null,
  expirationTime: null,
  lastLoginDate: null,
  isLoggedIn: false,
  REACT_APP_BASE_URL: "",
  REACT_APP_SECURITY_BASE_URL: "",
  REACT_APP_SECURITY_APP_ID: 0,
  login: (token, user, ip, lastLoginDate, expirationTime, menu) => {},
  logout: () => {},
  setConfig: (config) => {},
});

const calculateRemainingTime = (expirationTime) => {
  if (expirationTime === null) return -1;

  const date = new Date();
  const now_utc = Date.UTC(
    date.getUTCFullYear(),
    date.getUTCMonth(),
    date.getUTCDate(),
    date.getUTCHours(),
    date.getUTCMinutes(),
    date.getUTCSeconds()
  );
  const currentTime = new Date(now_utc).getTime();
  const adjExpirationTime = new Date(expirationTime).getTime();

  const remainingDuration = adjExpirationTime - currentTime;

  return remainingDuration;
};

export const AuthContextProvider = (props) => {
  const initialToken = localStorage.getItem("token");
  const initialUser = localStorage.getItem("user");
  const initialIp = localStorage.getItem("ip");
  const initialMenu = localStorage.getItem("menu");
  const initialUrl = localStorage.getItem("link");
  const initialSecurityUrl = localStorage.getItem("securitylink");
  const initialApp = localStorage.getItem("app");
  const initialExpiration = localStorage.getItem("expiration");
  const initialLoginDate = localStorage.getItem("lastLoginDate");
  const [token, setToken] = useState(initialToken);
  const [expirationTime, setExpirationTime] = useState(initialExpiration);
  const [user, setUser] = useState(initialUser);
  const [ip, setIp] = useState(initialIp);
  const [menu, setMenu] = useState(initialMenu);
  const [lastLoginDate, setLastLoginDate] = useState(initialLoginDate);
  const [REACT_APP_SECURITY_BASE_URL, setSecurityUrl] = useState(
    initialSecurityUrl
  );
  const [REACT_APP_BASE_URL, setUrl] = useState(initialUrl);
  const [REACT_APP_SECURITY_APP_ID, setApp] = useState(initialApp);

  const logoutHandler = () => {
    setToken(null);
    setUser(null);
    setIp(null);
    setMenu(null);
    setExpirationTime(null);
    setLastLoginDate(null);
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("ip");
    localStorage.removeItem("menu");
    localStorage.removeItem("expiration");
    localStorage.removeItem("lastLoginDate");
    //localStorage.removeItem('menuId');
  };

  const userIsLoggedIn = !!token && calculateRemainingTime(expirationTime) > 0;

  const configHandler = (config) => {
    const confUrl =
      (config ? config.REACT_APP_BASE_URL : "") + "/api/v1/parametrizacion/";
    const confSecurityUrl =
      (config ? config.REACT_APP_SECURITY_BASE_URL : "") + "/api/v1/seguridad/";
    const confApp = config ? config.REACT_APP_SECURITY_APP_ID : 0;
    setUrl(confUrl);
    setSecurityUrl(confSecurityUrl);
    setApp(confApp);
    localStorage.setItem("app", REACT_APP_SECURITY_APP_ID);
    localStorage.setItem("link", REACT_APP_BASE_URL);
    localStorage.setItem("securitylink", REACT_APP_SECURITY_BASE_URL);
  };

  const loginHandler = (token, user, ip, lastLoginDate, expirationTime, menu) => {
    setToken(token);
    setUser(user);
    setIp(ip);
    setMenu(JSON.stringify(menu));
    setExpirationTime(expirationTime);
    setLastLoginDate(lastLoginDate);
    localStorage.setItem("token", token);
    localStorage.setItem("user", user);
    localStorage.setItem("ip", ip);
    localStorage.setItem("expiration", expirationTime);
    localStorage.setItem("lastLoginDate", lastLoginDate);
    localStorage.setItem("menu", JSON.stringify(menu));

    const remainingTime = calculateRemainingTime(expirationTime);
    setTimeout(logoutHandler, remainingTime);
  };

  const contextValue = {
    token: token,
    user: user,
    ip: ip,
    menu: menu,
    expirationTime: expirationTime,
    lastLoginDate: lastLoginDate,
    isLoggedIn: userIsLoggedIn,
    REACT_APP_BASE_URL: REACT_APP_BASE_URL,
    REACT_APP_SECURITY_BASE_URL: REACT_APP_SECURITY_BASE_URL,
    REACT_APP_SECURITY_APP_ID: REACT_APP_SECURITY_APP_ID,
    login: loginHandler,
    logout: logoutHandler,
    setConfig: configHandler,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
