import {
  Fragment,
  useState,
  useContext,
  useCallback,
  useEffect,
  useRef,
} from "react";
import { useParams, useHistory } from "react-router-dom";
import { Form, Row } from "react-bootstrap";
import AuthContext from "../../store/auth-context";
import CustomButton from "../UI/buttons/CustomButton";
import HeaderTitle from "../UI/fields/HeaderTitle";
import LoadingSpinner from "../UI/LoadingSpinner";
import ErrorAlert from "../UI/ErrorAlert";
import classes from "../UI/css/SearchBar.module.css";
import SelectCatalogue from "../UI/fields/SelectCatalogue";
import SelectModel from "../UI/fields/SelectModel";

import FormInput from "../UI/fields/FormInput";

import { COLORS } from "../../values/colors";
import FormatSectionItem from "../UI/FormatSectionItem";
import SectionTitle from "../UI/fields/SectionTitle";
import FormatDetailModal from "./FormatDetailModal";

const FormFormat = () => {
  const [isLoading, setIsLoading] = useState(false);

  const [disableFields, setDisableFields] = useState(false);
  const [editModeIsOn, setEditModeIsOn] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState(null);

  const [formatId, setFormatId] = useState(0);
  const [name, setName] = useState("");
  const [refCode, setRefCode] = useState("");
  const [description, setDescription] = useState("");
  const [personType, setPersonType] = useState("J");
  const [idType, setIdType] = useState("N");
  const [clientType, setClientType] = useState("01");
  const [selectedPerson, setSelectedPerson] = useState("PJ");
  const [selectedProduct, setSelectedProduct] = useState("");

  const [personSections, setPersonSections] = useState([]);
  const [productSections, setProductSections] = useState([]);
  const [refSections, setRefSections] = useState([]);

  const [selectedModelType, setSelectedModelType] = useState("");
  const [selectedSection, setSelectedSection] = useState(0);
  const [selectedSubection, setSelectedSubsection] = useState(0);
  const [selectedEdit, setSelectedEdit] = useState(null);

  const [refCodeIsValid, setRefCodeIsValid] = useState(false);
  const [nameIsValid, setNameIsValid] = useState(false);
  const [descriptionIsValid, setDescriptionIsValid] = useState(false);

  const [error, setError] = useState(null);
  const [showError, setShowError] = useState(false);

  const [show, setShow] = useState(false);

  const [modelFields, setModelFields] = useState([]);
  const [modelReferenceFields, setModelReferenceFields] = useState([]);

  const authCtx = useContext(AuthContext);

  const params = useParams();

  let history = useHistory();

  let formIsValid = false;

  const modalRef = useRef();

  const getModelFields = (persona, producto, referencias) => {
    var fields = [];

    mapModelFields(fields, persona, "Cliente");
    if (producto !== null) {
      mapModelFields(fields, producto, "Producto");
    }

    var referenceFields = [];
    if (referencias !== undefined && referencias !== null && referencias.length > 0) {
      for (let index = 0; index < referencias.length; index++) {
        const element = referencias[index];
        var indexFields = [];
        mapModelFields(indexFields, element.seccionesCampo, element.nombre);
        referenceFields.push(indexFields);
      }
    }
    setModelReferenceFields(referenceFields);
    setModelFields(fields);
  };

  const mapModelFields = (fields, secciones, model) => {
    if (secciones !== undefined && secciones !== null) {
      for (var i = 0; i < secciones.length; i++) {
        var section = secciones[i];

        if (section.campos !== null && section.campos.length > 0) {
          for (var j = 0; j < section.campos.length; j++) {
            var field = section.campos[j];
            if (field.tipoValor.trim() == "VALOR")
              fields.push({
                etiqueta: field.etiqueta,
                codigo: field.codigo,
                tipoDato: field.tipoDato,
                model: model,
              });
          }
        }
        if (section.secciones !== null && section.secciones.length > 0) {
          for (var j = 0; j < section.secciones.length; j++) {
            var subsection = section.secciones[j];
            if (subsection.campos !== null && subsection.campos.length > 0) {
              for (var z = 0; z < subsection.campos.length; z++) {
                var field = subsection.campos[z];
                if (field.tipoValor.trim() == "VALOR")
                  fields.push({
                    etiqueta: field.etiqueta,
                    codigo: field.codigo,
                    tipoDato: field.tipoDato,
                    model: model,
                  });
              }
            }
          }
        }
      }
    }
  };

  const formSubmissionHandler = (event) => {
    event.preventDefault();

    if (refCodeIsValid && nameIsValid && descriptionIsValid) {
      formIsValid = true;
    }

    if (params.formatoId) {
      setFormatId(params.formatoId);
    }

    const format = {
      formatoId: formatId,
      codigo: refCode,
      nombre: name,
      descripcion: description,
      tipoPersona: personType,
      tipoIdentificacion: idType,
      tipoCliente: clientType,
      persona: selectedPerson,
      producto: selectedProduct,
      seccionesPersona: personSections === null ? [] : personSections,
      seccionesProducto: productSections === null ? [] : productSections,
      seccionesReferencias: refSections === null ? [] : refSections,
    };

    if (!editModeIsOn) {
      if (!formIsValid) {
        return;
      }
      AddFormatHandler(format);
    } else if (editModeIsOn) {
      EditFormatHandler(format);
    }
  };

  //#region Cargar Info desde API al renderizar

  const fetchFormatByIdHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    if (params.formatoId === null) {
      setIsLoading(false);
      return;
    }
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          formatoId: +params.formatoId,
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "formatos/ObtenerPorId",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }

      setRefCode(data.bodyResponse.formato.codigo);
      setDescription(data.bodyResponse.formato.descripcion);
      setName(data.bodyResponse.formato.nombre);
      setPersonType(data.bodyResponse.formato.tipoPersona.codigo);
      setClientType(data.bodyResponse.formato.tipoCliente.codigo);
      setIdType(data.bodyResponse.formato.tipoIdentificacion.codigo);
      setSelectedPerson(data.bodyResponse.formato.persona.codigo);
      setSelectedProduct(
        data.bodyResponse.formato.producto
          ? data.bodyResponse.formato.producto.codigo
          : ""
      );

      getModelFields(
        data.bodyResponse.formato.seccionesPersona,
        data.bodyResponse.formato.seccionesProducto,
        data.bodyResponse.formato.seccionesReferencias
      );
      //setFormatId(data.bodyResponse.formato.formatoId);

      setPersonSections(data.bodyResponse.formato.seccionesPersona);
      setProductSections(
        data.bodyResponse.formato.seccionesProducto
          ? data.bodyResponse.formato.seccionesProducto
          : []
      );
      setRefSections(
        data.bodyResponse.formato.seccionesReferencias
          ? data.bodyResponse.formato.seccionesReferencias
          : []
      );

      setDisableFields(false);
      setEditModeIsOn(true);
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }, [params.formatoId]);

  useEffect(() => {
    if (params.formatoId) fetchFormatByIdHandler();
  }, [fetchFormatByIdHandler]);

  async function AddFormatHandler(format) {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1,
          pageRequested: 1,
        },
        bodyRequest: {
          formato: {
            formatoId: format.formatoId,
            codigo: format.codigo,
            nombre: format.nombre,
            descripcion: format.descripcion,
            tipoPersona: format.tipoPersona,
            tipoIdentificacion: format.tipoIdentificacion,
            tipoCliente: format.tipoCliente,
            persona: format.persona,
            producto: format.producto,
            seccionesPersona: format.seccionesPersona,
            seccionesProducto: format.seccionesProducto,
            seccionesReferencias: format.seccionesReferencias,
          },
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "formatos/Crear",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();

      if (data.headerResponse.returnMessage === "OK") {
        history.push("/lista_formatos");
      } else {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }

  async function EditFormatHandler(format) {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1,
          pageRequested: 1,
        },
        bodyRequest: {
          formato: {
            formatoId: +params.formatoId
              ? +params.formatoId
              : +format.formatoId,
            codigo: format.codigo,
            nombre: format.nombre,
            descripcion: format.descripcion,
            tipoPersona: format.tipoPersona,
            tipoIdentificacion: format.tipoIdentificacion,
            tipoCliente: format.tipoCliente,
            persona: format.persona,
            producto: format.producto,
            seccionesPersona: format.seccionesPersona,
            seccionesProducto: format.seccionesProducto,
            seccionesReferencias: format.seccionesReferencias,
          },
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "formatos/Actualizar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );
      const data = await response.json();

      if (data.headerResponse.returnMessage === "OK") {
        history.push("/lista_formatos");
      } else {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }

  const editField = (sectionOrder, subsectionOrder, fieldOrder) => {
    let tempSections = [...personSections];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });
    let field;

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === fieldOrder;
        }
      );

      field = tempSections[index].secciones[subindex].campos[fieldindex];
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === fieldOrder;
      });

      field = tempSections[index].campos[fieldindex];
    }
    setSelectedModelType("PERSONA");
    setSelectedSection(sectionOrder);
    setSelectedSubsection(subsectionOrder);
    setSelectedEdit(field);
    modalRef.current.setEditItem(field, null);
    setShow(true);
  };

  const editProductField = (sectionOrder, subsectionOrder, fieldOrder) => {
    let tempSections = [...productSections];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });
    let field;

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === fieldOrder;
        }
      );

      field = tempSections[index].secciones[subindex].campos[fieldindex];
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === fieldOrder;
      });

      field = tempSections[index].campos[fieldindex];
    }
    setSelectedModelType("PRODUCTO");
    setSelectedSection(sectionOrder);
    setSelectedSubsection(subsectionOrder);
    setSelectedEdit(field);
    modalRef.current.setEditItem(field, null);
    setShow(true);
  };

  const editSectionField = (
    indexRef,
    refFields,
    sectionOrder,
    subsectionOrder,
    fieldOrder
  ) => {
    let tempSections = [...refFields];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });
    let field;

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === fieldOrder;
        }
      );

      field = tempSections[index].secciones[subindex].campos[fieldindex];
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === fieldOrder;
      });

      field = tempSections[index].campos[fieldindex];
    }
    setSelectedModelType("REF-" + indexRef);
    setSelectedSection(sectionOrder);
    setSelectedSubsection(subsectionOrder);
    setSelectedEdit(field);
    modalRef.current.setEditItem(field, modelReferenceFields[indexRef]);
    setShow(true);
  };

  const fetchFormatFieldsHandler = async () => {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    if (selectedPerson === null) {
      setIsLoading(false);
      return;
    }
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          persona: selectedPerson,
          producto: selectedProduct,
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "formatos/ObtenerCamposFormato",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }

      getModelFields(
        data.bodyResponse.formato.seccionesPersona,
        data.bodyResponse.formato.seccionesProducto
      );

      setPersonSections(data.bodyResponse.formato.seccionesPersona);
      setProductSections(data.bodyResponse.formato.seccionesProducto);
      setRefSections(data.bodyResponse.formato.seccionesReferencias);
      //setDisableFields(true);
      //setEditModeIsOn(true);
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  };

  const formEditHandler = () => {
    setDisableFields(false);
    setEditModeIsOn(true);
  };

  const saveFieldHandler = (entry) => {
    let tempSections;
    var refIndex = -1;
    if (selectedModelType === "PERSONA") {
      tempSections = [...personSections];
    } else if (selectedModelType === "PRODUCTO") {
      tempSections = [...productSections];
    } else {
      refIndex = selectedModelType.split("-")[1];
      let refSect = refSections[refIndex].seccionesCampo;
      tempSections = [...refSect];
    }

    let index = tempSections.findIndex((object) => {
      return object.orden === selectedSection;
    });
    if (selectedSubection > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === selectedSubection;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === entry.ordenCampo;
        }
      );
      tempSections[index].secciones[subindex].campos[fieldindex] = entry;
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === entry.ordenCampo;
      });
      tempSections[index].campos[fieldindex] = entry;
    }
    if (selectedModelType === "PERSONA") {
      setPersonSections(tempSections);
    } else if (selectedModelType === "PRODUCTO") {
      setProductSections(tempSections);
    } else {
      const allref = [...refSections];
      allref[refIndex].seccionesCampo = tempSections;
      setRefSections(allref);
    }

    setSelectedSection(0);
    setSelectedSubsection(0);
    setSelectedEdit(null);
  };

  //#endregion

  //#region dom

  const formButtons = (
    <Row xs="auto" className="justify-content-end m-3">
      {editModeIsOn && disableFields && (
        <CustomButton
          size=""
          class={classes["btn-custom"]}
          label="Editar"
          eventHandler={formEditHandler}
        />
      )}
      {(!editModeIsOn || (editModeIsOn && !disableFields)) && (
        <CustomButton
          size=""
          class={classes["btn-custom"]}
          label="Guardar"
          eventHandler={formSubmissionHandler}
        />
      )}
    </Row>
  );
  const actionButtons = (
    <Row xs="auto" className="justify-content-end m-3">
      {(!editModeIsOn || (editModeIsOn && !disableFields)) && (
        <CustomButton
          size=""
          class={classes["btn-custom-inverse"]}
          color={COLORS.primaryLight}
          iconColor={COLORS.primaryLight}
          label="Buscar Campos"
          icon="faMagnifyingGlass"
          eventHandler={fetchFormatFieldsHandler}
        />
      )}
    </Row>
  );
  const formatForm = (
    <Form className="m-4" onSubmit={formSubmissionHandler}>
      <Row className="mb-3">
        <FormInput
          label="Código"
          value={refCode}
          disabled={disableFields}
          parentCallback={setRefCode}
          parentIsValidCallback={setRefCodeIsValid}
        />
        <FormInput
          label="Nombre"
          value={name}
          disabled={disableFields}
          parentCallback={setName}
          parentIsValidCallback={setNameIsValid}
        />
      </Row>
      <Row className="mb-3">
        <FormInput
          label="Descripción"
          value={description}
          disabled={disableFields}
          parentCallback={setDescription}
          parentIsValidCallback={setDescriptionIsValid}
        />
        <SelectCatalogue
          selected={personType}
          disabled={disableFields}
          label="Tipo Persona"
          catalogo="CLASE_PERSONA"
          parentCallback={setPersonType}
        />
      </Row>
      <Row className="mb-3">
        <SelectCatalogue
          selected={idType}
          disabled={disableFields}
          label="Tipo Identificación"
          catalogo="TIPO_DOCUMENTO"
          parentCallback={setIdType}
        />
        <SelectCatalogue
          selected={clientType}
          disabled={disableFields}
          label="Tipo Cliente"
          catalogo="TIPO_CLIENTE"
          parentCallback={setClientType}
        />
      </Row>
      <Row className="mb-3">
        <SelectModel
          selected={selectedPerson}
          disabled={disableFields}
          label="Persona"
          tipo="PERSONA"
          parentCallback={setSelectedPerson}
        />
        <SelectModel
          allowNone={true}
          selected={selectedProduct}
          disabled={disableFields}
          label="Producto"
          tipo="PRODUCTO"
          parentCallback={setSelectedProduct}
        />
      </Row>
      {personSections !== null && personSections.length === 0 && actionButtons}
      {personSections !== null && personSections.length > 0 && (
        <Fragment>
          <SectionTitle label="Cliente" />
          <FormatSectionItem
            sections={personSections}
            hijos={selectedFormat}
            disable={disableFields}
            onEditField={editField}
            editModeIsOn={disableFields}
          />
        </Fragment>
      )}
      {productSections !== null && productSections.length > 0 && (
        <Fragment>
          <SectionTitle label="Producto" />
          <FormatSectionItem
            sections={productSections}
            hijos={selectedFormat}
            disable={disableFields}
            onEditField={editProductField}
            editModeIsOn={disableFields}
          />
        </Fragment>
      )}
      {refSections !== undefined && refSections !== null &&
        refSections.length > 0 &&
        refSections.map((refFields, index) => {
          return (
            <Fragment>
              <SectionTitle label={"CAMPO REFERENCIA: " + refFields.nombre} />
              <FormatSectionItem
                sections={refFields.seccionesCampo}
                hijos={selectedFormat}
                disable={disableFields}
                onEditField={(sectionOrder, subsectionOrder, fieldOrder) => {
                  editSectionField(
                    index,
                    refFields.seccionesCampo,
                    sectionOrder,
                    subsectionOrder,
                    fieldOrder
                  );
                }}
                editModeIsOn={disableFields}
              />
            </Fragment>
          );
        })}
      <FormatDetailModal
        ref={modalRef}
        show={show}
        modelFields={modelFields}
        setShow={setShow}
        disableFields={disableFields}
        onSaveField={saveFieldHandler}
        editItem={selectedEdit}
        formatId={formatId}
      />
    </Form>
  );
  const body = (
    <Fragment>
      {formatForm}
      {formButtons}
    </Fragment>
  );

  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );

  return (
    <Fragment>
      <HeaderTitle label="FORMATO" />
      {showError && errorAlert}
      {!isLoading && body}
      {isLoading && loading}
    </Fragment>
  );
  //#endregion
};

export default FormFormat;
