import { Modal, Form, Row } from "react-bootstrap";
import { Fragment, useState, useImperativeHandle, forwardRef } from "react";
import CustomButton from "../UI/buttons/CustomButton";
import FormInput from "../UI/fields/FormInput";
import FormSelect from "../UI/fields/FormSelect";
import classes from "../UI/css/BMButton.module.css";
import SelectDependencyRules from "../UI/fields/SelectDependencyRules";
import SelectDependency from "../UI/fields/SelectDependency";
import DependencyOperationValues from "../UI/fields/DependencyOperationValues";
import ValidationFieldsSelect from "../UI/fields/ValidationFieldsSelect";
import DefaultValueTable from "../UI/fields/DefaultValueTable";
import SubHeaderTitle from "../UI/fields/SubHeaderTitle";
import ValidationRulesValues from "../UI/fields/ValidationRulesValues";

const FormatDetailModal = (props, ref) => {
  const modalFields = props.modelFields;

  const [modelDependenceFields, setModelDependenceFields] =
    useState(modalFields);

  const [isLoading, setIsLoading] = useState(false);
  const [editItem, setEditItem] = useState();

  const [valorDefecto, setValorDefecto] = useState("");

  const [formatoId, setFormatoId] = useState(0);
  const [formatoDetalleId, setFormatoDetalleId] = useState(0);
  const [campoId, setCampoId] = useState(0);
  const [modeloId, setModeloId] = useState(0);
  const [tipoValor, setTipoValor] = useState("VALOR");
  const [etiqueta, setEtiqueta] = useState("");
  const [codigo, setCodigo] = useState("");
  const [tipoCampo, setTipoCampo] = useState("TEXTFIELD");
  const [tipoDato, setTipoDato] = useState("ALFABETICO");
  const [tipoCalculado, setTipoCalculado] = useState("");
  const [nombreCalculo, setNombreCalculo] = useState("");
  const [longitudMinima, setLongitudMinima] = useState(0);
  const [longitudMaxima, setLongitudMaxima] = useState(0);
  const [ordenCampo, setOrdenCampo] = useState(0);
  const [origenCombobox, setOrigenCombobox] = useState("");
  const [origenValores, setOrigenValores] = useState("");
  const [origenCatalogo, setOrigenCatalogo] = useState("");
  const [permiteEnmascaramiento, setPermiteEnmascaramiento] = useState(false);
  const [enmascarar, setEnmascarar] = useState(false);
  const [obligatorio, setObligatorio] = useState(false);
  const [requerido, setRequerido] = useState(false);
  const [dependenciaRequerido, setDependenciaRequerido] = useState("");
  const [reglaDependenciaRequerido, setReglaDependenciaRequerido] =
    useState("");
  const [valoresDependenciaRequerido, setValoresDependenciaRequerido] =
    useState({});
  const [visible, setVisible] = useState(false);
  const [dependenciaVisibilidad, setDependenciaVisibilidad] = useState("");
  const [reglaDependenciaVisibilidad, setReglaDependenciaVisibilidad] =
    useState("");
  const [valoresDependenciaVisibilidad, setValoresDependenciaVisibilidad] =
    useState({});
  const [editable, setEditable] = useState(false);
  const [dependenciaEditable, setDependenciaEditable] = useState("");
  const [reglaDependenciaEditable, setReglaDependenciaEditable] = useState("");
  const [valoresDependenciaEditable, setValoresDependenciaEditable] = useState(
    {}
  );
  const [tipoValidacion, setTipoValidacion] = useState("");
  const [dependenciaValidacion, setDependenciaValidacion] = useState("");
  const [reglaDependenciaValidacion, setReglaDependenciaValidacion] =
    useState("");
  const [valoresDependenciaValidacion, setValoresDependenciaValidacion] =
    useState({});
  const [validacionRegex, setValidacionRegex] = useState("");
  const [validacionReglas, setValidacionReglas] = useState("");
  const [validacionRutina, setValidacionRutina] = useState("");
  const [validacionRutinaCampos, setValidacionRutinaCampos] = useState([]);

  const [comboboxPermiteNinguno, setcomboboxPermiteNinguno] = useState(false);
  const [tipoFiltro, setTipoFiltro] = useState("INICIAL");
  const [dependenciaFiltro, setDependenciaFiltro] = useState("");
  const [reglaDependenciaFiltro, setReglaDependenciaFiltro] = useState("VALOR");
  const [valoresDependenciaFiltro, setValoresDependenciaFiltro] = useState({
    DEFAULT: { operacion: "NONE", valores: [] },
  });

  const [tipoValorDefecto, setTipoValorDefecto] = useState("INICIAL");
  const [dependenciaValorDefecto, setDependenciaValorDefecto] = useState("");
  const [reglaDependenciaValorDefecto, setReglaDependenciaValorDefecto] =
    useState("VALOR");
  const [valoresDependenciaValorDefecto, setValoresDependenciaValorDefecto] =
    useState({ DEFAULT: "" });

  const [anchoColumna, setAnchoColumna] = useState("12");
  const [formularioVisible, setFormularioVisible] = useState(false);
  const [etiquetaFormulario, setEtiquetaFormulario] = useState("");
  const [anchoColumnaFormulario, setAnchoColumnaFormulario] = useState("12");
  const [anchoEtiquetaFormulario, setAnchoEtiquetaFormulario] = useState("6");

  const [formatoModeloLista, setFormatoModeloLista] = useState("");

  const handleClose = () => {
    props.setShow(false);
    setEditItem(null);
  };

  useImperativeHandle(
    ref,
    () => ({
      setEditItem: (editItem, refFields) => setModalItem(editItem, refFields),
    }),
    []
  );

  const setModalItem = (editItem, refFields) => {
    setEditItem(editItem);

    let fields = [];
    if (refFields !== undefined && refFields !== null && refFields.length > 0) {
      fields = [...modalFields, ...refFields];
    } else {
      fields = [...modalFields];
    }
    setModelDependenceFields(fields);

    if (editItem !== undefined && editItem !== null) {
      setFormatoId(editItem.formatoId);
      setFormatoDetalleId(editItem.formatoDetalleId);
      setCampoId(editItem.campoId);
      setModeloId(editItem.modeloId);
      setTipoValor(editItem.tipoValor);
      setEtiqueta(editItem.etiqueta);
      setCodigo(editItem.codigo);
      setTipoCampo(editItem.tipoCampo);
      setTipoDato(editItem.tipoDato);
      setNombreCalculo(
        editItem.nombreCalculo === null ? "" : editItem.nombreCalculo?.trim()
      );
      setTipoCalculado(
        editItem.tipoCalculado === null ? "" : editItem.tipoCalculado?.trim()
      );
      setLongitudMinima(editItem.longitudMinima);
      setLongitudMaxima(editItem.longitudMaxima);
      setOrdenCampo(editItem.ordenCampo);
      setOrigenCombobox(
        editItem.origenCombobox === null ? "" : editItem.origenCombobox?.trim()
      );
      setOrigenValores(
        editItem.origenValores === null ? "" : editItem.origenValores?.trim()
      );
      setOrigenCatalogo(
        editItem.origenCatalogo === null ? "" : editItem.origenCatalogo?.trim()
      );
      setPermiteEnmascaramiento(editItem.permiteEnmascaramiento);
      setEnmascarar(editItem.permiteEnmascaramiento && editItem.enmascarar);
      setObligatorio(editItem.obligatorio);
      setRequerido(editItem.obligatorio || editItem.requerido);
      setDependenciaRequerido(
        editItem.dependenciaRequerido === null
          ? ""
          : editItem.dependenciaRequerido?.trim()
      );
      setReglaDependenciaRequerido(
        editItem.reglaDependenciaRequerido === null
          ? ""
          : editItem.reglaDependenciaRequerido?.trim()
      );
      setValoresDependenciaRequerido(
        editItem.valoresDependenciaRequerido === null
          ? {
            DEFAULT: { operacion: "NONE", valores: [] },
          }
          : editItem.valoresDependenciaRequerido
      );
      setVisible(editItem.visible);
      setDependenciaVisibilidad(
        editItem.dependenciaVisibilidad === null
          ? ""
          : editItem.dependenciaVisibilidad?.trim()
      );
      setReglaDependenciaVisibilidad(
        editItem.reglaDependenciaVisibilidad === null
          ? ""
          : editItem.reglaDependenciaVisibilidad?.trim()
      );
      setValoresDependenciaVisibilidad(
        editItem.valoresDependenciaVisibilidad === null
          ? {
            DEFAULT: { operacion: "NONE", valores: [] },
          }
          : editItem.valoresDependenciaVisibilidad
      );
      setEditable(editItem.tipoCampo !== "CALCULADO" && editItem.editable);
      setDependenciaEditable(
        editItem.dependenciaEditable === null
          ? ""
          : editItem.dependenciaEditable?.trim()
      );
      setReglaDependenciaEditable(
        editItem.reglaDependenciaEditable === null
          ? ""
          : editItem.reglaDependenciaEditable?.trim()
      );
      setValoresDependenciaEditable(
        editItem.valoresDependenciaEditable === null
          ? {
            DEFAULT: { operacion: "NONE", valores: [] },
          }
          : editItem.valoresDependenciaEditable
      );
      setTipoValidacion(
        editItem.tipoValidacion === null ? "" : editItem.tipoValidacion?.trim()
      );
      setDependenciaValidacion(
        editItem.dependenciaValidacion === null
          ? ""
          : editItem.dependenciaValidacion?.trim()
      );
      setReglaDependenciaValidacion(
        editItem.reglaDependenciaValidacion === null
          ? ""
          : editItem.reglaDependenciaValidacion?.trim()
      );
      setValoresDependenciaValidacion(
        editItem.valoresDependenciaValidacion === null
          ? {
            DEFAULT: { operacion: "NONE", valores: [] },
          }
          : editItem.valoresDependenciaValidacion
      );
      setValidacionRegex(
        editItem.validacionRegex === null
          ? ""
          : editItem.validacionRegex?.trim()
      );
      setValidacionReglas(
        editItem.validacionReglas === null
          ? {
            DEFAULT: { operacion: "NONE", valores: [] },
          }
          : editItem.validacionReglas
      );
      setValidacionRutina(
        editItem.validacionRutina === null
          ? ""
          : editItem.validacionRutina?.trim()
      );
      setValidacionRutinaCampos(
        editItem.validacionRutinaCampos === null
          ? []
          : editItem.validacionRutinaCampos
      );

      setcomboboxPermiteNinguno(
        editItem.validacionRutinaCampos === null
          ? false
          : editItem.validacionRutinaCampos
      );
      setTipoFiltro(
        editItem.tipoFiltro === null ? "" : editItem.tipoFiltro?.trim()
      );
      setDependenciaFiltro(
        editItem.dependenciaFiltro === null
          ? ""
          : editItem.dependenciaFiltro?.trim()
      );
      setReglaDependenciaFiltro(
        editItem.reglaDependenciaFiltro === null
          ? "VALOR"
          : editItem.reglaDependenciaFiltro?.trim()
      );
      setValoresDependenciaFiltro(
        editItem.valoresDependenciaFiltro === null
          ? {
            DEFAULT: { operacion: "NONE", valores: [] },
          }
          : editItem.valoresDependenciaFiltro
      );
      setTipoValorDefecto(
        editItem.tipoValorDefecto === null
          ? ""
          : editItem.tipoValorDefecto?.trim()
      );
      setDependenciaValorDefecto(
        editItem.dependenciaValorDefecto === null
          ? ""
          : editItem.dependenciaValorDefecto?.trim()
      );
      setReglaDependenciaValorDefecto(
        editItem.reglaDependenciaValorDefecto === null
          ? "VALOR"
          : editItem.reglaDependenciaValorDefecto?.trim()
      );
      setValoresDependenciaValorDefecto(
        editItem.valoresDependenciaValorDefecto === null
          ? {
            DEFAULT: "",
          }
          : editItem.valoresDependenciaValorDefecto
      );
      setValorDefecto(
        editItem.valoresDependenciaValorDefecto === null
          ? ""
          : editItem.valoresDependenciaValorDefecto["DEFAULT"] !== undefined
            ? editItem.valoresDependenciaValorDefecto["DEFAULT"]
            : ""
      );
      setAnchoColumna(
        editItem.anchoColumna === null ? "12" : editItem.anchoColumna?.trim()
      );
      setFormularioVisible(
        editItem.formularioVisible === null ? false : editItem.formularioVisible
      );
      setEtiquetaFormulario(
        editItem.etiquetaFormulario === null
          ? ""
          : editItem.etiquetaFormulario?.trim()
      );
      setAnchoColumnaFormulario(
        editItem.anchoColumnaFormulario === null
          ? "12"
          : editItem.anchoColumnaFormulario?.trim()
      );
      setAnchoEtiquetaFormulario(
        editItem.anchoEtiquetaFormulario === null
          ? "6"
          : editItem.anchoEtiquetaFormulario?.trim()
      );
      setFormatoModeloLista(editItem.formatoModeloLista);
    }
  };

  const saveField = () => {
    let info = {
      formatoId: formatoId,
      formatoDetalleId: formatoDetalleId,
      campoId: campoId,
      modeloId: modeloId,
      tipoValor: tipoValor,
      etiqueta: etiqueta,
      codigo: codigo,
      tipoCampo: tipoCampo,
      tipoDato: tipoDato,
      nombreCalculo: nombreCalculo,
      tipoCalculado: tipoCalculado,
      longitudMinima: longitudMinima,
      longitudMaxima: longitudMaxima,
      ordenCampo: ordenCampo,
      origenCombobox: origenCombobox,
      origenValores: origenValores,
      origenCatalogo: origenCatalogo,
      permiteEnmascaramiento: permiteEnmascaramiento,
      enmascarar: permiteEnmascaramiento ? enmascarar : false,
      obligatorio: obligatorio,
      requerido: obligatorio ? true : requerido,
      dependenciaRequerido:
        requerido && dependenciaRequerido !== "" ? dependenciaRequerido : null,
      reglaDependenciaRequerido:
        requerido && dependenciaRequerido !== ""
          ? reglaDependenciaRequerido
          : null,
      valoresDependenciaRequerido:
        requerido &&
          dependenciaRequerido !== "" &&
          reglaDependenciaRequerido === "OPERACION"
          ? valoresDependenciaRequerido
          : null,
      visible: visible,
      dependenciaVisibilidad:
        visible && dependenciaVisibilidad !== ""
          ? dependenciaVisibilidad
          : null,
      reglaDependenciaVisibilidad:
        visible && dependenciaVisibilidad !== ""
          ? reglaDependenciaVisibilidad
          : null,
      valoresDependenciaVisibilidad:
        visible &&
          dependenciaVisibilidad !== "" &&
          reglaDependenciaVisibilidad === "OPERACION"
          ? valoresDependenciaVisibilidad
          : null,
      editable: editable,
      dependenciaEditable:
        editable && dependenciaEditable !== "" ? dependenciaEditable : null,
      reglaDependenciaEditable:
        editable && dependenciaEditable !== ""
          ? reglaDependenciaEditable
          : null,
      valoresDependenciaEditable:
        editable &&
          dependenciaEditable !== "" &&
          reglaDependenciaEditable === "OPERACION"
          ? valoresDependenciaEditable
          : null,
      tipoValidacion: tipoValidacion !== "" ? tipoValidacion : null,
      dependenciaValidacion:
        tipoValidacion !== "" && dependenciaValidacion !== ""
          ? dependenciaValidacion
          : null,
      reglaDependenciaValidacion:
        tipoValidacion !== "" && dependenciaValidacion !== ""
          ? reglaDependenciaValidacion
          : null,
      valoresDependenciaValidacion:
        tipoValidacion !== "" &&
          dependenciaValidacion !== "" &&
          reglaDependenciaValidacion === "OPERACION"
          ? valoresDependenciaValidacion
          : null,
      validacionRegex: tipoValidacion === "REGEX" ? validacionRegex : null,
      validacionReglas: tipoValidacion === "REGLA" ? validacionReglas : null,
      validacionRutina: tipoValidacion === "RUTINA" ? validacionRutina : null,
      validacionRutinaCampos:
        tipoValidacion === "RUTINA" ? validacionRutinaCampos : null,
      comboboxPermiteNinguno:
        tipoCampo === "COMBOBOX" ? comboboxPermiteNinguno : null,
      tipoFiltro: tipoCampo === "COMBOBOX" ? tipoFiltro : null,
      dependenciaFiltro:
        tipoCampo === "COMBOBOX" &&
          tipoFiltro === "ONCHANGE" &&
          dependenciaFiltro !== ""
          ? dependenciaFiltro
          : null,
      reglaDependenciaFiltro:
        tipoCampo === "COMBOBOX" && tipoFiltro !== ""
          ? tipoFiltro == "INICIAL"
            ? "VALOR"
            : reglaDependenciaFiltro
          : null,
      valoresDependenciaFiltro:
        tipoCampo === "COMBOBOX" && tipoFiltro !== ""
          ? valoresDependenciaFiltro
          : null,
      tipoValorDefecto: tipoValor === "VALOR" ? tipoValorDefecto : null,
      dependenciaValorDefecto:
        tipoValor === "VALOR" &&
          tipoValorDefecto === "ONCHANGE" &&
          dependenciaValorDefecto !== ""
          ? dependenciaValorDefecto
          : null,
      reglaDependenciaValorDefecto:
        tipoValor === "VALOR" && tipoValorDefecto !== ""
          ? tipoValorDefecto == "INICIAL"
            ? "VALOR"
            : "CONDICIONAL"
          : null,
      valoresDependenciaValorDefecto:
        tipoValor === "VALOR" && tipoValorDefecto !== ""
          ? valoresDependenciaValorDefecto
          : null,
      anchoColumna: anchoColumna,
      formularioVisible: formularioVisible,
      etiquetaFormulario: formularioVisible ? etiquetaFormulario : null,
      anchoColumnaFormulario: formularioVisible ? anchoColumnaFormulario : null,
      anchoEtiquetaFormulario: formularioVisible
        ? anchoEtiquetaFormulario
        : null,
      formatoModeloLista: formatoModeloLista,
    };
    props.onSaveField(info);
    handleClose();
  };

  const form = (
    <Form style={{ width: "95%", margin: "auto" }}>
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN CAMPO"></SubHeaderTitle>
        <Row className="mb-3">
          <FormInput value={tipoValor} label="Tipo Valor" disabled={true} />
          <FormInput value={tipoCampo} label="Tipo Campo" disabled={true} />
        </Row>
      </Form.Group>
      <Form.Group>
        <Row className="mb-3">
          <FormInput value={tipoDato} label="Tipo Dato" disabled={true} />
          <FormInput
            value={etiqueta}
            label="Etiqueta"
            disabled={props.disableFields}
            parentCallback={setEtiqueta}
          />
        </Row>
      </Form.Group>
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN REQUERIDO"></SubHeaderTitle>
        <Row className="mb-3">
          <Form.Check
            type="checkbox"
            value={requerido}
            label="Requerido?"
            onChange={(e) => {
              setRequerido(e.target.checked);
            }}
            disabled={props.disableFields || obligatorio === true}
            checked={requerido}
          />
        </Row>
        {requerido && (
          <Row>
            <SelectDependency
              modeloId={modeloId}
              value={dependenciaRequerido}
              fields={modelDependenceFields}
              label={"Dependencia Requerido"}
              parentCallback={setDependenciaRequerido}
              disabled={props.disableFields}
            />
            {dependenciaRequerido !== "" && (
              <Fragment>
                <SelectDependencyRules
                  value={reglaDependenciaRequerido}
                  label="Regla Dependencia Requerido"
                  disabled={props.disableFields}
                  parentCallback={setReglaDependenciaRequerido}
                />
                {reglaDependenciaRequerido === "OPERACION" && (
                  <DependencyOperationValues
                    value={valoresDependenciaRequerido}
                    label="Valores Dependencia Requerido"
                    disabled={props.disableFields}
                    parentCallback={setValoresDependenciaRequerido}
                  />
                )}
              </Fragment>
            )}
          </Row>
        )}
      </Form.Group>
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN VISIBILIDAD"></SubHeaderTitle>
        <Row className="mb-3">
          <Form.Check
            type="checkbox"
            value={visible}
            label="Visible?"
            onChange={(e) => {
              setVisible(e.target.checked);
            }}
            disabled={props.disableFields}
            checked={visible}
          />
          {visible && (
            <Form.Check
              type="checkbox"
              value={enmascarar}
              label="Enmascarar?"
              onChange={(e) => {
                setEnmascarar(e.target.checked);
              }}
              disabled={props.disableFields || !permiteEnmascaramiento}
              checked={enmascarar}
            />
          )}
          {visible && (
            <Fragment>
              <FormSelect
                label="Ancho Columna"
                value={anchoColumna}
                disabled={props.disableFields}
                parentCallback={setAnchoColumna}
              >
                <option value="1">8%</option>
                <option value="2">16%</option>
                <option value="3">25%</option>
                <option value="4">33%</option>
                <option value="5">42%</option>
                <option value="6">50%</option>
                <option value="7">58%</option>
                <option value="8">67%</option>
                <option value="9">75%</option>
                <option value="10">83%</option>
                <option value="11">92%</option>
                <option value="12">100%</option>
              </FormSelect>
              <SelectDependency
                modeloId={modeloId}
                value={dependenciaVisibilidad}
                fields={modelDependenceFields}
                label={"Dependencia Visibilidad"}
                parentCallback={setDependenciaVisibilidad}
                disabled={props.disableFields}
              />
            </Fragment>
          )}
        </Row>

        {visible && dependenciaVisibilidad !== "" && (
          <Row>
            <SelectDependencyRules
              value={reglaDependenciaVisibilidad}
              label="Regla Dependencia Visibilidad"
              disabled={props.disableFields}
              parentCallback={setReglaDependenciaVisibilidad}
            />
            {reglaDependenciaVisibilidad === "OPERACION" && (
              <DependencyOperationValues
                value={valoresDependenciaVisibilidad}
                label="Valores Dependencia Visibilidad"
                disabled={props.disableFields}
                parentCallback={setValoresDependenciaVisibilidad}
              />
            )}
          </Row>
        )}
      </Form.Group>
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN EDITABLE"></SubHeaderTitle>
        <Row className="mb-3">
          <Form.Check
            type="checkbox"
            value={editable}
            label="Editable?"
            onChange={(e) => {
              setEditable(e.target.checked);
            }}
            disabled={props.disableFields || tipoCampo === "CALCULADO"}
            checked={editable}
          />
        </Row>
        {editable && (
          <Row>
            <SelectDependency
              modeloId={modeloId}
              value={dependenciaEditable}
              fields={modelDependenceFields}
              label={"Dependencia Editable"}
              parentCallback={setDependenciaEditable}
              disabled={props.disableFields}
            />
            {dependenciaEditable !== "" && (
              <Fragment>
                <SelectDependencyRules
                  value={reglaDependenciaEditable}
                  label="Regla Dependencia Editable"
                  disabled={props.disableFields}
                  parentCallback={setReglaDependenciaEditable}
                />
                {reglaDependenciaEditable === "OPERACION" && (
                  <DependencyOperationValues
                    value={valoresDependenciaEditable}
                    label="Valores Dependencia Editable"
                    disabled={props.disableFields}
                    parentCallback={setValoresDependenciaEditable}
                  />
                )}
              </Fragment>
            )}
          </Row>
        )}
      </Form.Group>
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN VALIDACIÓN"></SubHeaderTitle>
        <Row className="mb-3">
          <FormSelect
            label="Tipo Validación"
            value={tipoValidacion}
            disabled={props.disableFields}
            parentCallback={setTipoValidacion}
          >
            <option value="">Ninguno</option>
            <option value="REGEX">Regex</option>
            <option value="REGLA">Regla</option>
            <option value="RUTINA">Rutina</option>
          </FormSelect>
          {tipoValidacion !== "" && (
            <SelectDependency
              modeloId={modeloId}
              value={dependenciaValidacion}
              fields={modelDependenceFields}
              label={"Dependencia Validación"}
              parentCallback={setDependenciaValidacion}
              disabled={props.disableFields}
            />
          )}
        </Row>
        {tipoValidacion !== "" && dependenciaValidacion !== "" && (
          <Fragment>
            <Row className="mb-3">
              <SelectDependencyRules
                label="Regla Dependencia Validación"
                value={reglaDependenciaValidacion}
                disabled={props.disableFields}
                parentCallback={setReglaDependenciaValidacion}
              />
            </Row>
            {reglaDependenciaValidacion === "OPERACION" && (
              <Row>
                <DependencyOperationValues
                  value={valoresDependenciaValidacion}
                  label="Valores Dependencia Validación"
                  disabled={props.disableFields}
                  parentCallback={setValoresDependenciaValidacion}
                />
              </Row>
            )}
          </Fragment>
        )}
        {tipoValidacion !== "" && (
          <Fragment>
            <Row className="mb-3">
              {tipoValidacion === "REGEX" && (
                <FormInput
                  value={validacionRegex}
                  label="Regex"
                  disabled={props.disableFields}
                  parentCallback={setValidacionRegex}
                />
              )}
              {tipoValidacion === "REGLA" && (
                // <OperationSelect
                //   value={validacionReglas}
                //   label="Regla"
                //   disabled={props.disableFields}
                //   parentCallback={setValidacionReglas}
                // />
                <ValidationRulesValues
                  value={validacionReglas}
                  label="Regla"
                  disabled={props.disableFields}
                  parentCallback={setValidacionReglas}
                  disableAdd={true}
                />
              )}
              {tipoValidacion === "RUTINA" && (
                <FormSelect
                  label="Rutina"
                  value={validacionRutina}
                  disabled={props.disableFields}
                  parentCallback={setValidacionRutina}
                >
                  <option value=""></option>
                  <option value="ValidarCedula">Validar Cédula</option>
                  <option value="ValidarRuc">Validar RUC</option>
                </FormSelect>
              )}
            </Row>
            <Row className="mb-3">
              {tipoValidacion === "RUTINA" && (
                <ValidationFieldsSelect
                  value={validacionRutinaCampos}
                  values={modelDependenceFields}
                  label="Campos Rutina"
                  disabled={props.disableFields}
                  parentCallback={setValidacionRutinaCampos}
                />
              )}
            </Row>
          </Fragment>
        )}
      </Form.Group>
      {tipoCampo === "COMBOBOX" && (
        <Form.Group>
          <SubHeaderTitle label="CONFIGURACIÓN COMBOBOX"></SubHeaderTitle>
          <Row className="mb-3">
            <Form.Check
              type="checkbox"
              value={comboboxPermiteNinguno}
              label="¿Permite escoger Ninguno?"
              onChange={(e) => {
                setcomboboxPermiteNinguno(e.target.checked);
              }}
              disabled={props.disableFields}
              checked={comboboxPermiteNinguno}
            />
          </Row>
          <Row className="mb-3">
            <FormSelect
              label="Tipo Filtro Combobox"
              value={tipoFiltro}
              disabled={props.disableFields}
              parentCallback={setTipoFiltro}
            >
              <option value="">Ninguno</option>
              <option value="INICIAL">Inicial</option>
              <option value="ONCHANGE">On Change</option>
            </FormSelect>
            {tipoFiltro === "ONCHANGE" && (
              <SelectDependency
                modeloId={modeloId}
                value={dependenciaFiltro}
                fields={modelDependenceFields}
                label={"Dependencia Filtro Combobox"}
                parentCallback={setDependenciaFiltro}
                disabled={props.disableFields}
              />
            )}
          </Row>
          {tipoFiltro !== "" && (
            <Row className="mb-3">
              <DependencyOperationValues
                value={valoresDependenciaFiltro}
                label="Valores Dependencia Filtro Combobox"
                disabled={props.disableFields}
                parentCallback={setValoresDependenciaFiltro}
                disableAdd={
                  tipoFiltro == "INICIAL" || reglaDependenciaFiltro === "VALOR"
                }
              />
            </Row>
          )}
        </Form.Group>
      )}
      {tipoValor === "VALOR" && (
        <Form.Group>
          <SubHeaderTitle label="CONFIGURACIÓN VALOR DEFECTO"></SubHeaderTitle>
          <Row className="mb-3">
            <FormSelect
              label="Tipo Valor Defecto"
              value={tipoValorDefecto}
              disabled={props.disableFields}
              parentCallback={setTipoValorDefecto}
            >
              <option value="">Ninguno</option>
              <option value="INICIAL">Inicial</option>
              <option value="ONCHANGE">On Change</option>
            </FormSelect>
            {tipoValorDefecto === "ONCHANGE" && (
              <SelectDependency
                modeloId={modeloId}
                value={dependenciaValorDefecto}
                fields={modelDependenceFields}
                label={"Dependencia Valor Defecto"}
                parentCallback={setDependenciaValorDefecto}
                disabled={props.disableFields}
              />
            )}
            {tipoValorDefecto === "INICIAL" && (
              <FormInput
                value={valorDefecto}
                label="Valor Defecto"
                disabled={props.disableFields}
                parentCallback={(event) => {
                  setValorDefecto(event);
                  setValoresDependenciaValorDefecto({ DEFAULT: event });
                }}
              />
            )}
          </Row>
          {tipoValorDefecto === "ONCHANGE" && dependenciaValorDefecto !== "" && (
            <Row className="mb-3">
              <DefaultValueTable
                value={valoresDependenciaValorDefecto}
                label="Valores Dependencia Valor Defecto"
                disabled={props.disableFields}
                parentCallback={setValoresDependenciaValorDefecto}
              />
            </Row>
          )}
        </Form.Group>
      )}
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN IMPRESIÓN FORMULARIO"></SubHeaderTitle>
        <Row className="mb-3">
          <Form.Check
            type="checkbox"
            value={formularioVisible}
            label="¿Es Visible en Impresión Formulario?"
            onChange={(e) => {
              setFormularioVisible(e.target.checked);
            }}
            disabled={props.disableFields}
            checked={formularioVisible}
          />
          {formularioVisible && (
            <FormInput
              value={etiquetaFormulario}
              label="Etiqueta Formulario"
              disabled={props.disableFields}
              parentCallback={setEtiquetaFormulario}
            />
          )}
        </Row>
        {formularioVisible && (
          <Row>
            <FormSelect
              label="Ancho Campo Formulario"
              value={anchoColumnaFormulario}
              disabled={props.disableFields}
              parentCallback={setAnchoColumnaFormulario}
            >
              <option value="1">8%</option>
              <option value="2">16%</option>
              <option value="3">25%</option>
              <option value="4">33%</option>
              <option value="5">42%</option>
              <option value="6">50%</option>
              <option value="7">58%</option>
              <option value="8">67%</option>
              <option value="9">75%</option>
              <option value="10">83%</option>
              <option value="11">92%</option>
              <option value="12">100%</option>
            </FormSelect>
            <FormSelect
              label="Ancho Etiqueta Formulario"
              value={anchoEtiquetaFormulario}
              disabled={props.disableFields}
              parentCallback={setAnchoEtiquetaFormulario}
            >
              <option value="1">8%</option>
              <option value="2">16%</option>
              <option value="3">25%</option>
              <option value="4">33%</option>
              <option value="5">42%</option>
              <option value="6">50%</option>
              <option value="7">58%</option>
              <option value="8">67%</option>
              <option value="9">75%</option>
              <option value="10">83%</option>
              <option value="11">92%</option>
              <option value="12">100%</option>
            </FormSelect>
          </Row>
        )}
      </Form.Group>
    </Form>
  );

  return (
    <Fragment>
      {!isLoading && (
        <Modal show={props.show} onHide={handleClose} centered size="lg">
          <Modal.Header closeButton>
            <Modal.Title>Configurar Campo</Modal.Title>
          </Modal.Header>
          <Modal.Body>{form}</Modal.Body>
          <Modal.Footer>
            <CustomButton
              size=""
              class={classes["btn-custom"]}
              label="Guardar"
              eventHandler={saveField}
            />
          </Modal.Footer>
        </Modal>
      )}
    </Fragment>
  );
};

export default forwardRef(FormatDetailModal);
