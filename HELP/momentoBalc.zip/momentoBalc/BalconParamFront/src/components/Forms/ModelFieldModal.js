import { Modal, Form, Row } from "react-bootstrap";
import { Fragment, useState, useImperativeHandle, forwardRef } from "react";
import CustomButton from "../UI/buttons/CustomButton";
import FormInput from "../UI/fields/FormInput";
import FormSelect from "../UI/fields/FormSelect";
import classes from "../UI/css/BMButton.module.css";
import SelectModel from "../UI/fields/SelectModel";
import SelectCatalogueName from "../UI/fields/SelectCatalogueName";
import OriginValuesTable from "../UI/fields/OriginValuesTable";
import CalcValuesSelect from "../UI/fields/CalcValuesSelect";
import SubHeaderTitle from "../UI/fields/SubHeaderTitle";

const ModelFieldModal = (props, ref) => {
  const [isLoading, setIsLoading] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [fieldSelect, setFieldSelect] = useState([]);
  const [campoId, setCampoId] = useState(0);
  const [valueType, setValueType] = useState("VALOR");
  const [label, setLabel] = useState("");
  const [refCode, setRefCode] = useState("");
  const [fieldType, setFieldType] = useState("TEXTFIELD");
  const [dataType, setDataType] = useState("ALFABETICO");
  const [calcType, setCalcType] = useState("FRONT");
  const [calcName, setCalcName] = useState("");
  const [calcValues, setCalcValues] = useState([]);
  const [minLen, setMinLen] = useState(0);
  const [maxLen, setMaxLen] = useState(0);
  const [order, setOrder] = useState(0);
  const [comboOrigin, setComboOrigin] = useState("CATALOGO");
  const [labelOrigin, setLabelOrigin] = useState("");
  const [valueOrigin, setValueOrigin] = useState("");
  const [catalogueOrigin, setCatalogueOrigin] = useState("");
  const [xmlLabel, setXmlLabel] = useState("");
  const [isRequired, setIsRequired] = useState(false);
  const [hasMasking, setHasMasking] = useState(false);
  const [isSensitive, setIsSensitive] = useState(false);

  //poner referencia para que el padre llame a funcion del hijo que setee el item a editar

  const handleClose = () => {
    props.setShow(false);
    setEditItem(null);
  };

  useImperativeHandle(
    ref,
    () => ({
      setEditItem: (editItem, nextOrder, fields) =>
        setModalItem(editItem, nextOrder, fields),
    }),
    []
  );

  const setModalItem = (editItem, nextOrder, fields) => {
    setEditItem(editItem);
    setFieldSelect(fields);
    if (editItem !== null) {
      setCampoId(editItem.campoId);
      setValueType(editItem.tipoValor);
      setLabel(editItem.etiqueta);
      setRefCode(editItem.codigo);
      setFieldType(editItem.tipoCampo);
      setDataType(editItem.tipoDato);
      setCalcName(editItem.nombreCalculo);
      setCalcType(editItem.tipoCalculado);
      setMinLen(editItem.longitudMinima);
      setMaxLen(editItem.longitudMaxima);
      setOrder(editItem.ordenCampo);
      setComboOrigin(editItem.origenCombobox);
      setCatalogueOrigin(editItem.origenCatalogo);
      setValueOrigin(editItem.origenValores);
      setXmlLabel(editItem.campoAS400);
      setIsRequired(editItem.obligatorio);
      setHasMasking(editItem.permiteEnmascaramiento);
      setCalcValues(editItem.valoresCalculo);
      setLabelOrigin(editItem.origenEtiqueta);
      setIsSensitive(editItem.datoSensible);
    } else {
      setCampoId(0);
      setValueType("VALOR");
      setLabel("");
      setRefCode("");
      setFieldType("TEXTFIELD");
      setDataType("ALFABETICO");
      setCalcName("");
      setCalcType("FRONT");
      setMinLen(0);
      setMaxLen(0);
      setOrder(nextOrder);
      setComboOrigin("CATALOGO");
      setCatalogueOrigin("");
      setValueOrigin("");
      setXmlLabel("");
      setIsRequired(false);
      setHasMasking(false);
      setCalcValues([]);
      setLabelOrigin("");
      setIsSensitive(false);
    }
  };

  const saveField = () => {
    let info = {
      campoId: campoId,
      modeloId: props.modelId,
      tipoValor: valueType,
      etiqueta: label,
      codigo: refCode,
      tipoCampo: fieldType,
      tipoDato: dataType,
      nombreCalculo:
        fieldType === "CALCULADO" && calcType !== "ACT_RES" ? calcName : null,
      tipoCalculado: fieldType === "CALCULADO" ? calcType : null,
      valoresCalculo:
        fieldType === "CALCULADO" && calcType !== "ACT_RES" ? calcValues : null,
      longitudMinima: +minLen,
      longitudMaxima: +maxLen,
      ordenCampo: +order,
      origenCombobox: fieldType === "COMBOBOX" ? comboOrigin : null,
      origenEtiqueta: fieldType === "COMBOBOX" ? labelOrigin : null,
      origenCatalogo:
        fieldType === "COMBOBOX" && comboOrigin === "CATALOGO"
          ? catalogueOrigin
          : null,
      origenValores:
        fieldType === "COMBOBOX" &&
          (comboOrigin === "VALORES" || comboOrigin === "MODELOS")
          ? valueOrigin
          : null,
      campoAS400: xmlLabel,
      obligatorio: isRequired,
      permiteEnmascaramiento: hasMasking,
      datoSensible: isSensitive,
    };
    props.onSaveField(info);
    handleClose();
  };

  const onChangeIsRequiredHandler = (event) => {
    setIsRequired(event.target.checked);
  };

  const onChangeHasMaskingHandler = (event) => {
    setHasMasking(event.target.checked);
  };

  const onChangeIsSensitiveHandler = (event) => {
    setIsSensitive(event.target.checked);
  };

  const form = (
    <Form style={{ width: "95%", margin: "auto" }}>
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN CAMPO"></SubHeaderTitle>
        <Row className="mb-3">
          <FormInput
            value={refCode}
            label="Código"
            disabled={props.disableFields}
            parentCallback={setRefCode}
            required
            maxLength="50"
          />
          <FormInput
            value={label}
            label="Etiqueta"
            disabled={props.disableFields}
            parentCallback={setLabel}
            required
            maxLength="200"
          />
        </Row>
        <Row className="mb-3">
          <Form.Check
            type="checkbox"
            value={isRequired}
            label="¿Es Obligatorio?"
            onChange={onChangeIsRequiredHandler}
            disabled={props.disableFields}
            checked={isRequired}
          />
          <Form.Check
            type="checkbox"
            value={hasMasking}
            label="¿Permite Enmascaramiento?"
            onChange={onChangeHasMaskingHandler}
            disabled={props.disableFields}
            checked={hasMasking}
          />
          <Form.Check
            type="checkbox"
            value={isSensitive}
            label="¿Es Dato Sensible?"
            onChange={onChangeIsSensitiveHandler}
            disabled={props.disableFields}
            checked={isSensitive}
          />
        </Row>
        <Row className="mb-3">
          <FormSelect
            value={valueType}
            label="Tipo de Valor"
            disabled={props.disableFields}
            parentCallback={(valor) => {
              if (valor === "LISTA") {
                setFieldType("TABLA");
              } else {
                setFieldType("TEXTFIELD");
              }
              setValueType(valor);
            }}
            required
          >
            <option value="LISTA">Lista</option>
            <option value="VALOR">Valor</option>
          </FormSelect>
          <FormSelect
            value={fieldType}
            label="Tipo Campo"
            disabled={props.disableFields}
            parentCallback={setFieldType}
            required
          >
            <option value=""></option>
            {valueType === "VALOR" && (
              <Fragment>
                <option value="CALCULADO">Calculado</option>
                <option value="CHECKBOX">Checkbox</option>
                <option value="COMBOBOX">Combobox</option>
                <option value="DATEPICKER">Datepicker</option>
                <option value="TEXTFIELD">Textfield</option>
              </Fragment>
            )}
            {valueType === "LISTA" && (
              <Fragment>
                <option value="TABLA">Tabla</option>
                <option value="TABLAREADONLY">Tabla No Editable</option>
              </Fragment>
            )}
          </FormSelect>
        </Row>
        <Row className="mb-3">
          {valueType === "VALOR" && (
            <FormSelect
              value={dataType}
              label="Tipo de Dato"
              disabled={props.disableFields}
              parentCallback={setDataType}
            >
              <option value=""></option>
              <option value="ALFABETICO">Alfabetico</option>
              <option value="ALFANUMERICO">Alfanumérico</option>
              <option value="FECHA">Fecha</option>
              <option value="HORA">Hora</option>
              <option value="MONEDA">Moneda</option>
              <option value="NUMERICO">Numérico</option>
              <option value="NUMERICOST">Numérico String</option>
              <option value="PORCENTAJE">Porcentaje</option>
            </FormSelect>
          )}
          {valueType === "LISTA" && (
            <SelectModel
              selected={dataType}
              disabled={props.disableFields}
              label="Tipo de Dato"
              tipo="CAMPO"
              allowNone={true}
              parentCallback={setDataType}
            />
          )}
        </Row>
        <Row className="mb-3">
          <FormInput
            value={minLen}
            label="Longitud Mín."
            disabled={props.disableFields}
            parentCallback={setMinLen}
          />
          <FormInput
            value={maxLen}
            label="Longitud Máx."
            disabled={props.disableFields}
            parentCallback={setMaxLen}
          />
        </Row>
      </Form.Group>
      {fieldType === "CALCULADO" && (
        <Form.Group>
          <SubHeaderTitle label="CONFIGURACIÓN CÁLCULO"></SubHeaderTitle>
          <Row className="mb-3">
            <FormSelect
              value={calcType}
              label="Tipo Calculado"
              disabled={props.disableFields}
              parentCallback={setCalcType}
              required={fieldType === "CALCULADO" ? true : false}
            >
              <option value=""></option>
              <option value="ACT_RES">Proceso Automatico</option>
              <option value="API">En Línea</option>
              <option value="FRONT">Web</option>
            </FormSelect>
            {calcType !== "ACT_RES" && (
              <FormSelect
                value={calcName}
                label="Nombre Cálculo"
                disabled={props.disableFields}
                parentCallback={setCalcName}
              >
                <option value=""></option>
                {calcType === "FRONT" && (
                  <Fragment>
                    {(dataType === "MONEDA" || dataType === "NUMERICO" || dataType === "PORCENTAJE" ) && (
                      <Fragment>
                        <option value="CalcularDiferencia">
                          Calcular Diferencia
                        </option>
                        <option value="CalcularDiferenciaFecha">
                          Calcular Diferencia entre Fechas
                        </option>
                        <option value="CalcularDivision">
                          Calcular División
                        </option>
                        <option value="CalcularMultiplicacion">
                          Calcular Multiplicación
                        </option>
                        <option value="CalcularSuma">Calcular Suma</option>
                      </Fragment>
                    )}

                    {dataType !== "MONEDA" && (
                      <Fragment>
                        <option value="ConcatenarCampos">
                          Concatenar Campos
                        </option>

                        <option value="ObtenerAgencia">
                          Obtener Código Agencia
                        </option>
                        <option value="ObtenerAgencia2">
                          Obtener Código Agencia Login
                        </option>

                        <option value="ObtenerCodEjecutivo">
                          Obtener Código Ejecutivo
                        </option>
                        <option value="ObtenerEstacionTrabajo">
                          Obtener Estación Trabajo
                        </option>
                        <option value="ObtenerIdentificacionUsuario">
                          Obtener Identificación Usuario
                        </option>
                        <option value="ObtenerUsuario">Obtener Usuario</option>
                        <option value="ObtenerZona">Obtener Código Zona</option>
                        <option value="VerificadorFATCA">
                          Verificador FATCA
                        </option>
                        <option value="VerificadorFATCAAccionistas">
                          Verificador FATCA Accionistas
                        </option>
                      </Fragment>
                    )}

                    {(dataType === "FECHA" || dataType === "HORA") && (
                      <option value="ObtenerFechaHoraSistema">
                        Obtener Fecha y Hora del Sistema
                      </option>
                    )}
                    <option value="ObtenerSubCadena">
                      Obtener SubCadena (Posicional)
                    </option>
                    <option value="ObtenerValorCampo">
                      Obtener Valor de Campo
                    </option>
                    <option value="ObtenerValorCampoModeloRef">
                      Obtener Valor de Campo Padre
                    </option>
                  </Fragment>
                )}
                {calcType === "API" && (
                  <Fragment>
                    <option value="ObtenerNombreCliente">
                      Obtener Nombre Cliente
                    </option>
                    <option value="ObtenerInfoRegistroCivil">
                      Obtener Información Registro Civil
                    </option>
                    <option value="ObtenerNombreEmpresa">
                      Obtener Nombre de Empresa
                    </option>
                  </Fragment>
                )}
              </FormSelect>
            )}
          </Row>
          <Row className="mb-3">
            {fieldType === "CALCULADO" &&
              calcType !== "ACT_RES" &&
              ![
                "ObtenerAgencia",
                "ObtenerAgencia2",
                "ObtenerCodEjecutivo",
                "ObtenerFechaHoraSistema",
                "ObtenerUsuario",
                "ObtenerIdentificacionUsuario",
                "ObtenerZona",
                "ObtenerEstacionTrabajo",
                "ObtenerValorCampoModeloRef",
              ].includes(calcName) && (
                <CalcValuesSelect
                  value={calcValues}
                  values={fieldSelect}
                  dataType={dataType}
                  calc={calcName}
                  label="Parámetros Cálculo"
                  disabled={props.disableFields}
                  parentCallback={setCalcValues}
                />
              )}
            {fieldType === "CALCULADO" &&
              calcType !== "ACT_RES" &&
              calcName == "ObtenerValorCampoModeloRef" && (
                <FormInput
                  value={calcValues}
                  label="Parámetro Cálculo"
                  disabled={props.disableFields}
                  parentCallback={(val) => {
                    setCalcValues([val]);
                  }}
                  required
                />
              )}
          </Row>
        </Form.Group>
      )}
      {fieldType === "COMBOBOX" && (
        <Form.Group>
          <SubHeaderTitle label="CONFIGURACIÓN COMBOBOX"></SubHeaderTitle>
          <Row className="mb-3">
            <FormSelect
              value={comboOrigin}
              label="Origen Combobox"
              disabled={props.disableFields}
              parentCallback={setComboOrigin}
            >
              <option value=""></option>
              <option value="CATALOGO">Catálogo</option>
              <option value="VALORES">Valores</option>
              <option value="MODELOS">Campos Lista</option>
            </FormSelect>
            <FormSelect
              value={labelOrigin}
              label="Origen Etiqueta"
              disabled={props.disableFields}
              parentCallback={setLabelOrigin}
            >
              <option value=""></option>
              <option value="CODETIQUETA">Código - Etiqueta</option>
              <option value="CODIGO">Código</option>
              <option value="COMPLEMENTO">Complemento</option>
              <option value="ETIQUETA">Etiqueta</option>
            </FormSelect>
          </Row>
          <Row className="mb-3">
            {comboOrigin === "VALORES" && (
              <OriginValuesTable
                value={valueOrigin}
                label="Origen Valores"
                originType={comboOrigin}
                disabled={props.disableFields}
                parentCallback={setValueOrigin}
              />
            )}
            {comboOrigin === "MODELOS" && (
              <OriginValuesTable
                value={valueOrigin}
                label="Mapeo Modelos"
                originType={comboOrigin}
                disabled={props.disableFields}
                parentCallback={setValueOrigin}
              />
            )}
            {comboOrigin === "CATALOGO" && (
              <SelectCatalogueName
                selected={catalogueOrigin}
                disabled={props.disableFields}
                label="Origen Catalogo"
                parentCallback={setCatalogueOrigin}
              />
            )}
          </Row>
        </Form.Group>
      )}
      <Form.Group>
        <SubHeaderTitle label="CONFIGURACIÓN AS400"></SubHeaderTitle>
        <Row className="mb-3">
          <FormInput
            value={xmlLabel}
            label="Etiqueta XML"
            disabled={props.disableFields}
            parentCallback={setXmlLabel}
            required
          />
        </Row>
      </Form.Group>
    </Form>
  );

  return (
    <Fragment>
      {!isLoading && (
        <Modal show={props.show} onHide={handleClose} centered size="lg">
          <Modal.Header closeButton>
            <Modal.Title>Agregar Campo</Modal.Title>
          </Modal.Header>
          <Modal.Body>{form}</Modal.Body>
          <Modal.Footer>
            <CustomButton
              size=""
              class={classes["btn-custom"]}
              label="Guardar"
              eventHandler={saveField}
            />
          </Modal.Footer>
        </Modal>
      )}
    </Fragment>
  );
};

export default forwardRef(ModelFieldModal);
