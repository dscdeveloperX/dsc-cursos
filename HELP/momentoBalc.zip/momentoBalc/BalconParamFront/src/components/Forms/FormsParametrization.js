import { useState } from "react";
import { FormSelect } from "react-bootstrap";
import CustomDatePicker from "../UI/fields/CustomDatePicker";

const FormsParametrization = () => {
  //cargar campos del API en lista
  //renderizar campo según el tipo de dato
  [fieldList, setFieldList] = useState([]);

  const form = fieldList.map((field) => {
    if (field.tipoValor === "VALOR") {
      if (field.tipoCampo === "TEXTFIELD") {
        if (field.tipoDato === "ALFABETICO") {
          <div>TEXTFIELD</div>;
        } else if (field.tipoDato === "NUMERICO") {
          <div>TEXTFIELD</div>;
        } else if (field.tipoDato === "ALFANUMERICO") {
          <div>TEXTFIELD</div>;
        } else if (field.tipoDato === "FECHA") {
          <div>TEXTFIELD</div>;
        }
      } else if (field.tipoCampo === "COMBOBOX") {
        <FormSelect />;
      } else if (field.tipoCampo === "CALCULADO") {
        <div>CALCULADO</div>;
      } else if (field.tipoCampo === "DATEPICKER") {
        <CustomDatePicker />
      } else if (field.tipoCampo === "CHECKBOX") {
        <div>CHECKBOX</div>;
      }
    } else {
      //cuando es de tipoValor LISTA
    }
  });

  return <Form>{form}</Form>;
};

export default FormsParametrization;
