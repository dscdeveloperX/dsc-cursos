import {
  Fragment,
  useState,
  useContext,
  useCallback,
  useEffect,
  useRef,
} from "react";
import { useParams, useHistory } from "react-router-dom";
import { Form, Row } from "react-bootstrap";
import AuthContext from "../../store/auth-context";
import CustomButton from "../UI/buttons/CustomButton";
import FormInput from "../UI/fields/FormInput";
import FormSelect from "../UI/fields/FormSelect";
import HeaderTitle from "../UI/fields/HeaderTitle";

import LoadingSpinner from "../UI/LoadingSpinner";
import ErrorAlert from "../UI/ErrorAlert";

import classes from "../UI/css/BMButton.module.css";
import SectionItem from "../UI/SectionItem";

import { COLORS } from "../../values/colors";
import ModelFieldModal from "./ModelFieldModal";
//import InfoTooltip from "../UI/fields/InfoTooltip";

const FormModel = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [modelId, setModelId] = useState(0);

  const [selectedStatus, setSelectedStatus] = useState("ACTIVO");
  const [disableFields, setDisableFields] = useState(false);
  const [editModeIsOn, setEditModeIsOn] = useState(false);
  const [selectedModel, setSelectedModel] = useState(null);

  const [name, setName] = useState("");
  const [refCode, setRefCode] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("ACTIVO");
  const [modelType, setModelType] = useState("PERSONA");

  const [selectedSection, setSelectedSection] = useState(0);
  const [selectedSubection, setSelectedSubection] = useState(0);

  const [sections, setSections] = useState([]);
  const [selectedEdit, setSelectedEdit] = useState(null);

  const [nameIsValid, setNameIsValid] = useState(false);
  const [refCodeIsValid, setRefCodeIsValid] = useState(false);
  const [descriptionIsValid, setDescriptionIsValid] = useState(false);

  const [error, setError] = useState(null);
  const [showError, setShowError] = useState(false);

  const [show, setShow] = useState(false);

  const authCtx = useContext(AuthContext);

  const params = useParams();

  let history = useHistory();

  const [modelFields, setModelFields] = useState([]);

  let formIsValid = false;

  const modalRef = useRef();

  const formSubmissionHandler = (event) => {
    event.preventDefault();
    if (nameIsValid && refCodeIsValid && descriptionIsValid) {
      formIsValid = true;
    }

    const model = {
      modeloId: modelId,
      codigo: refCode,
      nombre: name,
      descripcion: description,
      tipoModelo: modelType,
      estado: status,
      secciones: sections,
    };

    if (!editModeIsOn) {
      if (!formIsValid) {
        return;
      }
      AddModelHandler(model);
    } else if (editModeIsOn) {
      EditModelHandler(model);
    }
  };

  const getModelFields = (secciones) => {
    var fields = [];
    if (secciones !== undefined && secciones !== null) {
      for (var i = 0; i < secciones.length; i++) {
        var section = secciones[i];

        if (section.campos !== null && section.campos?.length > 0) {
          for (var j = 0; j < section.campos.length; j++) {
            var field = section.campos[j];
            fields.push({
              etiqueta: field.etiqueta,
              codigo: field.codigo,
              tipoDato: field.tipoDato,
              tipoValor: field.tipoValor,
            });
          }
        }
        if (section.secciones !== null && section.secciones?.length > 0) {
          for (var j = 0; j < section.secciones.length; j++) {
            var subsection = section.secciones[j];
            if (subsection.campos !== null && subsection.campos?.length > 0) {
              for (var z = 0; z < subsection.campos.length; z++) {
                var field = subsection.campos[z];
                fields.push({
                  etiqueta: field.etiqueta,
                  codigo: field.codigo,
                  tipoDato: field.tipoDato,
                  tipoValor: field.tipoValor,
                });
              }
            }
          }
        }
      }
    }
    setModelFields(fields);
  };

  const fetchModelByIdHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    if (params.modeloId === null) {
      setIsLoading(false);
      return;
    }
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 10,
          pageRequested: 1,
        },
        bodyRequest: {
          modeloId: params.modeloId,
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "modelos/ObtenerPorId",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }

      getModelFields(data.bodyResponse.modelo.secciones);

      setModelId(data.bodyResponse.modelo.modeloId);
      setName(data.bodyResponse.modelo.nombre);
      setRefCode(data.bodyResponse.modelo.codigo);
      setDescription(data.bodyResponse.modelo.descripcion);
      setStatus(data.bodyResponse.modelo.estado);
      setModelType(data.bodyResponse.modelo.tipoModelo);
      setSections(data.bodyResponse.modelo.secciones);
      setSelectedStatus(data.bodyResponse.modelo.estado);
      setDisableFields(false);
      setEditModeIsOn(true);
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }, [params.modeloId]);

  useEffect(() => {
    if (params.modeloId) fetchModelByIdHandler();
  }, [fetchModelByIdHandler]);

  async function AddModelHandler(model) {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1,
          pageRequested: 1,
        },
        bodyRequest: {
          modelo: {
            modeloId: model.modeloId,
            codigo: model.codigo,
            nombre: model.nombre,
            descripcion: model.descripcion,
            tipoModelo: model.tipoModelo,
            estado: model.estado,
            secciones: model.secciones,
          },
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "modelos/Crear",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();

      if (data.headerResponse.returnMessage === "OK") {
        history.push("/lista_modelos");
      } else {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }

  async function EditModelHandler(model) {
    setIsLoading(true);
    setError(null);
    setShowError(false);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1,
          pageRequested: 1,
        },
        bodyRequest: {
          modelo: {
            modeloId: model.modeloId,
            codigo: model.codigo,
            nombre: model.nombre,
            descripcion: model.descripcion,
            tipoModelo: model.tipoModelo,
            estado: model.estado,
            secciones: model.secciones,
          },
        },
      };
      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "modelos/Actualizar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );
      const data = await response.json();
      if (data.headerResponse.returnMessage === "OK") {
        history.push("/lista_modelos");
      } else {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        throw Error(errorMessage[0]);
      }
    } catch (error) {
      setError(error.message);
      setShowError(true);
    }
    setIsLoading(false);
  }

  const formEditHandler = () => {
    setDisableFields(false);
    setEditModeIsOn(true);
  };

  const formAddSectionHandler = () => {
    var sectionsCpy = [...sections];
    sectionsCpy.push({
      nombre: "",
      orden: sectionsCpy.length + 1,
      secciones: [],
      campos: [],
    });
    setSections(sectionsCpy);
  };

  const deleteSection = (sectionOrder, subsectionOrder) => {
    let tempSections = [...sections];
    let tempFields = [...modelFields];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let temp = tempSections[index].secciones.splice(subindex, 1);

      if (temp.campos !== null && temp.campos?.length > 0) {
        for (let j = 0; j < temp.campos.length; j++) {
          var fieldDel = temp.campos[j];
          let delFieldindex = tempFields.findIndex((object) => {
            return object.codigo === fieldDel.codigo;
          });
          tempFields.splice(delFieldindex, 1);
        }
      }
      for (let i = 0; i < tempSections[index].secciones.length; i++) {
        tempSections[index].secciones[i].orden = i + 1;
      }
    } else {
      let temp = tempSections.splice(index, 1);

      if (temp.campos !== null && temp.campos?.length > 0) {
        for (let j = 0; j < temp.campos.length; j++) {
          var fieldDel = temp.campos[j];
          let delFieldindex = tempFields.findIndex((object) => {
            return object.codigo === fieldDel.codigo;
          });
          tempFields.splice(delFieldindex, 1);
        }
      }

      if (temp.secciones !== null && temp.secciones?.length > 0) {
        for (let z = 0; z < temp.secciones.length; z++) {
          var subsect = temp.secciones[z];
          if (subsect.campos !== null && subsect.campos?.length > 0) {
            for (let k = 0; k < subsect.campos.length; k++) {
              var fieldDel = subsect.campos[k];
              let delFieldindex = tempFields.findIndex((object) => {
                return object.codigo === fieldDel.codigo;
              });
              tempFields.splice(delFieldindex, 1);
            }
          }
        }
      }
      for (let i = 0; i < tempSections.length; i++) {
        tempSections[i].orden = i + 1;
      }
    }
    setModelFields(tempFields);
    setSections(tempSections);
  };

  const deleteField = (sectionOrder, subsectionOrder, fieldOrder) => {
    let tempSections = [...sections];
    var tempFields = [...modelFields];

    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });

    var codigo = "";

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === fieldOrder;
        }
      );
      let temp = tempSections[index].secciones[subindex].campos.splice(
        fieldindex,
        1
      );

      codigo = temp.codigo;

      for (
        let i = 0;
        i < tempSections[index].secciones[subindex].campos.length;
        i++
      ) {
        tempSections[index].secciones[subindex].campos[i].ordenCampo = i + 1;
      }
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === fieldOrder;
      });
      let temp = tempSections[index].campos.splice(fieldindex, 1);

      codigo = temp.codigo;

      for (let i = 0; i < tempSections[index].campos.length; i++) {
        tempSections[index].campos[i].ordenCampo = i + 1;
      }
    }
    let indexFields = tempFields.findIndex((object) => {
      return object.codigo === codigo;
    });

    tempFields.splice(indexFields, 1);
    setModelFields(tempFields);
    setSections(tempSections);
  };

  const editField = (sectionOrder, subsectionOrder, fieldOrder) => {
    let tempSections = [...sections];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });
    let field;

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === fieldOrder;
        }
      );

      field = tempSections[index].secciones[subindex].campos[fieldindex];
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === fieldOrder;
      });

      field = tempSections[index].campos[fieldindex];
    }
    setSelectedSection(sectionOrder);
    setSelectedSubection(subsectionOrder);
    setSelectedEdit(field);
    modalRef.current.setEditItem(field, 0, modelFields);
    setShow(true);
  };

  const addField = (sectionOrder, subsectionOrder) => {
    var nextOrder = 0;

    let tempSections = [...sections];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      nextOrder =
        tempSections[index].secciones[subindex].campos === null
          ? 1
          : tempSections[index].secciones[subindex].campos.length + 1;
    } else {
      nextOrder =
        tempSections[index].campos === null
          ? 1
          : tempSections[index].campos.length + 1;
    }
    setSelectedEdit(null);
    //entry.orden => el numero de seccion al cual agregar el campo
    setSelectedSection(sectionOrder);
    setSelectedSubection(subsectionOrder);
    //abrir modal, crear info, agregar a tabla en seccion correspondiente
    modalRef.current.setEditItem(null, nextOrder, modelFields);
    setShow(true);
  };

  const addSection = (sectionOrder) => {
    var sectionsCpy = [...sections];

    let index = sectionsCpy.findIndex((object) => {
      return object.orden === sectionOrder;
    });

    if (sectionsCpy[index].secciones === null)
      sectionsCpy[index].secciones = [];

    sectionsCpy[index].secciones.push({
      nombre: "",
      orden: sectionsCpy[index].secciones.length + 1,
      secciones: [],
      campos: [],
    });
    setSections(sectionsCpy);
  };

  const saveFieldHandler = (entry) => {
    var tempFields = [...modelFields];
    let tempSections;
    if (selectedEdit === null) {
      //parsear arreglo y agregar
      tempSections = [...sections];
      let index = tempSections.findIndex((object) => {
        return object.orden === selectedSection;
      });
      if (selectedSubection > 0) {
        let subindex = tempSections[index].secciones.findIndex((object) => {
          return object.orden === selectedSubection;
        });

        tempSections[index].secciones[subindex].campos.push(entry);
      } else {
        tempSections[index].campos.push(entry);
      }
      tempFields.push({
        etiqueta: entry.etiqueta,
        codigo: entry.codigo,
        tipoDato: entry.tipoDato,
      });
    } else {
      tempSections = [...sections];
      let index = tempSections.findIndex((object) => {
        return object.orden === selectedSection;
      });

      var fieldIn = 0;
      if (selectedSubection > 0) {
        let subindex = tempSections[index].secciones.findIndex((object) => {
          return object.orden === selectedSubection;
        });

        let fieldindex = tempSections[index].secciones[
          subindex
        ].campos.findIndex((object) => {
          return object.ordenCampo === entry.ordenCampo;
        });

        fieldIn = tempFields.findIndex((object) => {
          return (
            object.codigo ===
            tempSections[index].secciones[subindex].campos[fieldindex].codigo
          );
        });

        tempSections[index].secciones[subindex].campos[fieldindex] = entry;
      } else {
        let fieldindex = tempSections[index].campos.findIndex((object) => {
          return object.ordenCampo === entry.ordenCampo;
        });

        fieldIn = tempFields.findIndex((object) => {
          return (
            object.codigo === tempSections[index].campos[fieldindex].codigo
          );
        });

        tempSections[index].campos[fieldindex] = entry;
      }

      tempFields[fieldIn] = {
        etiqueta: entry.etiqueta,
        codigo: entry.codigo,
        tipoDato: entry.tipoDato,
      };
    }
    setModelFields(tempFields);
    setSections(tempSections);

    setSelectedSection(0);
    setSelectedSubection(0);
    setSelectedEdit(null);
  };

  const onChangeTitleHandler = (sectionOrder, subsectionOrder, title) => {
    let tempSections = [...sections];

    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });
    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex];
      fieldindex.nombre = title;
      tempSections[index].secciones[subindex] = fieldindex;
    } else {
      let fieldindex = tempSections[index];
      fieldindex.nombre = title;
      tempSections[index] = fieldindex;
    }
    setSections(tempSections);
  };

  const onClickUpHandler = (sectionOrder, subsectionOrder) => {
    let tempSections = [...sections];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });
    if (index < 0) return;
    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      if (subindex <= 0) return;

      let fieldindex = tempSections[index].secciones[subindex];
      fieldindex.orden = +fieldindex.orden - 1;

      let upperElement = tempSections[index].secciones[subindex - 1];
      upperElement.orden = +upperElement.orden + 1;

      tempSections[index].secciones[subindex] = upperElement;
      tempSections[index].secciones[subindex - 1] = fieldindex;
    } else {
      if (index <= 0) return;
      let fieldindex = tempSections[index];
      fieldindex.orden = +fieldindex.orden - 1;

      let upperElement = tempSections[index - 1];
      upperElement.orden = +upperElement.orden + 1;

      tempSections[index] = upperElement;
      tempSections[index - 1] = fieldindex;
    }
    setSections(tempSections);
  };

  const onClickDownHandler = (sectionOrder, subsectionOrder) => {
    let tempSections = [...sections];

    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });

    if (index < 0) return;

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      if (subindex >= tempSections[index].secciones.length - 1) return;

      let fieldindex = tempSections[index].secciones[subindex];
      fieldindex.orden = +fieldindex.orden + 1;

      let lowerElement = tempSections[index].secciones[subindex + 1];
      lowerElement.orden = +lowerElement.orden - 1;

      tempSections[index].secciones[subindex] = lowerElement;
      tempSections[index].secciones[subindex + 1] = fieldindex;
    } else {
      if (index >= tempSections.length - 1) return;
      let fieldindex = tempSections[index];
      fieldindex.orden = +fieldindex.orden + 1;

      let lowerElement = tempSections[index + 1];
      lowerElement.orden = +lowerElement.orden - 1;

      tempSections[index] = lowerElement;
      tempSections[index + 1] = fieldindex;
    }
    setSections(tempSections);
  };

  const onClickFieldUpHandler = (sectionOrder, subsectionOrder, fieldOrder) => {
    let tempSections = [...sections];
    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });
    if (index < 0) return;
    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === fieldOrder;
        }
      );

      if (fieldindex <= 0) return;

      let field = tempSections[index].secciones[subindex].campos[fieldindex];
      field.ordenCampo = +field.ordenCampo - 1;

      let upperElement =
        tempSections[index].secciones[subindex].campos[fieldindex - 1];
      upperElement.ordenCampo = +upperElement.ordenCampo + 1;

      tempSections[index].secciones[subindex].campos[fieldindex] = upperElement;
      tempSections[index].secciones[subindex].campos[fieldindex - 1] = field;
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === fieldOrder;
      });

      if (fieldindex <= 0) return;

      let field = tempSections[index].campos[fieldindex];
      field.ordenCampo = +field.ordenCampo - 1;

      let upperElement = tempSections[index].campos[fieldindex - 1];
      upperElement.ordenCampo = +upperElement.ordenCampo + 1;

      tempSections[index].campos[fieldindex] = upperElement;
      tempSections[index].campos[fieldindex - 1] = field;
    }
    setSections(tempSections);
  };

  const onClickFieldDownHandler = (
    sectionOrder,
    subsectionOrder,
    fieldOrder
  ) => {
    let tempSections = [...sections];

    let index = tempSections.findIndex((object) => {
      return object.orden === sectionOrder;
    });

    if (index < 0) return;

    if (subsectionOrder > 0) {
      let subindex = tempSections[index].secciones.findIndex((object) => {
        return object.orden === subsectionOrder;
      });

      let fieldindex = tempSections[index].secciones[subindex].campos.findIndex(
        (object) => {
          return object.ordenCampo === fieldOrder;
        }
      );

      if (
        fieldindex >=
        tempSections[index].secciones[subindex].campos.length - 1
      )
        return;

      let field = tempSections[index].secciones[subindex].campos[fieldindex];
      field.ordenCampo = +field.ordenCampo + 1;

      let lowerElement =
        tempSections[index].secciones[subindex].campos[fieldindex + 1];
      lowerElement.ordenCampo = +lowerElement.ordenCampo - 1;

      tempSections[index].secciones[subindex].campos[fieldindex] = lowerElement;
      tempSections[index].secciones[subindex].campos[fieldindex + 1] = field;
    } else {
      let fieldindex = tempSections[index].campos.findIndex((object) => {
        return object.ordenCampo === fieldOrder;
      });

      if (fieldindex >= tempSections[index].campos.length - 1) return;

      let field = tempSections[index].campos[fieldindex];
      field.ordenCampo = +field.ordenCampo + 1;

      let lowerElement = tempSections[index].campos[fieldindex + 1];
      lowerElement.ordenCampo = +lowerElement.ordenCampo - 1;

      tempSections[index].campos[fieldindex] = lowerElement;
      tempSections[index].campos[fieldindex + 1] = field;
    }
    setSections(tempSections);
  };

  const formButtons = (
    <Row xs="auto" className="justify-content-end m-3">
      {editModeIsOn && disableFields && (
        <CustomButton
          size=""
          class={classes["btn-custom"]}
          label="Editar"
          eventHandler={formEditHandler}
        />
      )}
      {(!editModeIsOn || (editModeIsOn && !disableFields)) && (
        <CustomButton
          size=""
          class={classes["btn-custom"]}
          label="Guardar"
          eventHandler={formSubmissionHandler}
        />
      )}
    </Row>
  );

  const actionButtons = (
    <Row xs="auto" className="justify-content-end m-3">
      {(!editModeIsOn || (editModeIsOn && !disableFields)) && (
        <CustomButton
          size=""
          class={classes["btn-custom-inverse"]}
          color={COLORS.primaryLight}
          iconColor={COLORS.primaryLight}
          label="Agregar"
          icon="faPlus"
          eventHandler={formAddSectionHandler}
        />
      )}
    </Row>
  );

  const modelForm = (
    <Form className="m-4" onSubmit={formSubmissionHandler}>
      <Row className="mb-3">
        <FormInput
          label="Nombre"
          value={name}
          disabled={disableFields}
          parentCallback={setName}
          parentIsValidCallback={setNameIsValid}
        />
      </Row>
      <Row className="mb-3">
        <FormInput
          disabled={disableFields}
          label="Código"
          value={refCode}
          parentCallback={setRefCode}
          parentIsValidCallback={setRefCodeIsValid}
        />
      </Row>
      <Row className="mb-3">
        <FormInput
          disabled={disableFields}
          label="Descripción"
          value={description}
          parentCallback={setDescription}
          parentIsValidCallback={setDescriptionIsValid}
        />
      </Row>
      <Row className="mb-3">
        <FormSelect
          label="Estado"
          value={status}
          disabled={disableFields}
          parentCallback={setStatus}
        >
          <option value="ACTIVO">Activo</option>
          <option value="INACTIVO">Inactivo</option>
        </FormSelect>
      </Row>
      <Row className="mb-3">
        <FormSelect
          label="Tipo Modelo"
          value={modelType}
          disabled={disableFields}
          parentCallback={setModelType}
        >
          <option value="PERSONA">Persona</option>
          <option value="PRODUCTO">Producto</option>
          <option value="CAMPO">Campo</option>
        </FormSelect>
      </Row>
      {
        <SectionItem
          key={"sectionprincipal"}
          onChangeTitle={onChangeTitleHandler}
          onClickUp={onClickUpHandler}
          onClickDown={onClickDownHandler}
          onClickFieldUp={onClickFieldUpHandler}
          onClickFieldDown={onClickFieldDownHandler}
          sections={sections}
          hijos={selectedModel}
          disable={disableFields}
          onDeleteSection={deleteSection}
          onDeleteField={deleteField}
          onEditField={editField}
          onAddSection={addSection}
          onAddField={addField}
          editModeIsOn={disableFields}
        />
      }
      <ModelFieldModal
        ref={modalRef}
        show={show}
        setShow={setShow}
        disableFields={disableFields}
        onSaveField={saveFieldHandler}
        editItem={selectedEdit}
        modelId={modelId}
      />
      {actionButtons}
    </Form>
  );

  const body = (
    <div>
      {modelForm}
      {formButtons}
    </div>
  );
  const errorAlert = (
    <ErrorAlert text={error} hideError={() => setShowError(false)} />
  );

  const loading = (
    <div className="centered">
      <LoadingSpinner />
    </div>
  );
  return (
    <Fragment>
      <HeaderTitle label="MODELO" />
      {showError && errorAlert}
      {!isLoading && body}
      {isLoading && loading}
    </Fragment>
  );
};

export default FormModel;
