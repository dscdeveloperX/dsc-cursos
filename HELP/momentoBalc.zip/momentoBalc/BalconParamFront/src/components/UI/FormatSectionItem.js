import { Fragment, useState, useEffect } from "react";
import { Row } from "react-bootstrap";
import { COLORS } from "../../values/colors";
import CustomTable from "../../components/Layout/CustomTable";
import SectionTitle from "../../components/UI/fields/SectionTitle";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheck,
  faPencil,
} from "@fortawesome/free-solid-svg-icons";

import { Accordion } from "react-bootstrap";

const FormatSectionItem = (props) => {
  const [show, setShow] = useState(false);
  const [selectedModel, setSelectedModel] = useState(null);
  const [sections, setSections] = useState(props.sections);
  const nivel = props.nivel ? props.nivel : 0;

  const orden = props.orden ? props.orden : 0;
  const suborden = props.suborden ? props.suborden : 0;

  const columns = [
    { dataField: "key", text: "", hidden: true },
    { dataField: "codigo", text: "Código", hidden: true },
    { dataField: "ordenCampo", text: "Orden" },
    { dataField: "etiqueta", text: "Etiqueta" },
    { dataField: "requerido", text: "Requerido" },
    { dataField: "visible", text: "Visible" },
    { dataField: "editable", text: "Editable" },
    { dataField: "action", text: "" },
  ];

  function selectItem(entry) {
    setSelectedModel(entry);
    setShow(true);
  }

  function editField(sectionOrder, subsectionOrder, fieldOrder) {
    if (props.onEditField) {
      props.onEditField(sectionOrder, subsectionOrder, fieldOrder);
    }
  }

  useEffect(() => {
    setSections(props.sections);
  }, [props.sections]);

  const actionButtons = (entry) => {
    return (
      <Fragment>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={editField.bind(this, orden, suborden, entry.ordenCampo)}
          icon={faPencil}
          color={COLORS.highlight}
          size="lg"
        />
      </Fragment>
    );
  };

  const form = (
    <Fragment>
      <SectionTitle label="CAMPOS" />
      <CustomTable
        columns={columns}
        items={
          props.hijos !== undefined &&
          props.hijos?.campos?.map((entry, index) => {
            return {
              key: index + "-" + orden + "-" + suborden + "-" + entry.campoId,
              codigo: entry.codigo,
              ordenCampo: entry.ordenCampo,
              etiqueta: entry.etiqueta,
              requerido:
                entry.obligatorio === true || entry.requerido == true ? (
                  <FontAwesomeIcon
                    icon={faCheck}
                    color={COLORS.highlight}
                    size="lg"
                  />
                ) : (
                  ""
                ),
              visible:
                entry.visible === true ? (
                  <FontAwesomeIcon
                    icon={faCheck}
                    color={COLORS.highlight}
                    size="lg"
                  />
                ) : (
                  ""
                ),
              editable:
                entry.editable === true ? (
                  <FontAwesomeIcon
                    icon={faCheck}
                    color={COLORS.highlight}
                    size="lg"
                  />
                ) : (
                  ""
                ),
              action: props.disable === true ? "" : actionButtons(entry),
            };
          })
        }
        hidePage={true}
      />
    </Fragment>
  );
  const body = (
    <Accordion defaultActiveKey="0">
      {props.hijos?.campos && form}
      {nivel === 1 && <SectionTitle label="SUBSECCIONES" />}
      {sections &&
        sections.map((entry) => {
          return (
            (entry.campos !== null || entry.secciones !== null) && (
              <Fragment>
                <Row>
                  <Accordion.Item
                    eventKey={entry.orden + entry.nombre}
                    key={entry.orden + entry.nombre}
                  >
                    <Accordion.Header>{entry.nombre}</Accordion.Header>
                    <Accordion.Body>
                      {nivel === 0 && (
                        <FormatSectionItem
                          sections={entry.secciones}
                          hijos={entry}
                          disable={props.disable}
                          nivel={nivel + 1}
                          editModeIsOn={props.editModeIsOn}
                          orden={entry.orden}
                          suborden={0}
                          onEditField={props.onEditField}
                        />
                      )}
                      {nivel === 1 && (
                        <FormatSectionItem
                          sections={entry.secciones}
                          hijos={entry}
                          disable={props.disable}
                          nivel={nivel + 1}
                          editModeIsOn={props.editModeIsOn}
                          orden={orden}
                          suborden={entry.orden}
                          onEditField={props.onEditField}
                        />
                      )}
                    </Accordion.Body>
                  </Accordion.Item>
                </Row>
              </Fragment>
            )
          );
        })}
    </Accordion>
  );
  return <Fragment>{body}</Fragment>;
};

export default FormatSectionItem;
