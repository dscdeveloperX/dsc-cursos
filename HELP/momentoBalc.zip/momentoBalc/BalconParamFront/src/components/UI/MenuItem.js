import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import * as Icons from "@fortawesome/free-solid-svg-icons";
import { Fragment } from "react";
import { Link } from "react-router-dom";
import { Nav, Accordion, Row } from "react-bootstrap";

const MenuItem = (props) => {
  const hasChildren = props.hijos !== undefined && props.hijos.length > 0;

  return (
    <Fragment>
      {props.estado === "ACTIVO" && !hasChildren && (
        <Nav.Link
          active={props.active}
          eventKey={props.menuId}
          as={Link}
          to={props.ruta}
          className="nav-item"
          onClick={() => localStorage.setItem('menuId', '')}
        >
          <FontAwesomeIcon icon={Icons[props.icono]} className="me-2" />{" "}
          {props.nombre}
        </Nav.Link>
      )}
      {props.estado === "ACTIVO" && hasChildren && (
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey={props.menuId} className="sidebar-accordion">
            <Accordion.Header>
              <FontAwesomeIcon icon={Icons[props.icono]} className="me-2" />{" "}
              {props.nombre}
            </Accordion.Header>
            <Accordion.Body>
              {props.hijos !== undefined &&
                props.hijos.length > 0 &&
                props.hijos.map((child) => {
                  return (
                    <Row key={child.menuId}>
                      <MenuItem
                        hijos={child.hijos}
                        ruta={child.ruta}
                        menuId={child.menuId}
                        icono={child.icono}
                        nombre={child.nombre}
                        estado={child.estado}
                      />
                    </Row>
                  );
                })}
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      )}
    </Fragment>
  );
};

export default MenuItem;
