import { Fragment, useState, useEffect } from "react";
import { Row, Form, Card } from "react-bootstrap";
import { COLORS } from "../../values/colors";
import CustomTable from "../../components/Layout/CustomTable";
import CustomHeader from "../../components/Layout/CustomHeader";
import SectionTitle from "../../components/UI/fields/SectionTitle";
import classes from "../UI/css/SearchBar.module.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPlus,
  faTrashCan,
  faX,
  faCheck,
  faPencil,
  faCaretDown,
  faCaretUp,
} from "@fortawesome/free-solid-svg-icons";

import { Accordion, Button } from "react-bootstrap";
import CustomButton from "./buttons/CustomButton";

const SectionItem = (props) => {
  const [show, setShow] = useState(false);
  const [selectedModel, setSelectedModel] = useState(null);
  const [sections, setSections] = useState([]);
  const nivel = props.nivel ? props.nivel : 0;
  //const modelType = props.modelType;

  const orden = props.orden ? props.orden : 0;
  const suborden = props.suborden ? props.suborden : 0;

  const columns = [
    { dataField: "key", text: "", hidden: true },
    { dataField: "order", text: "" },
    { dataField: "codigo", text: "Código", hidden: true },
    { dataField: "ordenCampo", text: "Orden" },
    { dataField: "etiqueta", text: "Etiqueta" },
    { dataField: "tipoDato", text: "Tipo Dato" },
    { dataField: "tipoValor", text: "Tipo Valor" },
    { dataField: "obligatorio", text: "Obligatorio" },
    { dataField: "action", text: "" },
  ];

  function selectItem(entry) {
    setSelectedModel(entry);
    setShow(true);
  }

  function deleteSection(sectionOrder, subsectionOrder) {
    if (props.onDeleteSection) {
      props.onDeleteSection(sectionOrder, subsectionOrder);
    }
  }

  function addSection(sectionOrder) {
    if (props.onAddSection) {
      props.onAddSection(sectionOrder);
    }
  }

  function addField() {
    if (props.onAddField) {
      props.onAddField(orden, suborden);
    }
  }

  function deleteField(sectionOrder, subsectionOrder, fieldOrder) {
    if (props.onDeleteField) {
      props.onDeleteField(sectionOrder, subsectionOrder, fieldOrder);
    }
  }

  function editField(sectionOrder, subsectionOrder, fieldOrder) {
    if (props.onEditField) {
      props.onEditField(sectionOrder, subsectionOrder, fieldOrder);
    }
  }

  useEffect(() => {
    setSections(props.sections);
  }, [props.sections]);

  const actionButtons = (entry) => {
    return (
      <Fragment>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={deleteField.bind(this, orden, suborden, entry.ordenCampo)}
          icon={faTrashCan}
          color={COLORS.alert}
          size="lg"
        />
        <FontAwesomeIcon
          className="link-cursor"
          onClick={editField.bind(this, orden, suborden, entry.ordenCampo)}
          icon={faPencil}
          color={COLORS.highlight}
          size="lg"
        />
      </Fragment>
    );
  };

  function onClickFieldUpHandler(sectionOrder, subsectionOrder, fieldOrder) {
    props.onClickFieldUp(sectionOrder, subsectionOrder, fieldOrder);
  }

  function onClickFieldDownHandler(sectionOrder, subsectionOrder, fieldOrder) {
    props.onClickFieldDown(sectionOrder, subsectionOrder, fieldOrder);
  }

  const orderActions = (entry) => (
    <Fragment>
      <Row>
        <FontAwesomeIcon
          icon={faCaretUp}
          onClick={onClickFieldUpHandler.bind(
            this,
            orden,
            suborden,
            entry.ordenCampo
          )}
        />
      </Row>
      <Row>
        <FontAwesomeIcon
          icon={faCaretDown}
          onClick={onClickFieldDownHandler.bind(
            this,
            orden,
            suborden,
            entry.ordenCampo
          )}
        />
      </Row>
    </Fragment>
  );

  const form = (
    <Fragment>
      <SectionTitle label="CAMPOS" />
      {!props.editModeIsOn && (
        <Row xs="auto" className="justify-content-end m-3">
          <CustomButton
            size=""
            class={classes["btn-custom-inverse"]}
            color={COLORS.primaryLight}
            iconColor={COLORS.primaryLight}
            label="Agregar Campo"
            icon="faPlus"
            eventHandler={addField}
          />
        </Row>
      )}

      <CustomTable
        columns={columns}
        items={props.hijos?.campos?.map((entry, index) => {
          return {
            key: index + "-" + orden + "-" + suborden + "-" + entry.campoId,
            order: props.disable === true ? "" : orderActions(entry),
            codigo: entry.codigo,
            ordenCampo: entry.ordenCampo,
            etiqueta: entry.etiqueta,
            tipoDato: entry.tipoDato,
            tipoValor: entry.tipoValor,
            obligatorio:
              entry.obligatorio === true ? (
                <FontAwesomeIcon
                  icon={faCheck}
                  color={COLORS.highlight}
                  size="lg"
                />
              ) : (
                ""
              ),
            action: props.disable === true ? "" : actionButtons(entry),
          };
        })}
        hidePage={true}
      />
    </Fragment>
  );
  const body = (
    <Accordion defaultActiveKey="0">
      {props.hijos?.campos && form}
      {nivel === 1 && <SectionTitle label="SUBSECCIONES" />}
      {sections &&
        sections.map((entry) => {
          return (
            (entry.campos !== null || entry.secciones !== null) && (
              <Fragment>
                <Row>
                  <Card
                    className="section-header"
                    key={
                      nivel === 0
                        ? "section" + entry.orden
                        : "section" + orden + "sub" + entry.orden
                    }
                  >
                    {nivel === 0 && (
                      <CustomHeader
                        entry={entry}
                        disable={props.disable}
                        orden={entry.orden}
                        suborden={0}
                        onChangeTitle={props.onChangeTitle}
                        eventKey={"section" + entry.orden}
                        onClickUp={props.onClickUp}
                        onClickDown={props.onClickDown}
                        onDeleteSection={deleteSection.bind(
                          this,
                          entry.orden,
                          0
                        )}
                      />
                    )}
                    {nivel === 1 && (
                      <CustomHeader
                        entry={entry}
                        disable={props.disable}
                        orden={orden}
                        suborden={entry.orden}
                        onChangeTitle={props.onChangeTitle}
                        eventKey={"section" + orden + "sub" + entry.orden}
                        onClickUp={props.onClickUp}
                        onClickDown={props.onClickDown}
                        onDeleteSection={deleteSection.bind(
                          this,
                          orden,
                          entry.orden
                        )}
                      />
                    )}

                    <Accordion.Collapse
                      eventKey={
                        nivel === 0
                          ? "section" + entry.orden
                          : "section" + orden + "sub" + entry.orden
                      }
                    >
                      <Card.Body>
                        {nivel === 0 && (
                          <SectionItem
                            key={"section" + entry.orden}
                            sections={entry.secciones}
                            hijos={entry}
                            disable={props.disable}
                            nivel={nivel + 1}
                            editModeIsOn={props.editModeIsOn}
                            orden={entry.orden}
                            suborden={0}
                            onAddField={props.onAddField}
                            onDeleteSection={props.onDeleteSection}
                            onAddSection={props.onAddSection}
                            onDeleteField={props.onDeleteField}
                            onEditField={props.onEditField}
                            onChangeTitle={props.onChangeTitle}
                            onClickUp={props.onClickUp}
                            onClickDown={props.onClickDown}
                            onClickFieldUp={props.onClickFieldUp}
                            onClickFieldDown={props.onClickFieldDown}
                          />
                        )}
                        {nivel === 1 && (
                          <SectionItem
                            key={"section" + orden + "sub" + entry.orden}
                            sections={entry.secciones}
                            hijos={entry}
                            disable={props.disable}
                            nivel={nivel + 1}
                            editModeIsOn={props.editModeIsOn}
                            orden={orden}
                            suborden={entry.orden}
                            onAddField={props.onAddField}
                            onDeleteSection={props.onDeleteSection}
                            onDeleteField={props.onDeleteField}
                            onEditField={props.onEditField}
                            onChangeTitle={props.onChangeTitle}
                            onClickUp={props.onClickUp}
                            onClickDown={props.onClickDown}
                            onClickFieldUp={props.onClickFieldUp}
                            onClickFieldDown={props.onClickFieldDown}
                          />
                        )}
                        {!props.editModeIsOn && nivel === 0 && (
                          <Row xs="auto" className="justify-content-end m-3">
                            <CustomButton
                              size=""
                              class={classes["btn-custom-inverse"]}
                              color={COLORS.primaryLight}
                              iconColor={COLORS.primaryLight}
                              label="Agregar Sección"
                              icon="faPlus"
                              eventHandler={addSection.bind(this, entry.orden)}
                            />
                          </Row>
                        )}
                      </Card.Body>
                    </Accordion.Collapse>
                  </Card>
                </Row>
              </Fragment>
            )
          );
        })}
    </Accordion>
  );
  return <Fragment>{body}</Fragment>;
};

export default SectionItem;
