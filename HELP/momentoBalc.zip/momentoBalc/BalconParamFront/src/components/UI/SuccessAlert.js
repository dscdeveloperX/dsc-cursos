import { Alert } from "react-bootstrap";
import { Link } from "react-router-dom";
import { COLORS } from "../../values/colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleExclamation } from "@fortawesome/free-solid-svg-icons";

const SuccessAlert = (props) => {
  return (
    <Alert style={{ backgroundColor: COLORS.primaryLight, color: COLORS.white }}>
      <Link>
        <FontAwesomeIcon
          icon={faCircleExclamation}
          color={COLORS.white}
          size="lg"
          className="me-2"
        />
      </Link>
      {props.text}
    </Alert>
  );
};

export default SuccessAlert;
