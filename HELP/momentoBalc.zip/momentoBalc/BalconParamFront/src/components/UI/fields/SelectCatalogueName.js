import { Fragment, useState, useEffect, useCallback, useContext } from "react";
import AuthContext from "../../../store/auth-context";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";

const SelectCatalogueName = (props) => {
  const [selectedValue, setSelectedValue] = useState(props.selected ? props.selected : "");
  const [appList, setAppList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const authCtx = useContext(AuthContext);

  const onChangeHandler = (event) => {
    setSelectedValue(event.target.value);
    props.parentCallback(event.target.value);
  };

  const fetchAppListHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const request = {
        headerRequest: {
          username: authCtx.user,
          stationIp: authCtx.ip,
          dateTime: new Date().toISOString(),
          pageSize: 1000,
          pageRequested: 1,
        },
        bodyRequest: {
            nombreCatalogo: "", 
        },
      };

      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "catalogos/ListarNombres",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        setError(errorMessage[0]);
      }

      
      if (props.selected === undefined) {
        setSelectedValue(data.bodyResponse.nombreCatalogos[0]);
        props.parentCallback(data.bodyResponse.nombreCatalogos[0]);
      } else {
        setSelectedValue(props.selected ? props.selected.trim() : "");
        props.parentCallback(props.selected ? props.selected.trim() : "");
      }
      setAppList(data.bodyResponse.nombreCatalogos);
      
    } catch (error) {
      setError(error.message);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchAppListHandler();
  }, [fetchAppListHandler]);

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-3">
        <Form.Select
          value={selectedValue}
          disabled={props.disabled}
          onChange={onChangeHandler}
        >
          {!isLoading &&
            appList.map((entry, index) => {
              return (
                <option
                  key={`${entry}+${index}`}
                  value={entry}
                >
                  {entry}
                </option>
              );
            })}
        </Form.Select>
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label}
        </Form.Label>
        {error && <p className="error-text">{error}</p>}
      </Form.Group>
    </Fragment>
  );
};

export default SelectCatalogueName;
