import FormSelect from "./FormSelect";

const OperationSelect = (props) => {
  return (
    <FormSelect
      label={props.label}
      value={props.value}
      disabled={props.disabled}
      parentCallback={props.parentCallback}
    >
      <option value=""></option>
      <option value="IN">Valores aceptados</option>
      <option value="NOT IN">Valores excepto</option>
      <option value="INI">Comienza con</option>
      <option value="FIN">Termina con</option>
      <option value="SUB">Contiene</option>
    </FormSelect>
  );
};

export default OperationSelect;
