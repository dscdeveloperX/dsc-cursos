import { Fragment, useState, useEffect, useCallback, useContext } from "react";
import AuthContext from "../../../store/auth-context";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";
import classes from "../css/InputField.module.css";

const ValidationFieldsSelect = (props) => {
  var dependencyList = props.values;
  var valores = [];
  if (props.value !== null && props.value.length > 0) {
    for (var i = 0; i < props.value.length; i++) {
      var code = props.value[i];
      var found = dependencyList.find((x) => x.codigo === code);
      if (found !== undefined) {
        valores.push(found);
      }
    }
  }
  const [selectedValue, setSelectedValue] = useState(valores);

  const onChangeHandler = (event) => {
    setSelectedValue(event);
    var retorno = [];
    for (var i = 0; i < event.length; i++) {
      retorno.push(event[i].codigo);
    }
    props.parentCallback(retorno);
  };

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-3">
        <Typeahead
          className={classes["bottom-line-input"]}
          id="calcValuesSelect"
          labelKey="etiqueta"
          multiple
          onChange={onChangeHandler}
          options={dependencyList}
          placeholder={props.label}
          selected={selectedValue}
        />
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label}
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default ValidationFieldsSelect;
