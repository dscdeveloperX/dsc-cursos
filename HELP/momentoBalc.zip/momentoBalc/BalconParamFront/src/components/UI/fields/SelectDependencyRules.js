import FormSelect from "./FormSelect";

const SelectDependencyRules = (props) => {
  return (
    <FormSelect
      label={props.label}
      value={props.value}
      disabled={props.disabled}
      parentCallback={props.parentCallback}
    >
      <option value="NOTEMPTY">No vacío</option>
      <option value="OPERACION">Operación</option>
    </FormSelect>
  );
};

export default SelectDependencyRules;
