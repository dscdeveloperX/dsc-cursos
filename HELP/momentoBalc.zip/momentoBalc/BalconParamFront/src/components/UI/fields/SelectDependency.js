import { Fragment, useState } from "react";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";
import {
  Highlighter,
  Menu,
  MenuItem,
  Typeahead,
} from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";
import classes from "../css/InputField.module.css";

const SelectDependency = (props) => {
  var valorInicial = { etiqueta: "Ninguna", codigo: "", model: "Default" };

  var valoresDependencia =
    props.fields !== undefined
      ? [valorInicial, ...props.fields]
      : [valorInicial];

  var found = valoresDependencia.find((x) => x.codigo === props.value);
  
  if (found !== undefined) {
    valorInicial = found;
  }

  const [selectedValue, setSelectedValue] = useState([valorInicial]);
  const dependencyList = valoresDependencia;

  const onBlurHandler = (event) => {
    if (event.length === 0) {
      setSelectedValue([{ etiqueta: "Ninguna", codigo: "", model: "Default" }]);
      props.parentCallback("");
    }
  };
  const onChangeHandler = (event) => {
    setSelectedValue(event);
    var valor = event.length > 0 ? event[0].codigo : "";
    props.parentCallback(valor);
  };

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-3">
        {
          <Typeahead
            className={classes["bottom-line-input"]}
            id="dependencyField"
            labelKey="etiqueta"
            onChange={onChangeHandler}
            onBlur={onBlurHandler}
            options={dependencyList}
            placeholder={props.label}
            selected={selectedValue}
            renderMenu={(results, menuProps, state) => {
              let index = 0;
              const models = results.reduce((group, product) => {
                const { model } = product;
                if (model !== undefined) {
                  group[model] = group[model] ?? [];
                  group[model].push(product);
                }
                return group;
              }, {});
              const items = Object.keys(models).map((model) => (
                <Fragment key={model}>
                  {index !== 0 && <Menu.Divider />}
                  <Menu.Header>{model}</Menu.Header>
                  {models[model].map((i) => {
                    const item = (
                      <MenuItem key={index} option={i} position={index}>
                        <Highlighter search={state.text}>
                          {i.etiqueta}
                        </Highlighter>
                      </MenuItem>
                    );

                    index += 1;
                    return item;
                  })}
                </Fragment>
              ));

              return <Menu {...menuProps}>{items}</Menu>;
            }}
          />
        }
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label}
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default SelectDependency;
