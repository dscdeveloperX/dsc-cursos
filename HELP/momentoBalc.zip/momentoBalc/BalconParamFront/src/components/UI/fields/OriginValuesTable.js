import { Fragment, useState } from "react";
import { COLORS } from "../../../values/colors";
import CustomButton from "../buttons/CustomButton";
import classes from "../css/BMButton.module.css";
import { Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashCan } from "@fortawesome/free-solid-svg-icons";
import CustomEditTable from "../../Layout/CustomEditTable";

const OriginValuesTable = (props) => {
  const [valuesStr, setValueStr] = useState(props.value);

  const modelType = props.originType === "MODELOS";

  var initVal = modelType
    ? [
        {
          Codigo: "Código",
          Descripcion: "",
        },
        {
          Codigo: "Descripción",
          Descripcion: "",
        },
        {
          Codigo: "Complemento",
          Descripcion: "",
        },
        {
          Codigo: "Modelo",
          Descripcion: "",
        },
      ]
    : [];

  const valueParse = props.value ? JSON.parse(valuesStr) : initVal;

  const [values, setValues] = useState(valueParse);
  //const label = props.label;

  const columns = modelType
    ? [
        { dataField: "key", text: "", hidden: true },
        {
          dataField: "Codigo",
          text: "Campo Catálogo",
        },
        {
          dataField: "Descripcion",
          text: "Código Campo Modelo",
        },
        { dataField: "action", text: "" },
      ]
    : [
        { dataField: "key", text: "", hidden: true },
        {
          dataField: "Codigo",
          text: "Código",
        },
        {
          dataField: "Descripcion",
          text: "Descripción",
        },
        { dataField: "action", text: "" },
      ];

  function UpdateValues(newValues) {
    setValues(newValues);
    var str = JSON.stringify(newValues);
    setValueStr(str);

    if (props.parentCallback) {
      props.parentCallback(str);
    }
  }

  function addValue() {
    var temp = [...values];
    temp.push({ Codigo: "", Descripcion: "" });
    UpdateValues(temp);
  }

  function deleteValue(index, entry) {
    var temp = [...values];
    temp.splice(index, 1);
    UpdateValues(temp);
  }

  const handleTableChange = (type, newState) => {
    let info = newState.cellEdit;

    if (info) {
      var temp = [...values];
      temp[info.rowId][info.dataField] = info.newValue;
      UpdateValues(temp);
    }
  };

  const actionButtons = (index, entry) => {
    return (
      <Fragment>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={deleteValue.bind(this, index, entry)}
          icon={faTrashCan}
          color={COLORS.alert}
          size="lg"
        />
      </Fragment>
    );
  };

  return (
    <Fragment>
      <CustomEditTable
        columns={columns}
        items={values.map((entry, index) => {
          return {
            key: index,
            Codigo: entry.Codigo,
            Descripcion: entry.Descripcion,
            action:
              props.disable === true || modelType
                ? ""
                : actionButtons(index, entry),
          };
        })}
        onChangePage={handleTableChange}
        hidePage={true}
      />
      {modelType !== true && (
        <Row xs="auto" className="justify-content-end m-3">
          <CustomButton
            size=""
            class={classes["btn-custom-inverse"]}
            color={COLORS.primaryLight}
            iconColor={COLORS.primaryLight}
            label="Agregar Valor"
            icon="faPlus"
            eventHandler={addValue}
          />
        </Row>
      )}
    </Fragment>
  );
};

export default OriginValuesTable;
