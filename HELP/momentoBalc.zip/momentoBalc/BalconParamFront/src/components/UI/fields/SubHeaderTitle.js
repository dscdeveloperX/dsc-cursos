import { Fragment } from "react";
import { COLORS } from "../../../values/colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import formClasses from "../../UI/css/Form.module.css";
import { Row } from "react-bootstrap";
const FormInput = (props) => {
  return (
    <Fragment>
      <Row>
        {props.icon && <FontAwesomeIcon icon={props.icon} />}
        <h1 className={formClasses.formtitle}>{props.label}</h1>
      </Row>
      <hr style={{ color: COLORS.grey, height: "1px" }} />
    </Fragment>
  );
};

export default FormInput;
