import { Fragment, useState, useEffect, useCallback, useContext } from "react";
import AuthContext from "../../../store/auth-context";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";

const SelectModel = (props) => {
  const [selectedValue, setSelectedValue] = useState("");
  const [appList, setAppList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const authCtx = useContext(AuthContext);

  const modeltype = props.tipo;

  const onChangeHandler = (event) => {
    setSelectedValue(event.target.value);
    props.parentCallback(event.target.value);
  };

  const fetchAppListHandler = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
        const request = {
            headerRequest: {
              username: authCtx.user,
              stationIp: authCtx.ip,
              dateTime: new Date().toISOString(),
              pageSize: 1000,
          pageRequested: 1,
            },
            bodyRequest: {
              estado: "ACTIVO",
              ordenarPor: "name",
              ordenDesc: false,
              filtrarPor: "",
              valorFiltro: "",
              tipo: modeltype, 
              menuId: localStorage.getItem('menuId'),
            },
          };

      const response = await fetch(
        authCtx.REACT_APP_BASE_URL + "modelos/Listar",
        {
          method: "POST",
          body: JSON.stringify(request),
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + authCtx.token,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        const errorMessage = data.headerResponse.returnMessage.split("|");
        setError(errorMessage[0]);
      }

      setAppList(data.bodyResponse.modelos);
      if (props.allowNone !== undefined && props.allowNone === true) {
        setAppList([
          { codigo: "", nombre: "Ninguno" },
          ...data.bodyResponse.modelos,
        ]);
      }

      if (props.selected === undefined) {
        setSelectedValue(data.bodyResponse.modelos[0]);
        props.parentCallback(data.bodyResponse.modelos[0].codigo);
      } else {
        setSelectedValue(props.selected);
        props.parentCallback(props.selected);
      }
      
    } catch (error) {
      setError(error.message);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchAppListHandler();
  }, [fetchAppListHandler]);

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-3">
        <Form.Select
          value={selectedValue}
          disabled={props.disabled}
          onChange={onChangeHandler}
        >
          {!isLoading &&
            appList.map((entry) => {
              return (
                <option
                  key={`${entry.modeloId}+${entry.nombre}`}
                  value={entry.codigo}
                >
                  {entry.nombre}
                </option>
              );
            })}
        </Form.Select>
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label}
        </Form.Label>
        {error && <p className="error-text">{error}</p>}
      </Form.Group>
    </Fragment>
  );
};

export default SelectModel;
