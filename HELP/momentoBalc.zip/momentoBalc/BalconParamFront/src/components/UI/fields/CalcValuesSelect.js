import { Fragment, useState, useEffect, useCallback, useContext } from "react";
import AuthContext from "../../../store/auth-context";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";
import { Typeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";
import classes from "../css/InputField.module.css";

const CalcValuesSelect = (props) => {
  var dependencyList = props.values;
  var signo = " ";
  var allowValue = [
    "CalcularDiferencia",
    "CalcularDivision",
    "CalcularMultiplicacion",
    "CalcularSuma",
    "ObtenerSubCadena",
    "VerificadorFATCAAccionistas",
  ].includes(props.calc);

  if (props.calc === "CalcularDiferenciaFecha") {
    signo = "-";
    dependencyList = dependencyList.filter((e) => e.tipoDato === "FECHA");
    dependencyList.push({
      etiqueta: "Hoy",
      codigo: "${TODAY}",
      tipoDato: "FECHA",
    });
  } else if (
    [
      "CalcularDiferencia",
      "CalcularDivision",
      "CalcularMultiplicacion",
      "CalcularSuma",
    ].includes(props.calc)
  ) {
    if (props.calc === "CalcularDiferencia") signo = " - ";
    else if (props.calc === "CalcularDivision") signo = " / ";
    else if (props.calc === "CalcularMultiplicacion") signo = " * ";
    else if (props.calc === "CalcularSuma") signo = " + ";
    dependencyList = dependencyList.filter((e) => e.tipoDato === "MONEDA");
  } else if (props.calc === "ObtenerValorCampo") {
    dependencyList = dependencyList.filter(
      (e) => e.tipoDato === props.dataType
    );
  } else if (props.calc === "VerificadorFATCAAccionistas")
  {
    dependencyList = dependencyList.filter(
      (e) => e.tipoValor === "LISTA"
    );
  } 
  var formulaInicial = "";
  var valores = [];
  if (props.value !== null && props.value.length > 0) {
    for (var i = 0; i < props.value.length; i++) {
      var code = props.value[i];

      if (signo !== "" && i > 0) formulaInicial += signo;
      formulaInicial += code;
      var found = dependencyList.find((x) => x.codigo === code);
      if (found !== undefined) {
        valores.push(found);
      } else if (allowValue) {
        valores.push({
          etiqueta: code.replace("$[", "").replace("]", ""),
          codigo: code,
          tipoDato: "NUMERICO",
        });
      }
    }
  }

  const [selectedValue, setSelectedValue] = useState(valores);
  const [formula, setFormula] = useState(formulaInicial);

  const onChangeHandler = (event) => {
    setSelectedValue(event);
    var retorno = [];
    var calc = "";
    for (var i = 0; i < event.length; i++) {
      if (signo !== "" && i > 0) calc += signo;

      if (event[i].customOption) {
        var code = "$[" + event[i].etiqueta + "]";
        calc += code;
        retorno.push(code);
      } else {
        calc += event[i].codigo;
        retorno.push(event[i].codigo);
      }
    }
    setFormula(calc);
    props.parentCallback(retorno);
  };

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-3">
        {"Valor = " + formula}
        <Typeahead
          className={classes["bottom-line-input"]}
          id="calcValuesSelect"
          labelKey="etiqueta"
          multiple
          allowNew={allowValue}
          onChange={onChangeHandler}
          options={dependencyList}
          placeholder={props.label}
          selected={selectedValue}
        />
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label}
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default CalcValuesSelect;
