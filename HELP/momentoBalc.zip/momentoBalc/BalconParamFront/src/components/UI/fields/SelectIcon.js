import { Fragment, useState } from "react";
import { Form, Col } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import * as Icons from "@fortawesome/free-solid-svg-icons";
import { COLORS } from "../../../values/colors";

const SelectIcon = (props) => {
  const [selectedValue, setSelectedValue] = useState(
    props.selected ? props.selected : "faHouse"
  );

  const onChangeHandler = (event) => {
    setSelectedValue(event.target.value);
    props?.parentCallback(event.target.value);
  };

  const iconList = [
    ...new Set(
      Object.keys(Icons).filter((key) => key !== "fas" && key !== "prefix")
    ),
  ]
    .map((icon) => {
      return {
        icon: Icons[icon],
        value: icon,
        label: Icons[icon].iconName,
      };
    })
    .sort(function (x, y) {
      let a = x.label.toUpperCase(),
        b = y.label.toUpperCase();
      return a === b ? 0 : a > b ? 1 : -1;
    });

  return (
    <Fragment>
      <Form.Group as={Col} className="mb-3">
        <FontAwesomeIcon icon={Icons[selectedValue]} />
        <Form.Select
          value={selectedValue}
          disabled={props.disabled}
          onChange={onChangeHandler}
        >
          {iconList.map((entry) => {
            return (
              <option key={entry.value} value={entry.value}>
                {entry.label}
              </option>
            );
          })}
        </Form.Select>
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          Ícono
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default SelectIcon;
