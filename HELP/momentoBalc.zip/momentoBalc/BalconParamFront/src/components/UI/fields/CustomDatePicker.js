import { Fragment } from "react";
import { Form, Col } from "react-bootstrap";

import classes from "../css/InputField.module.css";
import { COLORS } from "../../../values/colors";

const CustomDatePicker = (props) => {
  return (
    <Fragment>
      <Form.Group controlId="date" as={Col} className="mb-3">
        <Form.Control
          className={classes["bottom-line-input"]}
          disabled={props.disabled}
          type="date"
          name="date"
          value={props.value ? (props.value).split("T")[0] : undefined}
          onChange={props.eventHandler}
          placeholder={props.label ? props.label : "Seleccione Fecha"}
          style={{ marginBottom: 0 }}
        />
        <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
          {props.label ? props.label : "Seleccione Fecha"}
        </Form.Label>
      </Form.Group>
    </Fragment>
  );
};

export default CustomDatePicker;
