import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Fragment } from "react";
import { Popover, OverlayTrigger } from "react-bootstrap";
import { COLORS } from "../../../values/colors";

const InfoTooltip = (props) => {
  return (
    <Fragment>
      <div style={{ width: "90%" }}>{props.children}</div>
      <div style={{ width: "10%" }}>
        <OverlayTrigger
          trigger="click"
          key={props.llave}
          placement="right"
          overlay={
            <Popover id={`popover-positioned-${props.llave}`}>
              <Popover.Header as="h3">{props.label}</Popover.Header>
              <Popover.Body>{props.message}</Popover.Body>
            </Popover>
          }
        >
          <FontAwesomeIcon icon={faInfoCircle} color={COLORS.grey} size="xl" />
        </OverlayTrigger>
      </div>
    </Fragment>
  );
};

export default InfoTooltip;
