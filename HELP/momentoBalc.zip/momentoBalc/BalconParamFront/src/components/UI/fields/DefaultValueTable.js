import { Fragment, useState } from "react";
import { COLORS } from "../../../values/colors";
import CustomTable from "../../Layout/CustomTable";
import CustomButton from "../buttons/CustomButton";
import classes from "../css/BMButton.module.css";
import { Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashCan, faPencil } from "@fortawesome/free-solid-svg-icons";
import CustomEditTable from "../../Layout/CustomEditTable";

const DefaultValueTable = (props) => {
  var valueParse = [];

  var valorInicial = {
    DEFAULT: "",
  };

  if (props.value && props.value !== null) {
    valorInicial = props.value;
  }
  if (valorInicial && valorInicial !== null) {
    for (const [key, value] of Object.entries(valorInicial)) {
      valueParse.push({
        Codigo: key,
        Descripcion: value,
      });
    }
  }

  const [values, setValues] = useState(valueParse);
  //const label = props.label;

  const columns = [
    { dataField: "key", text: "", hidden: true },
    {
      dataField: "Codigo",
      text: "Código",
    },
    {
      dataField: "Descripcion",
      text: "Descripción",
    },
    { dataField: "action", text: "" },
  ];

  function UpdateValues(newValues) {
    setValues(newValues);
    var retorno = {};
    for (var i = 0; i < newValues.length; i++) {
      retorno[newValues[i].Codigo] = newValues[i].Descripcion;
    }

    if (props.parentCallback) {
      props.parentCallback(retorno);
    }
  }

  function addValue() {
    var temp = [...values];
    temp.push({ Codigo: "", Descripcion: "" });
    UpdateValues(temp);
  }

  function deleteValue(index, entry) {
    var temp = [...values];
    temp.splice(index, 1);

    UpdateValues(temp);
  }

  const handleTableChange = (type, newState) => {
    let info = newState.cellEdit;

    if (info) {
      var temp = [...values];

      temp[info.rowId][info.dataField] = info.newValue;

      UpdateValues(temp);
    }
  };

  const actionButtons = (index, entry) => {
    return (
      <Fragment>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={deleteValue.bind(this, index, entry)}
          icon={faTrashCan}
          color={COLORS.alert}
          size="lg"
        />
      </Fragment>
    );
  };

  return (
    <Fragment>
      <CustomEditTable
        columns={columns}
        items={values.map((entry, index) => {
          return {
            key: index,
            Codigo: entry.Codigo,
            Descripcion: entry.Descripcion,
            action:
              props.disable === true || entry.Codigo == "DEFAULT"
                ? ""
                : actionButtons(index, entry),
          };
        })}
        onChangePage={handleTableChange}
        hidePage={true}
      />
      <Row xs="auto" className="justify-content-end m-3">
        <CustomButton
          size=""
          class={classes["btn-custom-inverse"]}
          color={COLORS.primaryLight}
          iconColor={COLORS.primaryLight}
          label="Agregar Valor"
          icon="faPlus"
          eventHandler={addValue}
        />
      </Row>
    </Fragment>
  );
};

export default DefaultValueTable;
