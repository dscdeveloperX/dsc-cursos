import { Fragment, useState } from "react";
import { COLORS } from "../../../values/colors";
import CustomTable from "../../Layout/CustomTable";
import CustomButton from "../buttons/CustomButton";
import classes from "../css/BMButton.module.css";
import { Badge, Button, ButtonGroup, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrashCan } from "@fortawesome/free-solid-svg-icons";
import CustomEditTable from "../../Layout/CustomEditTable";
import OperationSelect from "./OperationSelect";

const DependencyOperationValues = (props) => {
  var valueParse = [];

  var valorInicial = {
    DEFAULT: { operacion: "NONE", valores: [] },
  };

  if (props.value && props.value !== null) {
    valorInicial = props.value;
  }
  if (valorInicial && valorInicial !== null) {
    for (const [key, value] of Object.entries(valorInicial)) {
      valueParse.push({
        llave: key,
        operacion: value.operacion,
        valores: value.valores.join(","),
      });
    }
  }

  const [values, setValues] = useState(valueParse);
  //const label = props.label;
  const disableAdd = props.disableAdd ? props.disableAdd : false;

  const columns = [
    { dataField: "key", text: "", hidden: true },
    {
      dataField: "llave",
      text: "Valor Campo",
    },
    {
      dataField: "operacion",
      text: "Operación",
      hidden: true,
    },
    {
      dataField: "opSelect",
      text: "Operación",
    },
    {
      dataField: "valores",
      text: "Valores",
    },
    { dataField: "action", text: "" },
  ];

  function UpdateValues(newValues) {
    setValues(newValues);

    var str = {};
    for (var i = 0; i < newValues.length; i++) {
      var valorLista = newValues[i];
      str[valorLista.llave] = {
        operacion: valorLista.operacion,
        valores: valorLista.valores.split(","),
      };
    }

    if (props.parentCallback) {
      props.parentCallback(str);
    }
  }

  function addValue() {
    var temp = [...values];
    temp.push({ llave: "", operacion: "", valores: "" });
    UpdateValues(temp);
  }

  function deleteValue(index, entry) {
    var temp = [...values];
    temp.splice(index, 1);

    UpdateValues(temp);
  }

  const handleTableChange = (type, newState) => {
    let info = newState.cellEdit;

    if (info) {
      var temp = [...values];

      temp[info.rowId][info.dataField] = info.newValue;

      UpdateValues(temp);
    }
  };

  const actionButtons = (index, entry) => {
    return (
      <Fragment>
        <FontAwesomeIcon
          className="link-cursor"
          onClick={deleteValue.bind(this, index, entry)}
          icon={faTrashCan}
          color={COLORS.alert}
          size="lg"
        />
      </Fragment>
    );
  };

  const onClickOperationHandler = (index, entry, disable) => {
    if (!disable) {
      var temp = [...values];
      temp[index].operacion = entry;
      UpdateValues(temp);
    }
  };

  const operationButton = (index, entry, disable) => {
    return (
      <Fragment>
        <Badge
          bg={entry.operacion == "NONE" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "NONE", disable)}
        >
          Ninguno
        </Badge>
        <Badge
          bg={entry.operacion == "IN" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "IN", disable)}
        >
          Aceptados
        </Badge>
        <Badge
          bg={entry.operacion == "NOT IN" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "NOT IN", disable)}
        >
          Excluyentes
        </Badge>
        <Badge
          bg={entry.operacion == "SUB" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "SUB", disable)}
        >
          Contiene
        </Badge>
        <Badge
          bg={entry.operacion == "INI" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "INI", disable)}
        >
          Comienza con
        </Badge>
        <Badge
          bg={entry.operacion == "FIN" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "FIN", disable)}
        >
          Termina con
        </Badge>
        <Badge
          bg={entry.operacion == "AND" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "AND", disable)}
        >
          Condicional AND
        </Badge>
        <Badge
          bg={entry.operacion == "OR" ? "primary" : "secondary"}
          onClick={onClickOperationHandler.bind(this, index, "OR", disable)}
        >
          Condicional OR
        </Badge>
      </Fragment>
    );
  };

  return (
    <Fragment>
      <CustomEditTable
        columns={columns}
        items={values.map((entry, index) => {
          return {
            key: index,
            llave: entry.llave,
            operacion: entry.operacion,
            opSelect: operationButton(index, entry, props.disable),
            valores: entry.valores,
            action:
              props.disable === true || entry.llave == "DEFAULT"
                ? ""
                : actionButtons(index, entry),
          };
        })}
        onChangePage={handleTableChange}
        hidePage={true}
      />
      {!disableAdd && (
        <Row xs="auto" className="justify-content-end m-3">
          <CustomButton
            size=""
            class={classes["btn-custom-inverse"]}
            color={COLORS.primaryLight}
            iconColor={COLORS.primaryLight}
            label="Agregar Valor"
            icon="faPlus"
            eventHandler={addValue}
          />
        </Row>
      )}
    </Fragment>
  );
};

export default DependencyOperationValues;
