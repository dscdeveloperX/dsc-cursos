import { useState } from "react";
import { Form, Col } from "react-bootstrap";

import classes from "../css/InputField.module.css";
import { COLORS } from "../../../values/colors";

const FormInput = (props) => {
  const [enteredValue, setEnteredValue] = useState(props.value);
  const [enteredValueTouched, setEnteredValueTouched] = useState(false);

  const enteredValueIsNotEmpty = enteredValue !== "";
  const enteredValueIsValid = enteredValueIsNotEmpty;
  const valueInputIsInvalid = !enteredValueIsValid && enteredValueTouched;

  const valueInputChangeHandler = (event) => {
    setEnteredValue(event.target.value);
    if (props.parentCallback) {
      props.parentCallback(enteredValue);
    }
  };

  const valueInputBlurHandler = (event) => {
    setEnteredValueTouched(true);
    if (props.parentCallback) {
      props.parentCallback(enteredValue);
    }
    if (props.parentIsValidCallback) {
      props.parentIsValidCallback(!valueInputIsInvalid);
    }
  };

  const requiredWarningMessage = "Campo Obligatorio";

  return (
    <Form.Group as={Col}>
      <Form.Control
        className={classes["bottom-line-input"]}
        disabled={props.disabled}
        value={enteredValue}
        onChange={valueInputChangeHandler}
        onBlur={valueInputBlurHandler}
        type="text"
        placeholder={props.label}
        style={{ marginBottom: 0 }}
      />
      <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
        {props.label}
      </Form.Label>
      {props.parentIsValidCallback && valueInputIsInvalid && (
        <p className="error-text">{requiredWarningMessage}</p>
      )}
    </Form.Group>
  );
};

export default FormInput;
