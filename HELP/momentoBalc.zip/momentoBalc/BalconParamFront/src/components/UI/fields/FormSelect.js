import { useState } from "react";
import { Form, Col } from "react-bootstrap";
import { COLORS } from "../../../values/colors";

const FormSelect = (props) => {
  const [enteredValue, setEnteredValue] = useState(props.value);

  const valueInputChangeHandler = (event) => {
    setEnteredValue(event.target.value);
    if (props.parentCallback) {
      props.parentCallback(event.target.value);
    }
  };

  return (
    <Form.Group as={Col}>
      <Form.Select
        disabled={props.disabled}
        value={enteredValue}
        onChange={valueInputChangeHandler}
      >
        {props.children}
      </Form.Select>
      <Form.Label style={{ color: COLORS.grey, fontSize: "0.8rem" }}>
        {props.label}
      </Form.Label>
    </Form.Group>
  );
};

export default FormSelect;
