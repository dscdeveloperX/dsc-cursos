import { Alert } from "react-bootstrap";
import { Link } from "react-router-dom";
import { COLORS } from "../../values/colors";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmarkCircle } from "@fortawesome/free-solid-svg-icons";

const ErrorAlert = (props) => {
  return (
    <Alert style={{ backgroundColor: COLORS.alert, color: COLORS.white }}>
      <Link>
        <FontAwesomeIcon
          icon={faXmarkCircle}
          onClick={props?.hideError}
          color={COLORS.white}
          size="lg"
          className="me-2"
        />
      </Link>
      {props.text}
    </Alert>
  );
};

export default ErrorAlert;
