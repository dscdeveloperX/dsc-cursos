import { Button } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowRight,
  faMagnifyingGlass,
  faHouseChimney,
  faPlus,
  faX,
  faCircleXmark,
  faUser,
  faCircleQuestion,
} from "@fortawesome/free-solid-svg-icons";

const CustomButton = (props) => {
  let icon = null;
  if (props.icon) {
    if (props.icon === "faArrowRight") {
      icon = faArrowRight;
    } else if (props.icon === "faMagnifyingGlass") {
      icon = faMagnifyingGlass;
    } else if (props.icon === "faHouseChimney") {
      icon = faHouseChimney;
    } else if (props.icon === "faPlus") {
      icon = faPlus;
    } else if (props.icon === "faX") {
      icon = faX;
    } else if (props.icon === "faCircleXmark") {
      icon = faCircleXmark;
    } else if (props.icon === "faUser") {
      icon = faUser;
    } else if (props.icon === "faCircleQuestion") {
      icon = faCircleQuestion;
    }
  }
  return (
    <Button
      size={props.size}
      variant="custom"
      onClick={props.eventHandler}
      className={props.class}
      style={{
        color: props.color ? props.color : undefined,
        fontFamily: props.fontFamily ? props.fontFamily : "Roboto",
        fontWeight: props.bold ? "bold" : undefined,
      }}
    >
      {props.icon && props.iconLeft ? (
        <FontAwesomeIcon
          color={props.iconColor ? props.iconColor : undefined}
          icon={icon}
          size="lg"
          className="me-2"
        />
      ) : (
        ""
      )}
      {props.fontFamily ? props.label : props.label?.toUpperCase()}
      {props.icon && props.iconLeft === undefined ? (
        <FontAwesomeIcon
          color={props.iconColor ? props.iconColor : undefined}
          icon={icon}
          size="lg"
          className="ms-1"
        />
      ) : (
        ""
      )}
    </Button>
  );
};

export default CustomButton;
