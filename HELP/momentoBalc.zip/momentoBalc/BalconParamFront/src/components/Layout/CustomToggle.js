import {
  faArrowAltCircleDown,
  faArrowAltCircleUp,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useAccordionButton } from "react-bootstrap";
import { useState } from "react";

const CustomToggle = (props) => {
  const [isOpen, setIsOpen] = useState(true);
  const decoratedOnClick = useAccordionButton(props.eventKey, () => {
    setIsOpen(!isOpen);
  });

  return (
    <FontAwesomeIcon
      onClick={decoratedOnClick}
      icon={isOpen ? faArrowAltCircleDown : faArrowAltCircleUp}
    />
  );
};

export default CustomToggle;
