import { faCaretDown, faCaretUp, faX } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Fragment, useState } from "react";
import { Card, Form, Row, Col } from "react-bootstrap";
import { COLORS } from "../../values/colors";
import CustomToggle from "./CustomToggle";

const CustomHeader = (props) => {
  const entry = props.entry;
  const [title, setTitle] = useState(entry.nombre);
  const orden = props.orden ? props.orden : 0;
  const suborden = props.suborden ? props.suborden : 0;

  function onClickUpHandler() {
    props.onClickUp(orden, suborden);
  }

  function onClickDownHandler() {
    props.onClickDown(orden, suborden);
  }

  return (
    <Card.Header>
      <Row>
        <Col md="1">
          {!props.disable && <FontAwesomeIcon
            className="link-cursor"
            onClick={props.onDeleteSection}
            icon={faX}
            color={COLORS.alert}
            size="lg"
          />}
        </Col>
        <Col md="1">
          {!props.disable && (
            <Fragment>
              <Row>
                <FontAwesomeIcon icon={faCaretUp} onClick={onClickUpHandler} />
              </Row>
              <Row>
                <FontAwesomeIcon
                  icon={faCaretDown}
                  onClick={onClickDownHandler}
                />
              </Row>
            </Fragment>
          )}
        </Col>
        <Col md="9">
          <Form.Control
            type="text"
            disabled={props.disable}
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
            }}
            onBlur={(e) => {
              setTitle(e.target.value);
              props.onChangeTitle(orden, suborden, e.target.value);
            }}
          ></Form.Control>
        </Col>
        <Col md="1">
          <CustomToggle eventKey={props.eventKey} />
        </Col>
      </Row>
    </Card.Header>
  );
};

export default CustomHeader;
