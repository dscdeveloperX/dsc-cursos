import { Fragment, useContext } from "react";
import { Link } from "react-router-dom";
import { Nav, Accordion, Row } from "react-bootstrap";
import AuthContext from "../../store/auth-context";
import "../UI/css/Dashboard.css";
import MenuItem from "../UI/MenuItem";

const Sidebar = (props) => {
  const authCtx = useContext(AuthContext);
  const menu = authCtx.menu ? JSON.parse(authCtx.menu) : [];
  return (
    <Fragment>
      <Nav className="sidebar flex-column">
        {menu !== undefined &&
          menu.length > 0 &&
          menu?.map((opcion) => {
            return (
              <div key={opcion.menuId}>
                <MenuItem
                  active={opcion.ruta === props.location.pathname}
                  hijos={opcion.hijos}
                  ruta={opcion.ruta}
                  menuId={opcion.menuId}
                  icono={opcion.icono}
                  nombre={opcion.nombre}
                  estado={opcion.estado}
                />
              </div>
            );
          })}
        {menu === undefined && (
          <Fragment>
            <Accordion defaultActiveKey="0">
              <Accordion.Item eventKey="2" className="sidebar-accordion">
                <Accordion.Header>Usuarios</Accordion.Header>
                <Accordion.Body>
                  <Row>
                    <Nav.Link
                      eventKey="2.1"
                      as={Link}
                      to="/usuario"
                      className="nav-item"
                    >
                      Listado
                    </Nav.Link>
                  </Row>
                  <Row>
                    <Nav.Link
                      eventKey="2.2"
                      as={Link}
                      to="/usuario_activacion"
                      className="nav-item"
                    >
                      Activacion
                    </Nav.Link>
                  </Row>
                  <Row>
                    <Nav.Link
                      eventKey="2.2"
                      as={Link}
                      to="/usuario_inactivacion"
                      className="nav-item"
                    >
                      Inactivacion
                    </Nav.Link>
                  </Row>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
            <Nav.Link eventKey="3" as={Link} to="/roles" className="nav-item">
              Roles
            </Nav.Link>
            <Nav.Link
              eventKey="8"
              as={Link}
              to="/aplicaciones"
              className="nav-item"
            >
              Aplicaciones
            </Nav.Link>
            <Nav.Link
              eventKey="4"
              as={Link}
              to="/permisos_roles"
              className="nav-item"
            >
              Permisos por Roles
            </Nav.Link>
            <Nav.Link
              eventKey="5"
              as={Link}
              to="/roles_usuario"
              className="nav-item"
            >
              Roles por Usuario
            </Nav.Link>
            <Accordion defaultActiveKey="0">
              <Accordion.Item eventKey="6" className="sidebar-accordion">
                <Accordion.Header>Reportes</Accordion.Header>
                <Accordion.Body>
                  <Row>
                    <Nav.Link
                      eventKey="6.1"
                      as={Link}
                      to="/reportes/usuario"
                      className="nav-item"
                    >
                      Listado de Usuario
                    </Nav.Link>
                  </Row>
                  <Row>
                    <Nav.Link
                      eventKey="6.2"
                      as={Link}
                      to="/reportes/roles"
                      className="nav-item"
                    >
                      Listado de Roles
                    </Nav.Link>
                  </Row>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
            <Nav.Link
              eventKey="7"
              as={Link}
              to="/auditoria"
              className="nav-item"
            >
              Auditoría
            </Nav.Link>
          </Fragment>
        )}
      </Nav>
    </Fragment>
  );
};

export default Sidebar;
