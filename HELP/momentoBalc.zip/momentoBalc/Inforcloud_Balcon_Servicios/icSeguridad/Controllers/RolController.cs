﻿using FluentValidation.Results;
using icCommon.Utils;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DTOs.API.Request.Roles;
using icSeguridad.DTOs.API.Response;
using icSeguridad.DTOs.API.Response.Roles;
using icSeguridad.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;

namespace icSeguridad.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/seguridad/roles")]
    [ApiController]
    [Authorize]
    public class RolController : ControllerBase
    {
        private readonly IRolBLL _clRepository;
        public RolController(IRolBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaRolesResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaRolesResponse> ListarRoles([FromBody] ListaRolesRequest ProfileRequestDto)
        {
            ListaRolesResponse response = new();
            ListaRolesValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ListarRoles: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ListarRoles -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ListarRoles(ProfileRequestDto);
                Log.Information("RolController/ListarRoles -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaRolResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaRolResponse> ObtenerRolPorId([FromBody] ConsultaRolRequest ProfileRequestDto)
        {
            ConsultaRolResponse response = new();
            ConsultaRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ObtenerRolPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ObtenerRolPorId -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ObtenerRolPorId(ProfileRequestDto);
                Log.Information("RolController/ObtenerRolPorId -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Crear")]
        [ProducesResponseType(200, Type = typeof(CreacionEdicionRolResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionEdicionRolResponse> CrearRol([FromBody] CreacionRolRequest ProfileRequestDto)
        {
            CreacionEdicionRolResponse response = new();
            CreacionRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/CrearRol: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/CrearRol -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.CrearRol(ProfileRequestDto);
                Log.Information("RolController/CrearRol -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Eliminar")]
        [ProducesResponseType(200, Type = typeof(EliminacionRolResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EliminacionRolResponse> EliminarRoles([FromBody] EliminacionRolRequest ProfileRequestDto)
        {
            EliminacionRolResponse response = new();
            EliminacionRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/EliminarRoles: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/EliminarRoles -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.EliminarRol(ProfileRequestDto);
                Log.Information("RolController/EliminarRoles -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Actualizar")]
        [ProducesResponseType(200, Type = typeof(CreacionEdicionRolResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionEdicionRolResponse> ActualizarRol([FromBody] EdicionRolRequest ProfileRequestDto)
        {
            CreacionEdicionRolResponse response = new();
            EdicionRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ActualizarRol: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ActualizarRol -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ActualizarRol(ProfileRequestDto);
                Log.Information("RolController/ActualizarRol -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Activar")]
        [ProducesResponseType(200, Type = typeof(ActivacionRolesResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ActivacionRolesResponse> ActivarRoles([FromBody] ActivacionRolRequest ProfileRequestDto)
        {
            ActivacionRolesResponse response = new();
            ActivacionRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ActivarRoles: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ActivarRoles -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ActivarRoles(ProfileRequestDto);
                Log.Information("RolController/ActivarRoles -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Inactivar")]
        [ProducesResponseType(200, Type = typeof(InactivacionRolResponse))]
        [ProducesResponseType(400)]
        public ActionResult<InactivacionRolResponse> InactivarRoles([FromBody] InactivacionRolRequest ProfileRequestDto)
        {
            InactivacionRolResponse response = new();
            InactivacionRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/InactivarRoles: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/InactivarRoles -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.InactivarRol(ProfileRequestDto);
                Log.Information("RolController/InactivarRoles -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }
        [HttpPost("ObtenerPermisosRol")]
        [ProducesResponseType(200, Type = typeof(ConsultaRolResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaRolResponse> ObtenerPermisosRol([FromBody] ConsultaPermisosRolRequest ProfileRequestDto)
        {
            ConsultaRolResponse response = new();
            ConsultaPermisosRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ObtenerPermisosRol: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ObtenerPermisosRol -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ObtenerPermisosRolPorId(ProfileRequestDto);
                Log.Information("RolController/ObtenerPermisosRol -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }
        [HttpPost("ActualizarPermisosRol")]
        [ProducesResponseType(200, Type = typeof(CreacionEdicionRolResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EdicionPermisosRolResponse> ActualizarPermisosRol([FromBody] EdicionPermisosRolRequest ProfileRequestDto)
        {
            EdicionPermisosRolResponse response = new();
            EdicionPermisosRolValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ActualizarPermisosRol: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ActualizarPermisosRol -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ActualizarPermisosRol(ProfileRequestDto);
                Log.Information("RolController/ActualizarPermisosRol -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ListarRolesReporte")]
        [ProducesResponseType(200, Type = typeof(ListaRolesReporteResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaRolesReporteResponse> ListarRolesReporte([FromBody] ListaRolesReporteRequest ProfileRequestDto)
        {
            ListaRolesReporteResponse response = new();
            ListaRolesReporteValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ListarRolesReporte: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ListarRolesReporte -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ListarRolesReporte(ProfileRequestDto);
                Log.Information("RolController/ListarRolesReporte -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ListarRolesUsuario")]
        [ProducesResponseType(200, Type = typeof(ListaRolesResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaRolesUsuarioResponse> ListarRolesUsuario([FromBody] ListaRolesRequest ProfileRequestDto)
        {
            ListaRolesUsuarioResponse response = new();
            ListaRolesValidator validator = new();
            ValidationResult validationResults = validator.Validate(ProfileRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("RolController/ListarRolesUsuario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    ProfileRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("RolController/ListarRolesUsuario -> Request: " + JsonConvert.SerializeObject(ProfileRequestDto));
                response = _clRepository.ListarRolesUsuario(ProfileRequestDto);
                Log.Information("RolController/ListarRolesUsuario -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }
    }
}
