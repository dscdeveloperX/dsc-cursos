﻿using FluentValidation.Results;
using icCommon.Utils;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DTOs.API.Request.Auditoria;
using icSeguridad.DTOs.API.Response.Auditoria;
using icSeguridad.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace icSeguridad.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/seguridad/auditoria")]
    [ApiController]
    [Authorize]
    public class AuditoriaController : ControllerBase
    {
        private readonly IAuditoriaBLL _clRepository;
        public AuditoriaController(IAuditoriaBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ConsultaAuditoriaResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaAuditoriaResponse> ListarAuditoria([FromBody] ConsultaAuditoriaRequest applicationRequestDto)
        {
            ConsultaAuditoriaResponse response = new();
            ConsultaAuditoriaValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AuditoriaController/ListarAuditoria: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AuditoriaController/ListarAuditoria -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.ListarAuditoria(applicationRequestDto);
                Log.Information("AuditoriaController/ListarAuditoria -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }
    }
}
