﻿using FluentValidation.Results;
using icCommon.Utils;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DTOs.API.Request.Catalogos;
using icSeguridad.DTOs.API.Response;
using icSeguridad.DTOs.API.Response.Catalogos;
using icSeguridad.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;

namespace icSeguridad.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/seguridad/catalogos")]
    [ApiController]
    [Authorize]
    public class CatalogoController : ControllerBase
    {
        private readonly ICatalogoBLL _clRepository;
        public CatalogoController(ICatalogoBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaCatalogosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaCatalogosResponse> ListarCatalogos([FromBody] ListaCatalogosRequest catalogueRequestDto)
        {
            ListaCatalogosResponse response = new();
            ListaCatalogosValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ListarCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("CatalogoController/ListarCatalogos -> Request: " + JsonConvert.SerializeObject(catalogueRequestDto));
                response = _clRepository.ListarCatalogos(catalogueRequestDto);
                Log.Information("CatalogoController/ListarCatalogos -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("ListarNombres")]
        [ProducesResponseType(200, Type = typeof(ListaNombreCatalogosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaNombreCatalogosResponse> ListarNombresCatalogos([FromBody] ListaNombreCatalogosRequest catalogueRequestDto)
        {
            ListaNombreCatalogosResponse response = new();
            ListaNombreCatalogosValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ListarNombresCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("CatalogoController/ListarNombresCatalogos -> Request: " + JsonConvert.SerializeObject(catalogueRequestDto));
                response = _clRepository.ListarNombresCatalogos(catalogueRequestDto);
                Log.Information("CatalogoController/ListarNombresCatalogos -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaCatalogoResponse> ObtenerCatalogoPorId([FromBody] ConsultaCatalogoRequest catalogueRequestDto)
        {
            ConsultaCatalogoResponse response = new();
            ConsultaCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ObtenerCatalogoPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("CatalogoController/ObtenerCatalogoPorId -> Request: " + JsonConvert.SerializeObject(catalogueRequestDto));
                response = _clRepository.ObtenerCatalogoPorId(catalogueRequestDto);
                Log.Information("CatalogoController/ObtenerCatalogoPorId -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("Crear")]
        [ProducesResponseType(200, Type = typeof(CreacionCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionCatalogoResponse> CrearCatalogos([FromBody] CreacionCatalogoRequest catalogueRequestDto)
        {
            CreacionCatalogoResponse response = new();
            CreacionCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/CrearCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("CatalogoController/CrearCatalogos -> Request: " + JsonConvert.SerializeObject(catalogueRequestDto));
                response = _clRepository.CrearCatalogo(catalogueRequestDto);
                Log.Information("CatalogoController/CrearCatalogos -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Eliminar")]
        [ProducesResponseType(200, Type = typeof(EliminacionCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EliminacionCatalogoResponse> EliminarCatalogos([FromBody] EliminacionCatalogoRequest catalogueRequestDto)
        {
            EliminacionCatalogoResponse response = new();
            EliminacionCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/EliminarCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("CatalogoController/EliminarCatalogos -> Request: " + JsonConvert.SerializeObject(catalogueRequestDto));
                response = _clRepository.EliminarCatalogo(catalogueRequestDto);
                Log.Information("CatalogoController/EliminarCatalogos -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Actualizar")]
        [ProducesResponseType(200, Type = typeof(EdicionCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EdicionCatalogoResponse> ActualizarCatalogo([FromBody] EdicionCatalogoRequest catalogueRequestDto)
        {
            EdicionCatalogoResponse response = new();
            EdicionCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ActualizarCatalogo: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("CatalogoController/ActualizarCatalogo -> Request: " + JsonConvert.SerializeObject(catalogueRequestDto));
                response = _clRepository.ActualizarCatalogo(catalogueRequestDto);
                Log.Information("CatalogoController/ActualizarCatalogo -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }
    }
}
