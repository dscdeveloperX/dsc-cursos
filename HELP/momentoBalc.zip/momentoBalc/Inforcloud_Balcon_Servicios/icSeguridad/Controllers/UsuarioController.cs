﻿using FluentValidation.Results;
using icAuth.DLL.Interfaces;
using icCommon.ManejoErrores.Utils;
using icCommon.Utils;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DTOs.API.Request.Usuarios;
using icSeguridad.DTOs.API.Response;
using icSeguridad.DTOs.API.Response.Usuarios;
using icSeguridad.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;

namespace icSeguridad.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/seguridad/usuarios")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioBLL _clRepository;
        private readonly IGeneradorToken _tokenGenerator;
        public UsuarioController(IUsuarioBLL dRepository, IGeneradorToken tokenGenerator)
        {
            _clRepository = dRepository;
            _tokenGenerator = tokenGenerator;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaUsuariosResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ListaUsuariosResponse> ListarUsuarios([FromBody] ListaUsuariosRequest UserRequestDto)
        {
            ListaUsuariosResponse response = new();
            ListaUsuariosValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ListarUsuarios: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ListarUsuarios -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ListarUsuarios(UserRequestDto);
                Log.Information("UsuarioController/ListarUsuarios -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ConsultaUsuarioResponse> ObtenerUsuarioPorId([FromBody] ConsultaUsuarioRequest UserRequestDto)
        {
            ConsultaUsuarioResponse response = new();
            ConsultaUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ObtenerUsuarioPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ObtenerUsuarioPorId -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ObtenerUsuarioPorId(UserRequestDto);
                Log.Information("UsuarioController/ObtenerUsuarioPorId -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Crear")]
        [ProducesResponseType(200, Type = typeof(CreacionEdicionUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<CreacionEdicionUsuarioResponse> CrearUsuario([FromBody] CreacionUsuarioRequest UserRequestDto)
        {
            CreacionEdicionUsuarioResponse response = new();
            CreacionUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/CrearUsuario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/CrearUsuario -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.CrearUsuarios(UserRequestDto);
                Log.Information("UsuarioController/CrearUsuario -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Eliminar")]
        [ProducesResponseType(200, Type = typeof(EliminacionUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<EliminacionUsuarioResponse> EliminarUsuarios([FromBody] EliminacionUsuarioRequest UserRequestDto)
        {
            EliminacionUsuarioResponse response = new();
            EliminacionUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/EliminarUsuarios: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/EliminarUsuarios -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.EliminarUsuarios(UserRequestDto);
                Log.Information("UsuarioController/EliminarUsuarios -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Actualizar")]
        [ProducesResponseType(200, Type = typeof(CreacionEdicionUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<CreacionEdicionUsuarioResponse> ActualizarUsuario([FromBody] CreacionUsuarioRequest UserRequestDto)
        {
            CreacionEdicionUsuarioResponse response = new();
            CreacionUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ActualizarUsuario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ActualizarUsuarios -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ActualizarUsuarios(UserRequestDto);
                Log.Information("UsuarioController/ActualizarUsuarios -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Activar")]
        [ProducesResponseType(200, Type = typeof(ActivacionUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ActivacionUsuarioResponse> ActivarUsuarios([FromBody] ActivacionUsuarioRequest UserRequestDto)
        {
            ActivacionUsuarioResponse response = new();
            ActivacionUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ActivarUsuarios: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ActivarUsuarios -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ActivarUsuario(UserRequestDto);
                Log.Information("UsuarioController/ActivarUsuarios -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Inactivar")]
        [ProducesResponseType(200, Type = typeof(InactivacionUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<InactivacionUsuarioResponse> InactivarUsuarios([FromBody] InactivacionUsuarioRequest UserRequestDto)
        {
            InactivacionUsuarioResponse response = new();
            InactivacionUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/InactivarUsuarios: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/InactivarUsuarios -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.InactivarUsuario(UserRequestDto);
                Log.Information("UsuarioController/InactivarUsuarios -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ConsultarRolUsuario")]
        [ProducesResponseType(200, Type = typeof(ConsultaRolesUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ConsultaRolesUsuarioResponse> ConsultarRolesUsuario([FromBody] ConsultaRolesUsuarioRequest UserRequestDto)
        {
            ConsultaRolesUsuarioResponse response = new();
            ConsultaRolesUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ConsultarRolesUsuario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ConsultarRolesUsuario -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ConsultarRolesUsuario(UserRequestDto);
                Log.Information("UsuarioController/ConsultarRolesUsuario -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ActualizarRolUsuario")]
        [ProducesResponseType(200, Type = typeof(ActualizarRolesUsuarioResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ActualizarRolesUsuarioResponse> ActualizarRolesUsuario([FromBody] ActualizarRolesUsuarioRequest UserRequestDto)
        {
            ActualizarRolesUsuarioResponse response = new();
            ActualizarRolesUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ActualizarRolesUsuario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = ErrorUtil.GetErrorValidationMessage(validationResults.Errors);
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ActualizarRolesUsuario -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ActualizarRolesUsuario(UserRequestDto);
                Log.Information("UsuarioController/ActualizarRolesUsuario -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ActualizarClave")]
        [ProducesResponseType(200, Type = typeof(ActualizarClaveResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ActualizarClaveResponse> ActualizarClave([FromBody] ActualizarClaveRequest UserRequestDto)
        {
            ActualizarClaveResponse response = new();
            ActualizarClaveValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ActualizarClave: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ActualizarClave -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ActualizarClave(UserRequestDto);
                Log.Information("UsuarioController/ActualizarClave -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ComprobarComplejidadClave")]
        [ProducesResponseType(200, Type = typeof(ComprobarComplejidadClaveResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ComprobarComplejidadClaveResponse> ComprobarComplejidadClave([FromBody] ComprobarComplejidadClaveRequest UserRequestDto)
        {
            ComprobarComplejidadClaveResponse response = new();
            ComprobarComplejidadClaveValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ComprobarComplejidadClave: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ComprobarComplejidadClave -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ComprobarComplejidadClave(UserRequestDto);
                Log.Information("UsuarioController/ComprobarComplejidadClave -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("ConsultarDataUsuario")]
        [ProducesResponseType(200, Type = typeof(ComprobarComplejidadClaveResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ConsultarDataUsuarioResponse> ConsultarDataUsuario([FromBody] ConsultarDataUsuarioRequest UserRequestDto)
        {
            ConsultarDataUsuarioResponse response = new();
            ConsultarDataUsuarioValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ConsultarDataUsuario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ConsultarDataUsuario -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ConsultarDataUsuario(UserRequestDto);
                Log.Information("UsuarioController/ConsultarDataUsuario -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }

        [HttpPost("Autenticar")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [AllowAnonymous]
        public ActionResult<AutenticacionUsuarioResponse> AuthPerfilUsuario([FromBody] AutenticacionUsuarioRequest userRequestDto)
        {
            AutenticacionUsuarioResponse response = new AutenticacionUsuarioResponse();
            AutenticacionUsuarioValidator validator = new AutenticacionUsuarioValidator();
            ValidationResult validationResults = validator.Validate(userRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/AuthPerfilUsuario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    userRequestDto.HeaderRequest.StationIp = clientIp;
                }
                

                Log.Information("UsuarioController/AuthPerfilUsuario -> Request: {Usuario:" + userRequestDto.BodyRequest.Usuario + ", Aplicacion: " + userRequestDto.BodyRequest.Aplicacion.ToString() + "}");
                response = _clRepository.ObtenerPerfilUsuario(userRequestDto);
                if (response == null || response.BodyResponse == null || response.BodyResponse.Usuario == null 
                    || string.IsNullOrEmpty(response.BodyResponse.Usuario.Usuario))
                {
                    Log.Error("UsuarioController/AuthPerfilUsuario: Unauthorized");
                    return Unauthorized(response);
                }
                string token = _tokenGenerator.GenerarJwtToken(out DateTime expireDate);
                response.BodyResponse.Token = token;
                response.BodyResponse.FechaExpiracion = expireDate;

                Log.Information("UsuarioController/AuthPerfilUsuario -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }



        [HttpPost]
        [Route("GenerarJWT")]
        //[ResponseType(typeof(AuthResponse))]
        [AllowAnonymous]
        //[ICControllerExceptionFilter]
        public IActionResult GenerarJWT([FromBody] AuthRequest request)
        {
            AuthResponse response = new AuthResponse();
            AuthValidator validator = new AuthValidator();
            //para mantener formato original AuthCanal
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/GenerarJWT: INVALID REQUEST");
                response.Mensaje = "Solicitud no válida";
                return BadRequest(response);


            }
            else
            {
                //DateTime expireDate = DateTime.UtcNow.AddMinutes(Convert.ToInt32(12));

                //string token = TokenGenerator.GenerarJwtToken(request.AppKey, out DateTime expireDate);
                string token = _tokenGenerator.GenerarJwtToken(request.AppCanal, out DateTime expireDate);//dsc

                if (string.IsNullOrEmpty(token))
                {
                    Log.Error("UsuarioController/GenerarJWT: Unauthorized");
                    response.Mensaje = "Key no válida";
                    //return Request.CreateResponse(HttpStatusCode.Unauthorized, response);
                    return Unauthorized(response);
                }

                response.Token = token;
                response.ExpirationDate = expireDate;
                response.Mensaje = "OK";
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("UsuarioController/GenerarJWT -> Response: " + resStr);

                return Ok(response);
            }
        }





        [HttpPost("ListarUsuarioReporte")]
        [ProducesResponseType(200, Type = typeof(ListaUsuariosReporteResponse))]
        [ProducesResponseType(400)]
        [Authorize]
        public ActionResult<ListaUsuariosReporteResponse> ListarUsuarioReporte([FromBody] ListaUsuariosReporteRequest UserRequestDto)
        {
            ListaUsuariosReporteResponse response = new();
            ListaUsuariosReporteValidator validator = new();
            ValidationResult validationResults = validator.Validate(UserRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("UsuarioController/ListarUsuarioReporte: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    UserRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("UsuarioController/ListarUsuarioReporte -> Request: " + JsonConvert.SerializeObject(UserRequestDto));
                response = _clRepository.ListarUsuariosReporte(UserRequestDto);
                Log.Information("UsuarioController/ListarUsuarioReporte -> Response: " + JsonConvert.SerializeObject(response));

                return Ok(response);
            }
        }
    }
}
