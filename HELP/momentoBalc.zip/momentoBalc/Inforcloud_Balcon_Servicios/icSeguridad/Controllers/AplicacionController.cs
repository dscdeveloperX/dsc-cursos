﻿using FluentValidation.Results;
using icCommon.Utils;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DTOs.API.Request.Aplicaciones;
using icSeguridad.DTOs.API.Response.Aplicaciones;
using icSeguridad.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace icSeguridad.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/seguridad/aplicaciones")]
    [ApiController]
    [Authorize]
    public class AplicacionController : ControllerBase
    {
        private readonly IAplicacionBLL _clRepository;
        public AplicacionController(IAplicacionBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaAplicacionResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaAplicacionResponse> ListarAplicaciones([FromBody] ListaAplicacionesRequest applicationRequestDto)
        {
            ListaAplicacionResponse response = new();
            ListaAplicacionesValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AplicacionController/ListarAplicaciones: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AplicacionController/ListarAplicaciones -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.ListarAplicaciones(applicationRequestDto);
                Log.Information("AplicacionController/ListarAplicaciones -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaAplicacionResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaAplicacionResponse> ObtenerAplicacionPorId([FromBody] ConsultaAplicacionRequest applicationRequestDto)
        {
            ConsultaAplicacionResponse response = new();
            ConsultaAplicacionValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AplicacionController/ObtenerAplicacionPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AplicacionController/ObtenerAplicacionPorId -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.ObtenerAplicacionPorId(applicationRequestDto);
                Log.Information("AplicacionController/ObtenerAplicacionPorId -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("Crear")]
        [ProducesResponseType(200, Type = typeof(CreacionEdicionAplicacionResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionEdicionAplicacionResponse> CrearAplicacion([FromBody] CreacionAplicacionRequest applicationRequestDto)
        {
            CreacionEdicionAplicacionResponse response = new();
            CreacionAplicacionValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AplicacionController/CrearAplicacion: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AplicacionController/CrearAplicacion -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.CrearAplicacion(applicationRequestDto);
                Log.Information("AplicacionController/CrearAplicacion -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("Eliminar")]
        [ProducesResponseType(200, Type = typeof(EliminacionAplicacioneResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EliminacionAplicacioneResponse> EliminarAplicaciones([FromBody] EliminacionAplicacionRequest applicationRequestDto)
        {
            EliminacionAplicacioneResponse response = new();
            EliminacionAplicacionValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AplicacionController/EliminarAplicaciones: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AplicacionController/EliminarAplicacion -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.EliminarAplicacion(applicationRequestDto);
                Log.Information("AplicacionController/EliminarAplicacion -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("Actualizar")]
        [ProducesResponseType(200, Type = typeof(CreacionEdicionAplicacionResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionEdicionAplicacionResponse> ActualizarAplicacion([FromBody] CreacionAplicacionRequest applicationRequestDto)
        {
            CreacionEdicionAplicacionResponse response = new();
            CreacionAplicacionValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AplicacionController/ActualizarAplicacion: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AplicacionController/ActualizarAplicacion -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.ActualizarAplicacion(applicationRequestDto);
                Log.Information("AplicacionController/ActualizarAplicacion -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("Activar")]
        [ProducesResponseType(200, Type = typeof(ActivacionAplicacionResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ActivacionAplicacionResponse> ActivarAplicaciones([FromBody] ActivacionAplicacionRequest applicationRequestDto)
        {
            ActivacionAplicacionResponse response = new();
            ActivacionAplicacionValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AplicacionController/ActivarAplicaciones: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AplicacionController/ActivarAplicaciones -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.ActivarAplicacion(applicationRequestDto);
                Log.Information("AplicacionController/ActivarAplicaciones -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }

        [HttpPost("Inactivar")]
        [ProducesResponseType(200, Type = typeof(InactivacionAplicacionResponse))]
        [ProducesResponseType(400)]
        public ActionResult<InactivacionAplicacionResponse> InactivarAplicaciones([FromBody] InactivacionAplicacionRequest applicationRequestDto)
        {
            InactivacionAplicacionResponse response = new();
            InactivacionAplicacionValidator validator = new();
            ValidationResult validationResults = validator.Validate(applicationRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AplicacionController/InactivarAplicaciones: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    applicationRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("AplicacionController/InactivarAplicaciones -> Request: " + JsonConvert.SerializeObject(applicationRequestDto));
                response = _clRepository.InactivarAplicacion(applicationRequestDto);
                Log.Information("AplicacionController/InactivarAplicaciones -> Response: " + JsonConvert.SerializeObject(response));
                return Ok(response);
            }
        }
    }
}
