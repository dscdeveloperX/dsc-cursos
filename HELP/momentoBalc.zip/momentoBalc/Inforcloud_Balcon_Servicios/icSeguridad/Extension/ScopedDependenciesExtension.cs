﻿using icCommon.Extensiones;
using icSeguridad.BLL;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DLL;
using icSeguridad.DLL.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace icSeguridad.Extension
{
    public static class ScopedDependenciesExtension
    {
        public static void AddInforcloudScopedDependencies(this IServiceCollection services)
        {
            #region Agregar DLL Helpers
            services.AddScoped<IAplicacionDLL, AplicacionDLL>();            
            services.AddScoped<ICatalogoDLL, CatalogoDLL>();
            services.AddScoped<IRolDLL, RolDLL>();
            services.AddScoped<IUsuarioDLL, UsuarioDLL>();
            #endregion

            #region Agregar BLL Repositories
            services.AddScoped<IAplicacionBLL, AplicacionBLL>();
            services.AddScoped<ICatalogoBLL, CatalogoBLL>();
            services.AddScoped<IRolBLL, RolBLL>();
            services.AddScoped<IUsuarioBLL, UsuarioBLL>();
            services.AddScoped<IAuditoriaBLL, AuditoriaBLL>();
            #endregion

            services.AddScoped<IConectorBancoBLL, ConectorBancoBLL>();

            services.AddInforcloudCommonUse();
            services.AddInforcloudExternalConnector<ConectorApiBLL>();
        }
    }
}
