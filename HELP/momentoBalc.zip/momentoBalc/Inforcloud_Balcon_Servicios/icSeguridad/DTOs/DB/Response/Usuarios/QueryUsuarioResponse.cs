﻿using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Usuarios
{
    public class QueryUsuarioResponse
    {
        public List<Usuario> Usuarios { get; set; }
        public int Total { get; set; }
    }
}
