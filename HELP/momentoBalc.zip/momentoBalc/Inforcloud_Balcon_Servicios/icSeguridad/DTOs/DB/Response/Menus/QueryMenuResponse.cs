﻿using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Menus
{
    public class QueryMenuResponse
    {
        public List<Menu> Menus { get; set; }
        public int Total { get; set; }
    }
}
