﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Roles
{
    public class QueryRolesReporteResponse
    {
        public List<RolReporte> Roles { get; set; }
        public int Total { get; set; }
    }

    public class RolReporte
    {
        public string Rol { get; set; }
        public string Nombre { get; set; }
        public string Permiso { get; set; }
        public string Estado { get; set; }
    }
}
