﻿using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Catalogos
{
    public class QueryCatalogosResponse
    {
        public List<Catalogo> Catalogos { get; set; }
        public int Total { get; set; }
    }
}
