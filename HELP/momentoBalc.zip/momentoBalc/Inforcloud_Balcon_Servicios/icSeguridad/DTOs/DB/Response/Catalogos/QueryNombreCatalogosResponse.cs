﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Catalogos
{
    public class QueryNombreCatalogosResponse
    {
        public List<string> NombreCatalogos { get; set; }
        public int Total { get; set; }
    }
}
