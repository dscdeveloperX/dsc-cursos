﻿using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Roles
{
    public class QueryRolesResponse
    {
        public List<RolDto> Roles { get; set; }
        public int Total { get; set; }
    }

    public class QueryRolesUsuarioResponse
    {
        public List<RolUsuarioDto> Roles { get; set; }
        public int Total { get; set; }
    }
}
