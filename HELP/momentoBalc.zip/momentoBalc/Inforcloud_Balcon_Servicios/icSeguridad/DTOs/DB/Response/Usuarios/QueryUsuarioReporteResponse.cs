﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Usuarios
{
    public class QueryUsuarioReporteResponse
    {
        public List<UsuarioReporte> Usuarios { get; set; }
        public int Total { get; set; }
    }

    public class UsuarioReporte 
    { 
        public string Nombre { get; set; }
        public string Usuario { get; set; }
        public string Cedula { get; set; }
        public string Estado { get; set; }
        public string Rol { get; set; }
        public string EstadoRol { get; set; }
        public string Cargo { get; set; }
        public string Email { get; set; }
    }
}
