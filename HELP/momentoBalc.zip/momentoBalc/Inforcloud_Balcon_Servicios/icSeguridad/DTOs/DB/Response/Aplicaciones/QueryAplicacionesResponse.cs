﻿using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.DB.Response.Aplicaciones
{
    public class QueryAplicacionesResponse
    {
        public List<Aplicacion> Aplicaciones { get; set; }
        public int Total { get; set; }
    }
}
