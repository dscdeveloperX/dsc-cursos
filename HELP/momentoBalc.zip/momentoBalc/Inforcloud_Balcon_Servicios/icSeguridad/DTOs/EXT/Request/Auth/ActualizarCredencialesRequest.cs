﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icSeguridad.DTOs.EXT.Request.Auth
{
    public class ActualizarCredencialesRequest
    {
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<ActualizarCredencialesRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }

            public override Envelope Clean(Envelope t)
            {
                Envelope e = base.Clean(t);
				e.Body.ActualizarCredenciales.CredencialesActualizadas.ClaveVieja = new string('*', e.Body.ActualizarCredenciales.CredencialesActualizadas.ClaveVieja.Length);
				e.Body.ActualizarCredenciales.CredencialesActualizadas.ClaveNueva = new string('*', e.Body.ActualizarCredenciales.CredencialesActualizadas.ClaveNueva.Length);
				return e;
			}
        }

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public ActualizarCredenciales ActualizarCredenciales { get; set; }
		}

		public class ActualizarCredenciales
		{
			[XmlElement(elementName: Constantes.ElementTag.CredencialesActualizadas, Namespace = Constantes.XmlNamespace.Tem)]
			public CredencialesActualizadas CredencialesActualizadas { get; set; }
		}

		public class CredencialesActualizadas
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
			public string ClaveNueva { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
			public string ClaveVieja { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
			public string Usuario { get; set; }
		}
	}
}
