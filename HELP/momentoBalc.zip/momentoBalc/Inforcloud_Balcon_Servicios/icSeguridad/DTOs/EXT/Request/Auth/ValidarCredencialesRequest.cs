﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icSeguridad.DTOs.EXT.Request.Auth
{
    public class ValidarCredencialesRequest
    {
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<ValidarCredencialesRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }

            public override Envelope Clean(Envelope t)
            {
				Envelope e = base.Clean(t);
				e.Body.ValidarCredenciales.Credenciales.Clave = new string('*', e.Body.ValidarCredenciales.Credenciales.Clave.Length);
				return e;
            }
        }

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public ValidarCredenciales ValidarCredenciales { get; set; }
		}

		public class ValidarCredenciales
		{
			[XmlElement(elementName: Constantes.ElementTag.Credenciales, Namespace = Constantes.XmlNamespace.Tem)]
			public Credenciales Credenciales { get; set; }
		}

		public class Credenciales
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
			public string Clave { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
			public string Usuario { get; set; }
		}
	}
}
