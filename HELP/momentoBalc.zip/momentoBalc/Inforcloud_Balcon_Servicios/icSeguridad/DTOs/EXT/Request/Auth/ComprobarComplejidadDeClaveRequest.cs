﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icSeguridad.DTOs.EXT.Request.Auth
{
    public class ComprobarComplejidadDeClaveRequest
    {
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<ComprobarComplejidadDeClaveRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }

			public override Envelope Clean(Envelope t)
			{
				Envelope e = base.Clean(t);
				e.Body.ComprobarComplejidadDeClave.Credenciales.Clave = new string('*', e.Body.ComprobarComplejidadDeClave.Credenciales.Clave.Length);
				return e;
			}
		}

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public ComprobarComplejidadDeClave ComprobarComplejidadDeClave { get; set; }
		}

		public class ComprobarComplejidadDeClave
		{
			[XmlElement(elementName: Constantes.ElementTag.Credenciales, Namespace = Constantes.XmlNamespace.Tem)]
			public Credenciales Credenciales { get; set; }
		}

		public class Credenciales
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
			public string Clave { get; set; }
		}
	}
}
