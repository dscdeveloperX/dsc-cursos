﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icSeguridad.DTOs.EXT.Request.Auth
{
    public class ConsultarUsuarioRequest
    {
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<ConsultarUsuarioRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }
		}

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public ConsultarUsuario ConsultarUsuario { get; set; }
		}

		public class ConsultarUsuario
		{
			[XmlElement(elementName: Constantes.ElementTag.Usuario, Namespace = Constantes.XmlNamespace.Tem)]
			public Credenciales Usuario { get; set; }
		}

		public class Credenciales
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
			public string Usuario { get; set; }
		}
	}
}
