﻿using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icSeguridad.DTOs.EXT.Response.Auth
{
    public class ActualizarCredencialesResponse
    {
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ActualizarCredencialesResponseDto ActualizarCredencialesResponse { get; set; }
        }
        public class ActualizarCredencialesResponseDto : ApiExternoResponse<ActualizarCredencialesResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public bool ActualizarCredencialesResult { get; set; }
            public MensajeAuth Mensaje { get; set; }

            public override ActualizarCredencialesResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList consultaResponse = soap.GetElementsByTagName("ActualizarCredencialesResponse", Constantes.XmlNamespace.Tem);

                if (consultaResponse.Count > 0)
                {
                    XmlNode consultaNode = consultaResponse.Item(0);
                    bool result = false;
                    if (consultaNode != null) result = true;

                    ActualizarCredencialesResponseDto respuestaExterno = new ActualizarCredencialesResponseDto
                    {
                        ActualizarCredencialesResult = result,
                        Mensaje = new MensajeAuth()
                    };

                    return respuestaExterno;
                }
                else
                {
                    return new ActualizarCredencialesResponseDto
                    {
                        Mensaje = new MensajeAuth(soap)
                    };
                }
            }
        }
    }
}
