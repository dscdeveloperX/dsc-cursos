﻿using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icSeguridad.DTOs.EXT.Response.Auth
{
    public class ValidarCredencialesResponse
    {
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ValidarCredencialesResponseDto ValidarCredencialesResponse { get; set; }
        }
        public class ValidarCredencialesResponseDto : ApiExternoResponse<ValidarCredencialesResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public bool ValidarCredencialesResult { get; set; }
            public MensajeAuth Mensaje { get; set; }

            public override ValidarCredencialesResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList consultaResponse = soap.GetElementsByTagName("ValidarCredencialesResult", Constantes.XmlNamespace.Tem);
                if (consultaResponse.Count > 0)
                {
                    XmlNode consultaNode = consultaResponse.Item(0);
                    bool result = false;
                    if (consultaNode != null) result = consultaNode.InnerText.Trim() == "true";

                    ValidarCredencialesResponseDto respuestaExterno = new ValidarCredencialesResponseDto
                    {
                        ValidarCredencialesResult = result,
                        Mensaje = new MensajeAuth()
                    };

                    return respuestaExterno;
                }
                else 
                {                    
                    return new ValidarCredencialesResponseDto
                    {
                        Mensaje = new MensajeAuth(soap)
                    };
                }
            }
        }
    }
}
