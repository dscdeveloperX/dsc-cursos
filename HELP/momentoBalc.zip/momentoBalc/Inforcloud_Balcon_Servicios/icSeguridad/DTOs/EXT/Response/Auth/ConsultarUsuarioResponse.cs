﻿using icCommon.DTOs.EXT;
using icCommon.Utils;
using System;
using System.Xml;
using System.Xml.Serialization;

namespace icSeguridad.DTOs.EXT.Response.Auth
{
    public class ConsultarUsuarioResponse
    {
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ConsultarUsuarioResponseDto ConsultarUsuarioResponse { get; set; }
        }
        public class ConsultarUsuarioResponseDto : ApiExternoResponse<ConsultarUsuarioResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ConsultarUsuarioResult ConsultarUsuarioResult { get; set; }

            public MensajeAuth Mensaje { get; set; }

            public override ConsultarUsuarioResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList consultaResponse = soap.GetElementsByTagName("ConsultarUsuarioResponse", Constantes.XmlNamespace.Tem);

                if (consultaResponse.Count > 0)
                {
                    XmlNode consultaNode = consultaResponse.Item(0);
                    string xmlInput = SerializadorXmlSoap.ObtenerXMLLimpio(consultaNode);

                    ConsultarUsuarioResult respuestaExterno = SerializadorXmlSoap.DeserializarObjeto<ConsultarUsuarioResult>(xmlInput);

                    return new ConsultarUsuarioResponseDto
                    {
                        ConsultarUsuarioResult = respuestaExterno,
                        Mensaje = new MensajeAuth()
                    };
                }
                else 
                {
                    return new ConsultarUsuarioResponseDto
                    {
                        Mensaje = new MensajeAuth(soap)
                    };
                }
                
            }
        }

        public class ConsultarUsuarioResult 
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
            public string Agencia { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
            public bool Bloqueado { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
            public string Cedula { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
            public string Nombre { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
            public string UltimoLogin { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
            public string UltimoLoginFallido { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Ser)]
            public string Usuario { get; set; }
        }
    }
}
