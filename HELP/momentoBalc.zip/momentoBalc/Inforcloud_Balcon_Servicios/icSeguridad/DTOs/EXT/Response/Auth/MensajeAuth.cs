﻿using System.Xml;

namespace icSeguridad.DTOs.EXT.Response.Auth
{
    public class MensajeAuth
    {
        public string Codigo { get; set; }
        public string Mensaje { get; set; }

        public MensajeAuth() {
            Codigo = icCommon.Utils.Constantes.MappingCode.EXITO;
            Mensaje = icCommon.Utils.Constantes.MappingCode.EXITO;
        }

        public MensajeAuth(XmlDocument xmlDocument)
        {
            XmlNodeList errorResponse = xmlDocument.GetElementsByTagName("AuroFault", Constantes.XmlNamespace.Ser);
            XmlNode? consultaNode = errorResponse.Item(0);

            string? codigo = null;
            string? mensaje = null;

            if (consultaNode != null && consultaNode.ChildNodes.Count > 0) {
                codigo = consultaNode.ChildNodes.Item(0)?.InnerText;
                mensaje = consultaNode.ChildNodes.Item(1)?.InnerText;
            }            

            this.Codigo = codigo == null ? "ErrorGeneral" : codigo;
            this.Mensaje = mensaje == null ? "Error General" : mensaje;
        }
    }
}
