﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Roles
{
    public class AsignacionMenuRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public AsignacionMenuRolRequestBody BodyRequest { get; set; }
    }
    public class AsignacionMenuRolRequestBody
    {
        public long RolId { get; set; }
        public List<long> MenuIds { get; set; }
    }
}
