﻿namespace icSeguridad.DTOs.API.Request.Catalogos
{
    public class ConsultaCatalogoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaCatalogoRequestBody BodyRequest { get; set; }
    }
    public class ConsultaCatalogoRequestBody
    {
        public long CatalogoId { get; set; }
    }
}
