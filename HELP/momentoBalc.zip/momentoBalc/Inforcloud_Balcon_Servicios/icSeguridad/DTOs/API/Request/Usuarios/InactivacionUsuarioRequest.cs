﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class InactivacionUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public InactivacionUsuarioRequestBody BodyRequest { get; set; }
    }
    public class InactivacionUsuarioRequestBody
    {
        public List<long> UsuariosIds { get; set; }
    }
}
