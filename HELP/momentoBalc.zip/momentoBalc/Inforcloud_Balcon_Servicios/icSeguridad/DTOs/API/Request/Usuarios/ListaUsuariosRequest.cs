﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ListaUsuariosRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaUsuariosRequestBody BodyRequest { get; set; }
    }
    public class ListaUsuariosRequestBody
    {
        public string Estado { get; set; }
        public string OrdenarPor { get; set; }
        public bool OrdenDesc { get; set; }
        public string FiltrarPor { get; set; }
        public string ValorFiltro { get; set; }
    }
}
