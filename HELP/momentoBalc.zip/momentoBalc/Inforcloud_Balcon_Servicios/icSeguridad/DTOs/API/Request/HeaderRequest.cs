﻿using System;

namespace icSeguridad.DTOs.API.Request
{
    public class HeaderRequest
    {
        public string UserName { get; set; }
        public string StationIp { get; set; }
        public DateTime DateTime { get; set; }
        public int PageSize { get; set; }
        public int PageRequested { get; set; }
    }
}
