﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Aplicaciones
{
    public class ActivacionAplicacionRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ActivacionAplicacionRequestBody BodyRequest { get; set; }
    }
    public class ActivacionAplicacionRequestBody
    {
        public List<long> AplicacionesIds { get; set; }
    }
}
