﻿using System;

namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ActualizarRolesUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ActualizarRolesUsuarioRequestBody BodyRequest { get; set; }
    }
    public class ActualizarRolesUsuarioRequestBody
    {
        public long UsuarioId { get; set; }
        public long AplicacionId { get; set; }
        public long RolPrincipalId { get; set; }
        public AsignacionRol RolTemporal { get; set; }

    }

    public class AsignacionRol { 
        public long RolId { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaVencimiento { get; set; }
    }
}
