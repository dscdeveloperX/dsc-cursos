﻿using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Request.Aplicaciones
{
    public class CreacionAplicacionRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionAplicacionRequestBody BodyRequest { get; set; }
    }
    public class CreacionAplicacionRequestBody
    {
        public AplicacionDto Aplicacion { get; set; }

    }
}
