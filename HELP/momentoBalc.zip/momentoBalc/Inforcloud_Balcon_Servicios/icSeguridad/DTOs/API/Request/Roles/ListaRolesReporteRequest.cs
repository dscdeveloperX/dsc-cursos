﻿namespace icSeguridad.DTOs.API.Request.Roles
{
    public class ListaRolesReporteRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaRolesReporteRequestBody BodyRequest { get; set; }
    }
    public class ListaRolesReporteRequestBody
    {
        public long AplicacionId { get; set; }
        public string Estado { get; set; }
    }
}
