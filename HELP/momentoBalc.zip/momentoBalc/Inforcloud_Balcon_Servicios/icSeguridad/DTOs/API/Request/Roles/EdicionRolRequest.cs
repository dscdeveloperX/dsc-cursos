﻿using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Request.Roles
{
    public class EdicionRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionRolRequestBody BodyRequest { get; set; }
    }
    public class EdicionRolRequestBody
    {
        public Rol Rol { get; set; }
    }
}
