﻿namespace icSeguridad.DTOs.API.Request.Aplicaciones
{
    public class EdicionAplicacionRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionAplicacionRequestBody BodyRequest { get; set; }
    }
    public class EdicionAplicacionRequestBody
    {
        public long AplicacionId { get; set; }
        public string Nombre { get; set; }
    }
}
