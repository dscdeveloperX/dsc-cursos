﻿namespace icSeguridad.DTOs.API.Request.Catalogos
{
    public class ListaCatalogosRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaCatalogosRequestBody BodyRequest { get; set; }
    }
    public class ListaCatalogosRequestBody
    {
        public string NombreCatalogo { get; set; }
        public string Estado { get; set; }
        public string OrdenarPor { get; set; }
        public bool OrdenDesc { get; set; }
        public string FiltrarPor { get; set; }
        public string ValorFiltro { get; set; }
    }
}
