﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ConsultaUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaUsuarioRequestBody BodyRequest { get; set; }
    }
    public class ConsultaUsuarioRequestBody
    {
        public long UsuarioId { get; set; }
    }
}
