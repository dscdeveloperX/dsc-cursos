﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Aplicaciones
{
    public class InactivacionAplicacionRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public InactivacionAplicacionRequestBody BodyRequest { get; set; }
    }
    public class InactivacionAplicacionRequestBody
    {
        public List<long> AplicacionesIds { get; set; }
    }
}
