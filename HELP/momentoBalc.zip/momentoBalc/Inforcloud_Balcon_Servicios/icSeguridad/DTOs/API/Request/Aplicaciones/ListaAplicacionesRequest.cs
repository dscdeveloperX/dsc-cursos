﻿namespace icSeguridad.DTOs.API.Request.Aplicaciones
{
    public class ListaAplicacionesRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaAplicacionesRequestBody BodyRequest { get; set; }
    }
    public class ListaAplicacionesRequestBody
    {
        public string Estado { get; set; }
        public string OrdenarPor { get; set; }
        public bool OrdenDesc { get; set; }
        public string FiltrarPor { get; set; }
        public string ValorFiltro { get; set; }
    }
}
