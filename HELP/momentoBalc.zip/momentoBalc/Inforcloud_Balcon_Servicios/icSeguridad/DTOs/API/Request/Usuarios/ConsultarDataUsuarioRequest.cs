﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ConsultarDataUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultarDataUsuarioRequestBody BodyRequest { get; set; }
    }
    public class ConsultarDataUsuarioRequestBody
    {
        public string Usuario { get; set; }
    }
}
