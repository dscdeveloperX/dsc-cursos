﻿using System;

namespace icSeguridad.DTOs.API.Request.Auditoria
{
    public class ConsultaAuditoriaRequest 
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaAuditoriaRequestBody BodyRequest { get; set; }
    }
    public class ConsultaAuditoriaRequestBody
    {
        public string Usuario { get; set; }
        public DateTime FechaDesde { get; set; }
        public DateTime FechaHasta { get; set; }
    }
}
