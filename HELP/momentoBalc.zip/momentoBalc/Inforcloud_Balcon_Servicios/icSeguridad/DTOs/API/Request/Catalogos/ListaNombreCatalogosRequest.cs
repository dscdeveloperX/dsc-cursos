﻿namespace icSeguridad.DTOs.API.Request.Catalogos
{
    public class ListaNombreCatalogosRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaNombreCatalogosRequestBody BodyRequest { get; set; }
    }
    public class ListaNombreCatalogosRequestBody
    {
        public string NombreCatalogo { get; set; }
    }
}
