﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Catalogos
{
    public class EliminacionCatalogoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EliminacionCatalogoRequestBody BodyRequest { get; set; }
    }
    public class EliminacionCatalogoRequestBody
    {
        public List<long> CatalogoIds { get; set; }
    }
}
