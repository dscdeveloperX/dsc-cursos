﻿namespace icSeguridad.DTOs.API.Request.Menus
{
    public class EdicionMenuRequest
    {
        public long MenuId { get; set; }
        public long PadreId { get; set; }
        public string Nombre { get; set; }
        public string Ruta { get; set; }
        public string Icono { get; set; }
        public byte Nivel { get; set; }
        public long AplicacionId { get; set; }
        public bool SeparadorDeNivel { get; set; }
    }
}
