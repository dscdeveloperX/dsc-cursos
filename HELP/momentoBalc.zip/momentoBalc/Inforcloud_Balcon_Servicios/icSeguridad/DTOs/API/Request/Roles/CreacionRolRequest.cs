﻿using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Request.Roles
{
    public class CreacionRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionRolRequestBody BodyRequest { get; set; }
    }
    public class CreacionRolRequestBody
    {
        public Rol Rol { get; set; }        
    }
}
