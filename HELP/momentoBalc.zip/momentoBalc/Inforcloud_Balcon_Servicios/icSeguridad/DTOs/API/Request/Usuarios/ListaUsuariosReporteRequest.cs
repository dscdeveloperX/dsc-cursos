﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ListaUsuariosReporteRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaUsuariosReporteRequestBody BodyRequest { get; set; }
    }
    public class ListaUsuariosReporteRequestBody
    {
        public string Estado { get; set; }
        public string EstadoRol { get; set; }
    }
}
