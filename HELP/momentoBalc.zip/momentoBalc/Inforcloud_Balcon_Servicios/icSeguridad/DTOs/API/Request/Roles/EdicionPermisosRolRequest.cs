﻿using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Roles
{
    public class EdicionPermisosRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionPermisosRolRequestBody BodyRequest { get; set; }
    }
    public class EdicionPermisosRolRequestBody
    {
        public long AplicacionId { get; set; }
        public long RolId { get; set; }
        public List<AccesoRolDto> Acceso {get;set;}
    }
}
