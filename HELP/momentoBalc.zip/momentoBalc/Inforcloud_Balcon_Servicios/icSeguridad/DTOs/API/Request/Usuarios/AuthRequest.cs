﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class AuthRequest
    {
        public string AppCanal { get; set; } = "";
    }
}
