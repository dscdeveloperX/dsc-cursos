﻿namespace icSeguridad.DTOs.API.Request.Roles
{
    public class ListaRolesRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaRolesRequestBody BodyRequest { get; set; }
    }
    public class ListaRolesRequestBody
    {
        public string Estado { get; set; }
        public string OrdenarPor { get; set; }
        public bool OrdenDesc { get; set; }
        public string FiltrarPor { get; set; }
        public string ValorFiltro { get; set; }
        public long Aplicacion { get; set; }
    }
}
