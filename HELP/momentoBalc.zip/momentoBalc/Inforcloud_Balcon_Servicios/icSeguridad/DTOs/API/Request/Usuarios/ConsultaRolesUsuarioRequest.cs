﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ConsultaRolesUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaRolesUsuarioRequestBody BodyRequest { get; set; }
    }
    public class ConsultaRolesUsuarioRequestBody
    {
        public long UsuarioId { get; set; }
        public long AplicacionId { get; set; }
    }
}
