﻿using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class CreacionUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionUsuarioRequestBody BodyRequest { get; set; }
    }
    public class CreacionUsuarioRequestBody
    {
        public UsuarioDto Usuario { get; set; }
    }
}
