﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Aplicaciones
{
    public class EliminacionAplicacionRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EliminacionAplicacionRequestBody BodyRequest { get; set; }
    }
    public class EliminacionAplicacionRequestBody
    {
        public List<long> AplicacionesIds { get; set; }
    }
}
