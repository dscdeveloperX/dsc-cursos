﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ActivacionUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ActivacionUsuarioRequestBody BodyRequest { get; set; }
    }
    public class ActivacionUsuarioRequestBody
    {
        public List<long> UsuariosIds { get; set; }
    }
}
