﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ComprobarComplejidadClaveRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ComprobarComplejidadClaveRequestBody BodyRequest { get; set; }
    }
    public class ComprobarComplejidadClaveRequestBody
    {
        public string Clave { get; set; }
    }
}
