﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class EliminacionUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EliminacionUsuarioRequestBody BodyRequest { get; set; }
    }
    public class EliminacionUsuarioRequestBody
    {
        public List<long> UsuariosIds { get; set; }
    }
}
