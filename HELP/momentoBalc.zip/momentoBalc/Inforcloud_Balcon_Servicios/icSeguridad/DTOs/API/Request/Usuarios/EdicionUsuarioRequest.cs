﻿using System;

namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class EdicionUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public UserUpdateBodyRequestDto BodyRequest { get; set; }
    }
    public class UserUpdateBodyRequestDto
    {
        public long profileId { get; set; }
        public string userName { get; set; }
        public string name { get; set; }
        public string userNumberType { get; set; }
        public string userNumber { get; set; }
        public string email { get; set; }
        public DateTime birthdate { get; set; }
        public string mobilePhoneCarrier { get; set; }
        public string mobilePhone { get; set; }
        public string type { get; set; }
    }
}
