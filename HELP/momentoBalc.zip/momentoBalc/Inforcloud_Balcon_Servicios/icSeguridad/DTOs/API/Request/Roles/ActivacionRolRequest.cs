﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Roles
{
    public class ActivacionRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ActivacionRolRequestBody BodyRequest { get; set; }
    }
    public class ActivacionRolRequestBody
    {
        public List<long> RolesIds { get; set; }
    }
}
