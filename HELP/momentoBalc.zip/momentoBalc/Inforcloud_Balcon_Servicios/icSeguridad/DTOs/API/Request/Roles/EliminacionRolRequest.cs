﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Roles
{
    public class EliminacionRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EliminacionRolRequestBody BodyRequest { get; set; }
    }
    public class EliminacionRolRequestBody
    {
        public List<long> RolesIds { get; set; }
    }
}
