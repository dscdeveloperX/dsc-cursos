﻿namespace icSeguridad.DTOs.API.Request.Roles
{
    public class ConsultaPermisosRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaPermisosRolRequestBody BodyRequest { get; set; }
    }
    public class ConsultaPermisosRolRequestBody
    {
        public long RolId { get; set; }
    }
}
