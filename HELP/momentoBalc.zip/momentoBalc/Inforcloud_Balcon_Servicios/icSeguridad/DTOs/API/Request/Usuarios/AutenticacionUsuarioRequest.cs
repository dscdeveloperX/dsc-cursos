﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class AutenticacionUsuarioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public AutenticacionUsuarioRequestBody BodyRequest { get; set; }
    }
    public class AutenticacionUsuarioRequestBody
    {
        public long Aplicacion { get; set; }
        public string Usuario { get; set; }
        public string Credenciales { get; set; }
    }
}
