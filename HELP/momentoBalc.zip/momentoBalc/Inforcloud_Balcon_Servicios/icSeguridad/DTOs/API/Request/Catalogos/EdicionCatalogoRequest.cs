﻿using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Request.Catalogos
{
    public class EdicionCatalogoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionCatalogoRequestBody BodyRequest { get; set; }
    }
    public class EdicionCatalogoRequestBody
    {
        public Catalogo Catalogo { get; set; }
    }
}
