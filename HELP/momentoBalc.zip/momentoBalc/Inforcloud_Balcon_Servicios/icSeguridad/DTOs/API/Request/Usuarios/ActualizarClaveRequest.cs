﻿namespace icSeguridad.DTOs.API.Request.Usuarios
{
    public class ActualizarClaveRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ActualizarClaveRequestBody BodyRequest { get; set; }
    }
    public class ActualizarClaveRequestBody
    {
        public string Usuario { get; set; }
        public string ClaveVieja { get; set; }
        public string ClaveNueva { get; set; }
    }
}
