﻿using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Request.Roles
{
    public class InactivacionRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public InactivacionRolRequestBody BodyRequest { get; set; }
    }
    public class InactivacionRolRequestBody
    {
        public List<long> RolesIds { get; set; }
    }
}
