﻿namespace icSeguridad.DTOs.API.Request.Roles
{
    public class ConsultaRolRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaRolRequestBody BodyRequest { get; set; }
    }
    public class ConsultaRolRequestBody
    {
        public long RolId { get; set; }
    }
}
