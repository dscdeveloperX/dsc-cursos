﻿namespace icSeguridad.DTOs.API.Request.Aplicaciones
{
    public class ConsultaAplicacionRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaAplicacionRequestBody BodyRequest { get; set; }
    }
    public class ConsultaAplicacionRequestBody
    {
        public long AplicacionId { get; set; }
    }
}
