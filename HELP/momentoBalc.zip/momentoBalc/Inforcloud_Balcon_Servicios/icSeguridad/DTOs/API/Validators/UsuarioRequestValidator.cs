﻿using FluentValidation;
using icSeguridad.DTOs.API.Request.Usuarios;

namespace icSeguridad.DTOs.API.Validators
{
    public class ListaUsuariosValidator : AbstractValidator<ListaUsuariosRequest>
    {
        public ListaUsuariosValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);
        }
    }
    public class CreacionUsuarioValidator : AbstractValidator<CreacionUsuarioRequest>
    {
        public CreacionUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Usuario).NotNull();
            RuleFor(x => x.BodyRequest.Usuario.Usuario).NotEmpty();
            RuleFor(x => x.BodyRequest.Usuario.Nombre).NotEmpty();
            RuleFor(x => x.BodyRequest.Usuario.Cedula).NotEmpty();
            RuleFor(x => x.BodyRequest.Usuario.Email).NotEmpty();
            RuleFor(x => x.BodyRequest.Usuario.Cargo).NotEmpty();
            RuleFor(x => x.BodyRequest.Usuario.Agencia).NotEmpty();
            RuleFor(x => x.BodyRequest.Usuario.Estado).NotEmpty();
        }
    }

    public class EliminacionUsuarioValidator : AbstractValidator<EliminacionUsuarioRequest>
    {
        public EliminacionUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.UsuariosIds).NotEmpty();
        }
    }

    public class ConsultaUsuarioValidator : AbstractValidator<ConsultaUsuarioRequest>
    {
        public ConsultaUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.UsuarioId).GreaterThan(0);
        }
    }

    public class AutenticacionUsuarioValidator : AbstractValidator<AutenticacionUsuarioRequest>
    {
        public AutenticacionUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Aplicacion).GreaterThan(0);
            RuleFor(x => x.BodyRequest.Usuario).NotEmpty();
            RuleFor(x => x.BodyRequest.Credenciales).NotEmpty();
        }
    }

    public class ActivacionUsuarioValidator : AbstractValidator<ActivacionUsuarioRequest>
    {
        public ActivacionUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.UsuariosIds).NotEmpty();
        }
    }

    public class InactivacionUsuarioValidator : AbstractValidator<InactivacionUsuarioRequest>
    {
        public InactivacionUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.UsuariosIds).NotEmpty();
        }
    }

    public class ConsultaRolesUsuarioValidator : AbstractValidator<ConsultaRolesUsuarioRequest>
    {
        public ConsultaRolesUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.UsuarioId).NotEqual(0);
            RuleFor(x => x.BodyRequest.AplicacionId).NotEqual(0);
        }
    }

    public class ActualizarRolesUsuarioValidator : AbstractValidator<ActualizarRolesUsuarioRequest>
    {
        public ActualizarRolesUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.UsuarioId).NotEqual(0).WithMessage("Debe escoger un usuario");
            RuleFor(x => x.BodyRequest.AplicacionId).NotEqual(0).NotNull().WithMessage("Debe escoger una aplicación");
            RuleFor(x => x.BodyRequest.RolPrincipalId).NotEqual(0).WithMessage("Debe asignar un rol principal al usuario")
                .NotNull().WithMessage("Debe asignar un rol principal al usuario");
        }
    }
    public class ListaUsuariosReporteValidator : AbstractValidator<ListaUsuariosReporteRequest>
    {
        public ListaUsuariosReporteValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);
        }
    }

    public class ActualizarClaveValidator : AbstractValidator<ActualizarClaveRequest>
    {
        public ActualizarClaveValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Usuario).NotEmpty();
            RuleFor(x => x.BodyRequest.ClaveNueva).NotEmpty();
            RuleFor(x => x.BodyRequest.ClaveVieja).NotEmpty();
        }
    }

    public class ComprobarComplejidadClaveValidator : AbstractValidator<ComprobarComplejidadClaveRequest>
    {
        public ComprobarComplejidadClaveValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Clave).NotEmpty();
        }
    }

    public class ConsultarDataUsuarioValidator : AbstractValidator<ConsultarDataUsuarioRequest>
    {
        public ConsultarDataUsuarioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Usuario).NotEmpty();
        }
    }
}
