﻿using FluentValidation;
using icSeguridad.DTOs.API.Request.Roles;

namespace icSeguridad.DTOs.API.Validators
{
    public class ListaRolesValidator : AbstractValidator<ListaRolesRequest>
    {
        public ListaRolesValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);
        }
    }
    public class CreacionRolValidator : AbstractValidator<CreacionRolRequest>
    {
        public CreacionRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Rol).NotEmpty();
        }
    }
    public class EdicionRolValidator : AbstractValidator<EdicionRolRequest>
    {
        public EdicionRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Rol).NotEmpty();
        }
    }
    public class EliminacionRolValidator : AbstractValidator<EliminacionRolRequest>
    {
        public EliminacionRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.RolesIds).NotEmpty();
        }
    }

    public class ActivacionRolValidator : AbstractValidator<ActivacionRolRequest>
    {
        public ActivacionRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.RolesIds).NotEmpty();
        }
    }

    public class InactivacionRolValidator : AbstractValidator<InactivacionRolRequest>
    {
        public InactivacionRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.RolesIds).NotEmpty();
        }
    }

    public class ConsultaRolValidator : AbstractValidator<ConsultaRolRequest>
    {
        public ConsultaRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.RolId).GreaterThan(0);
        }
    }

    public class ConsultaPermisosRolValidator : AbstractValidator<ConsultaPermisosRolRequest>
    {
        public ConsultaPermisosRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.RolId).GreaterThan(0);
        }
    }
    public class EdicionPermisosRolValidator : AbstractValidator<EdicionPermisosRolRequest>
    {
        public EdicionPermisosRolValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.RolId).GreaterThan(0);
            RuleFor(x => x.BodyRequest.AplicacionId).GreaterThan(0);
            RuleFor(x => x.BodyRequest.Acceso).NotNull();
        }
    }

    public class ListaRolesReporteValidator : AbstractValidator<ListaRolesReporteRequest>
    {
        public ListaRolesReporteValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);
        }
    }
}
