﻿using FluentValidation;
using icSeguridad.DTOs.API.Request.Auditoria;

namespace icSeguridad.DTOs.API.Validators
{
    public class ConsultaAuditoriaValidator : AbstractValidator<ConsultaAuditoriaRequest>
    {
        public ConsultaAuditoriaValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.FechaDesde).NotEmpty();
            RuleFor(x => x.BodyRequest.FechaHasta).NotEmpty();
        }
    }
}
