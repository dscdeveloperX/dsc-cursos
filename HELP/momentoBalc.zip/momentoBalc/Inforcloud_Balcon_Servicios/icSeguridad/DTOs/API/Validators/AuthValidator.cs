﻿using FluentValidation;
using icSeguridad.DTOs.API.Request.Usuarios;

namespace icSeguridad.DTOs.API.Validators
{
    public class AuthValidator : AbstractValidator<AuthRequest>
    {
        public AuthValidator()
        {
            //Header Validation
            RuleFor(x => x.AppCanal).NotEmpty();

        }
    }
}
