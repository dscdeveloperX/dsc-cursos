﻿using FluentValidation;
using icSeguridad.DTOs.API.Request.Aplicaciones;

namespace icSeguridad.DTOs.API.Validators
{
    public class ListaAplicacionesValidator : AbstractValidator<ListaAplicacionesRequest>
    {
        public ListaAplicacionesValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

        }
    }

    public class ConsultaAplicacionValidator : AbstractValidator<ConsultaAplicacionRequest>
    {
        public ConsultaAplicacionValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);
            RuleFor(x => x.BodyRequest.AplicacionId).GreaterThan(0);
        }
    }

    public class CreacionAplicacionValidator : AbstractValidator<CreacionAplicacionRequest>
    {
        public CreacionAplicacionValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Aplicacion).NotEmpty();
        }
    }
    public class EdicionAplicacionValidator : AbstractValidator<EdicionAplicacionRequest>
    {
        public EdicionAplicacionValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Nombre).NotEmpty();
            RuleFor(x => x.BodyRequest.AplicacionId).GreaterThan(0);
        }
    }
    public class EliminacionAplicacionValidator : AbstractValidator<EliminacionAplicacionRequest>
    {
        public EliminacionAplicacionValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.AplicacionesIds).NotEmpty();
        }
    }

    public class ActivacionAplicacionValidator : AbstractValidator<ActivacionAplicacionRequest>
    {
        public ActivacionAplicacionValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.AplicacionesIds).NotEmpty();
        }
    }

    public class InactivacionAplicacionValidator : AbstractValidator<InactivacionAplicacionRequest>
    {
        public InactivacionAplicacionValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.AplicacionesIds).NotEmpty();
        }
    }
}
