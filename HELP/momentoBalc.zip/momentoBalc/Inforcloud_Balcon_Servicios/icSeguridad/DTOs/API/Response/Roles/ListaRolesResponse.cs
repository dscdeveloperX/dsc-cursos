﻿using icCommon.DTOs.API;
using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Roles
{
    public class ListaRolesResponse : BaseResponse
    {
        public ListaRolesResponseBody BodyResponse { get; set; }

        public ListaRolesResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaRolesResponseBody();
        }

    }
    public class ListaRolesResponseBody
    {
        public List<RolDto> Roles { get; set; }
        public ListaRolesResponseBody()
        {
            this.Roles = new List<RolDto>();
        }
    }
}
