﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Roles
{
    public class InactivacionRolResponse : BaseResponse
    {
        public InactivacionRolResponseBody BodyResponse { get; set; }

        public InactivacionRolResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new InactivacionRolResponseBody();
        }

    }
    public class InactivacionRolResponseBody
    {
        public int RolesInactivados { get; set; }
        public InactivacionRolResponseBody()
        {
            this.RolesInactivados = 0;
        }
    }
}
