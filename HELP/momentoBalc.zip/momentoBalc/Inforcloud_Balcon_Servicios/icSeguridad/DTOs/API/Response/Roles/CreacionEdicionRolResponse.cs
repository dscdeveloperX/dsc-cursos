﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Roles
{
    public class CreacionEdicionRolResponse : BaseResponse
    {
        public CreacionEdicionRolResponseBody BodyResponse { get; set; }

        public CreacionEdicionRolResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionEdicionRolResponseBody();
        }

    }
    public class CreacionEdicionRolResponseBody
    {
        public long RolId { get; set; }
        public CreacionEdicionRolResponseBody()
        {
            this.RolId = 0;
        }
    }
}
