﻿using icCommon.DTOs.API;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Auditoria
{
    public class ConsultaAuditoriaResponse : BaseResponse
    {
        public ConsultaAuditoriaResponseBody BodyResponse { get; set; }

        public ConsultaAuditoriaResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultaAuditoriaResponseBody();
        }

    }
    public class ConsultaAuditoriaResponseBody
    {
        public List<icCommon.Modelos.Auditoria> Auditoria { get; set; }
        public ConsultaAuditoriaResponseBody()
        {
            this.Auditoria = new List<icCommon.Modelos.Auditoria>();
        }
    }
}
