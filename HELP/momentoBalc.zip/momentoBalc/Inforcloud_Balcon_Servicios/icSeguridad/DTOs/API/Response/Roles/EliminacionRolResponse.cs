﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Roles
{
    public class EliminacionRolResponse : BaseResponse
    {
        public EliminacionRolResponseBody BodyResponse { get; set; }
        public EliminacionRolResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EliminacionRolResponseBody();
        }
    }
    public class EliminacionRolResponseBody
    {
        public int RolesEliminados { get; set; }
        public EliminacionRolResponseBody()
        {
            this.RolesEliminados = 0;
        }
    }
}
