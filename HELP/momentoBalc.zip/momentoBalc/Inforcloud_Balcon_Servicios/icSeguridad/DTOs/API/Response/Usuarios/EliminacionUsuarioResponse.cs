﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class EliminacionUsuarioResponse : BaseResponse
    {
        public EliminacionUsuarioResponseBody BodyResponse { get; set; }
        public EliminacionUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EliminacionUsuarioResponseBody();
        }
    }
    public class EliminacionUsuarioResponseBody
    {
        public long UsuarioId { get; set; }
        public EliminacionUsuarioResponseBody()
        {
            this.UsuarioId = 0;
        }
    }
}
