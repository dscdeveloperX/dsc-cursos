﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Aplicaciones
{
    public class CreacionEdicionAplicacionResponse : BaseResponse
    {
        public CreacionEdicionAplicacionResponseBody BodyResponse { get; set; }

        public CreacionEdicionAplicacionResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionEdicionAplicacionResponseBody();
        }

    }
    public class CreacionEdicionAplicacionResponseBody
    {
        public long AplicacionId { get; set; }
        public CreacionEdicionAplicacionResponseBody()
        {
            this.AplicacionId = 0;
        }
    }
}
