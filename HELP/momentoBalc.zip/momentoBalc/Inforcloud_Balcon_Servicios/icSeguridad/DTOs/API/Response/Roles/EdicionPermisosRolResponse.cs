﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Roles
{
    public class EdicionPermisosRolResponse : BaseResponse
    {
        public EdicionPermisosRolResponseBody BodyResponse { get; set; }

        public EdicionPermisosRolResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionPermisosRolResponseBody();
        }

    }
    public class EdicionPermisosRolResponseBody
    {
        public int AccesosModificados { get; set; }
        public EdicionPermisosRolResponseBody()
        {
            this.AccesosModificados = 0;
        }
    }
}
