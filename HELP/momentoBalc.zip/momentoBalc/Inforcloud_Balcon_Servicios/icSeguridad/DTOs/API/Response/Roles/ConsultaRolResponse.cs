﻿using icCommon.DTOs.API;
using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Response.Roles
{
    public class ConsultaRolResponse : BaseResponse
    {
        public ConsultaRolResponseBody BodyResponse { get; set; }
    }
    public class ConsultaRolResponseBody
    {
        public RolDto Rol { get; set; }
    }
}
