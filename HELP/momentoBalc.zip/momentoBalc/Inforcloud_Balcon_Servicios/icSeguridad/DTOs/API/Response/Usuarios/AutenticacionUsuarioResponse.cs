﻿using icCommon.DTOs.API;
using icSeguridad.Models;
using System;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class AutenticacionUsuarioResponse : BaseResponse
    {
        public AutenticacionUsuarioResponseBody BodyResponse { get; set; }

        public AutenticacionUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new AutenticacionUsuarioResponseBody();
        }
    }

    public class AutenticacionUsuarioResponseBody
    {
        public PerfilUsuario Usuario { get; set; }
        public string Token { get; set; }
        public DateTime FechaExpiracion { get; set; }
    }
}
