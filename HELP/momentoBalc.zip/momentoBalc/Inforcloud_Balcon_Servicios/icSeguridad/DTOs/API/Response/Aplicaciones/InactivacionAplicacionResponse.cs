﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Aplicaciones
{
    public class InactivacionAplicacionResponse : BaseResponse
    {
        public InactivacionAplicacionResponseBody BodyResponse { get; set; }

        public InactivacionAplicacionResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new InactivacionAplicacionResponseBody();
        }

    }
    public class InactivacionAplicacionResponseBody
    {
        public int AplicacionesInactivadas { get; set; }
        public InactivacionAplicacionResponseBody()
        {
            this.AplicacionesInactivadas = 0;
        }
    }
}
