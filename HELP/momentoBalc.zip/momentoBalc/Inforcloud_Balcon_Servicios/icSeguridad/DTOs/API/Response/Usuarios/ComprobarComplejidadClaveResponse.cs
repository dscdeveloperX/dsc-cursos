﻿using icCommon.DTOs.API;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ComprobarComplejidadClaveResponse : BaseResponse
    {
        public ComprobarComplejidadClaveResponseBody BodyResponse { get; set; }

        public ComprobarComplejidadClaveResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ComprobarComplejidadClaveResponseBody();
        }
    }

    public class ComprobarComplejidadClaveResponseBody
    {
        public bool Resultado { get; set; }
    }
}
