﻿using icCommon.DTOs.API;
using icSeguridad.DTOs.DB.Response.Roles;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Roles
{
    public class ListaRolesReporteResponse : BaseResponse
    {
        public ListaRolesReporteResponseBody BodyResponse { get; set; }

        public ListaRolesReporteResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaRolesReporteResponseBody();
        }

    }
    public class ListaRolesReporteResponseBody
    {
        public List<RolReporte> Roles { get; set; }
        public ListaRolesReporteResponseBody()
        {
            this.Roles = new List<RolReporte>();
        }
    }
}
