﻿using icCommon.DTOs.API;

namespace icSeguridad.DTOs.API.Response.Aplicaciones
{
    public class ActivacionAplicacionResponse : BaseResponse
    {
        public ActivacionAplicacionResponseBody BodyResponse { get; set; }

        public ActivacionAplicacionResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ActivacionAplicacionResponseBody();
        }

    }
    public class ActivacionAplicacionResponseBody
    {
        public int AplicacionesActivadas { get; set; }
        public ActivacionAplicacionResponseBody()
        {
            this.AplicacionesActivadas = 0;
        }
    }
}
