﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ActivacionUsuarioResponse : BaseResponse
    {
        public ActivacionUsuarioResponseBody BodyResponse { get; set; }

        public ActivacionUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ActivacionUsuarioResponseBody();
        }

    }
    public class ActivacionUsuarioResponseBody
    {
        public int UsuarioActivados { get; set; }
        public ActivacionUsuarioResponseBody()
        {
            this.UsuarioActivados = 0;
        }
    }
}
