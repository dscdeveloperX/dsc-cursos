﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class InactivacionUsuarioResponse : BaseResponse
    {
        public InactivacionUsuarioResponseBody BodyResponse { get; set; }

        public InactivacionUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new InactivacionUsuarioResponseBody();
        }

    }
    public class InactivacionUsuarioResponseBody
    {
        public int UsuarioInactivados { get; set; }
        public InactivacionUsuarioResponseBody()
        {
            this.UsuarioInactivados = 0;
        }
    }
}
