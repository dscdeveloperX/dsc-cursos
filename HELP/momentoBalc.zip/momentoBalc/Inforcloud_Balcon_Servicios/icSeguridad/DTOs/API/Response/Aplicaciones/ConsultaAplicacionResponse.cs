﻿using icCommon.DTOs.API;
using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Response.Aplicaciones
{
    public class ConsultaAplicacionResponse : BaseResponse
    {
        public ConsultaAplicacionResponseBody BodyResponse { get; set; }
    }
    public class ConsultaAplicacionResponseBody
    {
        public AplicacionDto Aplicacion { get; set; }
    }
}
