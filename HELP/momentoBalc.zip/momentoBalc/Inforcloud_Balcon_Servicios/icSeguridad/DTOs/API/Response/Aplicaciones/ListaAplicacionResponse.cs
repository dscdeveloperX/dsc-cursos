﻿using icCommon.DTOs.API;
using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Aplicaciones
{
    public class ListaAplicacionResponse : BaseResponse
    {
        public ListaAplicacionResponseBody BodyResponse { get; set; }

        public ListaAplicacionResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaAplicacionResponseBody();
        }

    }
    public class ListaAplicacionResponseBody
    {
        public List<Aplicacion> Aplicaciones { get; set; }
        public ListaAplicacionResponseBody()
        {
            this.Aplicaciones = new List<Aplicacion>();
        }
    }
}
