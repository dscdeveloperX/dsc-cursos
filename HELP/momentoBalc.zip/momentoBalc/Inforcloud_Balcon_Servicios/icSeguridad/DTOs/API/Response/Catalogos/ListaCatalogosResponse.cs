﻿using icCommon.DTOs.API;
using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Catalogos
{
    public class ListaCatalogosResponse : BaseResponse
    {
        public ListaCatalogosResponseBody BodyResponse { get; set; }

        public ListaCatalogosResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaCatalogosResponseBody();
        }

    }
    public class ListaCatalogosResponseBody
    {
        public List<Catalogo> Catalogos { get; set; }
        public ListaCatalogosResponseBody()
        {
            this.Catalogos = new List<Catalogo>();
        }
    }
}
