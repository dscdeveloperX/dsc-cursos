﻿using icCommon.DTOs.API;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Roles
{
    public class MenuRolResponse : BaseResponse
    {
        public MenuRolResponseBody BodyResponse { get; set; }
        public MenuRolResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new MenuRolResponseBody();
        }
    }
    public class MenuRolResponseBody
    {
        public List<int> MenuRolId { get; set; }
        public MenuRolResponseBody()
        {
            this.MenuRolId = new List<int>();
        }
    }
}
