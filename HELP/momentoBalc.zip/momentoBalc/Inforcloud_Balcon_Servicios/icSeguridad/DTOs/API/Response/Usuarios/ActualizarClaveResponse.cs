﻿using icCommon.DTOs.API;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ActualizarClaveResponse : BaseResponse
    {
        public ActualizarClaveResponseBody BodyResponse { get; set; }

        public ActualizarClaveResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ActualizarClaveResponseBody();
        }
    }

    public class ActualizarClaveResponseBody
    {
        public bool Actualizado { get; set; }
    }
}
