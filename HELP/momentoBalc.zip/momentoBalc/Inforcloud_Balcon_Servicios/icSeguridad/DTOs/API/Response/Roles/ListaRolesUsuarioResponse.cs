﻿using icCommon.DTOs.API;
using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Roles
{
    public class ListaRolesUsuarioResponse : BaseResponse
    {
        public ListaRolesUsuarioResponseBody BodyResponse { get; set; }
        public ListaRolesUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaRolesUsuarioResponseBody();
        }
    }

    public class ListaRolesUsuarioResponseBody
    {
        public List<RolUsuarioDto> RolesUsuario { get; set; }
        public ListaRolesUsuarioResponseBody()
        {
            this.RolesUsuario = new List<RolUsuarioDto>();
        }
    }
}
