﻿using icCommon.DTOs.API;
using icSeguridad.DTOs.DB.Response.Usuarios;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ListaUsuariosReporteResponse : BaseResponse
    {
        public ListaUsuariosReporteResponseBody BodyResponse { get; set; }

        public ListaUsuariosReporteResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaUsuariosReporteResponseBody();
        }

    }
    public class ListaUsuariosReporteResponseBody
    {
        public List<UsuarioReporte> Usuarios { get; set; }
        public ListaUsuariosReporteResponseBody()
        {
            this.Usuarios = new List<UsuarioReporte>();
        }
    }
}
