﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Roles
{
    public class ActivacionRolesResponse : BaseResponse
    {
        public ActivacionRolesResponseBody BodyResponse { get; set; }

        public ActivacionRolesResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ActivacionRolesResponseBody();
        }

    }
    public class ActivacionRolesResponseBody
    {
        public int RolesActivados { get; set; }
        public ActivacionRolesResponseBody()
        {
            this.RolesActivados = 0;
        }
    }
}
