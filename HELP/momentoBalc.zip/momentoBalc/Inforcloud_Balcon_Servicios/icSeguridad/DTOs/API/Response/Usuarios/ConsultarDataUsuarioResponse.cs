﻿using icCommon.DTOs.API;
using System;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ConsultarDataUsuarioResponse : BaseResponse
    {
        public ConsultarDataUsuarioResponseBody BodyResponse { get; set; }

        public ConsultarDataUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultarDataUsuarioResponseBody();
        }
    }

    public class ConsultarDataUsuarioResponseBody
    {
        public string Agencia { get; set; }
        public bool Bloqueado { get; set; }
        public string Cedula { get; set; }
        public string Nombre { get; set; }
        public DateTime? UltimoLogin { get; set; }
        public DateTime? UltimoLoginFallido { get; set; }
        public string Usuario { get; set; }
        public string IpLoginActual { get; set; }
    }
}
