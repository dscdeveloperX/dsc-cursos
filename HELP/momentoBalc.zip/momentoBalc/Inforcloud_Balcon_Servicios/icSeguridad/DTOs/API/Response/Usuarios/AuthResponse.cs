﻿using System;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class AuthResponse
    {
        public string Mensaje { get; set; }
        /// <summary>
        /// Token (token).
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// Fecha de Expiracion de token en UTC
        /// </summary>
        public DateTime ExpirationDate { get; set; }
    }
}
