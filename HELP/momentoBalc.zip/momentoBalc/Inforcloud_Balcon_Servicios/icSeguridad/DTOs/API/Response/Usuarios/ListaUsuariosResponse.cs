﻿using icCommon.DTOs.API;
using icSeguridad.Models;
using System.Collections.Generic;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ListaUsuariosResponse : BaseResponse
    {
        public ListaUsuariosResponseBody BodyResponse { get; set; }

        public ListaUsuariosResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaUsuariosResponseBody();
        }

    }
    public class ListaUsuariosResponseBody
    {
        public List<Usuario> Usuarios { get; set; }
        public ListaUsuariosResponseBody()
        {
            this.Usuarios = new List<Usuario>();
        }
    }
}
