﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class CreacionEdicionUsuarioResponse : BaseResponse
    {
        public CreacionEdicionUsuarioResponseBody BodyResponse { get; set; }

        public CreacionEdicionUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionEdicionUsuarioResponseBody();
        }

    }
    public class CreacionEdicionUsuarioResponseBody
    {
        public long UsuarioId { get; set; }
        public CreacionEdicionUsuarioResponseBody()
        {
            this.UsuarioId = 0;
        }
    }
}
