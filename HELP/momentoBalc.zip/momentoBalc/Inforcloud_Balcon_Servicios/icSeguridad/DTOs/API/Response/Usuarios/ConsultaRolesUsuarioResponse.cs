﻿using icCommon.DTOs.API;
using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ConsultaRolesUsuarioResponse : BaseResponse
    {
        public ConsultaRolesUsuarioResponseBody BodyResponse { get; set; }
    }
    public class ConsultaRolesUsuarioResponseBody
    {
        public RolesUsuarioDto RolesUsuario { get; set; }
    }


}
