﻿using icCommon.DTOs.API;
using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ConsultaUsuarioResponse : BaseResponse
    {
        public ConsultaUsuarioResponseBody BodyResponse { get; set; }
    }
    public class ConsultaUsuarioResponseBody
    {
        public UsuarioDto Usuario { get; set; }
    }
}
