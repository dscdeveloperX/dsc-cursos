﻿using icCommon.DTOs.API;
using icSeguridad.Models;

namespace icSeguridad.DTOs.API.Response.Usuarios
{
    public class ActualizarRolesUsuarioResponse : BaseResponse
    {
        public ActualizarRolesUsuarioResponseBody BodyResponse { get; set; }

        public ActualizarRolesUsuarioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ActualizarRolesUsuarioResponseBody();
        }
    }
    public class ActualizarRolesUsuarioResponseBody
    {
        public RolesUsuarioDto RolesUsuario { get; set; }
    }
}
