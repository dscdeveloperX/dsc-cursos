﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Catalogos
{
    public class EdicionCatalogoResponse : BaseResponse
    {
        public EdicionCatalogoResponseBody BodyResponse { get; set; }
        public EdicionCatalogoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionCatalogoResponseBody();
        }
    }
    public class EdicionCatalogoResponseBody
    {
        public int CatalogosEditados { get; set; }
        public EdicionCatalogoResponseBody()
        {
            this.CatalogosEditados = 0;
        }
    }
}
