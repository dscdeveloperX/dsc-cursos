﻿using icCommon.DTOs.API;
namespace icSeguridad.DTOs.API.Response.Aplicaciones
{
    public class EliminacionAplicacioneResponse : BaseResponse
    {
        public EliminacionAplicacioneResponseBody BodyResponse { get; set; }

        public EliminacionAplicacioneResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EliminacionAplicacioneResponseBody();
        }

    }
    public class EliminacionAplicacioneResponseBody
    {
        public long AplicacionId { get; set; }
        public EliminacionAplicacioneResponseBody()
        {
            this.AplicacionId = 0;
        }
    }
}
