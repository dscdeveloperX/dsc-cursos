﻿using icCommon.Utils;
using System.Collections.Generic;

namespace icSeguridad
{
    public class Constantes
    {
        public static string ServiceName = "icSeguridad";

        public static List<NamespacePrefix> RequestNamespaces = new List<NamespacePrefix>
        {
            new NamespacePrefix{ Namespace = XmlNamespace.Envelope, Prefix = XmlRequestPrefix.Envelope},
            new NamespacePrefix{ Namespace = XmlNamespace.Tem, Prefix = XmlRequestPrefix.Tem},
            new NamespacePrefix{ Namespace = XmlNamespace.Ser, Prefix = XmlRequestPrefix.Ser}
        };

        public class XmlNamespace
        {
            public const string Envelope = "http://schemas.xmlsoap.org/soap/envelope/";
            public const string Tem = "http://tempuri.org/";
            public const string Ser = "http://schemas.datacontract.org/2004/07/ServicioAuRo";
        }
        public class XmlRequestPrefix
        {
            public const string Envelope = "soapenv";
            public const string Tem = "tem";
            public const string Ser = "ser";
        }

        public class ElementTag
        {
            public const string Usuario = "usuario";
            public const string Credenciales = "credenciales";
            public const string CredencialesActualizadas = "credencialesActualizadas";
        }

        public class Tramas
        {
            public const string VALIDAR_CREDENCIALES = "VALIDAR_CREDENCIALES";
            public const string ACTUALIZAR_CREDENCIALES = "ACTUALIZAR_CREDENCIALES";
            public const string COMPROBAR_COMPLEJIDAD_CREDENCIALES = "COMPROBAR_COMPLEJIDAD_CREDENCIALES";
            public const string CONSULTAR_USUARIO = "CONSULTAR_USUARIO";
        }
    }
}
