﻿using icCommon.DTOs.DB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace icSeguridad.Models
{
    public class Rol
    {
        public long RolId { get; set; }
        public long AplicacionId { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Estado { get; set; }
    }

    public class RolDto
    {
        public long RolId { get; set; }
        public CampoDescriptor Aplicacion { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Estado { get; set; }
        public List<AccesoMenuDto> AccesoMenu { get; set; }
    }

    public class RolUsuarioDto
    {
        public long RolId { get; set; }
        public CampoDescriptor Aplicacion { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Estado { get; set; }
        public bool EsPrincipal { get; set; }
        public List<AccesoMenuDto> AccesoMenu { get; set; }
        public DatosUsuario Usuario { get; set; }
    }

    public class AccesoMenuDto
    {
        public long MenuId { get; set; }
        public long PadreId { get; set; }
        public string Nombre { get; set; }
        public string Ruta { get; set; }
        public string Icono { get; set; }
        public byte Nivel { get; set; }
        public string Estado { get; set; }
        public bool SeparadorNivel { get; set; }
        public List<AccesoMenuDto> Hijos { get; set; }
    }

    public class DatosUsuario
    {
        public long UsuarioId { get; set; }
        public string NombreUsuario { get; set; } = string.Empty;
        public string Agencia { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}
