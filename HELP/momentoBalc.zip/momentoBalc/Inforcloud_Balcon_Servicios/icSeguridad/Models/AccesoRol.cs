﻿namespace icSeguridad.Models
{
    public class AccesoRol
    {
        public long AccesoRolId { get; set; }
        public long AplicacionId { get; set; }
        public long RolId { get; set; }
        public long MenuId { get; set; }
        public string Estado { get; set; }
    }

    public class AccesoRolDto { 
        public long MenuId { get; set; }
        public string Estado { get; set; }
    }
}
