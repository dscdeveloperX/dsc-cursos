﻿using icCommon.DTOs.DB;
using System;

namespace icSeguridad.Models
{
    public class RolUsuarioAplicacion
    {
        public long RolUsuarioAplicacionId { get; set; }
        public long AplicacionId { get; set; }
        public long RolId { get; set; }
        public long UsuarioId { get;set; }
        public string Estado { get; set; }
        public bool EsPrincipal { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaVencimiento { get; set; }
    }

    public class RolesUsuarioDto {
        public long UsuarioId { get; set; }
        public CampoDescriptor Aplicacion { get; set; }
        public RolTemporalDto RolPrincipal { get; set; }
        public RolTemporalDto RolTemporal { get; set; }

    }

    public class RolTemporalDto {
        public long Id { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public bool EsPrincipal { get; set; }
    }
}
