﻿using icSeguridad.DTOs.API.Request.Menus;
using System;
using System.Collections.Generic;

namespace icSeguridad.Models
{
    public class Menu
    {
        public long MenuId { get; set; }
        public long PadreId { get; set; }
        public long AplicacionId { get; set; }
        public string Nombre { get; set; }
        public string Ruta { get; set; }
        public string Icono { get; set; }
        public byte Nivel { get; set; }
        public string Estado { get; set; }
        public bool SeparadorNivel { get; set; }
    }

    public class MenuDto
    {
        public long MenuId { get; set; }
        public long PadreId { get; set; }
        public string Nombre { get; set; }
        public string Ruta { get; set; }
        public string Icono { get; set; }
        public byte Nivel { get; set; }
        public string Estado { get; set; }
        public long AplicacionId { get; set; }
        public bool SeparadorNivel { get; set; }
        public List<MenuDto> Hijos { get; set; }
    }
}
