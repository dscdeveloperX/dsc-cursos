﻿using System;
using System.Collections.Generic;

namespace icSeguridad.Models
{

    public class Usuario
    {
        public long UsuarioId { get; set; }
        public string NombreUsuario { get; set; }
        public string Nombre { get; set; }
        public string Cedula { get; set; }
        public string Cargo { get; set; }
        public string Email { get; set; }
        public string Agencia { get; set; }
        public string Estado { get; set; }
        public bool TieneEnmascaramiento { get; set; }
        public bool RequiereControlEstacion { get; set; }
        public DateTime UltimaSesionFecha { get; set; }
        public string UltimaSesionIP { get; set; }
        public int IntentosFallidos { get; set; }

        public UsuarioDto ToModelo()
        {
            return new UsuarioDto
            {
                Usuario = this.NombreUsuario,
                UsuarioId = this.UsuarioId,
                Estado = this.Estado,
                RequiereControlEstacion = this.RequiereControlEstacion,
                Email = this.Email,
                Nombre = this.Nombre,
                Cedula = this.Cedula,
                Cargo = this.Cargo,
                Agencia = this.Agencia,
                TieneEnmascaramiento = this.TieneEnmascaramiento,
            };
        }
    }

    public class UsuarioDto
    {
        public long UsuarioId { get; set; }
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Cedula { get; set; }
        public string Email { get; set; }
        public string Cargo { get; set; }
        public string Agencia { get; set; }
        public bool RequiereControlEstacion { get; set; }
        public string Estado { get; set; }
        public bool TieneEnmascaramiento { get; set; }
        public List<RolUsuarioAplicacion> Acceso { get; set; }

        public Usuario ToModelo()
        {
            return new Usuario { 
                Agencia = this.Agencia,
                Cargo = this.Cargo,
                Cedula = this.Cedula,
                Email = this.Email,
                Estado = this.Estado,
                IntentosFallidos = 0,
                Nombre = this.Nombre,
                NombreUsuario = this.Usuario,
                RequiereControlEstacion = this.RequiereControlEstacion,
                TieneEnmascaramiento = this.TieneEnmascaramiento,
                UsuarioId = this.UsuarioId
            };
        }
    }

    public class PerfilUsuario
    {
        public long UsuarioId { get; set; }
        public string Usuario { get; set; }
        public string Nombre { get; set; }
        public string Cedula { get; set; }
        public string Cargo { get; set; }
        public string Email { get; set; }
        public string Agencia { get; set; }
        public bool TieneEnmascaramiento { get; set; }
        public DateTime UltimoFechaSesion { get; set; }
        public string UltimaSesionIP { get; set; }
        public string Rol { get; set; }
        public string CodigoEjecutivo { get; set; }
        public string Zona { get; set; }
        public List<AccesoMenuDto> Acceso { get; set; }
    }
}
