﻿using icCommon.DTOs.API;
using icCommon.Mensajes;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Aplicaciones;
using icSeguridad.DTOs.API.Response;
using icSeguridad.DTOs.API.Response.Aplicaciones;
using icSeguridad.DTOs.DB.Response.Aplicaciones;
using icSeguridad.Models;
using Serilog;
using System;

namespace icSeguridad.BLL
{
    public class AplicacionBLL : IAplicacionBLL
    {
        private readonly IAplicacionDLL _clHelper;
        private readonly IMensajeoDLL _mHelper;

        public AplicacionBLL(IAplicacionDLL dHelper, IMensajeoDLL mHelper)
        {
            _clHelper = dHelper;
            _mHelper = mHelper;
        }

        public ActivacionAplicacionResponse ActivarAplicacion(ActivacionAplicacionRequest applicationActivateRequestDto)
        {
            ActivacionAplicacionResponse response = new ActivacionAplicacionResponse();
            ActivacionAplicacionResponseBody bodyResponse = new ActivacionAplicacionResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = applicationActivateRequestDto.HeaderRequest;
                ActivacionAplicacionRequestBody body = applicationActivateRequestDto.BodyRequest;
                //create Log
                Log.Information("AplicacionBLL/ActivarAplicacion: Consulta DB -> INICIO");
                int applicationsActivated = _clHelper.ActivarAplicaciones(header, body);
                Log.Information("AplicacionBLL/ActivarAplicacion: Consulta DB -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("APP_ACT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.AplicacionesActivadas = applicationsActivated;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AplicacionBLL/ActivarAplicacion: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionEdicionAplicacionResponse CrearAplicacion(CreacionAplicacionRequest applicationCreateRequestDto)
        {
            CreacionEdicionAplicacionResponse response = new CreacionEdicionAplicacionResponse();
            CreacionEdicionAplicacionResponseBody bodyResponse = new CreacionEdicionAplicacionResponseBody();
            long ApplicationId;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = applicationCreateRequestDto.HeaderRequest;
                CreacionAplicacionRequestBody body = applicationCreateRequestDto.BodyRequest;
                //create Log
                Log.Information("AplicacionBLL/CrearAplicacion: Consulta DB -> INICIO");
                ApplicationId = _clHelper.CrearAplicacion(header, body);
                Log.Information("AplicacionBLL/CrearAplicacion: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("APP_CREA_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.AplicacionId = ApplicationId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AplicacionBLL/CrearAplicacion: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public InactivacionAplicacionResponse InactivarAplicacion(InactivacionAplicacionRequest applicationDeactivateRequestDto)
        {
            InactivacionAplicacionResponse response = new InactivacionAplicacionResponse();
            InactivacionAplicacionResponseBody bodyResponse = new InactivacionAplicacionResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = applicationDeactivateRequestDto.HeaderRequest;
                InactivacionAplicacionRequestBody body = applicationDeactivateRequestDto.BodyRequest;

                //create Log
                Log.Information("AplicacionBLL/InactivarAplicacion: Consulta DB -> INICIO");
                int applicationsDeactivated = _clHelper.DesactivarAplicaciones(header, body);
                Log.Information("AplicacionBLL/InactivarAplicacion: Consulta DB -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("APP_INACT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.AplicacionesInactivadas = applicationsDeactivated;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AplicacionBLL/InactivarAplicacion: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EliminacionAplicacioneResponse EliminarAplicacion(EliminacionAplicacionRequest applicationDeleteRequestDto)
        {
            EliminacionAplicacioneResponse response = new EliminacionAplicacioneResponse();
            EliminacionAplicacioneResponseBody bodyResponse = new EliminacionAplicacioneResponseBody();
            long ApplicationId;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = applicationDeleteRequestDto.HeaderRequest;
                EliminacionAplicacionRequestBody body = applicationDeleteRequestDto.BodyRequest;

                //create Log
                Log.Information("AplicacionBLL/EliminarAplicacion: Consulta DB -> INICIO");
                ApplicationId = _clHelper.EliminarAplicacion(header, body);
                Log.Information("AplicacionBLL/EliminarAplicacion: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("APP_ELIM_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.AplicacionId = Convert.ToInt32(ApplicationId);
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AplicacionBLL/EliminarAplicacion: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaAplicacionResponse ObtenerAplicacionPorId(ConsultaAplicacionRequest request)
        {
            HeaderRequest header = request.HeaderRequest;
            ConsultaAplicacionRequestBody body = request.BodyRequest;
            try
            {
                ConsultaAplicacionResponse response = new ConsultaAplicacionResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaAplicacionResponseBody bodyResponse = new ConsultaAplicacionResponseBody();
                AplicacionDto application = new AplicacionDto();

                Log.Information("AplicacionBLL/ObtenerAplicacionPorId: Consulta DB -> INICIO");
                application = _clHelper.ObtenerAplicacionPorId(header, body);
                Log.Information("AplicacionBLL/ObtenerAplicacionPorId: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (application != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Aplicacion = application;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AplicacionBLL/ObtenerAplicacionPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaAplicacionResponse ListarAplicaciones(ListaAplicacionesRequest applicationRequestDto)
        {
            ListaAplicacionResponse response = new ListaAplicacionResponse();
            ListaAplicacionResponseBody bodyResponse = new ListaAplicacionResponseBody();
            QueryAplicacionesResponse applications;
            HeaderResponse headerResponseDto = new HeaderResponse();

            HeaderRequest header = applicationRequestDto.HeaderRequest;
            ListaAplicacionesRequestBody body = applicationRequestDto.BodyRequest;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            try
            {
                Log.Information("AplicacionBLL/ListarAplicaciones: Consulta DB -> INICIO");
                applications = _clHelper.ListarAplicaciones(header, body);
                Log.Information("AplicacionBLL/ListarAplicaciones: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = applications.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Aplicaciones = applications.Aplicaciones;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AplicacionBLL/ListarAplicaciones: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionEdicionAplicacionResponse ActualizarAplicacion(CreacionAplicacionRequest applicationUpdateRequestDto)
        {
            CreacionEdicionAplicacionResponse response = new CreacionEdicionAplicacionResponse();
            CreacionEdicionAplicacionResponseBody bodyResponse = new CreacionEdicionAplicacionResponseBody();
            long ApplicationId;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = applicationUpdateRequestDto.HeaderRequest;
                CreacionAplicacionRequestBody body = applicationUpdateRequestDto.BodyRequest;

                //create Log
                Log.Information("AplicacionBLL/ActualizarAplicacion: Consulta DB -> INICIO");
                ApplicationId = _clHelper.ActualizarAplicacion(header, body);
                Log.Information("AplicacionBLL/ActualizarAplicacion: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("APP_EDIT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.AplicacionId = ApplicationId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AplicacionBLL/ActualizarAplicacion: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
