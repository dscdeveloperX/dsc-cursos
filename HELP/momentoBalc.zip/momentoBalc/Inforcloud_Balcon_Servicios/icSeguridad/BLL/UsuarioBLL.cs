﻿using icCommon.DTOs.API;
using icCommon.Mensajes;
using icCommon.Modelos;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Usuarios;
using icSeguridad.DTOs.API.Response;
using icSeguridad.DTOs.API.Response.Usuarios;
using icSeguridad.DTOs.DB.Response.Usuarios;
using icSeguridad.Models;
using Serilog;
using System;

namespace icSeguridad.BLL
{
    public class UsuarioBLL : IUsuarioBLL
    {
        private readonly IUsuarioDLL _clHelper;
        private readonly IConectorBancoBLL _bancoBLL;
        private readonly IMensajeoDLL _mHelper;
        public UsuarioBLL(IUsuarioDLL dHelper, IConectorBancoBLL bancoBLL, IMensajeoDLL mHelper)
        {
            _clHelper = dHelper;
            _bancoBLL = bancoBLL;
            _mHelper = mHelper;
        }

        public ActivacionUsuarioResponse ActivarUsuario(ActivacionUsuarioRequest userActivateRequestDto)
        {
            ActivacionUsuarioResponse response = new ActivacionUsuarioResponse();
            ActivacionUsuarioResponseBody bodyResponse = new ActivacionUsuarioResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = userActivateRequestDto.HeaderRequest;
                ActivacionUsuarioRequestBody body = userActivateRequestDto.BodyRequest;

                //create Log
                Log.Information("UsuarioBLL/ActivarUsuario: Consulta DB -> INICIO");
                int usersActivated = _clHelper.ActivarUsuario(header, body);
                Log.Information("UsuarioBLL/ActivarUsuario: Consulta DB -> RESPUESTA");
                
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("USR_ACT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.UsuarioActivados = usersActivated;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ActivarUsuario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionEdicionUsuarioResponse CrearUsuarios(CreacionUsuarioRequest request)
        {
            CreacionEdicionUsuarioResponse response = new CreacionEdicionUsuarioResponse();
            CreacionEdicionUsuarioResponseBody bodyResponse = new CreacionEdicionUsuarioResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();

            HeaderRequest header = request.HeaderRequest;
            CreacionUsuarioRequestBody body = request.BodyRequest;

            try
            {
                //create Log
                Log.Information("UsuarioBLL/CrearUsuarios: Consulta DB -> INICIO");
                long UserId = _clHelper.CrearUsuario(header, body);
                Log.Information("UsuarioBLL/CrearUsuarios: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("USR_CREA_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.UsuarioId = UserId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/CrearUsuarios: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public InactivacionUsuarioResponse InactivarUsuario(InactivacionUsuarioRequest userDeactivateRequestDto)
        {
            InactivacionUsuarioResponse response = new InactivacionUsuarioResponse();
            InactivacionUsuarioResponseBody bodyResponse = new InactivacionUsuarioResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = userDeactivateRequestDto.HeaderRequest;
                InactivacionUsuarioRequestBody body = userDeactivateRequestDto.BodyRequest;

                //create Log
                Log.Information("UsuarioBLL/InactivarUsuario: Consulta DB -> INICIO");
                int usersDeactivated = _clHelper.InactivarUsuario(header, body);
                Log.Information("UsuarioBLL/InactivarUsuario: Consulta DB -> RESPUESTA");
                
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("USR_INACT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.UsuarioInactivados = usersDeactivated;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/InactivarUsuario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EliminacionUsuarioResponse EliminarUsuarios(EliminacionUsuarioRequest deleteRequestDto)
        {
            EliminacionUsuarioResponse response = new EliminacionUsuarioResponse();
            EliminacionUsuarioResponseBody bodyResponse = new EliminacionUsuarioResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();

            HeaderRequest header = deleteRequestDto.HeaderRequest;
            EliminacionUsuarioRequestBody body = deleteRequestDto.BodyRequest;

            try
            {
                //create Log
                Log.Information("UsuarioBLL/EliminarUsuarios: Consulta DB -> INICIO");
                long UserId = _clHelper.EliminarUsuario(header, body);
                Log.Information("UsuarioBLL/EliminarUsuarios: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("USR_ELIM_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.UsuarioId = UserId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/EliminarUsuarios: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaUsuarioResponse ObtenerUsuarioPorId(ConsultaUsuarioRequest request)
        {
            HeaderRequest header = request.HeaderRequest;
            ConsultaUsuarioRequestBody body = request.BodyRequest;
            try
            {
                ConsultaUsuarioResponse response = new ConsultaUsuarioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaUsuarioResponseBody bodyResponse = new ConsultaUsuarioResponseBody();
                UsuarioDto user = new UsuarioDto();

                Log.Information("UsuarioBLL/ObtenerUsuarioPorId: Consulta DB -> INICIO");
                user = _clHelper.ObtenerUsuarioPorId(header, body);
                Log.Information("UsuarioBLL/ObtenerUsuarioPorId: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (user != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Usuario = user;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ObtenerUsuarioPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ActualizarClaveResponse ActualizarClave(ActualizarClaveRequest request)
        {
            HeaderRequest header = request.HeaderRequest;
            ActualizarClaveRequestBody body = request.BodyRequest;
            try
            {
                ActualizarClaveResponse response = new ActualizarClaveResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ActualizarClaveResponseBody bodyResponse = new ActualizarClaveResponseBody();

                string claveVieja = body.ClaveVieja;
                body.ClaveVieja = "**************";
                string claveNueva = body.ClaveNueva;
                body.ClaveNueva = "**************";
                request.BodyRequest = body;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                Log.Information($"UsuarioBLL/ActualizarClave: Consulta Api Banco Usuario {body.Usuario} -> INICIO");
                bool actualizado = _bancoBLL.ActualizarCredenciales(body.Usuario, claveVieja, claveNueva, header.UserName, header.StationIp, "USUARIO", DateTime.Now, body.Usuario, ref mensaje);
                Log.Information($"UsuarioBLL/ActualizarClave: Consulta Api Banco Usuario {body.Usuario} -> RESPUESTA");
                Log.Information($"UsuarioBLL/ActualizarClave: Consulta Api Banco Mensaje {mensaje.CodigoOrigen}-{mensaje.DescripcionOrigen} -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (actualizado)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Actualizado = actualizado;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ActualizarClave: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ComprobarComplejidadClaveResponse ComprobarComplejidadClave(ComprobarComplejidadClaveRequest request)
        {
            HeaderRequest header = request.HeaderRequest;
            ComprobarComplejidadClaveRequestBody body = request.BodyRequest;
            try
            {
                ComprobarComplejidadClaveResponse response = new ComprobarComplejidadClaveResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ComprobarComplejidadClaveResponseBody bodyResponse = new ComprobarComplejidadClaveResponseBody();

                string claveVieja = body.Clave;
                body.Clave = "**************";
                request.BodyRequest = body;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                Log.Information($"UsuarioBLL/ComprobarComplejidadClave: Consulta Api Banco Usuario -> INICIO");
                bool resultado = _bancoBLL.ComprobarComplejidadCredenciales(claveVieja, header.UserName, header.StationIp, "USUARIO", DateTime.Now, "ComprobarComplejidadClave", ref mensaje);
                Log.Information($"UsuarioBLL/ComprobarComplejidadClave: Consulta Api Banco Usuario -> RESPUESTA");
                Log.Information($"UsuarioBLL/ComprobarComplejidadClave: Consulta Api Banco Mensaje {mensaje.CodigoOrigen}-{mensaje.DescripcionOrigen} -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Resultado = resultado;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ComprobarComplejidadClave: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultarDataUsuarioResponse ConsultarDataUsuario(ConsultarDataUsuarioRequest request)
        {
            HeaderRequest header = request.HeaderRequest;
            ConsultarDataUsuarioRequestBody body = request.BodyRequest;
            try
            {
                ConsultarDataUsuarioResponse response = new ConsultarDataUsuarioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultarDataUsuarioResponseBody bodyResponse = new ConsultarDataUsuarioResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                Log.Information($"UsuarioBLL/ConsultarDataUsuario: Consulta Api Banco Usuario -> INICIO");
                DTOs.EXT.Response.Auth.ConsultarUsuarioResponse.ConsultarUsuarioResult resultado = _bancoBLL.ConsultarUsuario(body.Usuario, header.UserName, header.StationIp, "USUARIO", DateTime.Now, body.Usuario, ref mensaje);
                Log.Information($"UsuarioBLL/ConsultarDataUsuario: Consulta Api Banco Usuario -> RESPUESTA");
                Log.Information($"UsuarioBLL/ConsultarDataUsuario: Consulta Api Banco Mensaje {mensaje.CodigoOrigen}-{mensaje.DescripcionOrigen} -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;

                    //Create Body Response
                    bodyResponse.Bloqueado = resultado.Bloqueado;
                    bodyResponse.Agencia = resultado.Agencia;
                    bodyResponse.Usuario = resultado.Usuario;
                    bodyResponse.Cedula = resultado.Cedula;
                    bodyResponse.Nombre = resultado.Nombre;
                    bodyResponse.UltimoLogin = !string.IsNullOrEmpty(resultado.UltimoLogin)? DateTime.Parse(resultado.UltimoLogin) : null;
                    bodyResponse.UltimoLoginFallido = !string.IsNullOrEmpty(resultado.UltimoLoginFallido) ? DateTime.Parse(resultado.UltimoLoginFallido) : null;
                    bodyResponse.IpLoginActual = request.HeaderRequest.StationIp;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }                

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ConsultarDataUsuario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public AutenticacionUsuarioResponse ObtenerPerfilUsuario(AutenticacionUsuarioRequest request)
        {
            HeaderRequest header = request.HeaderRequest;
            AutenticacionUsuarioRequestBody body = request.BodyRequest;
            try
            {
                AutenticacionUsuarioResponse response = new AutenticacionUsuarioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                AutenticacionUsuarioResponseBody bodyResponse = new AutenticacionUsuarioResponseBody();
                PerfilUsuario userProfile = new PerfilUsuario();
                Usuario userEntity = new Usuario();

                Log.Information("UsuarioBLL/ObtenerPerfilUsuario: Consulta DB Nombre de Usuario -> INICIO");
                userEntity = _clHelper.ObtenerUsuarioPorNombre(header, body);
                Log.Information("UsuarioBLL/ObtenerPerfilUsuario: Consulta DB Nombre de Usuario -> RESPUESTA");
                if (userEntity != null)
                {
                    if (userEntity.Estado == "ACTIVO")
                    {
                        //create Log
                        //enmascaramiento de las credenciales para registrar en LOG
                        string userCredential = body.Credenciales;
                        body.Credenciales = "**************";
                        request.BodyRequest = body;

                        ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                        Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: Consulta Api Banco Usuario {body.Usuario} -> INICIO");
                        bool estaAutenticado = _bancoBLL.ValidarCredenciales(body.Usuario, userCredential, header.UserName,header.StationIp,"USUARIO",DateTime.Now,body.Usuario, ref mensaje);
                        Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: Consulta Api Banco Usuario {body.Usuario} -> RESPUESTA");
                        Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: Consulta Api Banco Mensaje {mensaje.CodigoOrigen}-{mensaje.DescripcionOrigen} -> RESPUESTA");
                        if (estaAutenticado)
                        {
                            Log.Information("UsuarioBLL/ObtenerPerfilUsuario: Consulta DB Perfil -> INICIO");
                            userProfile = _clHelper.ObtenerPerfilUsuario(body.Aplicacion, userEntity);
                            Log.Information("UsuarioBLL/ObtenerPerfilUsuario: Consulta DB Perfil -> RESPUESTA");
                            //Create Header response
                            headerResponseDto.returnCode = "OK";
                            headerResponseDto.returnMessage = "OK";
                            if (userProfile != null)
                            {
                                bodyResponse.Usuario = userProfile;
                                bodyResponse.Usuario.UltimaSesionIP = request.HeaderRequest.StationIp;
                                headerResponseDto.currentPage = 1;
                                headerResponseDto.pageSize = header.PageSize;
                                headerResponseDto.totalRecords = 1;
                                headerResponseDto.totalPages = 1;
                            }
                            else
                            {
                                Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: El usuario {body.Usuario} no tiene acceso a esta aplicacion.");
                                headerResponseDto.returnCode = "FAILEDLOGIN";
                                headerResponseDto.returnMessage = "Estimado cliente, no posee permisos para ingresar a esta aplicacion.";
                                headerResponseDto.currentPage = 0;
                                headerResponseDto.pageSize = header.PageSize;
                                headerResponseDto.totalRecords = 0;
                                headerResponseDto.totalPages = 0;
                            }
                        }
                        else //Wrong Credential
                        {
                            Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: El usuario {body.Usuario} ha ingresado credenciales incorrectas.");
                            int iAffected = _clHelper.ActualizarIntentosFallidos(userEntity);

                            headerResponseDto.returnCode = "FAILEDLOGIN";
                            headerResponseDto.returnMessage = "Estimado cliente, la combinación de usuario y contraseña ingresado es incorrecta.";
                            headerResponseDto.currentPage = 0;
                            headerResponseDto.pageSize = header.PageSize;
                            headerResponseDto.totalRecords = iAffected;
                            headerResponseDto.totalPages = 0;
                        }
                    } //User Inactive
                    else if (userEntity.Estado == "INACTIVO")
                    {
                        headerResponseDto.returnCode = "INACTIVE";
                        headerResponseDto.returnMessage = "Estimado cliente, su usuario se encuentra inactivo.";
                        headerResponseDto.currentPage = 0;
                        headerResponseDto.pageSize = header.PageSize;
                        headerResponseDto.totalRecords = 0;
                        headerResponseDto.totalPages = 0;
                        Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: El usuario {body.Usuario} está inactivo.");
                    }
                    else if (userEntity.Estado == "BLOQUEADO")
                    {
                        headerResponseDto.returnCode = "BLOCKED";
                        headerResponseDto.returnMessage = "Estimado cliente, su usuario se encuentra bloqueado.";
                        headerResponseDto.currentPage = 0;
                        headerResponseDto.pageSize = header.PageSize;
                        headerResponseDto.totalRecords = 0;
                        headerResponseDto.totalPages = 0;
                        Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: El usuario {body.Usuario} está bloqueado.");
                    }

                }
                else //User not found
                {
                    Log.Information($"UsuarioBLL/ObtenerPerfilUsuario: No existe un usuario con nombre {body.Usuario}");
                    headerResponseDto.returnCode = "NOTFOUND";
                    headerResponseDto.returnMessage = "Estimado cliente, el usuario no ha sido creado en el aplicativo de seguridad.";
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = header.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ObtenerPerfilUsuario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaUsuariosResponse ListarUsuarios(ListaUsuariosRequest request)
        {
            ListaUsuariosResponse response = new ListaUsuariosResponse();
            ListaUsuariosResponseBody bodyResponse = new ListaUsuariosResponseBody();
            QueryUsuarioResponse users;
            HeaderResponse headerResponseDto = new HeaderResponse();

            ListaUsuariosRequestBody body = request.BodyRequest;
            HeaderRequest header = request.HeaderRequest;

            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            try
            {
                Log.Information("UsuarioBLL/ListarUsuarios: Consulta DB -> INICIO");
                users = _clHelper.ListarUsuarios(header, body);
                Log.Information("UsuarioBLL/ListarUsuarios: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = users.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Usuarios = users.Usuarios;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ListarUsuarios: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionEdicionUsuarioResponse ActualizarUsuarios(CreacionUsuarioRequest request)
        {
            CreacionEdicionUsuarioResponse response = new CreacionEdicionUsuarioResponse();
            CreacionEdicionUsuarioResponseBody bodyResponse = new CreacionEdicionUsuarioResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();

            HeaderRequest header = request.HeaderRequest;
            CreacionUsuarioRequestBody body = request.BodyRequest;

            try
            {
                //create Log
                Log.Information("UsuarioBLL/ActualizarUsuarios: Consulta DB -> INICIO");
                long UserId = _clHelper.ActualizarUsuario(header, body);
                Log.Information("UsuarioBLL/ActualizarUsuarios: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("USR_EDIT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.UsuarioId = UserId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ActualizarUsuarios: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaRolesUsuarioResponse ConsultarRolesUsuario(ConsultaRolesUsuarioRequest request)
        {
            ConsultaRolesUsuarioResponse response = new ConsultaRolesUsuarioResponse();
            ConsultaRolesUsuarioResponseBody bodyResponse = new ConsultaRolesUsuarioResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();

            HeaderRequest header = request.HeaderRequest;
            ConsultaRolesUsuarioRequestBody body = request.BodyRequest;

            try
            {
                //create Log
                Log.Information("UsuarioBLL/ConsultarRolesUsuario: Consulta DB -> INICIO");
                RolesUsuarioDto rolUsuario = _clHelper.ConsultarRolesUsuario(header, body);
                Log.Information("UsuarioBLL/ConsultarRolesUsuario: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolesUsuario = rolUsuario;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ConsultarRolesUsuario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ActualizarRolesUsuarioResponse ActualizarRolesUsuario(ActualizarRolesUsuarioRequest request)
        {
            ActualizarRolesUsuarioResponse response = new ActualizarRolesUsuarioResponse();
            ActualizarRolesUsuarioResponseBody bodyResponse = new ActualizarRolesUsuarioResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();

            HeaderRequest header = request.HeaderRequest;
            ActualizarRolesUsuarioRequestBody body = request.BodyRequest;

            try
            {
                //create Log
                Log.Information("UsuarioBLL/ActualizarRolesUsuario: Consulta DB -> INICIO");
                RolesUsuarioDto rolUsuario = _clHelper.ActualizarRolesUsuario(header, body);
                Log.Information("UsuarioBLL/ActualizarRolesUsuario: Consulta DB -> RESPUESTA");
                
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("USR_ROLEDIT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolesUsuario = rolUsuario;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ActualizarRolesUsuario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaUsuariosReporteResponse ListarUsuariosReporte(ListaUsuariosReporteRequest request)
        {
            ListaUsuariosReporteResponse response = new ListaUsuariosReporteResponse();
            ListaUsuariosReporteResponseBody bodyResponse = new ListaUsuariosReporteResponseBody();
            QueryUsuarioReporteResponse users;
            HeaderResponse headerResponseDto = new HeaderResponse();

            ListaUsuariosReporteRequestBody body = request.BodyRequest;
            HeaderRequest header = request.HeaderRequest;

            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            try
            {
                Log.Information("UsuarioBLL/ListarUsuariosReporte: Consulta DB -> INICIO");
                users = _clHelper.ListarUsuarioReporte(header, body);
                Log.Information("UsuarioBLL/ListarUsuariosReporte: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = users.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Usuarios = users.Usuarios;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("UsuarioBLL/ListarUsuariosReporte: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
