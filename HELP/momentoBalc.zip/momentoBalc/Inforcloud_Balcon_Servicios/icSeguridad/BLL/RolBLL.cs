﻿using icCommon.DTOs.API;
using icCommon.Mensajes;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Roles;
using icSeguridad.DTOs.API.Response;
using icSeguridad.DTOs.API.Response.Roles;
using icSeguridad.DTOs.DB.Response.Roles;
using icSeguridad.Models;
using Serilog;
using System;

namespace icSeguridad.BLL
{
    public class RolBLL : IRolBLL
    {
        private readonly IRolDLL _clHelper;
        private readonly IMensajeoDLL _mHelper;
        public RolBLL(IRolDLL dHelper, IMensajeoDLL mHelper)
        {
            _clHelper = dHelper;
            _mHelper = mHelper;
        }

        public ActivacionRolesResponse ActivarRoles(ActivacionRolRequest companiesActivateRequestDto)
        {
            ActivacionRolesResponse response = new ActivacionRolesResponse();
            ActivacionRolesResponseBody bodyResponse = new ActivacionRolesResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = companiesActivateRequestDto.HeaderRequest;
                ActivacionRolRequestBody body = companiesActivateRequestDto.BodyRequest;
                //create Log
                Log.Information("RolBLL/ActivarRoles: Consulta DB -> INICIO");
                int profilesActivated = _clHelper.ActivarRol(header, body);
                Log.Information("RolBLL/ActivarRoles: Consulta DB -> RESPUESTA"); 
                
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("ROL_ACT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolesActivados = profilesActivated;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ActivarRoles: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionEdicionRolResponse CrearRol(CreacionRolRequest request)
        {
            CreacionEdicionRolResponse response = new CreacionEdicionRolResponse();
            CreacionEdicionRolResponseBody bodyResponse = new CreacionEdicionRolResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                CreacionRolRequestBody body = request.BodyRequest;

                //create Log
                Log.Information("RolBLL/CrearRol: Consulta DB -> INICIO");
                long ProfileId = _clHelper.CrearRol(header, body);
                Log.Information("RolBLL/CrearRol: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("ROL_CREA_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolId = ProfileId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/CrearRol: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public InactivacionRolResponse InactivarRol(InactivacionRolRequest companiesDeactivateRequestDto)
        {
            InactivacionRolResponse response = new InactivacionRolResponse();
            InactivacionRolResponseBody bodyResponse = new InactivacionRolResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = companiesDeactivateRequestDto.HeaderRequest;
                InactivacionRolRequestBody body = companiesDeactivateRequestDto.BodyRequest;

                //create Log
                Log.Information("RolBLL/InactivarRol: Consulta DB -> INICIO");
                int profilesDeactivated = _clHelper.DesactivarRol(header, body);
                Log.Information("RolBLL/InactivarRol: Consulta DB -> RESPUESTA");
                
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("ROL_INACT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolesInactivados = profilesDeactivated;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/InactivarRol: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EliminacionRolResponse EliminarRol(EliminacionRolRequest profileRequestDto)
        {
            EliminacionRolResponse response = new EliminacionRolResponse();
            EliminacionRolResponseBody bodyResponse = new EliminacionRolResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = profileRequestDto.HeaderRequest;
                EliminacionRolRequestBody body = profileRequestDto.BodyRequest;

                //create Log
                Log.Information("RolBLL/EliminarRol: Consulta DB -> INICIO");
                int RolesEliminados = _clHelper.EliminarRol(header, body);
                Log.Information("RolBLL/EliminarRol: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("ROL_ELIM_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolesEliminados = RolesEliminados;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/EliminarRol: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaRolResponse ObtenerRolPorId(ConsultaRolRequest request)
        {
            try
            {
                ConsultaRolResponse response = new ConsultaRolResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaRolResponseBody bodyResponse = new ConsultaRolResponseBody();
                RolDto profile = new RolDto();

                Log.Information("RolBLL/ObtenerRolPorId: Consulta DB -> INICIO");
                profile = _clHelper.ObtenerRolPorId(request.HeaderRequest, request.BodyRequest);
                Log.Information("RolBLL/ObtenerRolPorId: Consulta DB -> RESPUESTA"); 
                
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (profile != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = request.HeaderRequest.PageSize;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = request.HeaderRequest.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Rol = profile;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ObtenerRolPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaRolesResponse ListarRoles(ListaRolesRequest request)
        {
            ListaRolesResponse response = new ListaRolesResponse();
            ListaRolesResponseBody bodyResponse = new ListaRolesResponseBody();
            QueryRolesResponse profiles;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                Log.Information("RolBLL/ListarRoles: Consulta DB -> INICIO");
                profiles = _clHelper.ListarRoles(request.HeaderRequest, request.BodyRequest);
                Log.Information("RolBLL/ListarRoles: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = request.HeaderRequest.PageRequested;
                headerResponseDto.pageSize = request.HeaderRequest.PageSize;
                headerResponseDto.totalRecords = profiles.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Roles = profiles.Roles;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ListarRoles: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaRolesUsuarioResponse ListarRolesUsuario(ListaRolesRequest request)
        {
            ListaRolesUsuarioResponse response = new();
            ListaRolesUsuarioResponseBody bodyResponse = new();
            QueryRolesUsuarioResponse profiles;
            HeaderResponse headerResponseDto = new();
            try
            {
                Log.Information("RolBLL/ListarRolesUsuario: Consulta DB -> INICIO");
                profiles = _clHelper.ListarRolesUsuario(request.HeaderRequest, request.BodyRequest);
                Log.Information("RolBLL/ListarRolesUsuario: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = request.HeaderRequest.PageRequested;
                headerResponseDto.pageSize = request.HeaderRequest.PageSize;
                headerResponseDto.totalRecords = profiles.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolesUsuario = profiles.Roles;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ListarRolesUsuario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionEdicionRolResponse ActualizarRol(EdicionRolRequest request)
        {
            CreacionEdicionRolResponse response = new CreacionEdicionRolResponse();
            CreacionEdicionRolResponseBody bodyResponse = new CreacionEdicionRolResponseBody();
            long ProfileId;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                EdicionRolRequestBody body = request.BodyRequest;

                //create Log
                Log.Information("RolBLL/ActualizarRol: Consulta DB -> INICIO");
                ProfileId = _clHelper.ActualizarRol(header, body);
                Log.Information("RolBLL/ActualizarRol: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("ROL_EDIT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.RolId = ProfileId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ActualizarRol: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EdicionPermisosRolResponse ActualizarPermisosRol(EdicionPermisosRolRequest profileRequestDto)
        {
            EdicionPermisosRolResponse response = new EdicionPermisosRolResponse();
            EdicionPermisosRolResponseBody bodyResponse = new EdicionPermisosRolResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = profileRequestDto.HeaderRequest;
                EdicionPermisosRolRequestBody body = profileRequestDto.BodyRequest;

                //create Log
                Log.Information("RolBLL/ActualizarPermisosRol: Consulta DB -> INICIO");
                int profilesActivated = _clHelper.ActualizarPermisosRol(header, body);
                Log.Information("RolBLL/ActualizarPermisosRol: Consulta DB -> RESPUESTA");                

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("ROL_PEREDIT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.AccesosModificados = profilesActivated;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ActualizarPermisosRol: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaRolResponse ObtenerPermisosRolPorId(ConsultaPermisosRolRequest request)
        {
            try
            {
                ConsultaRolResponse response = new ConsultaRolResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaRolResponseBody bodyResponse = new ConsultaRolResponseBody();
                RolDto profile = new RolDto();

                Log.Information("RolBLL/ObtenerPermisosRolPorId: Consulta DB -> INICIO");
                profile = _clHelper.ObtenerPermisosRolPorId(request.HeaderRequest, request.BodyRequest);
                Log.Information("RolBLL/ObtenerPermisosRolPorId: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (profile != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = request.HeaderRequest.PageSize;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = request.HeaderRequest.PageSize;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Rol = profile;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ObtenerPermisosRolPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaRolesReporteResponse ListarRolesReporte(ListaRolesReporteRequest request)
        {
            ListaRolesReporteResponse response = new ListaRolesReporteResponse();
            ListaRolesReporteResponseBody bodyResponse = new ListaRolesReporteResponseBody();
            QueryRolesReporteResponse profiles;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                Log.Information("RolBLL/ListarRolesReporte: Consulta DB -> INICIO");
                profiles = _clHelper.ListarRolesReporte(request.HeaderRequest, request.BodyRequest);
                Log.Information("RolBLL/ListarRolesReporte: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = request.HeaderRequest.PageRequested;
                headerResponseDto.pageSize = request.HeaderRequest.PageSize;
                headerResponseDto.totalRecords = profiles.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Roles = profiles.Roles;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("RolBLL/ListarRolesReporte: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
