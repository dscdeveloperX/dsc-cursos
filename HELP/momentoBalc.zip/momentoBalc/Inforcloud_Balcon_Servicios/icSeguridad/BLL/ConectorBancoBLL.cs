﻿using icCommon.ConexionApi;
using icCommon.ManejoErrores;
using icCommon.ManejoErrores.Utils;
using icCommon.Modelos;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DTOs.EXT.Request.Auth;
using icSeguridad.DTOs.EXT.Response.Auth;
using Serilog;
using System;

namespace icSeguridad.BLL
{
    public class ConectorBancoBLL : IConectorBancoBLL
    {
        private readonly IConectorApi _apiConnector;
        private readonly IMapeoMensajesError _errorHelper;

        public ConectorBancoBLL(IConectorApi apiConnector, IMapeoMensajesError errorHelper)
        {
            _apiConnector = apiConnector;
            _errorHelper = errorHelper;
        }

        public bool ValidarCredenciales(string usuarioCred, string cred,string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ValidarCredencialesRequest.Envelope envelope = new ValidarCredencialesRequest.Envelope { 
                Body = new ValidarCredencialesRequest.Body { 
                    ValidarCredenciales = new ValidarCredencialesRequest.ValidarCredenciales { 
                        Credenciales = new ValidarCredencialesRequest.Credenciales { 
                            Clave = cred,
                            Usuario = usuarioCred
                        }
                    }
                }
            };
                        
            string serviceName = Constantes.Tramas.VALIDAR_CREDENCIALES;

            Log.Information($"ConectorBancoBLL/ValidarCredenciales: {serviceName} -> REQUEST API BANCO");

            ValidarCredencialesResponse.ValidarCredencialesResponseDto result = _apiConnector.PostApi<ValidarCredencialesResponse.ValidarCredencialesResponseDto, ValidarCredencialesRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestNamespaces);

            Log.Information($"ConectorBancoBLL/ValidarCredenciales: {serviceName} -> RESPONSE API BANCO");

            if (result.Mensaje.Codigo != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.Codigo);
                if (codeResponse.CodigoError == "NOT_REGISTERED")
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.Codigo, result.Mensaje.Mensaje);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return result.ValidarCredencialesResult;
        }

        public bool ActualizarCredenciales(string usuarioCred, string viejaCred, string nuevaCred, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ActualizarCredencialesRequest.Envelope envelope = new ActualizarCredencialesRequest.Envelope
            {
                Body = new ActualizarCredencialesRequest.Body
                {
                    ActualizarCredenciales = new ActualizarCredencialesRequest.ActualizarCredenciales
                    {
                        CredencialesActualizadas = new ActualizarCredencialesRequest.CredencialesActualizadas
                        {
                            ClaveVieja = viejaCred,
                            ClaveNueva = nuevaCred,
                            Usuario = usuarioCred
                        }
                    }
                }
            };

            string serviceName = Constantes.Tramas.ACTUALIZAR_CREDENCIALES;

            Log.Information($"ConectorBancoBLL/ActualizarCredenciales: {serviceName} -> REQUEST API BANCO");

            ActualizarCredencialesResponse.ActualizarCredencialesResponseDto result = _apiConnector.PostApi<ActualizarCredencialesResponse.ActualizarCredencialesResponseDto, ActualizarCredencialesRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestNamespaces);

            Log.Information($"ConectorBancoBLL/ActualizarCredenciales: {serviceName} -> RESPONSE API BANCO");

            if (result.Mensaje.Codigo != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.Codigo);
                if (codeResponse.CodigoError == "NOT_REGISTERED")
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.Codigo, result.Mensaje.Mensaje);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return result.ActualizarCredencialesResult;
        }

        public bool ComprobarComplejidadCredenciales(string cred, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ComprobarComplejidadDeClaveRequest.Envelope envelope = new ComprobarComplejidadDeClaveRequest.Envelope
            {
                Body = new ComprobarComplejidadDeClaveRequest.Body
                {
                    ComprobarComplejidadDeClave = new ComprobarComplejidadDeClaveRequest.ComprobarComplejidadDeClave
                    {
                        Credenciales = new ComprobarComplejidadDeClaveRequest.Credenciales
                        {
                            Clave = cred
                        }
                    }
                }
            };

            string serviceName = Constantes.Tramas.COMPROBAR_COMPLEJIDAD_CREDENCIALES;

            Log.Information($"ConectorBancoBLL/ComprobarComplejidadCredenciales: {serviceName} -> REQUEST API BANCO");

            ComprobarComplejidadDeClaveResponse.ComprobarComplejidadDeClaveResponseDto result = _apiConnector.PostApi<ComprobarComplejidadDeClaveResponse.ComprobarComplejidadDeClaveResponseDto, ComprobarComplejidadDeClaveRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestNamespaces);

            Log.Information($"ConectorBancoBLL/ComprobarComplejidadCredenciales: {serviceName} -> RESPONSE API BANCO");

            if (result.Mensaje.Codigo != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.Codigo);
                if (codeResponse.CodigoError == "NOT_REGISTERED")
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.Codigo, result.Mensaje.Mensaje);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return result.ComprobarComplejidadDeClaveResult;
        }

        public ConsultarUsuarioResponse.ConsultarUsuarioResult ConsultarUsuario(string usuarioCred, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultarUsuarioRequest.Envelope envelope = new ConsultarUsuarioRequest.Envelope
            {
                Body = new ConsultarUsuarioRequest.Body
                {
                    ConsultarUsuario = new ConsultarUsuarioRequest.ConsultarUsuario
                    {
                        Usuario = new ConsultarUsuarioRequest.Credenciales { 
                            Usuario = usuarioCred
                        }
                    }
                }
            };

            string serviceName = Constantes.Tramas.CONSULTAR_USUARIO;

            Log.Information($"ConectorBancoBLL/ConsultarUsuario: {serviceName} -> REQUEST API BANCO");

            ConsultarUsuarioResponse.ConsultarUsuarioResponseDto result = _apiConnector.PostApi<ConsultarUsuarioResponse.ConsultarUsuarioResponseDto, ConsultarUsuarioRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestNamespaces);

            Log.Information($"ConectorBancoBLL/ConsultarUsuario: {serviceName} -> RESPONSE API BANCO");

            if (result.Mensaje.Codigo != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.Codigo);
                if (codeResponse.CodigoError == "NOT_REGISTERED")
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.Codigo, result.Mensaje.Mensaje);
                }
                else {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
               
            }

            return result.ConsultarUsuarioResult;
        }
    }
}
