﻿using icSeguridad.DTOs.API.Request.Roles;
using icSeguridad.DTOs.API.Response.Roles;

namespace icSeguridad.BLL.Interfaces
{
    public interface IRolBLL
    {
        ListaRolesResponse ListarRoles(ListaRolesRequest profileRequestDto);
        ListaRolesUsuarioResponse ListarRolesUsuario(ListaRolesRequest profileRequestDto);
        CreacionEdicionRolResponse CrearRol(CreacionRolRequest profileRequestDto);
        CreacionEdicionRolResponse ActualizarRol(EdicionRolRequest profileRequestDto);
        EdicionPermisosRolResponse ActualizarPermisosRol(EdicionPermisosRolRequest profileRequestDto);
        EliminacionRolResponse EliminarRol(EliminacionRolRequest profileRequestDto);
        ConsultaRolResponse ObtenerRolPorId(ConsultaRolRequest request);
        ConsultaRolResponse ObtenerPermisosRolPorId(ConsultaPermisosRolRequest request);
        ActivacionRolesResponse ActivarRoles(ActivacionRolRequest companiesActivateRequestDto);
        InactivacionRolResponse InactivarRol(InactivacionRolRequest companiesDeactivateRequestDto);
        ListaRolesReporteResponse ListarRolesReporte(ListaRolesReporteRequest profileRequestDto);
    }
}
