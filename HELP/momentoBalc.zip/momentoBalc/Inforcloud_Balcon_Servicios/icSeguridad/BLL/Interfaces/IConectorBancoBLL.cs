﻿using icCommon.Modelos;
using icSeguridad.DTOs.EXT.Request.Auth;
using icSeguridad.DTOs.EXT.Response.Auth;
using System;

namespace icSeguridad.BLL.Interfaces
{
    public interface IConectorBancoBLL
    {
        bool ValidarCredenciales(string usuarioCred, string cred, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        bool ActualizarCredenciales(string usuarioCred, string viejaCred, string nuevaCred, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        bool ComprobarComplejidadCredenciales(string cred, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        ConsultarUsuarioResponse.ConsultarUsuarioResult ConsultarUsuario(string usuarioCred, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
    }
}
