﻿using icSeguridad.DTOs.API.Request.Auditoria;
using icSeguridad.DTOs.API.Response.Auditoria;

namespace icSeguridad.BLL.Interfaces
{
    public interface IAuditoriaBLL
    {
        ConsultaAuditoriaResponse ListarAuditoria(ConsultaAuditoriaRequest request);
    }
}
