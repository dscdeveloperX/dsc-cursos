﻿using icSeguridad.DTOs.API.Request.Catalogos;
using icSeguridad.DTOs.API.Response.Catalogos;

namespace icSeguridad.BLL.Interfaces
{
    public interface ICatalogoBLL
    {
        ConsultaCatalogoResponse ObtenerCatalogoPorId(ConsultaCatalogoRequest request);
        ListaCatalogosResponse ListarCatalogos(ListaCatalogosRequest request);
        ListaNombreCatalogosResponse ListarNombresCatalogos(ListaNombreCatalogosRequest request);
        CreacionCatalogoResponse CrearCatalogo(CreacionCatalogoRequest request);
        EdicionCatalogoResponse ActualizarCatalogo(EdicionCatalogoRequest request);
        EliminacionCatalogoResponse EliminarCatalogo(EliminacionCatalogoRequest request);
    }
}
