﻿using icSeguridad.DTOs.API.Request.Aplicaciones;
using icSeguridad.DTOs.API.Response.Aplicaciones;

namespace icSeguridad.BLL.Interfaces
{
    public interface IAplicacionBLL
    {
        ListaAplicacionResponse ListarAplicaciones(ListaAplicacionesRequest applicationRequestDto);
        ActivacionAplicacionResponse ActivarAplicacion(ActivacionAplicacionRequest applicationActivateRequestDto);
        InactivacionAplicacionResponse InactivarAplicacion(InactivacionAplicacionRequest applicationDeactivateRequestDto);
        CreacionEdicionAplicacionResponse CrearAplicacion(CreacionAplicacionRequest newApp);
        CreacionEdicionAplicacionResponse ActualizarAplicacion(CreacionAplicacionRequest newApp);
        EliminacionAplicacioneResponse EliminarAplicacion(EliminacionAplicacionRequest deleteApps);
        ConsultaAplicacionResponse ObtenerAplicacionPorId(ConsultaAplicacionRequest request);
    }
}
