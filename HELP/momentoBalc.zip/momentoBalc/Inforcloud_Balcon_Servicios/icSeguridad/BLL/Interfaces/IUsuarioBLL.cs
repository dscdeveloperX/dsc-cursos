﻿using icSeguridad.DTOs.API.Request.Usuarios;
using icSeguridad.DTOs.API.Response.Usuarios;

namespace icSeguridad.BLL.Interfaces
{
    public interface IUsuarioBLL
    {
        ListaUsuariosResponse ListarUsuarios(ListaUsuariosRequest userRequestDto);
        CreacionEdicionUsuarioResponse CrearUsuarios(CreacionUsuarioRequest newApp);
        CreacionEdicionUsuarioResponse ActualizarUsuarios(CreacionUsuarioRequest updatedUser);
        EliminacionUsuarioResponse EliminarUsuarios(EliminacionUsuarioRequest deleteUsers);
        ConsultaUsuarioResponse ObtenerUsuarioPorId(ConsultaUsuarioRequest request);
        ActivacionUsuarioResponse ActivarUsuario(ActivacionUsuarioRequest userActivateRequestDto);
        InactivacionUsuarioResponse InactivarUsuario(InactivacionUsuarioRequest userDeactivateRequestDto);
        ConsultaRolesUsuarioResponse ConsultarRolesUsuario(ConsultaRolesUsuarioRequest request);
        ActualizarRolesUsuarioResponse ActualizarRolesUsuario(ActualizarRolesUsuarioRequest request);
        AutenticacionUsuarioResponse ObtenerPerfilUsuario(AutenticacionUsuarioRequest request);
        ActualizarClaveResponse ActualizarClave(ActualizarClaveRequest request);
        ComprobarComplejidadClaveResponse ComprobarComplejidadClave(ComprobarComplejidadClaveRequest request);
        ConsultarDataUsuarioResponse ConsultarDataUsuario(ConsultarDataUsuarioRequest request);
        ListaUsuariosReporteResponse ListarUsuariosReporte(ListaUsuariosReporteRequest userRequestDto);
    }
}
