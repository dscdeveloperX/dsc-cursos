﻿using icCommon.DB;
using icCommon.DTOs.API;
using icCommon.DTOs.DB;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Auditoria;
using icSeguridad.DTOs.API.Response.Auditoria;
using Serilog;
using System;

namespace icSeguridad.BLL
{
    public class AuditoriaBLL : IAuditoriaBLL
    {
        private readonly IAuditoria _clHelper;
        public AuditoriaBLL(IAuditoria dHelper)
        {
            _clHelper = dHelper;
        }

        public ConsultaAuditoriaResponse ListarAuditoria(ConsultaAuditoriaRequest request)
        {
            ConsultaAuditoriaResponse response = new ConsultaAuditoriaResponse();
            ConsultaAuditoriaResponseBody bodyResponse = new ConsultaAuditoriaResponseBody();
            QueryAuditoriaResponse users;
            HeaderResponse headerResponseDto = new HeaderResponse();

            ConsultaAuditoriaRequestBody body = request.BodyRequest;
            HeaderRequest header = request.HeaderRequest;

            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            try
            {
                Log.Information("AuditoriaBLL/ListarAuditoria: Consulta DB -> INICIO");
                users = _clHelper.ListarAuditoria(body.Usuario, body.FechaDesde, body.FechaHasta, itemsPerPage, page);
                Log.Information("AuditoriaBLL/ListarAuditoria: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = users.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Auditoria = users.Auditoria;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AuditoriaBLL/ListarAuditoria: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
