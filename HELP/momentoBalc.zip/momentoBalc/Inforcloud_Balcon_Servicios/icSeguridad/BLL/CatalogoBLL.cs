﻿using icCommon.DTOs.API;
using icCommon.Mensajes;
using icSeguridad.BLL.Interfaces;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Catalogos;
using icSeguridad.DTOs.API.Response;
using icSeguridad.DTOs.API.Response.Catalogos;
using icSeguridad.DTOs.DB.Response.Catalogos;
using icSeguridad.Models;
using Serilog;
using System;

namespace icSeguridad.BLL
{
    public class CatalogoBLL : ICatalogoBLL
    {
        private readonly ICatalogoDLL _clHelper;
        private readonly IMensajeoDLL _mHelper;
        public CatalogoBLL(ICatalogoDLL dHelper, IMensajeoDLL mHelper)
        {
            _clHelper = dHelper;
            _mHelper = mHelper;
        }

        public CreacionCatalogoResponse CrearCatalogo(CreacionCatalogoRequest catalogueCreateRequestDto)
        {
            CreacionCatalogoResponse response = new CreacionCatalogoResponse();
            CreacionCatalogoResponseBody bodyResponse = new CreacionCatalogoResponseBody();
            int cataloguesCount = 0;
            string message = string.Empty;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = catalogueCreateRequestDto.HeaderRequest;
                CreacionCatalogoRequestBody body = catalogueCreateRequestDto.BodyRequest;

                int itemsPerPage = header.PageSize;

                //Create Catalogue
                Log.Information("CatalogoBLL/CrearCatalogo: Consulta DB -> INICIO");
                long catalogos = _clHelper.CrearCatalogo(header, body);
                Log.Information("CatalogoBLL/CrearCatalogo: Consulta DB -> RESPUESTA");
                if (catalogos > 0)
                {
                    //Create Header response
                    headerResponseDto.returnCode = "OK";
                    headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("CAT_CREA_OK");
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    response.HeaderResponse = headerResponseDto;
                    bodyResponse.CatalogosCreados = Convert.ToInt32(cataloguesCount);
                    response.BodyResponse = bodyResponse;
                }
                else
                {
                    //Create Header response
                    headerResponseDto.returnCode = "WARNING";
                    headerResponseDto.returnMessage = message;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                    //Create Body Response
                    response.HeaderResponse = headerResponseDto;
                    bodyResponse.CatalogosCreados = Convert.ToInt32(cataloguesCount);
                    response.BodyResponse = bodyResponse;
                }
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("CatalogoBLL/CrearCatalogo: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EliminacionCatalogoResponse EliminarCatalogo(EliminacionCatalogoRequest catalogueDeleteRequestDto)
        {
            EliminacionCatalogoResponse response = new EliminacionCatalogoResponse();
            EliminacionCatalogoResponseBody bodyResponse = new EliminacionCatalogoResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = catalogueDeleteRequestDto.HeaderRequest;
                EliminacionCatalogoRequestBody body = catalogueDeleteRequestDto.BodyRequest;

                Log.Information("CatalogoBLL/EliminarCatalogo: Consulta DB -> INICIO");
                int cataloguesDeleted = _clHelper.EliminarCatalogos(header, body);
                Log.Information("CatalogoBLL/EliminarCatalogo: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("CAT_ELIM_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.CatalogosEliminados = cataloguesDeleted;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("CatalogoBLL/EliminarCatalogo: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaCatalogoResponse ObtenerCatalogoPorId(ConsultaCatalogoRequest request)
        {
            try
            {
                ConsultaCatalogoResponse response = new ConsultaCatalogoResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaCatalogoResponseBody bodyResponse = new ConsultaCatalogoResponseBody();
                Catalogo catalogue = new Catalogo();

                int itemsPerPage = request.HeaderRequest.PageSize;

                Log.Information("CatalogoBLL/ObtenerCatalogoPorId: Consulta DB -> INICIO");
                catalogue = _clHelper.ObtenerCatalogoPorId(request.HeaderRequest, request.BodyRequest);
                Log.Information("CatalogoBLL/ObtenerCatalogoPorId: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (catalogue != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Catalogo = catalogue;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("CatalogoBLL/ObtenerCatalogoPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaCatalogosResponse ListarCatalogos(ListaCatalogosRequest request)
        {
            ListaCatalogosResponse response = new ListaCatalogosResponse();
            ListaCatalogosResponseBody bodyResponse = new ListaCatalogosResponseBody();
            QueryCatalogosResponse catalogues;
            HeaderResponse headerResponseDto = new HeaderResponse();
            int page = request.HeaderRequest.PageRequested;
            int itemsPerPage = request.HeaderRequest.PageSize;

            try
            {
                Log.Information("CatalogoBLL/ListarCatalogos4: Consulta DB -> INICIO");
                catalogues = _clHelper.ListarCatalogos(request.HeaderRequest, request.BodyRequest);
                Log.Information("CatalogoBLL/ListarCatalogos5: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = catalogues.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Catalogos = catalogues.Catalogos;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("CatalogoBLL/ListarCatalogos6: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaNombreCatalogosResponse ListarNombresCatalogos(ListaNombreCatalogosRequest request)
        {
            ListaNombreCatalogosResponse response = new ListaNombreCatalogosResponse();
            ListaNombreCatalogosResponseBody bodyResponse = new ListaNombreCatalogosResponseBody();
            QueryNombreCatalogosResponse catalogues;
            HeaderResponse headerResponseDto = new HeaderResponse();
            int page = request.HeaderRequest.PageRequested;
            int itemsPerPage = request.HeaderRequest.PageSize;
            
            try
            {
                Log.Information("CatalogoBLL/ListarNombresCatalogos: Consulta DB -> INICIO");
                catalogues = _clHelper.ListarNombresCatalogos(request.HeaderRequest, request.BodyRequest);
                Log.Information("CatalogoBLL/ListarNombresCatalogos: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = catalogues.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.NombreCatalogos = catalogues.NombreCatalogos;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("CatalogoBLL/ListarNombresCatalogos: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EdicionCatalogoResponse ActualizarCatalogo(EdicionCatalogoRequest catalogueUpdateRequestDto)
        {
            EdicionCatalogoResponse response = new EdicionCatalogoResponse();
            EdicionCatalogoResponseBody bodyResponse = new EdicionCatalogoResponseBody();
            int CatalogueId;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = catalogueUpdateRequestDto.HeaderRequest;
                EdicionCatalogoRequestBody body = catalogueUpdateRequestDto.BodyRequest;

                Log.Information("CatalogoBLL/ActualizarCatalogo: Consulta DB -> INICIO");
                CatalogueId = _clHelper.ActualizarCatalogo(header, body);
                Log.Information("CatalogoBLL/ActualizarCatalogo: Consulta DB -> RESPUESTA"); 
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = _mHelper.ObtenerMensaje("CAT_EDIT_OK");
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.CatalogosEditados = CatalogueId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("CatalogoBLL/ActualizarCatalogo: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
