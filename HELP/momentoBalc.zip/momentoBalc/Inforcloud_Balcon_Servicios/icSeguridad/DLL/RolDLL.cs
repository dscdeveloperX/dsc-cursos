﻿using Dapper;
using icCommon.DB;
using icCommon.DTOs.DB;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Roles;
using icSeguridad.DTOs.DB.Response.Roles;
using icSeguridad.Models;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace icSeguridad.DLL
{
    public class RolDLL : IRolDLL
    {
        private readonly IProveedorConexion _config;
        private readonly IAuditoria _auditoria;

        const string ROL = "ROL";
        private readonly string SCHEMA = "";

        public RolDLL(IProveedorConexion proveedor, IAuditoria auditoria)
        {
            _config = proveedor;
            _auditoria = auditoria;
            SCHEMA = _config.ObtenerSchema();
        }

        public int ActivarRol(HeaderRequest header, ActivacionRolRequestBody body)
        {
            using (IDbConnection db = _config.ObtenerConexion())
            {
                string ids = "(" + string.Join(",", body.RolesIds) + ")";
                string getSql = $"Select * from [{SCHEMA}].[Rol] WHERE RolId in {ids} AND [Estado] = 'INACTIVO'; ";
                string activateSQL = $"UPDATE [{SCHEMA}].[Rol] SET Estado='ACTIVO' WHERE RolId in {ids};" +
                    $"SELECT @@ROWCOUNT; ";

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<Rol> roles = db.Query<Rol>(getSql, transaction: tran, commandType: CommandType.Text).ToList();

                        foreach (Rol app in roles)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.ACTIVAR);
                        }

                        var result = db.Query<int>(activateSQL, transaction: tran, commandType: CommandType.Text);

                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("RolDLL/ActivarRol: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("RolDLL/ActivarRol: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
        public long CrearRol(HeaderRequest header, CreacionRolRequestBody body)
        {
            Rol newRol = body.Rol;

            var dbPara = new DynamicParameters();
            dbPara.Add("Nombre", newRol.Nombre, DbType.String);
            dbPara.Add("Estado", newRol.Estado, DbType.String);
            dbPara.Add("AplicacionId", newRol.AplicacionId, DbType.Int64);
            dbPara.Add("Descripcion", newRol.Descripcion, DbType.String);

            string sql = $"INSERT INTO [{SCHEMA}].[Rol](Nombre, Estado, AplicacionId, Descripcion) " +
                        "VALUES(@Nombre, @Estado, @AplicacionId, @Descripcion);" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = db.Query<int>(sql, dbPara, tran, commandType: CommandType.Text).Single();

                        CrearLogAuditoria(header, db, tran, newRol, icCommon.Utils.Constantes.EventName.CREAR);
                        tran.Commit();
                        return result;

                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("RolDLL/CrearRol: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("RolDLL/CrearRol: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
        public int DesactivarRol(HeaderRequest header, InactivacionRolRequestBody body)
        {
            string ids = "(" + string.Join(",", body.RolesIds) + ")";
            string getSql = $"Select * from [{SCHEMA}].[Rol] WHERE RolId in {ids} AND [Estado] = 'ACTIVO'; ";
            string deactivateSQL = $"UPDATE [{SCHEMA}].[Rol] SET Estado='INACTIVO' where RolId in {ids};" +
                $"SELECT @@ROWCOUNT; ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<Rol> roles = db.Query<Rol>(getSql, transaction: tran, commandType: CommandType.Text).ToList();
                        foreach (Rol app in roles)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.INACTIVAR);
                        }

                        var result = db.Query<int>(deactivateSQL, transaction: tran, commandType: CommandType.Text);
                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("RolDLL/DesactivarRol: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("RolDLL/DesactivarRol: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
        public int EliminarRol(HeaderRequest header, EliminacionRolRequestBody body)
        {
            List<long> profileIds = body.RolesIds;
            string ids = "(" + string.Join(",", profileIds) + ")";
            string getSql = $"Select * from [{SCHEMA}].[Rol] WHERE RolId in {ids}; ";
            string deleteSql = $"DELETE FROM [{SCHEMA}].[AccesoRol] WHERE RolId in {ids}; " +
                               $"DELETE FROM [{SCHEMA}].[RolUsuarioAplicacion] WHERE RolId in {ids}; " +
                               $"DELETE FROM [{SCHEMA}].[Rol] WHERE RolId in {ids}; " +                
                               $"SELECT @@ROWCOUNT; ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = 0;

                        List<Rol> roles = db.Query<Rol>(getSql, transaction: tran, commandType: CommandType.Text).ToList();
                        foreach (Rol app in roles)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.BORRAR);
                        }

                        result = db.Query<int>(deleteSql, transaction: tran, commandType: CommandType.Text).Single();

                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("RolDLL/EliminarRol: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("RolDLL/EliminarRol: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
        public RolDto ObtenerPermisosRolPorId(HeaderRequest header, ConsultaPermisosRolRequestBody body)
        {
            var dbPara = new DynamicParameters();
            dbPara.Add("RolId", body.RolId, DbType.Int64);

            string profilesql = $"Select pro.*, app.AplicacionId, app.Nombre as NombreAplicacion from [{SCHEMA}].[Rol] pro " +
                                    $"LEFT JOIN [{SCHEMA}].[Aplicacion] app ON app.AplicacionId = pro.AplicacionId " +
                                    "WHERE RolId = @RolId; ";

            List<AccesoRol> access = new List<AccesoRol>();

            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    RolDto profile = db.Query(profilesql, param: dbPara, commandType: CommandType.Text,
                        map: (RolDto app, long aplicacionId, string appNom) =>
                        {
                            app.Aplicacion = new icCommon.DTOs.DB.CampoDescriptor
                            {
                                Id = aplicacionId,
                                Descripcion = appNom
                            };
                            return app;
                        }, splitOn: "AplicacionId,NombreAplicacion").Single();

                    dbPara.Add("AplicacionId", profile.Aplicacion.Id, DbType.Int64);

                    string sql = $"Select * from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";
                    sql += $"Select * from [{SCHEMA}].[AccesoRol] WHERE AplicacionId = @AplicacionId and RolId = @RolId and Estado = 'ACTIVO'; ";
                    sql += $"Select Coalesce(Max(Nivel),0) from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";

                    using (SqlMapper.GridReader multi = db.QueryMultiple(sql, param: dbPara, commandType: CommandType.Text))
                    {
                        List<AccesoMenuDto> children = multi.Read<AccesoMenuDto>()?.ToList();
                        access = multi.Read<AccesoRol>()?.ToList();
                        int maxLevel = multi.Read<int>().Single();

                        List<AccesoMenuDto> previousLevel = new List<AccesoMenuDto>();

                        if (children != null)
                        {

                            for (int i = maxLevel; i >= 0; i--)
                            {
                                List<AccesoMenuDto> levelChildren = children.FindAll(x => x.Nivel == i);

                                levelChildren.ForEach(x => {

                                    AccesoRol menuAccess = access.Find(y => y.MenuId == x.MenuId);

                                    if (menuAccess != null)
                                    {
                                        x.Estado = menuAccess.Estado;
                                    }
                                    else
                                    {
                                        x.Estado = "INACTIVO";
                                    }

                                    x.Hijos = previousLevel.FindAll(y => y.PadreId == x.MenuId);
                                });

                                previousLevel = levelChildren;
                                children.RemoveAll(x => x.Nivel == i);
                            }
                        }

                        profile.AccesoMenu = previousLevel;

                        return profile;
                    }
                }
                catch (SqlException e)
                {
                    Log.Error("RolDLL/SqlException: Exception -> " + e.Message);
                    throw;
                }
            }
        }

        private RolDto ObtenerPermisosRolXId(long rolId, IDbConnection db, IDbTransaction tran, List<AccesoRolDto>? excepciones = null)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("RolId", rolId, DbType.Int64);

                string profilesql = $"Select pro.*, app.AplicacionId, app.Nombre as NombreAplicacion from [{SCHEMA}].[Rol] pro " +
                                        $"LEFT JOIN [{SCHEMA}].[Aplicacion] app ON app.AplicacionId = pro.AplicacionId " +
                                        "WHERE RolId = @RolId; ";

                List<AccesoRol> access = new List<AccesoRol>();

                RolDto profile = db.Query(profilesql, param: dbPara, transaction:tran, commandType: CommandType.Text,
                    map: (RolDto app, long aplicacionId, string appNom) =>
                    {
                        app.Aplicacion = new icCommon.DTOs.DB.CampoDescriptor
                        {
                            Id = aplicacionId,
                            Descripcion = appNom
                        };
                        return app;
                    }, splitOn: "AplicacionId,NombreAplicacion").Single();

                dbPara.Add("AplicacionId", profile.Aplicacion.Id, DbType.Int64);

                string sql = $"Select * from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";
                sql += $"Select * from [{SCHEMA}].[AccesoRol] WHERE AplicacionId = @AplicacionId and RolId = @RolId and Estado = 'ACTIVO'; ";
                sql += $"Select Coalesce(Max(Nivel),0) from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";

                using (SqlMapper.GridReader multi = db.QueryMultiple(sql, transaction:tran, param: dbPara, commandType: CommandType.Text))
                {
                    List<AccesoMenuDto> children = multi.Read<AccesoMenuDto>()?.ToList();
                    access = multi.Read<AccesoRol>()?.ToList();
                    int maxLevel = multi.Read<int>().Single();

                    List<AccesoMenuDto> previousLevel = new List<AccesoMenuDto>();

                    if (children != null)
                    {

                        for (int i = maxLevel; i >= 0; i--)
                        {
                            List<AccesoMenuDto> levelChildren = children.FindAll(x => x.Nivel == i);

                            levelChildren.ForEach(x => {

                                if (excepciones != null)
                                {
                                    AccesoRolDto menuAccess = excepciones.Find(y => y.MenuId == x.MenuId);

                                    if (menuAccess != null)
                                    {
                                        x.Estado = menuAccess.Estado;
                                    }
                                    else
                                    {
                                        x.Estado = "INACTIVO";
                                    }
                                }
                                else {
                                    AccesoRol menuAccess = access.Find(y => y.MenuId == x.MenuId);


                                    if (menuAccess != null)
                                    {
                                        x.Estado = menuAccess.Estado;
                                    }
                                    else
                                    {
                                        x.Estado = "INACTIVO";
                                    }
                                }                                

                                x.Hijos = previousLevel.FindAll(y => y.PadreId == x.MenuId);
                            });

                            previousLevel = levelChildren;
                            children.RemoveAll(x => x.Nivel == i);
                        }
                    }

                    profile.AccesoMenu = previousLevel;

                    return profile;
                }
            }
            catch (SqlException e)
            {
                Log.Error("RolDLL/ObtenerPermisosRolPorId: SqlException -> " + e.Message);
                throw;
            }
        }

        public RolDto ObtenerRolPorId(HeaderRequest header, ConsultaRolRequestBody body)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("RolId", body.RolId, DbType.Int64);

                using (IDbConnection db = _config.ObtenerConexion())
                {
                    string profilesql = $"Select pro.*, app.AplicacionId, app.Nombre as NombreAplicacion from [{SCHEMA}].[Rol] pro " +
                                        $"LEFT JOIN [{SCHEMA}].[Aplicacion] app ON app.AplicacionId = pro.AplicacionId " +
                                        "WHERE RolId = @RolId; ";
                    
                    RolDto result = db.Query(profilesql, param: dbPara, commandType: CommandType.Text,
                        map: (RolDto app, long aplicacionId, string appNom) =>
                        {
                            app.Aplicacion = new icCommon.DTOs.DB.CampoDescriptor { 
                                Id = aplicacionId,
                                Descripcion = appNom
                            };
                            return app;
                        }, splitOn: "AplicacionId,NombreAplicacion").Single();

                    return result;
                }
            }
            catch (SqlException e)
            {
                Log.Error("RolDLL/ObtenerRolPorId: SqlException -> " + e.Message);
                throw;
            }
        }
        public QueryRolesResponse ListarRoles(HeaderRequest header, ListaRolesRequestBody body)
        {
            string state = string.IsNullOrEmpty(body.Estado) ? string.Empty : body.Estado.Trim();
            string sortBy = body.OrdenarPor ?? string.Empty;
            string filterBy = body.FiltrarPor ?? string.Empty;
            string filterValue = body.ValorFiltro != null ? body.ValorFiltro.ToLower() : string.Empty;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;
            long applicationId = body.Aplicacion;

            var dbPara = new DynamicParameters();
            dbPara.Add("State", state.ToUpper(), DbType.String);
            dbPara.Add("SortBy", sortBy, DbType.String);
            dbPara.Add("SortDesc", body.OrdenDesc, DbType.Boolean);
            dbPara.Add("FilterBy", filterBy, DbType.String);
            dbPara.Add("FilterValue", '%' + filterValue.ToLower() + '%', DbType.String);
            dbPara.Add("AplicacionId", applicationId, DbType.Int64);

            dbPara.Add("Page", page, DbType.Int32);
            dbPara.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            string sql = $"Select rol.*, app.Nombre as NombreAplicacion, COUNT(*) OVER() as TotalCount from [{SCHEMA}].[Rol] rol " +
                $"INNER JOIN [{SCHEMA}].[Aplicacion] app on app.AplicacionId = rol.AplicacionId " +
                $"WHERE 1=1 ";

            if (!string.IsNullOrEmpty(state))
            {
                sql += "AND UPPER(rol.[Estado]) = @State ";
            }

            if (applicationId > 0)
            {
                sql += "AND app.AplicacionId = @AplicacionId ";
            }

            if (!string.IsNullOrEmpty(filterBy) && !string.IsNullOrEmpty(filterValue))
            {
                switch (filterBy.ToLower())
                {
                    case "name": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST(rol.[Nombre] as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                    case "description": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST(rol.[Descripcion] as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                }
            }

            if (!string.IsNullOrEmpty(sortBy))
            {
                switch (sortBy.ToLower())
                {
                    case "name":
                        sql += "ORDER BY rol.[Nombre] ";
                        break;
                    default:
                        sql += "ORDER BY rol.[Nombre] ";
                        break;
                }
            }
            else
            {
                sql += "ORDER BY rol.[Nombre] ";
            }
            sql += body.OrdenDesc ? "DESC " : "ASC ";

            sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                   "FETCH NEXT @ItemsPerPage ROWS ONLY; ";

            QueryRolesResponse result = new QueryRolesResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<RolDto> queryResult = db.Query(sql, param: dbPara, commandType: CommandType.Text,
                        map: (Rol rol, string NombreAplicacion, int totalCount) =>
                        {
                            RolDto res = new RolDto
                            {
                                Aplicacion = new CampoDescriptor { Id = rol.AplicacionId, Descripcion = NombreAplicacion },
                                Descripcion = rol.Descripcion,
                                Estado = rol.Estado,
                                Nombre = rol.Nombre,
                                RolId = rol.RolId
                            };
                            totalItems = totalCount;
                            return res;
                        }, splitOn: "NombreAplicacion,TotalCount").ToList();

                    result.Roles = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("RolDLL/ListarRoles: SqlException -> " + e.Message);
                    throw;
                }
            }            
        }

        public QueryRolesUsuarioResponse ListarRolesUsuario(HeaderRequest header, ListaRolesRequestBody body)
        {
            string state = string.IsNullOrEmpty(body.Estado) ? string.Empty : body.Estado.Trim();
            string sortBy = body.OrdenarPor ?? string.Empty;
            string filterBy = body.FiltrarPor ?? string.Empty;
            string filterValue = body.ValorFiltro != null ? body.ValorFiltro.ToLower() : string.Empty;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;
            long applicationId = body.Aplicacion;

            var dbPara = new DynamicParameters();
            dbPara.Add("State", state.ToUpper(), DbType.String);
            dbPara.Add("SortBy", sortBy, DbType.String);
            dbPara.Add("SortDesc", body.OrdenDesc, DbType.Boolean);
            dbPara.Add("FilterBy", filterBy, DbType.String);

            if (filterBy.ToLower().Equals("codigo"))
                dbPara.Add("FilterValue", filterValue, DbType.Int64);
            else if (filterBy.ToLower().Equals("codigousuario"))
                dbPara.Add("FilterValue", filterValue, DbType.String);
            else
                dbPara.Add("FilterValue", filterValue, DbType.String);

            dbPara.Add("AplicacionId", applicationId, DbType.Int64);

            dbPara.Add("Page", page, DbType.Int32);
            dbPara.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            string sql = $"Select rol.*, usu.*, rapp.*, app.Nombre as NombreAplicacion, COUNT(*) OVER() as TotalCount from [{SCHEMA}].[Rol] rol " +
                $"INNER JOIN [{SCHEMA}].[Aplicacion] app on app.AplicacionId = rol.AplicacionId " +
                $"INNER JOIN [{SCHEMA}].[RolUsuarioAplicacion] rapp on rol.RolId = rapp.RolId and app.AplicacionId = rapp.AplicacionId " +
                $"INNER JOIN [{SCHEMA}].[Usuario] usu on rapp.UsuarioId = usu.UsuarioId " +
                $"WHERE 1=1 ";

            if (!string.IsNullOrEmpty(state))
            {
                sql += "AND UPPER(rol.[Estado]) = @State ";
            }

            if (applicationId > 0)
            {
                sql += "AND app.AplicacionId = @AplicacionId ";
            }

            if (!string.IsNullOrEmpty(filterBy) && !string.IsNullOrEmpty(filterValue))
            {
                switch (filterBy.ToLower())
                {
                    case "name": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST(rol.[Nombre] as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                    case "description": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST(rol.[Descripcion] as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                    case "codigo":
                        sql += "AND rol.rolId = cast(@FilterValue as bigint) ";
                        break;
                    case "codigousuario":
                        sql += "AND usu.[Cedula] = @FilterValue ";
                        break;
                    case "user":
                        sql += "AND LOWER(CAST(usu.[NombreUsuario] as varchar) collate SQL_Latin1_General_Cp1251_CS_AS) = cast(@FilterValue as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS";
                        break;
                }
            }

            if (!string.IsNullOrEmpty(sortBy))
            {
                switch (sortBy.ToLower())
                {
                    case "name":
                        sql += " ORDER BY rol.[Nombre] ";
                        break;
                    default:
                        sql += " ORDER BY rol.[Nombre] ";
                        break;
                }
            }
            else
            {
                sql += " ORDER BY rol.[Nombre] ";
            }
            sql += body.OrdenDesc ? "DESC " : "ASC ";

            sql += "OFFSET " + itemsPerPage + " * (" + page + " - 1) ROWS " +
                   "FETCH NEXT " + itemsPerPage + " ROWS ONLY; ";

            QueryRolesUsuarioResponse result = new QueryRolesUsuarioResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<RolUsuarioDto> queryResult = db.Query(sql, param: dbPara, commandType: CommandType.Text,
                        map: (Rol rol, Usuario usuario, RolUsuarioAplicacion rapp, string NombreAplicacion, int totalCount) =>
                        {
                            RolUsuarioDto res = new RolUsuarioDto
                            {
                                Aplicacion = new CampoDescriptor { Id = rol.AplicacionId, Descripcion = NombreAplicacion },
                                Descripcion = rol.Descripcion,
                                Estado = rol.Estado,
                                Nombre = rol.Nombre,
                                RolId = rol.RolId,
                                EsPrincipal = rapp.EsPrincipal,
                                Usuario = new DatosUsuario { UsuarioId = usuario.UsuarioId, NombreUsuario = usuario.NombreUsuario, Agencia = usuario.Agencia, Email = usuario.Email }
                            };
                            totalItems = totalCount;
                            return res;
                        }, splitOn: "UsuarioId,NombreAplicacion,TotalCount").ToList();

                    result.Roles = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("RolDLL/ListarRoles: SqlException -> " + e.Message);
                    throw;
                }
            }
        }

        public int ActualizarPermisosRol(HeaderRequest header, EdicionPermisosRolRequestBody body)
        {
            var dbPara = new DynamicParameters();
            dbPara.Add("RolId", body.RolId, DbType.Int64);
            dbPara.Add("AplicacionId", body.AplicacionId, DbType.Int64);

            string sqlAccesos = $"SELECT * FROM [{SCHEMA}].[AccesoRol] " +
                                $"WHERE RolId = @RolId AND AplicacionId = @AplicacionId;";

            string sqlInsert = $"INSERT INTO [{SCHEMA}].[AccesoRol](AplicacionId, RolId, MenuId, [Estado]) " +
                        $"VALUES({body.AplicacionId}, {body.RolId}, @MenuId, @Estado);";

            string sqlUpdate = $"UPDATE [{SCHEMA}].[AccesoRol] SET [Estado] = @Estado " +
                        $" WHERE MenuId = @MenuId AND AplicacionId = {body.AplicacionId} AND RolId = {body.RolId};";

            string sqlInactivar = $"UPDATE [{SCHEMA}].[AccesoRol] SET [Estado] = 'INACTIVO' " +
                        $" WHERE MenuId = @MenuId AND AplicacionId = {body.AplicacionId} AND RolId = {body.RolId};";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                var accesosAnteriores = db.Query<AccesoRol>(sqlAccesos, dbPara, commandType: CommandType.Text).ToList();
                var idsMenuAnteriores = accesosAnteriores.Select(x => x.MenuId).ToList();

                var accesosNuevos = body.Acceso.FindAll(x => !idsMenuAnteriores.Contains(x.MenuId));
                var accesosUpdate = body.Acceso.FindAll(x => idsMenuAnteriores.Contains(x.MenuId));
                var idsAccesosUpdate = accesosUpdate.Select(x => x.MenuId).ToList();

                var accesosInactivar = accesosAnteriores.FindAll(x => !idsAccesosUpdate.Contains(x.MenuId));

                using (var tran = db.BeginTransaction())
                {
                    try
                    {

                        Rol rol = new Rol { RolId = body.RolId, AplicacionId = body.AplicacionId };

                        CrearLogAuditoria(header, db, tran, rol, icCommon.Utils.Constantes.EventName.ACTUALIZAR, true, body.Acceso);

                        if (accesosNuevos.Count > 0) db.Execute(sqlInsert, accesosNuevos, tran, commandType: CommandType.Text);
                        if (accesosUpdate.Count > 0) db.Execute(sqlUpdate, accesosUpdate, tran, commandType: CommandType.Text);
                        if (accesosInactivar.Count > 0) db.Execute(sqlInactivar, accesosInactivar, tran, commandType: CommandType.Text);

                        tran.Commit();
                        return 1;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("RolDLL/ActualizarPermisosRol: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("RolDLL/ActualizarPermisosRol: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
        public int ActualizarRol(HeaderRequest header, EdicionRolRequestBody body)
        {
            Rol profile = body.Rol;
            
            var dbPara = new DynamicParameters();
            dbPara.Add("RolId", profile.RolId, DbType.Int64);
            dbPara.Add("Nombre", profile.Nombre, DbType.String);
            dbPara.Add("Estado", profile.Estado, DbType.String);
            dbPara.Add("AplicacionId", profile.AplicacionId, DbType.Int64);
            dbPara.Add("Descripcion", profile.Descripcion, DbType.String);

            string sql = $"UPDATE [{SCHEMA}].[Rol] SET Nombre=@Nombre, Estado=@Estado, AplicacionId=@AplicacionId, Descripcion = @Descripcion " +
               $" WHERE RolId= @RolId;" +
               $"SELECT @@ROWCOUNT; ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        CrearLogAuditoria(header, db, tran, profile, icCommon.Utils.Constantes.EventName.ACTUALIZAR);

                        var result = db.Query<int>(sql, dbPara, tran, commandType: CommandType.Text).Single();

                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("RolDLL/ActualizarRol: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("RolDLL/ActualizarRol: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public QueryRolesReporteResponse ListarRolesReporte(HeaderRequest header, ListaRolesReporteRequestBody body)
        {
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;
            long applicationId = body.AplicacionId;

            var dbPara = new DynamicParameters();
            dbPara.Add("Page", page, DbType.Int32);
            dbPara.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            string sql = $"Select CONCAT(app.Nombre,'-',rol.Nombre) as Rol, rol.Nombre, menu.Nombre as Permiso, rol.Estado, COUNT(*) OVER() as TotalCount " +
                $"FROM [{SCHEMA}].[Rol] rol INNER JOIN [{SCHEMA}].[Aplicacion] app ON app.AplicacionId = rol.AplicacionId " +
                $"LEFT JOIN [{SCHEMA}].[AccesoRol] acc ON acc.RolId = rol.RolId " +
                $"LEFT JOIN [{SCHEMA}].[Menu] menu ON menu.MenuId = acc.MenuId " +
                $"WHERE acc.Estado = 'ACTIVO' ";

            if (applicationId > 0)
            {
                dbPara.Add("AplicacionId", applicationId, DbType.Int64);
                sql += " AND rol.AplicacionId = @AplicacionId ";
            }
            if (!string.IsNullOrEmpty(body.Estado))
            {
                dbPara.Add("State", body.Estado.Trim().ToUpper(), DbType.String);
                sql += " AND UPPER(rol.[Estado]) = @State ";

            }

            sql += "ORDER BY rol.[Nombre] DESC ";

            if (itemsPerPage > 0)
            {
                sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                       "FETCH NEXT @ItemsPerPage ROWS ONLY; ";
            }

            QueryRolesReporteResponse result = new QueryRolesReporteResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<RolReporte> queryResult = db.Query(sql, param: dbPara, commandType: CommandType.Text,
                        map: (RolReporte app, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return app;
                        }, splitOn: "TotalCount").ToList();

                    result.Roles = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("RolDLL/ListarRolesReporte: SqlException -> " + e.Message);
                    throw;
                }
            }            
        }

        private void CrearLogAuditoria(HeaderRequest header, IDbConnection db, IDbTransaction tran, Rol rol, string accion, bool cambioMenu = false, List<AccesoRolDto>? accesoMenus = null)
        {
            Rol anterior = new Rol();

            List<CambioCampo> cambios = new List<CambioCampo>();
            switch (accion)
            {
                case icCommon.Utils.Constantes.EventName.ACTIVAR:
                    anterior = ObtenerRolXId(rol.RolId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "INACTIVO", Nuevo = "ACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.INACTIVAR:
                    anterior = ObtenerRolXId(rol.RolId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "ACTIVO", Nuevo = "INACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.BORRAR:
                    anterior = ObtenerRolXId(rol.RolId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Descripcion", Anterior = anterior.Descripcion, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "AplicacionId", Anterior = anterior.AplicacionId, Nuevo = null });
                    RolDto menu = ObtenerPermisosRolXId(rol.RolId,db,tran);
                    cambios.Add(new CambioCampo { Campo = "AccesoMenu", Anterior = menu.AccesoMenu, Nuevo = accesoMenus });
                    break;
                case icCommon.Utils.Constantes.EventName.ACTUALIZAR:
                    anterior = ObtenerRolXId(rol.RolId, db, tran);
                    if (cambioMenu)
                    {
                        RolDto menuActual = ObtenerPermisosRolXId(rol.RolId, db, tran, accesoMenus);
                        RolDto menuAnterior = ObtenerPermisosRolXId(rol.RolId, db, tran);
                        if (accesoMenus != null)
                            cambios.Add(new CambioCampo { Campo = "AccesoMenu", Anterior = menuAnterior.AccesoMenu, Nuevo = menuActual.AccesoMenu });
                    }
                    else {
                        if (anterior.Nombre != rol.Nombre)
                            cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = rol.Nombre });
                        if (anterior.Descripcion != rol.Descripcion)
                            cambios.Add(new CambioCampo { Campo = "Descripcion", Anterior = anterior.Descripcion, Nuevo = rol.Descripcion });
                        if (anterior.Estado != rol.Estado)
                            cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = rol.Estado });
                        if (anterior.AplicacionId != rol.AplicacionId)
                            cambios.Add(new CambioCampo { Campo = "AplicacionId", Anterior = anterior.AplicacionId, Nuevo = rol.AplicacionId });
                    } 
                    break;
                case icCommon.Utils.Constantes.EventName.CREAR:
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = string.Empty, Nuevo = rol.Nombre });
                    cambios.Add(new CambioCampo { Campo = "Descripcion", Anterior = string.Empty, Nuevo = rol.Descripcion });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = string.Empty, Nuevo = rol.Estado });
                    cambios.Add(new CambioCampo { Campo = "AplicacionId", Anterior = null, Nuevo = rol.AplicacionId });
                    break;
            }
            _auditoria.InsertarLog(header.UserName, header.StationIp, accion, ROL, rol.RolId, rol.Nombre, cambios, anterior, db, tran);
        }

        private Rol ObtenerRolXId(long rolId, IDbConnection db, IDbTransaction tran)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("RolId", rolId, DbType.Int64);

                string profilesql = $"Select * from [{SCHEMA}].[Rol] pro " +
                                        "WHERE RolId = @RolId; ";

                Rol result = db.Query<Rol>(profilesql,transaction: tran, param: dbPara, commandType: CommandType.Text).Single();

                return result;
            }
            catch (SqlException e)
            {
                Log.Error("RolDLL/ObtenerRolPorId: SqlException -> " + e.Message);
                throw;
            }
        }
    }
}
