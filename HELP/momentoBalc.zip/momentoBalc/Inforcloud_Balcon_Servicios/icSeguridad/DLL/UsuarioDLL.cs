﻿using Dapper;
using icCommon.DB;
using icCommon.DTOs.DB;
using icCommon.ManejoErrores;
using icCommon.ManejoErrores.Utils;
using icCommon.Utils;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Usuarios;
using icSeguridad.DTOs.DB.Response.Usuarios;
using icSeguridad.Models;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace icSeguridad.DLL
{
    public class UsuarioDLL : IUsuarioDLL
    {
        private readonly IProveedorConexion _config;
        private readonly IAuditoria _auditoria;

        const string USUARIO = "USUARIO";
        private readonly string SCHEMA = "";

        public UsuarioDLL(IProveedorConexion proveedor, IAuditoria auditoria)
        {
            _config = proveedor;
            _auditoria = auditoria;
            SCHEMA = _config.ObtenerSchema();
        }

        public int ActivarUsuario(HeaderRequest header, ActivacionUsuarioRequestBody body)
        {
            using (IDbConnection db = _config.ObtenerConexion())
            {
                string ids = "(" + string.Join(",", body.UsuariosIds) + ")";
                string getSql = $"Select * from [{SCHEMA}].[Usuario] WHERE UsuarioId in {ids} AND [Estado] = 'INACTIVO'; ";
                string activateSQL = $"UPDATE [{SCHEMA}].[Usuario] SET Estado='ACTIVO' WHERE UsuarioId in {ids};" +
                    $"SELECT @@ROWCOUNT; ";

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<Usuario> usuarios = db.Query<Usuario>(getSql, transaction: tran, commandType: CommandType.Text).ToList();
                        foreach (Usuario app in usuarios)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.ACTIVAR);
                        }

                        var result = db.Query<int>(activateSQL, transaction: tran, commandType: CommandType.Text);

                        tran.Commit();
                        return result.ToList().First();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("UsuarioDLL/ActivarUsuario: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("UsuarioDLL/ActivarUsuario: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public long CrearUsuario(HeaderRequest header, CreacionUsuarioRequestBody body)
        {
            Usuario newUser = body.Usuario.ToModelo();

            var dbPara = new DynamicParameters();
            dbPara.Add("Nombre", newUser.Nombre, DbType.String);
            dbPara.Add("NombreUsuario", newUser.NombreUsuario, DbType.String);
            dbPara.Add("Cedula", newUser.Cedula, DbType.String);
            dbPara.Add("Cargo", newUser.Cargo, DbType.String);
            dbPara.Add("Email", newUser.Email, DbType.String);
            dbPara.Add("Agencia", newUser.Agencia, DbType.String);
            dbPara.Add("RequiereControlEstacion", newUser.RequiereControlEstacion, DbType.Boolean);
            dbPara.Add("Estado", newUser.Estado, DbType.String);
            dbPara.Add("IntentosFallidos", 0, DbType.Int32);
            dbPara.Add("TieneEnmascaramiento", newUser.TieneEnmascaramiento, DbType.Boolean);

            string sql = $"INSERT INTO [{SCHEMA}].[Usuario](Nombre, NombreUsuario, Cedula,Cargo, Email,Agencia, RequiereControlEstacion, [Estado], IntentosFallidos, TieneEnmascaramiento) " +
            "VALUES(@Nombre, @NombreUsuario, @Cedula,@Cargo, @Email,@Agencia, @RequiereControlEstacion, @Estado, @IntentosFallidos, @TieneEnmascaramiento); " +
            "SELECT CAST(SCOPE_IDENTITY() as int);";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    string mensaje = string.Empty;
                    
                    try
                    {
                        if (!UsuarioValido(newUser.Cedula,newUser.NombreUsuario, newUser.Email, 0, db, tran, ref mensaje))
                        {
                            ErrorUtil.ThrowAppException("GENERAL", "VALIDATION_ERROR", mensaje);
                        }

                        var result = db.Query<long>(sql, dbPara, tran, commandType: CommandType.Text).Single();
                        CrearLogAuditoria(header, db, tran, newUser, icCommon.Utils.Constantes.EventName.CREAR);
                        tran.Commit();
                        return result;

                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("UsuarioDLL/CrearUsuario: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("UsuarioDLL/CrearUsuario: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public int InactivarUsuario(HeaderRequest header, InactivacionUsuarioRequestBody body)
        {
            using (IDbConnection db = _config.ObtenerConexion())
            {
                DynamicParameters dbPara = new DynamicParameters();
                dbPara.Add("WriteUid", header.UserName, DbType.String);
                dbPara.Add("WriteDate", DateTime.Now, DbType.DateTime);

                string ids = "(" + string.Join(",", body.UsuariosIds) + ")";
                string getSql = $"Select * from [{SCHEMA}].[Usuario] WHERE UsuarioId in {ids} AND [Estado] = 'ACTIVO'; ";
                string deactivateSQL = $"UPDATE [{SCHEMA}].[Usuario] SET Estado='INACTIVO' where UsuarioId in {ids};" +
                    $"SELECT @@ROWCOUNT; ";

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<Usuario> usuarios = db.Query<Usuario>(getSql, transaction: tran, commandType: CommandType.Text).ToList();
                        foreach (Usuario app in usuarios)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.INACTIVAR);
                        }

                        var result = db.Query<int>(deactivateSQL, transaction: tran, commandType: CommandType.Text);

                        tran.Commit();
                        return result.ToList().First();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("UsuarioDLL/InactivarUsuario: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("UsuarioDLL/InactivarUsuario: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public int EliminarUsuario(HeaderRequest header, EliminacionUsuarioRequestBody body)
        {
            List<long> userIds = body.UsuariosIds;
            string ids = "(" + string.Join(",", userIds) + ")";
            string getSql = $"Select * from [{SCHEMA}].[Usuario] WHERE UsuarioId in {ids}; ";
            string deleteSql = $"DELETE FROM [{SCHEMA}].[RolUsuarioAplicacion] WHERE UsuarioId in {ids}; " +
                               $"DELETE FROM [{SCHEMA}].[Usuario] WHERE UsuarioId in {ids}; " +
                               $"SELECT @@ROWCOUNT; ";

            var result = 0;
            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<Usuario> usuarios = db.Query<Usuario>(getSql, transaction: tran, commandType: CommandType.Text).ToList();
                        foreach (Usuario app in usuarios)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.BORRAR);
                        }
                        if (userIds.Count > 0) result = db.Query<int>(deleteSql, transaction: tran, commandType: CommandType.Text).Single();

                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("UsuarioDLL/EliminarUsuario: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("UsuarioDLL/EliminarUsuario: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }                    
                }
            }
        }

        public UsuarioDto ObtenerUsuarioPorId(HeaderRequest header, ConsultaUsuarioRequestBody body)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("UsuarioId", body.UsuarioId, DbType.Int64);

                string sql = $"Select * from [{SCHEMA}].[Usuario] WHERE UsuarioId = @UsuarioId; ";

                using (IDbConnection db = _config.ObtenerConexion())
                {
                    Usuario user = db.Query<Usuario>(sql, param: dbPara, commandType: CommandType.Text).Single();
                    UsuarioDto result = user.ToModelo();
                    return result;
                }
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ObtenerUsuarioPorId: SqlException -> " + e.Message);
                throw;
            }
        }

        public Usuario ObtenerUsuarioPorNombre(HeaderRequest header, AutenticacionUsuarioRequestBody body)
        {
            Usuario user = new Usuario();
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("NombreUsuario", body.Usuario.ToLower(), DbType.String);

                string sql = $"SELECT * FROM [{SCHEMA}].[Usuario] WHERE LOWER([NombreUsuario]) = @NombreUsuario;";

                using (IDbConnection db = _config.ObtenerConexion())
                {
                    if (db.State == ConnectionState.Closed)
                        db.Open();

                    user = db.Query<Usuario>(sql, param: dbPara, commandType: CommandType.Text).FirstOrDefault();
                }
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ObtenerUsuarioPorNombre: Exception -> " + e.Message);
                throw;
            }
            return user;
        }

        public PerfilUsuario ObtenerPerfilUsuario(long applicationId, Usuario user)
        {
            PerfilUsuario userRol = new PerfilUsuario();

            var dbPara = new DynamicParameters();
            dbPara.Add("UsuarioId", user.UsuarioId, DbType.Int64);
            dbPara.Add("AplicacionId", applicationId, DbType.Int64);
            dbPara.Add("Cedula",user.Cedula, DbType.String);

            string profileAccessSql = $"SELECT rel.* FROM [{SCHEMA}].[RolUsuarioAplicacion] rel " +
                                      $"INNER JOIN [{SCHEMA}].[Rol] pro on rel.RolId = pro.RolId " +
                                      "WHERE rel.UsuarioId = @UsuarioId AND rel.AplicacionId = @AplicacionId AND  pro.AplicacionId = @AplicacionId " +
                                      "AND  (rel.EsPrincipal=1 OR (rel.EsPrincipal=0 AND CONVERT(DATE, SYSDATETIME()) BETWEEN rel.FechaInicio AND rel.FechaVencimiento));";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();
                
                try
                {
                    List<AccesoRol> access = new List<AccesoRol>();

                    var userMltipleAccess = db.Query<RolUsuarioAplicacion>(profileAccessSql, param: dbPara, commandType: CommandType.Text).ToList();

                    RolUsuarioAplicacion userAccess = userMltipleAccess.Find(x => x.EsPrincipal);

                    if (userMltipleAccess.Count > 1)
                    {
                        userAccess = userMltipleAccess.Find(x => !x.EsPrincipal);
                    }

                    if (userAccess != null)
                    {
                        dbPara.Add("RolId", userAccess.RolId, DbType.Int64);

                        string sql = $"Select * from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";
                        sql += $"Select * from [{SCHEMA}].[AccesoRol] WHERE AplicacionId = @AplicacionId and RolId = @RolId and Estado = 'ACTIVO'; ";
                        sql += $"Select Coalesce(Max(Nivel),0) from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";
                        sql += $"Select Nombre from [{SCHEMA}].[Rol] WHERE RolId = @RolId; ";
                        sql += $"Select Descripcion from [{SCHEMA}].[Catalogo] WHERE Codigo = @Cedula and Nombre = 'EJECUTIVO_CONTROL'; ";
                        sql += $"Select Complemento from [{SCHEMA}].[Catalogo] WHERE Codigo = @Cedula and Nombre = 'EJECUTIVO_CONTROL'; ";
                        sql += $"SELECT Complemento FROM Catalogo where Nombre = 'AGENCIAS' AND " +
                            $"Codigo IN (Select Complemento from [{SCHEMA}].[Catalogo] WHERE Codigo = @Cedula and Nombre = 'EJECUTIVO_CONTROL'); ";


                        using (SqlMapper.GridReader multi = db.QueryMultiple(sql, param: dbPara, commandType: CommandType.Text))
                        {
                            List<AccesoMenuDto> children = multi.Read<AccesoMenuDto>()?.ToList();
                            access = multi.Read<AccesoRol>()?.ToList();
                            int maxLevel = multi.Read<int>().Single();
                            string nombreRol = multi.Read<string>().Single();
                            string codigoEjecutivo = multi.Read<string>()?.FirstOrDefault();
                            string agencia = multi.Read<string>()?.FirstOrDefault();
                            string zona = multi.Read<string>()?.FirstOrDefault();

                            List<AccesoMenuDto> previousLevel = new List<AccesoMenuDto>();

                            userRol = new PerfilUsuario
                            {
                                UsuarioId = user.UsuarioId,
                                Usuario = user.NombreUsuario,
                                Nombre = user.Nombre,
                                Email = user.Email,
                                TieneEnmascaramiento = user.TieneEnmascaramiento,
                                Agencia = string.IsNullOrEmpty(agencia) ? user.Agencia : agencia,
                                Cargo = user.Cargo,
                                Cedula = user.Cedula,
                                UltimoFechaSesion = user.UltimaSesionFecha,
                                UltimaSesionIP = user.UltimaSesionIP,
                                CodigoEjecutivo = codigoEjecutivo,
                                Rol = nombreRol,
                                Zona = zona
                            };

                            if (children != null)
                            {

                                for (int i = maxLevel; i >= 0; i--)
                                {
                                    List<AccesoMenuDto> levelChildren = children.FindAll(x => x.Nivel == i);

                                    levelChildren.ForEach(x => {

                                        AccesoRol menuAccess = access.Find(y => y.MenuId == x.MenuId);

                                        if (menuAccess != null)
                                        {
                                            x.Estado = menuAccess.Estado;
                                        }
                                        else
                                        {
                                            x.Estado = "INACTIVO";
                                        }

                                        x.Hijos = previousLevel.FindAll(y => y.PadreId == x.MenuId);
                                    });

                                    previousLevel = levelChildren;
                                    children.RemoveAll(x => x.Nivel == i);
                                }
                            }

                            userRol.Acceso = previousLevel;
                        }                                   

                        string updateSQL = $"UPDATE [{SCHEMA}].[Usuario] SET UltimaSesionFecha=SYSDATETIME(), IntentosFallidos=0 WHERE UsuarioId = @UsuarioId;";

                        db.Execute(updateSQL, param: dbPara, commandType: CommandType.Text);

                        return userRol;
                    }
                    else
                    {
                        return null;
                    }
                }
                catch (SqlException e)
                {
                    Log.Error("UsuarioDLL/ObtenerPerfilUsuario: SqlException -> " + e.Message);
                    throw;
                }
            }
        }
        public RolesUsuarioDto ConsultarRolesUsuario(HeaderRequest header, ConsultaRolesUsuarioRequestBody body) {
            RolesUsuarioDto userRol = new RolesUsuarioDto();

            var dbPara = new DynamicParameters();
            dbPara.Add("UsuarioId", body.UsuarioId, DbType.Int64);
            dbPara.Add("AplicacionId", body.AplicacionId, DbType.Int64);

            string profileAccessSql = $"SELECT rel.*, app.Nombre as NombreAplicacion, pro.Nombre as NombreRol FROM [{SCHEMA}].[RolUsuarioAplicacion] rel " +
                                      $"INNER JOIN [{SCHEMA}].[Rol] pro on rel.RolId = pro.RolId " +
                                      $"INNER JOIN [{SCHEMA}].[Aplicacion] app on rel.AplicacionId = app.AplicacionId " +
                                      "WHERE rel.UsuarioId = @UsuarioId AND rel.AplicacionId = @AplicacionId " +
                                      "AND (rel.EsPrincipal=1 OR (rel.EsPrincipal=0 AND CONVERT(DATE, SYSDATETIME()) BETWEEN rel.FechaInicio AND rel.FechaVencimiento))";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    CampoDescriptor aplicacion = new CampoDescriptor();

                    List<RolTemporalDto> userMltipleAccess = db.Query(profileAccessSql, param: dbPara, commandType: CommandType.Text,
                        map: (RolUsuarioAplicacion app, string appNom, string rolNom) =>
                        {
                            RolTemporalDto rol = new RolTemporalDto
                            {
                                Id = app.RolId,
                                Descripcion = rolNom,
                                FechaInicio = app.FechaInicio,
                                FechaVencimiento = app.FechaVencimiento,
                                EsPrincipal = app.EsPrincipal
                            };
                            aplicacion = new CampoDescriptor
                            {
                                Id = app.AplicacionId,
                                Descripcion = appNom
                            };
                            return rol;
                        }, splitOn: "NombreAplicacion,NombreRol").ToList();

                    userRol = new RolesUsuarioDto
                    {
                        Aplicacion = aplicacion,
                        UsuarioId = body.UsuarioId,
                        RolPrincipal = userMltipleAccess.Find(x => x.EsPrincipal),
                        RolTemporal = userMltipleAccess.Find(x => !x.EsPrincipal)
                    };
                }
                catch (SqlException e)
                {
                    Log.Error("UsuarioDLL/ConsultarRolesUsuario: SqlException -> " + e.Message);
                    throw;
                }
            }
            
            return userRol;
        }

        private RolesUsuarioDto ConsultarRolesXUsuario(long usuarioId, long aplicacionId, IDbConnection db, IDbTransaction tran)
        {
            RolesUsuarioDto userRol = new RolesUsuarioDto();
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("UsuarioId", usuarioId, DbType.Int64);
                dbPara.Add("AplicacionId", aplicacionId, DbType.Int64);

                string profileAccessSql = $"SELECT rel.*, app.Nombre as NombreAplicacion, pro.Nombre as NombreRol FROM [{SCHEMA}].[RolUsuarioAplicacion] rel " +
                                          $"INNER JOIN [{SCHEMA}].[Rol] pro on rel.RolId = pro.RolId " +
                                          $"INNER JOIN [{SCHEMA}].[Aplicacion] app on rel.AplicacionId = app.AplicacionId " +
                                          "WHERE rel.UsuarioId = @UsuarioId AND rel.AplicacionId = @AplicacionId " +
                                          "AND (rel.EsPrincipal=1 OR (rel.EsPrincipal=0 AND CONVERT(DATE, SYSDATETIME()) BETWEEN rel.FechaInicio AND rel.FechaVencimiento))";

                CampoDescriptor aplicacion = new CampoDescriptor();

                List<RolTemporalDto> userMltipleAccess = db.Query(profileAccessSql, param: dbPara, transaction:tran, commandType: CommandType.Text,
                    map: (RolUsuarioAplicacion app, string appNom, string rolNom) =>
                    {
                        RolTemporalDto rol = new RolTemporalDto
                        {
                            Id = app.RolId,
                            Descripcion = rolNom,
                            FechaInicio = app.FechaInicio,
                            FechaVencimiento = app.FechaVencimiento,
                            EsPrincipal = app.EsPrincipal
                        };
                        aplicacion = new CampoDescriptor
                        {
                            Id = app.AplicacionId,
                            Descripcion = appNom
                        };
                        return rol;
                    }, splitOn: "NombreAplicacion,NombreRol").ToList();

                userRol = new RolesUsuarioDto
                {
                    Aplicacion = aplicacion,
                    UsuarioId = usuarioId,
                    RolPrincipal = userMltipleAccess.Find(x => x.EsPrincipal),
                    RolTemporal = userMltipleAccess.Find(x => !x.EsPrincipal)
                };
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ConsultarRolesXUsuario: SqlException -> " + e.Message);
                throw;
            }
            return userRol;
        }

        public RolesUsuarioDto ActualizarRolesUsuario(HeaderRequest header, ActualizarRolesUsuarioRequestBody body)
        {
            RolesUsuarioDto userRol = new RolesUsuarioDto();
            CampoDescriptor aplicacion = new CampoDescriptor();

            var dbPara = new DynamicParameters();
            dbPara.Add("UsuarioId", body.UsuarioId, DbType.Int64);
            dbPara.Add("AplicacionId", body.AplicacionId, DbType.String);
            dbPara.Add("RolId", body.RolPrincipalId, DbType.Int64);

            string updatePrincipal = $"BEGIN " +
                                     $"IF NOT EXISTS (SELECT * FROM [{SCHEMA}].[RolUsuarioAplicacion] WHERE UsuarioId = @UsuarioId AND AplicacionId = @AplicacionId AND EsPrincipal=1) " +
                                     $"INSERT INTO [{SCHEMA}].[RolUsuarioAplicacion](UsuarioId,AplicacionId,EsPrincipal,RolId,Estado) " +
                                     $"VALUES(@UsuarioId,@AplicacionId,1,@RolId,'ACTIVO') " +
                                     $"ELSE " +
                                     $"UPDATE [{SCHEMA}].[RolUsuarioAplicacion] SET RolId=@RolId WHERE UsuarioId = @UsuarioId AND AplicacionId = @AplicacionId AND EsPrincipal=1 " +
                                     $"END;";

            var dbParaTemp = new DynamicParameters();
            dbParaTemp.Add("UsuarioId", body.UsuarioId, DbType.Int64);
            dbParaTemp.Add("AplicacionId", body.AplicacionId, DbType.String);

            string updateTemporal = $"DELETE FROM [{SCHEMA}].[RolUsuarioAplicacion] " +
                                     $"WHERE UsuarioId = @UsuarioId AND AplicacionId = @AplicacionId AND EsPrincipal=0;";

            if (body.RolTemporal != null && body.RolTemporal.RolId > 0) {                
                dbParaTemp.Add("RolTempId", body.RolTemporal.RolId, DbType.Int64);
                dbParaTemp.Add("FechaInicio", body.RolTemporal.FechaInicio, DbType.Date);
                dbParaTemp.Add("FechaVencimiento", body.RolTemporal.FechaVencimiento, DbType.Date);

                updateTemporal = $"BEGIN " +
                                     $"IF NOT EXISTS (SELECT * FROM [{SCHEMA}].[RolUsuarioAplicacion] WHERE UsuarioId = @UsuarioId AND AplicacionId = @AplicacionId AND EsPrincipal=0) " +
                                     $"INSERT INTO [{SCHEMA}].[RolUsuarioAplicacion](UsuarioId,AplicacionId,EsPrincipal,RolId,FechaInicio,FechaVencimiento,Estado) " +
                                     $"VALUES(@UsuarioId,@AplicacionId,0,@RolTempId,@FechaInicio,@FechaVencimiento,'ACTIVO') " +
                                     $"ELSE " +
                                     $"UPDATE [{SCHEMA}].[RolUsuarioAplicacion] SET RolId=@RolTempId, FechaInicio=@FechaInicio, FechaVencimiento=@FechaVencimiento, Estado='ACTIVO' " +
                                     $"WHERE UsuarioId = @UsuarioId AND AplicacionId = @AplicacionId AND EsPrincipal=0 " +
                                     $"END;";
            }

            var dbParaAccess = new DynamicParameters();
            dbParaAccess.Add("UsuarioId", body.UsuarioId, DbType.Int64);
            dbParaAccess.Add("AplicacionId", body.AplicacionId, DbType.Int64);

            string queryResult = $"SELECT rel.*, app.Nombre as NombreAplicacion, pro.Nombre as NombreRol FROM [{SCHEMA}].[RolUsuarioAplicacion] rel " +
                                      $"INNER JOIN [{SCHEMA}].[Rol] pro ON rel.RolId = pro.RolId " +
                                      $"INNER JOIN [{SCHEMA}].[Aplicacion] app ON rel.AplicacionId = app.AplicacionId " +
                                      "WHERE rel.UsuarioId = @UsuarioId AND rel.AplicacionId = @AplicacionId " +
                                      "AND (rel.EsPrincipal=1 OR (rel.EsPrincipal=0 AND CONVERT(DATE, SYSDATETIME()) BETWEEN rel.FechaInicio AND rel.FechaVencimiento)) ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        CrearLogAuditoria(header, db, tran, null, icCommon.Utils.Constantes.EventName.ACTUALIZAR, true, body);

                        db.Execute(updatePrincipal, dbPara, tran, commandType: CommandType.Text);
                        db.Execute(updateTemporal, dbParaTemp, tran, commandType: CommandType.Text);

                        tran.Commit();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("UsuarioDLL/ActualizarRolesUsuario: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("UsuarioDLL/ActualizarRolesUsuario: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }

                }
                List<RolTemporalDto> userMltipleAccess = db.Query(queryResult, param: dbPara, commandType: CommandType.Text,
                    map: (RolUsuarioAplicacion app, string appNom, string rolNom) =>
                    {
                        RolTemporalDto rol = new RolTemporalDto
                        {
                            Id = app.RolId,
                            Descripcion = rolNom,
                            FechaInicio = app.FechaInicio,
                            FechaVencimiento = app.FechaVencimiento,
                            EsPrincipal = app.EsPrincipal
                        };
                        aplicacion = new CampoDescriptor
                        {
                            Id = app.AplicacionId,
                            Descripcion = appNom
                        };
                        return rol;
                    }, splitOn: "NombreAplicacion,NombreRol").ToList();

                userRol = new RolesUsuarioDto
                {
                    Aplicacion = aplicacion,
                    UsuarioId = body.UsuarioId,
                    RolPrincipal = userMltipleAccess.Find(x => x.EsPrincipal),
                    RolTemporal = userMltipleAccess.Find(x => !x.EsPrincipal)
                };

                return userRol;
            }
        }

        public QueryUsuarioResponse ListarUsuarios(HeaderRequest header, ListaUsuariosRequestBody body)
        {
            try
            {
                string userName = header.UserName;
                int page = header.PageRequested;
                int itemsPerPage = header.PageSize;

                string state = string.IsNullOrEmpty(body.Estado) ? string.Empty : body.Estado.Trim();
                
                string sortBy = body.OrdenarPor ?? string.Empty;
                bool sortDesc = body.OrdenDesc;
                string filterBy = body.FiltrarPor ?? string.Empty;
                string filterValue = body.ValorFiltro != null ? body.ValorFiltro.ToLower() : string.Empty;

                DynamicParameters dbParam = new DynamicParameters();
                dbParam.Add("Username", userName, DbType.String);
                dbParam.Add("Page", page, DbType.Int32);
                dbParam.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

                dbParam.Add("State", state.ToUpper(), DbType.String);
                dbParam.Add("SortBy", sortBy, DbType.String);
                dbParam.Add("SortDesc", body.OrdenDesc, DbType.Boolean);
                dbParam.Add("FilterBy", filterBy, DbType.String);
                dbParam.Add("FilterValue", '%' + filterValue.ToLower() + '%', DbType.String);

                string sql = $"Select *, COUNT(*) OVER() as TotalCount from [{SCHEMA}].[Usuario] where 1=1 ";

                if (!string.IsNullOrEmpty(state))
                {
                    sql += "AND UPPER([Estado]) = @State ";
                }

                if (!string.IsNullOrEmpty(filterBy) && !string.IsNullOrEmpty(filterValue))
                {
                    switch (filterBy.ToLower())
                    {
                        case "username":
                            sql += "AND LOWER([NombreUsuario]) like @FilterValue ";
                            break;
                        case "name": //para que la busqueda considere vocales con tildes
                            sql += "AND LOWER(CAST([Nombre] as varchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                            break;
                        case "number": //para que la busqueda considere vocales con tildes
                            sql += "AND LOWER(CAST([Cedula] as varchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                            break;
                        case "email": //para que la busqueda considere vocales con tildes
                            sql += "AND LOWER(CAST([Email] as varchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                            break;
                    }
                }

                if (!string.IsNullOrEmpty(sortBy))
                {
                    switch (sortBy.ToLower())
                    {
                        case "username":
                            sql += "ORDER BY [NombreUsuario] ";
                            break;
                        case "name":
                            sql += "ORDER BY [Nombre] ";
                            break;
                        case "number":
                            sql += "ORDER BY [Cedula] ";
                            break;
                        case "email":
                            sql += "ORDER BY [Email] ";
                            break;
                        default:
                            sql += "ORDER BY [NombreUsuario] ";
                            break;
                    }
                }
                else
                {
                    sql += "ORDER BY [NombreUsuario] ";
                }
                sql += sortDesc ? "DESC " : "ASC ";

                sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                       "FETCH NEXT @ItemsPerPage ROWS ONLY; ";

                QueryUsuarioResponse result = new QueryUsuarioResponse();
                using (IDbConnection db = _config.ObtenerConexion())
                {
                    int totalItems = 0;
                    List<Usuario> queryResult = db.Query(sql, param: dbParam, commandType: CommandType.Text,
                        map: (Usuario user, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return user;
                        }, splitOn: "TotalCount").ToList();

                    result.Usuarios = queryResult;
                    result.Total = totalItems;
                    return result;
                }
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ListarUsuarios: SqlException -> " + e.Message);
                throw;
            }
        }

        public int ActualizarUsuario(HeaderRequest header, CreacionUsuarioRequestBody body)
        {
            Usuario user = body.Usuario.ToModelo();

            var dbPara = new DynamicParameters();
            dbPara.Add("UsuarioId", user.UsuarioId, DbType.Int64);
            dbPara.Add("Nombre", user.Nombre, DbType.String);
            dbPara.Add("NombreUsuario", user.NombreUsuario, DbType.String);
            dbPara.Add("Cedula", user.Cedula, DbType.String);
            dbPara.Add("Cargo", user.Cargo, DbType.String);
            dbPara.Add("Email", user.Email, DbType.String);
            dbPara.Add("Agencia", user.Agencia, DbType.String);
            dbPara.Add("RequiereControlEstacion", user.RequiereControlEstacion, DbType.Boolean);
            dbPara.Add("Estado", user.Estado, DbType.String);
            dbPara.Add("TieneEnmascaramiento", user.TieneEnmascaramiento, DbType.Boolean);

            string sql = $"UPDATE [{SCHEMA}].[Usuario] SET Nombre = @Nombre, NombreUsuario = @NombreUsuario, Cedula = @Cedula, Cargo = @Cargo, Email = @Email, Agencia = @Agencia, " +
                        "RequiereControlEstacion = @RequiereControlEstacion, Estado = @Estado, TieneEnmascaramiento = @TieneEnmascaramiento " +
                        "WHERE UsuarioId = @UsuarioId ;";

            sql += "SELECT @@ROWCOUNT;";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        string mensaje = "";
                        if (!UsuarioValido(user.Cedula, user.NombreUsuario, user.Email, user.UsuarioId, db, tran, ref mensaje))
                        {
                            ErrorUtil.ThrowAppException("GENERAL", "VALIDATION_ERROR", mensaje);
                        }

                        CrearLogAuditoria(header, db, tran, user, icCommon.Utils.Constantes.EventName.ACTUALIZAR);

                        var result = db.Query<int>(sql, dbPara, transaction: tran, commandType: CommandType.Text).Single();
                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("UsuarioDLL/ActualizarUsuario: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("UsuarioDLL/ActualizarUsuario: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }

                }
            }
        }

        public int ActualizarIntentosFallidos(Usuario user)
        {
            int iAffected = 0;
            try
            {
                int failedAttempts = user.IntentosFallidos + 1;
                var dbPara = new DynamicParameters();
                dbPara.Add("UsuarioId", user.UsuarioId, DbType.Int64);

                using (IDbConnection db = _config.ObtenerConexion())
                {
                    if (db.State == ConnectionState.Closed)
                        db.Open();

                    string updateSQL = string.Empty;

                    if (failedAttempts >= 3)
                    {
                        updateSQL = $"UPDATE [{SCHEMA}].[Usuario] SET IntentosFallidos=IntentosFallidos + 1 WHERE UsuarioId = @UsuarioId;SELECT @@ROWCOUNT;";
                    }
                    else
                    {
                        updateSQL = $"UPDATE [{SCHEMA}].[Usuario] SET IntentosFallidos=IntentosFallidos + 1 WHERE UsuarioId = @UsuarioId;SELECT @@ROWCOUNT;";
                    }

                    iAffected = db.Query<int>(updateSQL, dbPara, commandType: CommandType.Text).Single();
                }//fin USING CONNECTION
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ActualizarIntentosFallidos: SqlException -> " + e.Message);
                throw;
            }
            return iAffected;
        }

        public QueryUsuarioReporteResponse ListarUsuarioReporte(HeaderRequest header, ListaUsuariosReporteRequestBody body)
        {
            try
            {
                string userName = header.UserName;
                int page = header.PageRequested;
                int itemsPerPage = header.PageSize;

                string sql = $"Select usr.Nombre, usr.NombreUsuario as Usuario, usr.Cedula, usr.Estado, Coalesce(temp.Rol, pro.Rol) as Rol, Coalesce(temp.EstadoRol, pro.EstadoRol) as EstadoRol," +
                            $"cat.Descripcion as Cargo,usr.Email, COUNT(*) OVER() as TotalCount " +
                            $"FROM [{SCHEMA}].[Usuario] usr " +
                            $"LEFT JOIN [{SCHEMA}].[Catalogo] cat ON cat.Codigo = usr.Cargo AND cat.Nombre = 'CARGOS_BCO' " +
                            $"LEFT JOIN (SELECT rel.UsuarioId, CONCAT(app.Nombre,'-',rol.Nombre) as Rol, rol.Estado as EstadoRol FROM [{SCHEMA}].[RolUsuarioAplicacion] rel " +
                                          $"INNER JOIN [{SCHEMA}].[Rol] rol on rel.RolId = rol.RolId " +
                                          $"INNER JOIN [{SCHEMA}].[Aplicacion] app on rel.AplicacionId = app.AplicacionId " +
                                          $"WHERE rel.EsPrincipal=1) pro " +
                                          $"ON pro.UsuarioId = usr.UsuarioId " +
                            $"LEFT JOIN (SELECT rel.UsuarioId, CONCAT(app.Nombre,'-',rol.Nombre) as Rol, rol.Estado as EstadoRol FROM [{SCHEMA}].[RolUsuarioAplicacion] rel " +
                                          $"INNER JOIN [{SCHEMA}].[Rol] rol on rel.RolId = rol.RolId " +
                                          $"INNER JOIN [{SCHEMA}].[Aplicacion] app on rel.AplicacionId = app.AplicacionId " +
                                          $"WHERE rel.EsPrincipal=0 AND CONVERT(DATE, SYSDATETIME()) BETWEEN rel.FechaInicio AND rel.FechaVencimiento) temp " +
                                          $"ON temp.UsuarioId = usr.UsuarioId " +
                            $"WHERE 1=1 ";

                DynamicParameters dbParam = new DynamicParameters();
                dbParam.Add("Username", userName, DbType.String);
                dbParam.Add("Page", page, DbType.Int32);
                dbParam.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

                if (!string.IsNullOrEmpty(body.Estado)) 
                {
                    dbParam.Add("State", body.Estado.Trim().ToUpper(), DbType.String);
                    sql += " AND UPPER(usr.[Estado]) = @State ";

                }
                if (!string.IsNullOrEmpty(body.EstadoRol))
                {
                    dbParam.Add("StateRol", body.EstadoRol.Trim().ToUpper(), DbType.String);
                    sql += " AND Coalesce(UPPER(temp.EstadoRol), UPPER(pro.EstadoRol)) = @StateRol ";

                }

                sql += "ORDER BY usr.Nombre DESC ";

                if (itemsPerPage > 0) {
                    sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                           "FETCH NEXT @ItemsPerPage ROWS ONLY; ";
                }
                    

                QueryUsuarioReporteResponse result = new QueryUsuarioReporteResponse();
                using (IDbConnection db = _config.ObtenerConexion())
                {
                    int totalItems = 0;
                    List<UsuarioReporte> queryResult = db.Query(sql, param: dbParam, commandType: CommandType.Text,
                        map: (UsuarioReporte user, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return user;
                        }, splitOn: "TotalCount").ToList();

                    result.Usuarios = queryResult;
                    result.Total = totalItems;
                    return result;
                }
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ListarUsuarioReporte: SqlException -> " + e.Message);
                throw;
            }
        }

        private void CrearLogAuditoria(HeaderRequest header, IDbConnection db, IDbTransaction tran, Usuario app, string accion, bool cambioRol = false, 
            ActualizarRolesUsuarioRequestBody cambio = null)
        {
            Usuario anterior = new Usuario();
            RolesUsuarioDto rolAnterior = new RolesUsuarioDto();
            List<CambioCampo> cambios = new List<CambioCampo>();
            switch (accion)
            {
                case icCommon.Utils.Constantes.EventName.ACTIVAR:
                    anterior = ObtenerUsuarioXId(app.UsuarioId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "INACTIVO", Nuevo = "ACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.INACTIVAR:
                    anterior = ObtenerUsuarioXId(app.UsuarioId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "ACTIVO", Nuevo = "INACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.BORRAR:
                    anterior = ObtenerUsuarioXId(app.UsuarioId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Agencia", Anterior = anterior.Agencia, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Cargo", Anterior = anterior.Cargo, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Cedula", Anterior = anterior.Cedula, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Email", Anterior = anterior.Email, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "RequiereControlEstacion", Anterior = anterior.RequiereControlEstacion, Nuevo = false });
                    cambios.Add(new CambioCampo { Campo = "TieneEnmascaramiento", Anterior = anterior.TieneEnmascaramiento, Nuevo = false });
                    cambios.Add(new CambioCampo { Campo = "NombreUsuario", Anterior = anterior.NombreUsuario, Nuevo = string.Empty });
                    break;
                case icCommon.Utils.Constantes.EventName.ACTUALIZAR:
                    if (!cambioRol)
                    {
                        anterior = ObtenerUsuarioXId(app.UsuarioId, db, tran);

                        if (anterior.Nombre != app.Nombre)
                            cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = app.Nombre });
                        if (anterior.Estado != app.Estado)
                            cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = app.Estado });
                        if (anterior.Agencia != app.Agencia)
                            cambios.Add(new CambioCampo { Campo = "Agencia", Anterior = anterior.Agencia, Nuevo = app.Agencia });
                        if (anterior.Cargo != app.Cargo)
                            cambios.Add(new CambioCampo { Campo = "Cargo", Anterior = anterior.Cargo, Nuevo = app.Cargo });
                        if (anterior.Cedula != app.Cedula)
                            cambios.Add(new CambioCampo { Campo = "Cedula", Anterior = anterior.Cedula, Nuevo = app.Cedula });
                        if (anterior.Email != app.Email)
                            cambios.Add(new CambioCampo { Campo = "Email", Anterior = anterior.Email, Nuevo = app.Email });
                        if (anterior.RequiereControlEstacion != app.RequiereControlEstacion)
                            cambios.Add(new CambioCampo { Campo = "RequiereControlEstacion", Anterior = anterior.RequiereControlEstacion, Nuevo = app.RequiereControlEstacion });
                        if (anterior.TieneEnmascaramiento != app.TieneEnmascaramiento)
                            cambios.Add(new CambioCampo { Campo = "TieneEnmascaramiento", Anterior = anterior.TieneEnmascaramiento, Nuevo = app.TieneEnmascaramiento });
                        if (anterior.NombreUsuario != app.NombreUsuario)
                            cambios.Add(new CambioCampo { Campo = "NombreUsuario", Anterior = anterior.NombreUsuario, Nuevo = app.NombreUsuario });
                    }
                    else 
                    {
                        anterior = ObtenerUsuarioXId(cambio.UsuarioId, db, tran);
                        app = new Usuario { UsuarioId = anterior.UsuarioId, Nombre = anterior.Nombre };
                        rolAnterior = ConsultarRolesXUsuario(cambio.UsuarioId, cambio.AplicacionId, db, tran);
                        if (rolAnterior.RolPrincipal != null)
                        {
                            if (rolAnterior.RolPrincipal.Id != cambio.RolPrincipalId)
                                cambios.Add(new CambioCampo { Campo = "RolPrincipal", Anterior = rolAnterior.RolPrincipal.Id, Nuevo = cambio.RolPrincipalId });
                        }
                        else {
                            cambios.Add(new CambioCampo { Campo = "RolPrincipal", Anterior = null, Nuevo = cambio.RolPrincipalId });
                        }
                        if (rolAnterior.RolTemporal != null && cambio.RolTemporal != null)
                        {
                            if (rolAnterior.RolTemporal.Id != cambio.RolTemporal.RolId)
                                cambios.Add(new CambioCampo { Campo = "RolTemporal", Anterior = rolAnterior.RolTemporal.Id, Nuevo = cambio.RolTemporal.RolId });
                            if (rolAnterior.RolTemporal.FechaInicio != cambio.RolTemporal.FechaInicio)
                                cambios.Add(new CambioCampo { Campo = "FechaInicio", Anterior = rolAnterior.RolTemporal.FechaInicio, Nuevo = cambio.RolTemporal.FechaInicio });
                            if (rolAnterior.RolTemporal.FechaVencimiento != cambio.RolTemporal.FechaVencimiento)
                                cambios.Add(new CambioCampo { Campo = "FechaVencimiento", Anterior = rolAnterior.RolTemporal.FechaVencimiento, Nuevo = cambio.RolTemporal.FechaVencimiento });
                        }
                        else if (rolAnterior.RolTemporal == null && cambio.RolTemporal != null)
                        {
                            cambios.Add(new CambioCampo { Campo = "RolTemporal", Anterior = null, Nuevo = cambio.RolTemporal.RolId });
                            cambios.Add(new CambioCampo { Campo = "FechaInicio", Anterior = null, Nuevo = cambio.RolTemporal.FechaInicio });
                            cambios.Add(new CambioCampo { Campo = "FechaVencimiento", Anterior = null, Nuevo = cambio.RolTemporal.FechaVencimiento });
                        } 
                        else if (rolAnterior.RolTemporal != null && cambio.RolTemporal == null)
                        {
                            cambios.Add(new CambioCampo { Campo = "RolTemporal", Anterior = rolAnterior.RolTemporal.Id, Nuevo = null });
                            cambios.Add(new CambioCampo { Campo = "FechaInicio", Anterior = rolAnterior.RolTemporal.FechaInicio, Nuevo = null });
                            cambios.Add(new CambioCampo { Campo = "FechaVencimiento", Anterior = rolAnterior.RolTemporal.FechaVencimiento, Nuevo = null });
                        }

                    }
                    
                    break;
                case icCommon.Utils.Constantes.EventName.CREAR:
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = string.Empty, Nuevo = app.Nombre });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = string.Empty, Nuevo = app.Estado });
                    cambios.Add(new CambioCampo { Campo = "Agencia", Anterior = string.Empty, Nuevo = app.Agencia });
                    cambios.Add(new CambioCampo { Campo = "Cargo", Anterior = string.Empty, Nuevo = app.Cargo });
                    cambios.Add(new CambioCampo { Campo = "Cedula", Anterior = string.Empty, Nuevo = app.Cedula });
                    cambios.Add(new CambioCampo { Campo = "Email", Anterior = string.Empty, Nuevo = app.Email });
                    cambios.Add(new CambioCampo { Campo = "RequiereControlEstacion", Anterior = false, Nuevo = app.RequiereControlEstacion });
                    cambios.Add(new CambioCampo { Campo = "TieneEnmascaramiento", Anterior = false, Nuevo = app.TieneEnmascaramiento });
                    cambios.Add(new CambioCampo { Campo = "NombreUsuario", Anterior = string.Empty, Nuevo = app.NombreUsuario });
                    break;
            }
            if (cambioRol)
            {
                _auditoria.InsertarLog(header.UserName, header.StationIp, accion, USUARIO, app.UsuarioId, app.Nombre, cambios, rolAnterior, db, tran);
            }
            else {
                _auditoria.InsertarLog(header.UserName, header.StationIp, accion, USUARIO, app.UsuarioId, app.Nombre, cambios, anterior, db, tran);
            }
            
        }

        private Usuario ObtenerUsuarioXId(long usuarioId, IDbConnection db, IDbTransaction tran)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("UsuarioId", usuarioId, DbType.Int64);

                string sql = $"Select * from [{SCHEMA}].[Usuario] WHERE UsuarioId = @UsuarioId; ";

                Usuario user = db.Query<Usuario>(sql, param: dbPara, transaction: tran, commandType: CommandType.Text).Single();
                return user;
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ObtenerUsuarioPorId: SqlException -> " + e.Message);
                throw;
            }
        }

        private bool UsuarioValido(string cedula, string usuario, string email, long usuarioId, IDbConnection db, IDbTransaction tran, ref string mensaje)
        {
            try
            {
                if (cedula.Length != 10) {
                    mensaje = "Longitud de cédula debe ser de 10 dígitos";
                    return false;
                }

                if (!Validaciones.VerificaCedula(cedula)) {
                    mensaje = "Número de cédula inválido.";
                    return false;
                }

                var dbPara = new DynamicParameters();
                dbPara.Add("Cedula", cedula, DbType.String);

                string sql = $"Select * from [{SCHEMA}].[Usuario] WHERE Cedula = @Cedula;";
                if (usuarioId != 0) {
                    dbPara.Add("UsuarioId", usuarioId, DbType.Int64);
                    sql = $"Select * from [{SCHEMA}].[Usuario] WHERE Cedula = @Cedula AND UsuarioId != @UsuarioId; ";
                }


                var dbParaUs = new DynamicParameters();
                dbParaUs.Add("Usuario", usuario, DbType.String);

                string sqlUsuario = $"Select * from [{SCHEMA}].[Usuario] WHERE NombreUsuario = @Usuario;";
                if (usuarioId != 0)
                {
                    dbParaUs.Add("UsuarioId", usuarioId, DbType.Int64);
                    sqlUsuario = $"Select * from [{SCHEMA}].[Usuario] WHERE NombreUsuario = @Usuario AND UsuarioId != @UsuarioId; ";
                }

                var dbParaEm = new DynamicParameters();
                dbParaEm.Add("Email", email, DbType.String);

                string sqlEmail = $"Select * from [{SCHEMA}].[Usuario] WHERE Email = @Email;";
                if (usuarioId != 0)
                {
                    dbParaEm.Add("UsuarioId", usuarioId, DbType.Int64);
                    sqlEmail = $"Select * from [{SCHEMA}].[Usuario] WHERE Email = @Email AND UsuarioId != @UsuarioId; ";
                }


                Usuario user = db.Query<Usuario>(sql, param: dbPara, transaction: tran, commandType: CommandType.Text).FirstOrDefault();

                if (user != null)
                {
                    mensaje = $"Ya existe un usuario con la cédula {cedula}.";
                    return false;
                }

                Usuario userUs = db.Query<Usuario>(sqlUsuario, param: dbParaUs, transaction: tran, commandType: CommandType.Text).FirstOrDefault();

                if (userUs != null)
                {
                    mensaje = $"Ya existe un usuario con el nombre de usuario {usuario}.";
                    return false;
                }

                Usuario useEmas = db.Query<Usuario>(sqlEmail, param: dbParaEm, transaction: tran, commandType: CommandType.Text).FirstOrDefault();

                if (useEmas != null)
                {
                    mensaje = $"Ya existe un usuario con el email {email}.";
                    return false;
                }

                return true;
            }
            catch (SqlException e)
            {
                Log.Error("UsuarioDLL/ObtenerUsuarioPorId: SqlException -> " + e.Message);
                throw;
            }
        }
    }
}
