﻿using Dapper;
using icCommon.DB;
using icCommon.DTOs.DB;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Aplicaciones;
using icSeguridad.DTOs.DB.Response.Aplicaciones;
using icSeguridad.Models;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace icSeguridad.DLL
{
    public class AplicacionDLL : IAplicacionDLL
    {
        private readonly IProveedorConexion _config;
        private readonly IAuditoria _auditoria;

        const string APLICACION = "APLICACION";
        private readonly string SCHEMA = "";

        public AplicacionDLL(IProveedorConexion proveedor, IAuditoria auditoria)
        {
            _config = proveedor;
            _auditoria = auditoria;
            SCHEMA = _config.ObtenerSchema();
        }

        public int ActivarAplicaciones(HeaderRequest header, ActivacionAplicacionRequestBody body)
        {
            using (IDbConnection db = _config.ObtenerConexion())
            {
                string ids = "(" + string.Join(",", body.AplicacionesIds) + ")";
                string getSql = $"Select * from [{SCHEMA}].[Aplicacion] WHERE AplicacionId in {ids} AND [Estado] = 'INACTIVO'; ";
                string activateSQL = $"UPDATE [{SCHEMA}].[Aplicacion] SET [Estado]='ACTIVO' WHERE AplicacionId in {ids};" +
                    $"SELECT @@ROWCOUNT; ";

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<AplicacionDto> aplicaciones = db.Query<AplicacionDto>(getSql, transaction: tran, commandType: CommandType.Text).ToList();

                        foreach (AplicacionDto app in aplicaciones)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.ACTIVAR);
                        }

                        var result = db.Query<int>(activateSQL, transaction: tran, commandType: CommandType.Text);

                        tran.Commit();
                        return result.ToList().First();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("AplicacionDLL/ActivarAplicaciones: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception sqlException)
                    {
                        Log.Error("AplicacionDLL/ActivarAplicaciones: Transaccion Exception -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public long CrearAplicacion(HeaderRequest header, CreacionAplicacionRequestBody body)
        {
            var dbPara = new DynamicParameters();
            AplicacionDto newApp = body.Aplicacion;
            string userId = header.UserName;
            DateTime date = header.DateTime;
            dbPara.Add("Nombre", newApp.Nombre, DbType.String);
            dbPara.Add("Estado", newApp.Estado, DbType.String);

            string sql = $"INSERT INTO [{SCHEMA}].[Aplicacion](Nombre, [Estado]) " +
                        "VALUES(@Nombre, @Estado);" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";

            List<int> menuIds = new List<int>();

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = db.Query<long>(sql, dbPara, tran, commandType: CommandType.Text).Single();

                        if (newApp.Menu != null && newApp.Menu.Count > 0)
                        {
                            InsertUpdateMenuChildren(db, tran, result, 0, newApp.Menu, userId, date, ref menuIds);
                        }

                        newApp.AplicacionId = result;
                        CrearLogAuditoria(header, db, tran, newApp, icCommon.Utils.Constantes.EventName.CREAR);

                        tran.Commit();
                        return result;

                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("AplicacionDLL/CrearAplicacion: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception sqlException)
                    {
                        Log.Error("AplicacionDLL/CrearAplicacion: Transaccion Exception -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public int DesactivarAplicaciones(HeaderRequest header, InactivacionAplicacionRequestBody body)
        {
            string ids = "(" + string.Join(",", body.AplicacionesIds) + ")";
            string getSql = $"Select * from [{SCHEMA}].[Aplicacion] WHERE AplicacionId in {ids} AND [Estado] = 'INACTIVO'; ";
            string deactivateSQL = $"UPDATE [{SCHEMA}].[Aplicacion] SET Estado='INACTIVO' where AplicacionId in {ids};" +
                $"SELECT @@ROWCOUNT; ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<AplicacionDto> aplicaciones = db.Query<AplicacionDto>(getSql, transaction: tran, commandType: CommandType.Text).ToList();

                        foreach (AplicacionDto app in aplicaciones)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.INACTIVAR);
                        }

                        var result = db.Query<int>(deactivateSQL, transaction: tran, commandType: CommandType.Text);

                        tran.Commit();
                        return result.ToList().First();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("AplicacionDLL/DesactivarAplicaciones: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception sqlException)
                    {
                        Log.Error("AplicacionDLL/DesactivarAplicaciones: Transaccion Exception -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public int EliminarAplicacion(HeaderRequest header, EliminacionAplicacionRequestBody body)
        {
            List<long> applicationIds = body.AplicacionesIds;
            string ids = "(" + string.Join(",", applicationIds) + ")";
            string getSql = $"Select * from [{SCHEMA}].[Aplicacion] WHERE AplicacionId in {ids}; ";
            string deleteSql = $"DELETE FROM [{SCHEMA}].[Menu] WHERE AplicacionId in {ids}; " +
                               $"DELETE FROM [{SCHEMA}].[Aplicacion] WHERE AplicacionId in {ids}; " +
                               $"SELECT @@ROWCOUNT; ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<AplicacionDto> aplicaciones = db.Query<AplicacionDto>(getSql, transaction: tran, commandType: CommandType.Text).ToList();

                        foreach (AplicacionDto app in aplicaciones)
                        {
                            CrearLogAuditoria(header, db, tran, app, icCommon.Utils.Constantes.EventName.BORRAR);
                        }

                        var result = 0;
                        if (applicationIds.Count > 0) result = db.Query<int>(deleteSql, transaction: tran, commandType: CommandType.Text).Single();


                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("AplicacionDLL/EliminarAplicacion: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception sqlException)
                    {
                        Log.Error("AplicacionDLL/EliminarAplicacion: Transaccion Exception -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public AplicacionDto ObtenerAplicacionPorId(HeaderRequest header, ConsultaAplicacionRequestBody body)
        {
            var dbPara = new DynamicParameters();
            dbPara.Add("AplicacionId", body.AplicacionId, DbType.Int64);

            string sql = $"Select * from [{SCHEMA}].[Aplicacion] WHERE AplicacionId = @AplicacionId; ";
            sql += $"Select * from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";
            sql += $"Select Coalesce(Max(Nivel),0) from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId; ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                try 
                {
                    using (SqlMapper.GridReader multi = db.QueryMultiple(sql, param: dbPara, commandType: CommandType.Text))
                    {
                        AplicacionDto result;

                        result = multi.Read<AplicacionDto>().Single();
                        List<MenuDto>? children = multi.Read<MenuDto>()?.ToList();
                        int maxNivel = multi.Read<int>().Single();

                        List<MenuDto> previousNivel = new List<MenuDto>();

                        if (children != null)
                        {

                            for (int i = maxNivel; i >= 0; i--)
                            {
                                List<MenuDto> levelChildren = children.FindAll(x => x.Nivel == i);

                                levelChildren.ForEach(x => x.Hijos = previousNivel.FindAll(y => y.PadreId == x.MenuId));

                                previousNivel = levelChildren;
                                children.RemoveAll(x => x.Nivel == i);
                            }
                        }

                        result.Menu = previousNivel;

                        return result;
                    }
                }
                catch (SqlException sqlException)
                {
                    Log.Error("AplicacionDLL/ObtenerAplicacionPorId: SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }

        public QueryAplicacionesResponse ListarAplicaciones(HeaderRequest header, ListaAplicacionesRequestBody body)
        {
            string state = string.IsNullOrEmpty(body.Estado) ? string.Empty : body.Estado.Trim();
            string sortBy = body.OrdenarPor ?? string.Empty;
            string filterBy = body.FiltrarPor ?? string.Empty;
            string filterValue = body.ValorFiltro != null ? body.ValorFiltro.ToLower() : string.Empty;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            var dbPara = new DynamicParameters();
            dbPara.Add("State", state.ToUpper(), DbType.String);
            dbPara.Add("SortBy", sortBy, DbType.String);
            dbPara.Add("SortDesc", body.OrdenDesc, DbType.Boolean);
            dbPara.Add("FilterBy", filterBy, DbType.String);
            dbPara.Add("FilterValue", '%' + filterValue.ToLower() + '%', DbType.String);

            dbPara.Add("Page", page, DbType.Int32);
            dbPara.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            string sql = $"Select *, COUNT(*) OVER() as TotalCount from [{SCHEMA}].[Aplicacion] where 1=1 ";

            if (!string.IsNullOrEmpty(state))
            {
                sql += "AND UPPER([Estado]) = @State ";
            }

            if (!string.IsNullOrEmpty(filterBy) && !string.IsNullOrEmpty(filterValue))
            {
                switch (filterBy.ToLower())
                {
                    case "name": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST([Nombre] as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as nvarchar) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                }
            }

            if (!string.IsNullOrEmpty(sortBy))
            {
                switch (sortBy.ToLower())
                {
                    case "name":
                        sql += "ORDER BY [Nombre] ";
                        break;
                    default:
                        sql += "ORDER BY [Nombre] ";
                        break;
                }
            }
            else
            {
                sql += "ORDER BY Nombre ";
            }
            sql += body.OrdenDesc ? "DESC " : "ASC ";

            sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                   "FETCH NEXT @ItemsPerPage ROWS ONLY; ";

            QueryAplicacionesResponse result = new QueryAplicacionesResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                try 
                {
                    int totalItems = 0;
                    List<Aplicacion> queryResult = db.Query(sql, param: dbPara, commandType: CommandType.Text,
                        map: (Aplicacion app, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return app;
                        }, splitOn: "TotalCount").ToList();

                    result.Aplicaciones = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException sqlException)
                {
                    Log.Error("AplicacionDLL/ListarAplicaciones: SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }

        public int ActualizarAplicacion(HeaderRequest header, CreacionAplicacionRequestBody body)
        {
            var dbPara = new DynamicParameters();
            dbPara.Add("AplicacionId", body.Aplicacion.AplicacionId, DbType.Int64);
            dbPara.Add("Nombre", body.Aplicacion.Nombre, DbType.String);
            dbPara.Add("Estado", body.Aplicacion.Estado, DbType.String);

            string sql = $"UPDATE [{SCHEMA}].[Aplicacion] SET Nombre = @Nombre, Estado = @Estado WHERE AplicacionId = @AplicacionId;" +
                        "SELECT @AplicacionId; ";

            List<int> menuIds = new List<int>();
            int deleted = 0;
            using (IDbConnection db = _config.ObtenerConexion())
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        CrearLogAuditoria(header, db, tran, body.Aplicacion, icCommon.Utils.Constantes.EventName.ACTUALIZAR);

                        var result = db.Query<int>(sql, dbPara, tran, commandType: CommandType.Text).Single();

                        if (body.Aplicacion.Menu != null && body.Aplicacion.Menu.Count > 0)
                        {
                            InsertUpdateMenuChildren(db, tran, body.Aplicacion.AplicacionId, 0, body.Aplicacion.Menu, header.UserName, header.DateTime, ref menuIds);
                        }

                        if (menuIds.Count > 0)
                        {
                            string ids = string.Join(",", menuIds);
                            string deleteSql = $"DELETE FROM [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId and MenuId NOT IN ({ids});" +
                                                "SELECT @@ROWCOUNT; ";
                            if (ids.Length > 0) deleted = db.Query<int>(deleteSql, dbPara, tran, commandType: CommandType.Text).Single();
                        }

                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("AplicacionDLL/ActualizarAplicacion: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception sqlException)
                    {
                        Log.Error("AplicacionDLL/ActualizarAplicacion: Transaccion Exception -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        private AplicacionDto ObtenerAplicacionesXId(long aplicacionId, IDbConnection db, IDbTransaction tran)
        {
            if (aplicacionId <= 0) return null;

            var dbPara = new DynamicParameters();
            dbPara.Add("AplicacionId", aplicacionId, DbType.Int64);

            try
            {
                AplicacionDto result = db.Query<AplicacionDto>($"Select * from [{SCHEMA}].[Aplicacion] WHERE AplicacionId = @AplicacionId;", param: dbPara, commandType: CommandType.Text, transaction: tran).Single();

                List<MenuDto>? children = db.Query<MenuDto>($"Select * from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId;", param: dbPara, commandType: CommandType.Text, transaction: tran).ToList();

                int maxNivel = db.Query<int>($"Select Coalesce(Max(Nivel),0) from [{SCHEMA}].[Menu] WHERE AplicacionId = @AplicacionId;", param: dbPara, commandType: CommandType.Text, transaction: tran).Single();

                List<MenuDto> previousNivel = new List<MenuDto>();

                if (children != null)
                {

                    for (int i = maxNivel; i >= 0; i--)
                    {
                        List<MenuDto> levelChildren = children.FindAll(x => x.Nivel == i);

                        levelChildren.ForEach(x => x.Hijos = previousNivel.FindAll(y => y.PadreId == x.MenuId));

                        previousNivel = levelChildren;
                        children.RemoveAll(x => x.Nivel == i);
                    }
                }

                result.Menu = previousNivel;

                return result;
            }
            catch (SqlException e)
            {
                Log.Error("AplicacionDLL/ObtenerAplicacionesXId: SqlException -> " + e.Message);
                throw;
            }
        }

        private void CrearLogAuditoria(HeaderRequest header, IDbConnection db, IDbTransaction tran, AplicacionDto app, string accion)
        {
            AplicacionDto anterior = new AplicacionDto();

            List<CambioCampo> cambios = new List<CambioCampo>();
            switch (accion)
            {
                case icCommon.Utils.Constantes.EventName.ACTIVAR:
                    anterior = ObtenerAplicacionesXId(app.AplicacionId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "INACTIVO", Nuevo = "ACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.INACTIVAR:
                    anterior = ObtenerAplicacionesXId(app.AplicacionId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "ACTIVO", Nuevo = "INACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.BORRAR:
                    anterior = ObtenerAplicacionesXId(app.AplicacionId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Menu", Anterior = anterior.Menu, Nuevo = null });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = string.Empty });
                    break;
                case icCommon.Utils.Constantes.EventName.ACTUALIZAR:
                    anterior = ObtenerAplicacionesXId(app.AplicacionId, db, tran);
                    if (anterior.Nombre != app.Nombre)
                        cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = app.Nombre });
                    if (JsonConvert.SerializeObject(anterior.Menu) != JsonConvert.SerializeObject(app.Menu))
                        cambios.Add(new CambioCampo { Campo = "Menu", Anterior = anterior.Menu, Nuevo = app.Menu });
                    if (anterior.Estado != app.Estado)
                        cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = app.Estado });
                    break;
                case icCommon.Utils.Constantes.EventName.CREAR:
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = "", Nuevo = app.Nombre });
                    cambios.Add(new CambioCampo { Campo = "Menu", Anterior = "", Nuevo = app.Menu });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "", Nuevo = app.Estado });
                    break;
            }
            _auditoria.InsertarLog(header.UserName, header.StationIp, accion, APLICACION, app.AplicacionId, app.Nombre, cambios, anterior, db, tran);
        }

        private void InsertUpdateMenuChildren(IDbConnection db, IDbTransaction tran, long appId, long parentId, List<MenuDto> children, string userId, DateTime date, ref List<int> ids)
        {
            List<int> menu = new List<int>();
            children.ForEach(child => {
                var dbPara = new DynamicParameters();
                dbPara.Add("MenuId", child.MenuId, DbType.Int64);
                dbPara.Add("PadreId", parentId, DbType.Int64);
                dbPara.Add("Nombre", child.Nombre, DbType.String);
                dbPara.Add("Ruta", child.Ruta != null ? child.Ruta : string.Empty, DbType.String);
                dbPara.Add("Icono", child.Icono, DbType.String);
                dbPara.Add("Nivel", child.Nivel, DbType.Int32);
                dbPara.Add("Estado", child.Estado, DbType.String);
                dbPara.Add("AplicacionId", appId, DbType.Int64);
                dbPara.Add("SeparadorNivel", child.SeparadorNivel, DbType.Boolean);

                string sql = string.Empty;

                if (child.MenuId == 0)
                {
                    // Insert
                    if (parentId == 0)
                    {
                        sql = $"INSERT INTO [{SCHEMA}].[Menu](Nombre, [Ruta], [Icono], [Nivel], [Estado], AplicacionId, SeparadorNivel) " +
                        "VALUES(@Nombre, @Ruta, @Icono, @Nivel, @Estado, @AplicacionId, @SeparadorNivel);" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";
                    }
                    else
                    {
                        sql = $"INSERT INTO [{SCHEMA}].[Menu](PadreId, Nombre, [Ruta], [Icono], [Nivel], [Estado], AplicacionId, SeparadorNivel) " +
                        "VALUES(@PadreId, @Nombre, @Ruta, @Icono, @Nivel, @Estado, @AplicacionId, @SeparadorNivel);" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";
                    }
                }
                else
                {
                    // Update
                    sql = $"UPDATE [{SCHEMA}].[Menu] SET Nombre = @Nombre, [Ruta] = @Ruta, [Icono] = @Icono, [Estado] = @Estado, SeparadorNivel = @SeparadorNivel " +
                        " WHERE MenuId = @MenuId AND AplicacionId = @AplicacionId;" +
                        " SELECT @MenuId;";
                }

                var result = db.Query<int>(sql, dbPara, tran, commandType: CommandType.Text).Single();
                menu.Add(result);

                if (child.Hijos != null && child.Hijos.Count > 0)
                {
                    InsertUpdateMenuChildren(db, tran, appId, result, child.Hijos, userId, date, ref menu);
                }

            });
            ids.AddRange(menu);
        }
    }
}
