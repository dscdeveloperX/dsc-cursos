﻿using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Usuarios;
using icSeguridad.DTOs.DB.Response.Usuarios;
using icSeguridad.Models;

namespace icSeguridad.DLL.Interfaces
{
    public interface IUsuarioDLL
    {
        QueryUsuarioResponse ListarUsuarios(HeaderRequest header, ListaUsuariosRequestBody body);
        int ActivarUsuario(HeaderRequest header, ActivacionUsuarioRequestBody body);
        int InactivarUsuario(HeaderRequest header, InactivacionUsuarioRequestBody body);
        UsuarioDto ObtenerUsuarioPorId(HeaderRequest header, ConsultaUsuarioRequestBody body);
        Usuario ObtenerUsuarioPorNombre(HeaderRequest header, AutenticacionUsuarioRequestBody body);
        long CrearUsuario(HeaderRequest header, CreacionUsuarioRequestBody body);
        int EliminarUsuario(HeaderRequest header, EliminacionUsuarioRequestBody body);
        int ActualizarUsuario(HeaderRequest header, CreacionUsuarioRequestBody body);
        RolesUsuarioDto ConsultarRolesUsuario(HeaderRequest header, ConsultaRolesUsuarioRequestBody body);
        RolesUsuarioDto ActualizarRolesUsuario(HeaderRequest header, ActualizarRolesUsuarioRequestBody body);
        PerfilUsuario ObtenerPerfilUsuario(long applicationId, Usuario user);        
        int ActualizarIntentosFallidos(Usuario user);
        QueryUsuarioReporteResponse ListarUsuarioReporte(HeaderRequest header, ListaUsuariosReporteRequestBody body);
    }
}
