﻿using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Aplicaciones;
using icSeguridad.DTOs.DB.Response.Aplicaciones;
using icSeguridad.Models;

namespace icSeguridad.DLL.Interfaces
{
    public interface IAplicacionDLL
    {
        QueryAplicacionesResponse ListarAplicaciones(HeaderRequest header, ListaAplicacionesRequestBody body);
        int ActivarAplicaciones(HeaderRequest header, ActivacionAplicacionRequestBody body);
        int DesactivarAplicaciones(HeaderRequest header, InactivacionAplicacionRequestBody body);
        AplicacionDto ObtenerAplicacionPorId(HeaderRequest header, ConsultaAplicacionRequestBody body);
        long CrearAplicacion(HeaderRequest header, CreacionAplicacionRequestBody body);
        int EliminarAplicacion(HeaderRequest header, EliminacionAplicacionRequestBody body);
        int ActualizarAplicacion(HeaderRequest header, CreacionAplicacionRequestBody body);
    }
}
