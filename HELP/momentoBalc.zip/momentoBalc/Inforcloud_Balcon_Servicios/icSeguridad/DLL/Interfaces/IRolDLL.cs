﻿using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Roles;
using icSeguridad.DTOs.DB.Response.Roles;
using icSeguridad.Models;

namespace icSeguridad.DLL.Interfaces
{
    public interface IRolDLL
    {
        QueryRolesResponse ListarRoles(HeaderRequest header, ListaRolesRequestBody body);
        QueryRolesUsuarioResponse ListarRolesUsuario(HeaderRequest header, ListaRolesRequestBody body);
        RolDto ObtenerRolPorId(HeaderRequest header, ConsultaRolRequestBody body);
        RolDto ObtenerPermisosRolPorId(HeaderRequest header, ConsultaPermisosRolRequestBody body);
        long CrearRol(HeaderRequest header, CreacionRolRequestBody body);
        int EliminarRol(HeaderRequest header, EliminacionRolRequestBody body);
        int ActualizarRol(HeaderRequest header, EdicionRolRequestBody body);
        int ActualizarPermisosRol(HeaderRequest header, EdicionPermisosRolRequestBody body);
        int ActivarRol(HeaderRequest header, ActivacionRolRequestBody body);
        int DesactivarRol(HeaderRequest header, InactivacionRolRequestBody body);
        QueryRolesReporteResponse ListarRolesReporte(HeaderRequest header, ListaRolesReporteRequestBody body);
    }
}
