﻿using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Catalogos;
using icSeguridad.DTOs.DB.Response.Catalogos;
using icSeguridad.Models;

namespace icSeguridad.DLL.Interfaces
{
    public interface ICatalogoDLL
    {
        Catalogo ObtenerCatalogoPorId(HeaderRequest request, ConsultaCatalogoRequestBody body);
        QueryCatalogosResponse ListarCatalogos(HeaderRequest header, ListaCatalogosRequestBody body);
        QueryNombreCatalogosResponse ListarNombresCatalogos(HeaderRequest header, ListaNombreCatalogosRequestBody dbParam);
        long CrearCatalogo(HeaderRequest header, CreacionCatalogoRequestBody CatalogueCreateList);
        int EliminarCatalogos(HeaderRequest request, EliminacionCatalogoRequestBody body);
        int ActualizarCatalogo(HeaderRequest header, EdicionCatalogoRequestBody param);
    }
}
