﻿using Dapper;
using icCommon.DB;
using icCommon.DTOs.DB;
using icSeguridad.DLL.Interfaces;
using icSeguridad.DTOs.API.Request;
using icSeguridad.DTOs.API.Request.Catalogos;
using icSeguridad.DTOs.DB.Response.Catalogos;
using icSeguridad.Models;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;

namespace icSeguridad.DLL
{
    public class CatalogoDLL : ICatalogoDLL
    {
        private readonly IProveedorConexion _config;
        private readonly IAuditoria _auditoria;

        const string CATALOGO = "CATALOGO";
        private readonly string SCHEMA = "";

        public CatalogoDLL(IProveedorConexion proveedor, IAuditoria auditoria)
        {
            _config = proveedor;
            _auditoria = auditoria;
            SCHEMA = _config.ObtenerSchema();
        }

        public long CrearCatalogo(HeaderRequest header, CreacionCatalogoRequestBody CatalogoCreateList)
        {
            DynamicParameters dbPara = new DynamicParameters();
            dbPara.Add("Descripcion", CatalogoCreateList.Catalogo.Descripcion, DbType.String);
            dbPara.Add("Codigo", CatalogoCreateList.Catalogo.Codigo, DbType.String);
            dbPara.Add("Nombre", CatalogoCreateList.Catalogo.Nombre, DbType.String);
            dbPara.Add("Complemento", CatalogoCreateList.Catalogo.Complemento, DbType.String);
            dbPara.Add("Estado", CatalogoCreateList.Catalogo.Estado, DbType.String);

            using (IDbConnection db = _config.ObtenerConexion())
            {
                string insertSQL = $"INSERT INTO [{SCHEMA}].[Catalogo](Descripcion,Codigo,Nombre,Complemento,Estado) " +
                        $"VALUES(@Descripcion,@Codigo,@Nombre,@Complemento,@Estado);" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = db.Query<long>(insertSQL, dbPara, tran, commandType: CommandType.Text).First();

                        Catalogo catalogo = new Catalogo
                        {
                            CatalogoId = result,
                            Codigo = CatalogoCreateList.Catalogo.Codigo,
                            Complemento = CatalogoCreateList.Catalogo.Complemento,
                            Descripcion = CatalogoCreateList.Catalogo.Descripcion,
                            Estado = CatalogoCreateList.Catalogo.Estado,
                            Nombre = CatalogoCreateList.Catalogo.Nombre
                        };
                        CrearLogAuditoria(header, db, tran, catalogo, icCommon.Utils.Constantes.EventName.CREAR);
                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("CatalogoDLL/CrearCatalogo: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("CatalogoDLL/CrearCatalogo: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public int EliminarCatalogos(HeaderRequest request, EliminacionCatalogoRequestBody body)
        {
            using (IDbConnection db = _config.ObtenerConexion())
            {
                string ids = "(" + string.Join(",", body.CatalogoIds) + ")";
                string getSql = $"Select * from [{SCHEMA}].[Catalogo] WHERE CatalogoId in {ids} ORDER BY CatalogoId; ";
                string deleteSQL = $"DELETE FROM [{SCHEMA}].[Catalogo] WHERE CatalogoId in {ids};" +
                    $"SELECT @@ROWCOUNT; ";


                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        List<Catalogo> catalogos = db.Query<Catalogo>(getSql, transaction: tran, commandType: CommandType.Text).ToList();

                        foreach (Catalogo cat in catalogos)
                        {
                            CrearLogAuditoria(request, db, tran, cat, icCommon.Utils.Constantes.EventName.BORRAR);
                        }

                        var result = db.Query<int>(deleteSQL, transaction: tran, commandType: CommandType.Text);

                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("CatalogoDLL/EliminarCatalogos: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("CatalogoDLL/EliminarCatalogos: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public Catalogo ObtenerCatalogoPorId(HeaderRequest header, ConsultaCatalogoRequestBody body)
        {
            long catalogueId = body.CatalogoId;

            #region user dynamic parameter
            var dbPara = new DynamicParameters();
            dbPara.Add("CatalogoId", catalogueId, DbType.Int64);
            #endregion

            string sql = $"SELECT * FROM [{SCHEMA}].[Catalogo] WHERE CatalogoId = @CatalogoId ORDER BY CatalogoId";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                try {
                    Catalogo result = db.Query<Catalogo>(sql, param: dbPara, commandType: CommandType.Text).FirstOrDefault();
                    return result;
                }
                catch (SqlException sqlException)
                {
                    Log.Error("CatalogoDLL/ObtenerCatalogoPorId: Transaccion SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }

        public QueryCatalogosResponse ListarCatalogos(HeaderRequest header, ListaCatalogosRequestBody body)
        {
            string userName = header.UserName;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            string catalogueName = body.NombreCatalogo ?? string.Empty;
            string state = body.Estado ?? string.Empty;
            string sortBy = body.OrdenarPor ?? string.Empty;
            string filterBy = body.FiltrarPor ?? string.Empty;
            string filterValue = body.ValorFiltro != null ? body.ValorFiltro.ToLower() : string.Empty;

            #region user dynamic parameter
            var dbParam = new DynamicParameters();
            dbParam.Add("Username", userName, DbType.String);
            dbParam.Add("Page", page, DbType.Int32);
            dbParam.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            dbParam.Add("Nombre", '%' + catalogueName.ToLower() + '%', DbType.String);
            dbParam.Add("Estado", state.ToUpper(), DbType.String);
            dbParam.Add("SortBy", sortBy, DbType.String);
            dbParam.Add("SortDesc", body.OrdenDesc, DbType.Boolean);
            dbParam.Add("FilterBy", filterBy, DbType.String);
            dbParam.Add("FilterValue", '%' + filterValue.ToLower() + '%', DbType.String);
            #endregion

            string sql = $"Select *, COUNT(*) OVER() as TotalCount from [{SCHEMA}].[Catalogo] where 1=1 ";

            if (!string.IsNullOrEmpty(state))
            {
                sql += "AND UPPER([Estado]) = @Estado ";
            }

            if (!string.IsNullOrEmpty(catalogueName))
            {
                sql += "AND LOWER(Nombre) like @Nombre ";
            }

            if (!string.IsNullOrEmpty(filterBy) && !string.IsNullOrEmpty(filterValue))
            {
                switch (filterBy.ToLower())
                {
                    case "key":
                        sql += "AND LOWER([Codigo]) like @FilterValue ";
                        break;
                    case "value": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST([Descripcion] as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                }
            }

            bool sortDesc = body.OrdenDesc;

            if (!string.IsNullOrEmpty(sortBy))
            {
                switch (sortBy.ToLower())
                {
                    case "key":
                        sql += "ORDER BY [Codigo] ";
                        break;
                    case "value":
                        sql += "ORDER BY [Descripcion] ";
                        break;
                    default:
                        sql += "ORDER BY [Codigo] ";
                        break;
                }
            }
            else
            {
                sql += "ORDER BY [Codigo] ";
            }
            sql += sortDesc ? "DESC " : "ASC ";

            sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                   "FETCH NEXT @ItemsPerPage ROWS ONLY; ";

            QueryCatalogosResponse result = new QueryCatalogosResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<Catalogo> queryResult = db.Query(sql, param: dbParam, commandType: CommandType.Text,
                        map: (Catalogo catalogue, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return catalogue;
                        }, splitOn: "TotalCount").ToList();

                    result.Catalogos = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("CatalogoDLL/ListarCatalogos: SqlException -> " + e.Message);
                    throw;
                }
            }
            
        }

        public QueryNombreCatalogosResponse ListarNombresCatalogos(HeaderRequest header, ListaNombreCatalogosRequestBody body)
        {
            string userName = header.UserName;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;
            string catalogueName = body.NombreCatalogo ?? string.Empty;

            #region user dynamic parameter
            var dbPara = new DynamicParameters();
            dbPara.Add("Username", userName, DbType.String);
            dbPara.Add("Page", page, DbType.Int32);
            dbPara.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            dbPara.Add("CatalogoName", '%' + catalogueName.ToLower() + '%', DbType.String);
            #endregion

            string sql = $"SELECT DISTINCT [Nombre], COUNT(*) OVER() as TotalCount FROM [{SCHEMA}].[Catalogo] ";

            if (!string.IsNullOrEmpty(catalogueName))
            {
                sql += "WHERE LOWER(Name) LIKE @CatalogoName ";
            }

            sql += "ORDER BY [Nombre] ASC ";

            sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                   "FETCH NEXT @ItemsPerPage ROWS ONLY; ";

            QueryNombreCatalogosResponse result = new QueryNombreCatalogosResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<string> queryResult = db.Query(sql, param: dbPara, commandType: CommandType.Text,
                        map: (string catalogue, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return catalogue;
                        }, splitOn: "TotalCount").ToList();

                    result.NombreCatalogos = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("CatalogoDLL/ListarNombresCatalogos: SqlException -> " + e.Message);
                    throw;
                }
            }            
        }

        public int ActualizarCatalogo(HeaderRequest header, EdicionCatalogoRequestBody body)
        {
            DynamicParameters dbPara = new DynamicParameters();
            dbPara.Add("Descripcion", body.Catalogo.Descripcion, DbType.String);
            dbPara.Add("CatalogoId", body.Catalogo.CatalogoId, DbType.Int64);

            using (IDbConnection db = _config.ObtenerConexion())
            {
                string updateSQL = $"UPDATE [{SCHEMA}].[Catalogo] SET Descripcion=@Descripcion where CatalogoId=@CatalogoId;" +
                        $"SELECT @@ROWCOUNT; ";

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        CrearLogAuditoria(header, db, tran, body.Catalogo, icCommon.Utils.Constantes.EventName.ACTUALIZAR);

                        var result = db.Query<int>(updateSQL, dbPara, tran, commandType: CommandType.Text);

                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("CatalogoDLL/ActualizarCatalogo: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception exception)
                    {
                        Log.Error("CatalogoDLL/ActualizarCatalogo: Transaccion Exception -> " + exception.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        private void CrearLogAuditoria(HeaderRequest header, IDbConnection db, IDbTransaction tran, Catalogo catalogo, string accion)
        {
            Catalogo anterior = new Catalogo();

            List<CambioCampo> cambios = new List<CambioCampo>();
            switch (accion)
            {
                case icCommon.Utils.Constantes.EventName.ACTIVAR:
                    anterior = ObtenerCatalogoXId(catalogo.CatalogoId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "INACTIVO", Nuevo = "ACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.INACTIVAR:
                    anterior = ObtenerCatalogoXId(catalogo.CatalogoId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = "ACTIVO", Nuevo = "INACTIVO" });
                    break;
                case icCommon.Utils.Constantes.EventName.BORRAR:
                    anterior = ObtenerCatalogoXId(catalogo.CatalogoId, db, tran);
                    cambios.Add(new CambioCampo { Campo = "Codigo", Anterior = anterior.Codigo, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Descripcion", Anterior = anterior.Descripcion, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Complemento", Anterior = anterior.Complemento, Nuevo = string.Empty });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = string.Empty });
                    break;
                case icCommon.Utils.Constantes.EventName.ACTUALIZAR:
                    anterior = ObtenerCatalogoXId(catalogo.CatalogoId, db, tran);
                    if (anterior.Codigo != catalogo.Codigo)
                        cambios.Add(new CambioCampo { Campo = "Codigo", Anterior = anterior.Codigo, Nuevo = catalogo.Codigo });
                    if (anterior.Nombre != catalogo.Nombre)
                        cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = anterior.Nombre, Nuevo = catalogo.Nombre });
                    if (anterior.Descripcion != catalogo.Descripcion)
                        cambios.Add(new CambioCampo { Campo = "Descripcion", Anterior = anterior.Descripcion, Nuevo = catalogo.Descripcion });
                    if (anterior.Complemento != catalogo.Complemento)
                        cambios.Add(new CambioCampo { Campo = "Complemento", Anterior = anterior.Complemento, Nuevo = catalogo.Complemento });
                    if (anterior.Estado != catalogo.Estado)
                        cambios.Add(new CambioCampo { Campo = "Estado", Anterior = anterior.Estado, Nuevo = catalogo.Estado });
                    break;
                case icCommon.Utils.Constantes.EventName.CREAR:
                    cambios.Add(new CambioCampo { Campo = "Codigo", Anterior = string.Empty, Nuevo = catalogo.Codigo });
                    cambios.Add(new CambioCampo { Campo = "Nombre", Anterior = string.Empty, Nuevo = catalogo.Nombre });
                    cambios.Add(new CambioCampo { Campo = "Descripcion", Anterior = string.Empty, Nuevo = catalogo.Descripcion });
                    cambios.Add(new CambioCampo { Campo = "Complemento", Anterior = string.Empty, Nuevo = catalogo.Complemento });
                    cambios.Add(new CambioCampo { Campo = "Estado", Anterior = string.Empty, Nuevo = catalogo.Estado });
                    break;
            }
            _auditoria.InsertarLog(header.UserName, header.StationIp, accion, CATALOGO, catalogo.CatalogoId, catalogo.Nombre, cambios, anterior, db, tran);
        }

        private Catalogo ObtenerCatalogoXId(object catalogueId, IDbConnection db, IDbTransaction tran)
        {
            #region user dynamic parameter
            var dbPara = new DynamicParameters();
            dbPara.Add("CatalogoId", catalogueId, DbType.Int64);
            #endregion

            string sql = $"SELECT * FROM [{SCHEMA}].[Catalogo] WHERE CatalogoId = @CatalogoId ORDER BY CatalogoId";

            try
            {                
                Catalogo result = db.Query<Catalogo>(sql, param: dbPara, transaction: tran, commandType: CommandType.Text).Single();
                return result;
            }
            catch (SqlException e)
            {
                Log.Error("CatalogoDLL/ObtenerCatalogoXId: SqlException -> " + e.Message);
                throw;
            }
        }
    }
}
