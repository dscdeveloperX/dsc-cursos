using System.Web.Http;
using WebActivatorEx;
using icSwithBalconServicios;
using Swashbuckle.Application;
using System.IO;

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace icSwithBalconServicios
{
    /// <summary>
    /// Configuracion Swagger
    /// </summary>
    public class SwaggerConfig
    {
        /// <summary>
        /// OBTENEMOS EL PATH DEL ARCHIVO XML DE DOCUMENTACI?N.
        /// </summary>
        /// <returns></returns>
        protected static string GetXmlCommentsPath()
        {
            return Path.Combine(System.Web.HttpRuntime.AppDomainAppPath, "bin", "icSwithBalconServicios.xml");
        }

        /// <summary>
        /// Registro de metodos Swagger
        /// </summary>
        public static void Register()
        {
            // var thisAssembly = typeof(SwaggerConfig).Assembly;

            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                {
                    // DEFINIMOS LAS CARACTER?STICAS DEL WEB API.
                    c.SingleApiVersion("v1", "Switch Balcon Servicios API")
                        .Description("Web API para establecer conexion con el AS400.");

                    // HABILITAMOS EL ARCHIVO DE DOCUMENTACI?N XML.
                    c.IncludeXmlComments(GetXmlCommentsPath());

                    // NOTE: You must also configure 'EnableApiKeySupport' below in the SwaggerUI section
                    //
                    // HABILITAMOS LA AUTENTICACI?N JWT.
                    c.ApiKey("Authorization")
                    .Description("API Authentication")
                    .Name("Bearer")
                    .In("header");

                    // If you want the output Swagger docs to be indented properly, enable the "PrettyPrint" option.
                    //
                    c.PrettyPrint();
                })
                .EnableSwaggerUi(c =>
                {
                    // If your API supports ApiKey, you can override the default values.
                    // "apiKeyIn" can either be "query" or "header"
                    //
                    // HABILITAMOS LA AUTENTICACI?N JWT EN LA INTERFAZ.
                    c.EnableApiKeySupport("Authorization", "header");

                    // Use the "DocumentTitle" option to change the Document title.
                    // Very helpful when you have multiple Swagger pages open, to tell them apart.
                    //
                    //c.DocumentTitle("My Swagger UI");
                });
        }
    }
}
