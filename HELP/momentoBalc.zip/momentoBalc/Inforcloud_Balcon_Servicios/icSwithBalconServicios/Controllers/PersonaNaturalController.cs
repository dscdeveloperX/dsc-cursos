﻿using FluentValidation.Results;
using icCommonFramework.Utils;
using Newtonsoft.Json;
using log4net;
using icSwithBalconServicios.BLL;
using icSwithBalconServicios.DTOs.API.Request;
using icSwithBalconServicios.DTOs.API.Response;
using icSwithBalconServicios.DTOs.API.Validator;
using System.Web.Http;
using System.Web.Http.Description;
using icCommonFramework.ManejoErrores.Utils;
using System.Net.Http;
using System.Net;
using System.Web;
using icSwithBalconServicios.DTOs.API.Request.PersonaNatural;
using icSwithBalconServicios.DTOs.API.Response.PersonaNatural;
using System;
using icSwithBalconServicios.DTOs.API.Response.PersonaNatural.Persona;
using icSwithBalconServicios.DTOs.API.Request.PersonaNatural.Persona;

namespace icSwithBalconServicios.Controllers
{
    [RoutePrefix("api/v1/switchBalcon/personaNatural")]
    [Authorize]
    public class PersonaNaturalController : ApiController
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(PersonaNaturalController));

        private readonly BalconServiciosPersonaNatural _clRepository;
        public PersonaNaturalController()
        {
            _clRepository = new BalconServiciosPersonaNatural();
        }

        [HttpPost]
        [Route("Consultar")]
        [ResponseType(typeof(ConsultaPersonaNaturalResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarPersonaNatural([FromBody] ConsultaPersonaNaturalRequest request)
        {
            ConsultaPersonaNaturalResponse response = new ConsultaPersonaNaturalResponse();
            ConsultaPersonaNaturalValidator validator = new ConsultaPersonaNaturalValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/ConsultarPersonaNatural: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/ConsultarPersonaNatural -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultarPersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/ConsultarPersonaNatural -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("Editar")]
        [ResponseType(typeof(EdicionPersonaNaturalResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage EditarPersonaNatural([FromBody] EdicionPersonaNaturalRequest request)
        {
            EdicionPersonaNaturalResponse response = new EdicionPersonaNaturalResponse();
            EdicionPersonaNaturalValidator validator = new EdicionPersonaNaturalValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/EditarPersonaNatural: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/EditarPersonaNatural -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.EditarPersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/EditarPersonaNatural -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }


        [HttpPost]
        [Route("Editar/Fallecido")]
        [ResponseType(typeof(EdicionPersonaNaturalFallecidoResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage EditarPersonaNaturalFallecido([FromBody] EdicionPersonaNaturalFallecidoRequest request)
        {
            EdicionPersonaNaturalFallecidoResponse response = new EdicionPersonaNaturalFallecidoResponse();
            EdicionPersonaNaturalFallecidoValidator validator = new EdicionPersonaNaturalFallecidoValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/EditarPersonaNaturalFallecido: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/EditarPersonaNaturalFallecido -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.EditarPersonaNaturalFallecido(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/EditarPersonaNaturalFallecido -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }


        [HttpPost]
        [Route("Crear")]
        [ResponseType(typeof(CreacionPersonaNaturalResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage CreacionPersonaNatural([FromBody] CreacionPersonaNaturalRequest request)
        {
            CreacionPersonaNaturalResponse response = new CreacionPersonaNaturalResponse();
            CreacionPersonaNaturalValidator validator = new CreacionPersonaNaturalValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/CreacionPersonaNatural: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/CreacionPersonaNatural -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.CrearPersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/CreacionPersonaNatural -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("ConsultarCuentaAhorro")]
        [ResponseType(typeof(ConsultaCuentaAhorroPNResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarCuentaAhorroPN([FromBody] ConsultaCuentaAhorroPNRequest request)
        {
            ConsultaCuentaAhorroPNResponse response = new ConsultaCuentaAhorroPNResponse();
            ConsultaPNCuentaAhorroValidator validator = new ConsultaPNCuentaAhorroValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/ConsultarCuentaAhorroPN: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/ConsultarCuentaAhorroPN -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultaCuentaAhorroPersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/ConsultarCuentaAhorroPN -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("CrearCuentaAhorro")]
        [ResponseType(typeof(CreacionCuentaAhorroPNResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage CrearCuentaAhorroPN([FromBody] CreacionCuentaAhorroPNRequest request)
        {
            CreacionCuentaAhorroPNResponse response = new CreacionCuentaAhorroPNResponse();
            CreacionCuentaAhorroPNValidator validator = new CreacionCuentaAhorroPNValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/CrearCuentaAhorroPN: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/CrearCuentaAhorroPN -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.CreacionCuentaAhorroPersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/CrearCuentaAhorroPN -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("EditarCuentaAhorro")]
        [ResponseType(typeof(EdicionCuentaAhorroPNResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage EditarCuentaAhorroPN([FromBody] EdicionCuentaAhorroPNRequest request)
        {
            EdicionCuentaAhorroPNResponse response = new EdicionCuentaAhorroPNResponse();
            EdicionCuentaAhorroPNValidator validator = new EdicionCuentaAhorroPNValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/EditarCuentaAhorroPN: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/EditarCuentaAhorroPN -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.EditarCuentaAhorroPersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/EditarCuentaAhorroPN -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("ConsultarCuentaCorriente")]
        [ResponseType(typeof(ConsultaCuentaCorrientePNResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarCuentaCorrientePN([FromBody] ConsultaCuentaCorrientePNRequest request)
        {
            ConsultaCuentaCorrientePNResponse response = new ConsultaCuentaCorrientePNResponse();
            ConsultaPNCuentaCorrienteValidator validator = new ConsultaPNCuentaCorrienteValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/ConsultarCuentaCorrientePN: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/ConsultarCuentaCorrientePN -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultaCuentaCorrientePersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/ConsultarCuentaCorrientePN -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("CrearCuentaCorriente")]
        [ResponseType(typeof(CreacionCuentaCorrientePNResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage CrearCuentaCorrientePN([FromBody] CreacionCuentaCorrientePNRequest request)
        {
            CreacionCuentaCorrientePNResponse response = new CreacionCuentaCorrientePNResponse();
            CreacionCuentaCorrientePNRequestValidator validator = new CreacionCuentaCorrientePNRequestValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/CrearCuentaCorrientePN: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/CrearCuentaCorrientePN -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.CreacionCuentaCorrientePersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/CrearCuentaCorrientePN -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("EditarCuentaCorriente")]
        [ResponseType(typeof(EdicionCuentaCorrientePNResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage EditarCuentaCorrientePN([FromBody] EdicionCuentaCorrientePNRequest request)
        {
            EdicionCuentaCorrientePNResponse response = new EdicionCuentaCorrientePNResponse();
            EdicionCuentaCorrientePNValidator validator = new EdicionCuentaCorrientePNValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/EditarCuentaCorrientePN: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/EditarCuentaCorrientePN -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.EditarCuentaCorrientePersonaNatural(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/EditarCuentaCorrientePN -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }
        ///api/v1/switchBalcon/personaNatural/ConsultarNombreEmpresa
        [HttpPost]
        [Route("ConsultarNombreEmpresa")]
        //[ResponseType(typeof(ConsultaNombreEmpresaResponse))]
        //[ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarNombreEmpresa([FromBody] ConsultaNombreEmpresaRequest request)
        {
            ConsultaNombreEmpresaResponse response = new ConsultaNombreEmpresaResponse();
            ConsultaNombreEmpresaValidator validator = new ConsultaNombreEmpresaValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaNaturalController/ConsultarNombreEmpresa: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaNaturalController/ConsultarNombreEmpresa -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultarNombreEmpresa(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaNaturalController/ConsultarNombreEmpresa -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }



    }
}
