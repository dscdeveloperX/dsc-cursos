﻿using FluentValidation.Results;
using icCommonFramework.Utils;
using Newtonsoft.Json;
using log4net;
using icSwithBalconServicios.BLL;
using icSwithBalconServicios.DTOs.API.Request;
using icSwithBalconServicios.DTOs.API.Response;
using icSwithBalconServicios.DTOs.API.Validator;
using System.Web.Http;
using System.Web.Http.Description;
using icCommonFramework.ManejoErrores.Utils;
using System.Net.Http;
using System.Net;
using System.Web;
using icSwithBalconServicios.DTOs.API.Request.ContactabilidadCliente;
using icSwithBalconServicios.DTOs.API.Response.ContactabilidadCliente;
using icSwithBalconServicios.DTOs.API.Validator;
using System;

namespace icSwithBalconServicios.Controllers
{
    [RoutePrefix("api/v1/switchBalcon/contactabilidad")]
    [Authorize]
    public class ContactabilidadController : ApiController
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ContactabilidadController));

        private readonly ContactabilidadClienteBLL _clRepository;
        public ContactabilidadController()
        {
            _clRepository = new ContactabilidadClienteBLL();
        }

        [HttpPost]
        [Route("Consultar")]
        [ResponseType(typeof(ConsultaContactabilidadResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarContactabilidad([FromBody] ConsultaContactabilidadRequest request)
        {
            ConsultaContactabilidadResponse response = new ConsultaContactabilidadResponse();
            ConsultaContactabilidadValidator validator = new ConsultaContactabilidadValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("ContactabilidadController/ConsultarContactabilidad: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("ContactabilidadController/ConsultarContactabilidad -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultarContactabilidadCliente(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("ContactabilidadController/ConsultarContactabilidad -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("Editar")]
        [ResponseType(typeof(EdicionContactabilidadResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage EditarContactabilidad([FromBody] EdicionContactabilidadRequest request)
        {
            EdicionContactabilidadResponse response = new EdicionContactabilidadResponse();
            EdicionContactabilidadValidator validator = new EdicionContactabilidadValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("ContactabilidadController/EditarContactabilidad: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("ContactabilidadController/EditarContactabilidad -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.EditarContactabilidadCliente(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("ContactabilidadController/EditarContactabilidad -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        
    }
}
