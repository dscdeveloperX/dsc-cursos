﻿using FluentValidation.Results;
using icCommonFramework.Utils;
using Newtonsoft.Json;
using log4net;
using icSwithBalconServicios.BLL;
using icSwithBalconServicios.DTOs.API.Request;
using icSwithBalconServicios.DTOs.API.Response;
using icSwithBalconServicios.DTOs.API.Validator;
using System.Web.Http;
using System.Web.Http.Description;
using icCommonFramework.ManejoErrores.Utils;
using System.Net.Http;
using System.Net;
using icSwithBalconServicios.DTOs.API.Response.PersonaJuridica;
using icSwithBalconServicios.DTOs.API.Request.PersonaJuridica;
using System;

namespace icSwithBalconServicios.Controllers
{
    [RoutePrefix("api/v1/switchBalcon/personaJuridica")]
    [Authorize]
    public class PersonaJuridicaController : ApiController
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(PersonaJuridicaController));

        private readonly BalconServiciosPersonaJuridica _clRepository;
        public PersonaJuridicaController()
        {
            _clRepository = new BalconServiciosPersonaJuridica();
        }

        [HttpPost]
        [Route("Consultar")]
        [ResponseType(typeof(ConsultaPersonaJuridicaResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarPersonaJuridica([FromBody] ConsultaPersonaJuridicaRequest request)
        {
            ConsultaPersonaJuridicaResponse response = new ConsultaPersonaJuridicaResponse();
            ConsultaPersonaJuridicaValidator validator = new ConsultaPersonaJuridicaValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaJuridicaController/ConsultarPersonaJuridica: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/ConsultarPersonaJuridica -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultarPersonaJuridica(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/ConsultarPersonaJuridica -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("Editar")]
        [ResponseType(typeof(EdicionPersonaJuridicaResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage EditarPersonaJuridica([FromBody] EdicionPersonaJuridicaRequest request)
        {
            EdicionPersonaJuridicaResponse response = new EdicionPersonaJuridicaResponse();
            EdicionPersonaJuridicaValidator validator = new EdicionPersonaJuridicaValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaJuridicaController/EditarPersonaJuridica: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaJuridicaController/EditarPersonaJuridica -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.EditarPersonaJuridica(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/EditarPersonaJuridica -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("Crear")]
        [ResponseType(typeof(CreacionPersonaJuridicaResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage CreacionPersonaJuridica([FromBody] CreacionPersonaJuridicaRequest request)
        {
            CreacionPersonaJuridicaResponse response = new CreacionPersonaJuridicaResponse();
            CreacionPersonaJuridicaValidator validator = new CreacionPersonaJuridicaValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaJuridicaController/CreacionPersonaJuridica: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaJuridicaController/CreacionPersonaJuridica -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.CrearPersonaJuridica(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/CreacionPersonaJuridica -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("CrearCuentaAhorro")]
        [ResponseType(typeof(CreacionPJCuentaAhorroResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage CrearCuentaAhorroPJ([FromBody] CreacionPJCuentaAhorroRequest request)
        {
            CreacionPJCuentaAhorroResponse response = new CreacionPJCuentaAhorroResponse();
            CreacionPJCuentaAhorroValidator validator = new CreacionPJCuentaAhorroValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaJuridicaController/CrearCuentaAhorroPJ: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaJuridicaController/CrearCuentaAhorroPJ -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.CreacionCuentaAhorroPersonaJuridica(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/CrearCuentaAhorroPJ -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("ConsultarCuentaAhorro")]
        [ResponseType(typeof(ConsultaPJCuentaAhorroResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarCuentaAhorroPJ([FromBody] ConsultaPJCuentaAhorroRequest request)
        {
            ConsultaPJCuentaAhorroResponse response = new ConsultaPJCuentaAhorroResponse();
            ConsultaPJCuentaAhorroValidator validator = new ConsultaPJCuentaAhorroValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaJuridicaController/ConsultarCuentaAhorroPJ: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaJuridicaController/ConsultarCuentaAhorroPJ -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultaCuentaAhorroPersonaJuridica(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/ConsultarCuentaAhorroPJ -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("CrearCuentaCorriente")]
        [ResponseType(typeof(CreacionPJCuentaCorrienteResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage CrearCuentaCorrientePJ([FromBody] CreacionPJCuentaCorrienteRequest request)
        {
            CreacionPJCuentaCorrienteResponse response = new CreacionPJCuentaCorrienteResponse();
            CreacionPJCuentaCorrienteValidator validator = new CreacionPJCuentaCorrienteValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaJuridicaController/CrearCuentaCorrientePJ: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaJuridicaController/CrearCuentaCorrientePJ -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.CreacionCuentaCorrientePersonaJuridica(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/CrearCuentaCorrientePJ -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }

        [HttpPost]
        [Route("ConsultarCuentaCorriente")]
        [ResponseType(typeof(ConsultaPJCuentaCorrienteResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage ConsultarCuentaCorrientePJ([FromBody] ConsultaPJCuentaCorrienteRequest request)
        {
            ConsultaPJCuentaCorrienteResponse response = new ConsultaPJCuentaCorrienteResponse();
            ConsultaPJCuentaCorrienteValidator validator = new ConsultaPJCuentaCorrienteValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("PersonaJuridicaController/ConsultarCuentaCorrientePJ: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string reqStr = UtilGeneral.SerializedNeutralizedJson(request);
                Log.Info("PersonaJuridicaController/ConsultarCuentaCorrientePJ -> Request: " + reqStr.Replace(Environment.NewLine, ""));
                response = _clRepository.ConsultaCuentaCorrientePersonaJuridica(request);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("PersonaJuridicaController/ConsultarCuentaCorrientePJ -> Response: " + resStr.Replace(Environment.NewLine, ""));

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }
    }
}
