﻿using FluentValidation.Results;
using icCommonFramework.Auth;
using icCommonFramework.ManejoErrores.Utils;
using log4net;
using Newtonsoft.Json;
using icSwithBalconServicios.DTOs.API.Request;
using icSwithBalconServicios.DTOs.API.Response;
using icSwithBalconServicios.DTOs.API.Validator;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using icCommonFramework.Utils;

namespace icSwithBalconServicios.Controllers
{
    /// <summary>
    /// login controller class for authenticate users
    /// </summary>
    [AllowAnonymous]
    [RoutePrefix("api/v1/switchBalcon/auth")]
    public class AuthController : ApiController
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(AuthController));

        /// <summary>
        /// Generar la jwt para usuario
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GenerarJWT")]
        [ResponseType(typeof(AuthResponse))]
        [ICControllerExceptionFilter]
        public HttpResponseMessage GenerarJWT([FromBody] AuthRequest request)
        {
            AuthResponse response = new AuthResponse();
            AuthValidator validator = new AuthValidator();
            ValidationResult validationResults = validator.Validate(request);

            if (!validationResults.IsValid)
            {
                Log.Error("AuthController/GenerarJWT: INVALID REQUEST");
                response.Mensaje = "Solicitud no válida";
                return Request.CreateResponse(HttpStatusCode.BadRequest, response);
            }
            else
            {
                string token = TokenGenerator.GenerarJwtToken(request.AppKey, out DateTime expireDate);

                if (string.IsNullOrEmpty(token))
                {
                    Log.Error("AuthController/GenerarJWT: Unauthorized");
                    response.Mensaje = "Key no válida";
                    return Request.CreateResponse(HttpStatusCode.Unauthorized, response);
                }
                
                response.Token = token;
                response.ExpirationDate = expireDate;
                response.Mensaje = "OK";
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Info("AuthController/GenerarJWT -> Response: " + resStr);

                return Request.CreateResponse(HttpStatusCode.OK, response);
            }
        }
    }
}
