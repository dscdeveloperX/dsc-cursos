﻿using icCommonFramework.Modelos;
using Newtonsoft.Json;
using log4net;
using icSwithBalconServicios.DTOs;
using icSwithBalconServicios.DTOs.API.Request;
using icSwithBalconServicios.DTOs.API.Response;
using System;
using icCommonFramework.DTOs.API;
using icSwithBalconServicios.DTOs.API.Response.PersonaNatural;
using icSwithBalconServicios.DTOs.API.Request.PersonaNatural;
using icSwithBalconServicios.DTOs.AS400.Response.CuentaCorriente;
using icSwithBalconServicios.DTOs.Response.CuentaAhorro;
using icCommonFramework.Utils;
using icSwithBalconServicios.DTOs.API.Response.PersonaNatural.Persona;
using icSwithBalconServicios.DTOs.API.Request.PersonaNatural.Persona;

namespace icSwithBalconServicios.BLL
{
    public class BalconServiciosPersonaNatural
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(BalconServiciosPersonaNatural));

        private readonly ConectorBancoBLL _clRepository;
        public BalconServiciosPersonaNatural()
        {
            _clRepository = new ConectorBancoBLL();
        }
        /// <summary>
        /// Consulta de persona natural
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ConsultaPersonaNaturalResponse ConsultarPersonaNatural(ConsultaPersonaNaturalRequest request)
        {
            try
            {
                ConsultaPersonaNaturalResponse response = new ConsultaPersonaNaturalResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaPersonaNaturalResponseBody bodyResponse = new ConsultaPersonaNaturalResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Identificacion;
                var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;

                Log.Info("BalconServicios/ConsultarPersonaNatural: ConsultarClienteNatural -> INICIO");
                 var resultadoPersona = _clRepository.ConsultarClienteNatural(tipoIdentificacion,nutCliente, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultarPersonaNatural: ConsultarClienteNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.DatosPersona = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultarPersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Creacion de persona natural sin producto
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public CreacionPersonaNaturalResponse CrearPersonaNatural(CreacionPersonaNaturalRequest request)
        {
            try
            {
                CreacionPersonaNaturalResponse response = new CreacionPersonaNaturalResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                CreacionPersonaNaturalResponseBody bodyResponse = new CreacionPersonaNaturalResponseBody();

                var valoresPersona = request.BodyRequest.DatosPersona;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.DatosPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente;

                bool resultadoPersona = false;

                string serializedJson = JsonConvert.SerializeObject(valoresPersona);
                var valoresPersonaCreate = UtilGeneral.DeserializeNeutralizeJson<DatosPersonaNatural<RefComercialesInCreate, RefPersonalesInCreate, RefBancariaInCreate>>(serializedJson);

                Log.Info("BalconServicios/CrearPersonaNatural: CreacionClienteNatural -> INICIO");
                resultadoPersona = _clRepository.CreacionClienteNatural(valoresPersonaCreate, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/CrearPersonaNatural: CreacionClienteNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Creado = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/CrearPersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        
        /// <summary>
        /// Edicion de Persona Natural
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public EdicionPersonaNaturalResponse EditarPersonaNatural(EdicionPersonaNaturalRequest request)
        {
            try
            {
                EdicionPersonaNaturalResponse response = new EdicionPersonaNaturalResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EdicionPersonaNaturalResponseBody bodyResponse = new EdicionPersonaNaturalResponseBody();

                var valoresPersona = request.BodyRequest.DatosPersona;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.DatosPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente;

                bool resultadoPersona = false;

                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaNatural: EdicionClienteNatural -> INICIO");
                resultadoPersona = _clRepository.EdicionClienteNatural(valoresPersona, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaNatural: EdicionClienteNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Editado = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EditarPersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }




        public EdicionPersonaNaturalFallecidoResponse EditarPersonaNaturalFallecido(EdicionPersonaNaturalFallecidoRequest request)
        {
            try
            {
                EdicionPersonaNaturalFallecidoResponse response = new EdicionPersonaNaturalFallecidoResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EdicionPersonaNaturalFallecidoResponseBody bodyResponse = new EdicionPersonaNaturalFallecidoResponseBody();

                var valoresPersona = request.BodyRequest.DatosPersona;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.DatosPersona.Identificacion;

                bool resultadoPersona = false;

                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaNatural: EdicionClienteNatural -> INICIO");
                resultadoPersona = _clRepository.EdicionClienteNaturalFallecido(request.BodyRequest.DatosPersona, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaNatural: EdicionClienteNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Editado = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EditarPersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }





        public ConsultaCuentaCorrientePNResponse ConsultaCuentaCorrientePersonaNatural(ConsultaCuentaCorrientePNRequest request)
        {
            try
            {
                ConsultaCuentaCorrientePNResponse response = new ConsultaCuentaCorrientePNResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaCuentaCorrientePNResponseBody bodyResponse = new ConsultaCuentaCorrientePNResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Identificacion;
                var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;
                string cuenta = request.BodyRequest.Cuenta;
                string prefijo = request.BodyRequest.Prefijo;

                Log.Info("BalconServicios/ConsultarPersonaNatural: ConsultaCuentaCorrientePersonaNatural -> INICIO");
                var resultadoPersona = _clRepository.ConsultarCuentaCorrientePersonaNatural(tipoIdentificacion, nutCliente, cuenta, prefijo, request.HeaderRequest.UserName,
                   request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultarPersonaNatural: ConsultaCuentaCorrientePersonaNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.DatosCuenta = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultaCuentaCorrientePersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        public CreacionCuentaCorrientePNResponse CreacionCuentaCorrientePersonaNatural(CreacionCuentaCorrientePNRequest request)
        {

            try
            {
                CreacionCuentaCorrientePNResponse response = new CreacionCuentaCorrientePNResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                CreacionCuentaCorrientePNResponseBody bodyResponse = new CreacionCuentaCorrientePNResponseBody();

               var valoresCuenta = request.BodyRequest.DatosCuenta;

                string nutCliente = valoresCuenta.Documento_Titular;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                CreacionCuentaCorrienteResult resultado = null;

                Log.Info("BalconServicios/ConsultaCuentaCorrientePersonaNatural: CreacionCuentaAhorroPersonaNatural -> INICIO");
                resultado = _clRepository.CreacionCuentaCorrientePersonaNatural(valoresCuenta, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultaCuentaCorrientePersonaNatural: CreacionCuentaAhorroPersonaNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;

                    //Create Body Response
                    bodyResponse.Cuenta = resultado.Cuenta;
                    bodyResponse.Prefijo = resultado.Prefijo;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/CreacionCuentaCorrientePersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        public EdicionCuentaCorrientePNResponse EditarCuentaCorrientePersonaNatural(EdicionCuentaCorrientePNRequest request)
        {
            try
            {
                EdicionCuentaCorrientePNResponse response = new EdicionCuentaCorrientePNResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EdicionCuentaCorrientePNResponseBody bodyResponse = new EdicionCuentaCorrientePNResponseBody();

                var valoresCuenta = request.BodyRequest.DatosCuenta;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.DatosCuenta.Documento_Titular;

                bool resultadoPersona = false;
                bool resultado = false;

                Log.Info("BalconServicios/EditarCuentaCorrientePersonaNatural: EdicionCuentaCorrientePersonaNatural -> INICIO");
                resultadoPersona = _clRepository.EdicionCuentaCorrientePersonaNatural(valoresCuenta, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/EditarCuentaCorrientePersonaNatural: EdicionCuentaCorrientePersonaNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Editado = resultado;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EditarCuentaCorrientePersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        public ConsultaCuentaAhorroPNResponse ConsultaCuentaAhorroPersonaNatural(ConsultaCuentaAhorroPNRequest request)
        {
            try
            {
                ConsultaCuentaAhorroPNResponse response = new ConsultaCuentaAhorroPNResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaCuentaAhorroPNResponseBody bodyResponse = new ConsultaCuentaAhorroPNResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Identificacion;
                var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;
                string cuenta = request.BodyRequest.Cuenta;
                string prefijo = request.BodyRequest.Prefijo;

                Log.Info("BalconServicios/ConsultarPersonaNatural: ConsultaCuentaAhorroPersonaNatural -> INICIO");
                var resultadoPersona = _clRepository.ConsultarCuentaAhorroPersonaNatural(tipoIdentificacion, nutCliente, cuenta, prefijo, request.HeaderRequest.UserName,
                   request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultarPersonaNatural: ConsultaCuentaAhorroPersonaNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.DatosCuenta = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultaCuentaAhorroPersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        public CreacionCuentaAhorroPNResponse CreacionCuentaAhorroPersonaNatural(CreacionCuentaAhorroPNRequest request)
        {

            try
            {
                CreacionCuentaAhorroPNResponse response = new CreacionCuentaAhorroPNResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                CreacionCuentaAhorroPNResponseBody bodyResponse = new CreacionCuentaAhorroPNResponseBody();

                var valoresCuenta = request.BodyRequest.DatosCuenta;

                string nutCliente = valoresCuenta.Documento_Titular;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                CreacionCuentaAhorroResult resultado = null;

                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaNatural: CreacionCuentaAhorroPersonaNatural -> INICIO");
                resultado = _clRepository.CreacionCuentaAhorroPersonaNatural(valoresCuenta, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaNatural: CreacionCuentaAhorroPersonaNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;

                    //Create Body Response
                    bodyResponse.Cuenta = resultado.Cuenta;
                    bodyResponse.Prefijo = resultado.Prefijo;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }                

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/CreacionCuentaAhorroPersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        public EdicionCuentaAhorroPNResponse EditarCuentaAhorroPersonaNatural(EdicionCuentaAhorroPNRequest request)
        {
            try
            {
                EdicionCuentaAhorroPNResponse response = new EdicionCuentaAhorroPNResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EdicionCuentaAhorroPNResponseBody bodyResponse = new EdicionCuentaAhorroPNResponseBody();

                var valoresCuenta = request.BodyRequest.DatosCuenta;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.DatosCuenta.Documento_Titular;

                bool resultadoPersona = false;
                bool resultado = false;

                Log.Info("BalconServicios/EditarCuentaAhorroPersonaNatural: EdicionCuentaAhorroPersonaNatural -> INICIO");
                resultadoPersona = _clRepository.EdicionCuentaAhorroPersonaNatural(valoresCuenta, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/EditarCuentaAhorroPersonaNatural: EdicionCuentaAhorroPersonaNatural -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Editado = resultado;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EditarCuentaAhorroPersonaNatural: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaNombreEmpresaResponse ConsultarNombreEmpresa(ConsultaNombreEmpresaRequest request)
        {
            try
            {
                ConsultaNombreEmpresaResponse response = new ConsultaNombreEmpresaResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaNombreEmpresaResponseBody bodyResponse = new ConsultaNombreEmpresaResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                //string nutCliente = request.BodyRequest.Identificacion;
                //var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;
                string rucEmpresa = request.BodyRequest.RucEmpresa;

                Log.Info("BalconServicios/ConsultarNombreEmpresa: ConsultarNombreEmpresa -> INICIO");
                var resultadoPersona = _clRepository.ConsultarNombreEmpresa(rucEmpresa, rucEmpresa, request.HeaderRequest.UserName,
                   request.HeaderRequest.StationIp, "Identificacion", new DateTime(), rucEmpresa, ref mensaje);
                Log.Info("BalconServicios/ConsultarNombreEmpresa: ConsultarNombreEmpresa -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.DatosEmpresa = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultarNombreEmpresa: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }





    }
}
