﻿using icCommonFramework.DTOs.API;
using icCommonFramework.Modelos;
using icSwithBalconServicios.DTOs.API.Request.ContactabilidadCliente;
using icSwithBalconServicios.DTOs.API.Response.ContactabilidadCliente;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace icSwithBalconServicios.BLL
{
    public class ContactabilidadClienteBLL
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ContactabilidadClienteBLL));

        private readonly ConectorBancoBLL _clRepository;
        public ContactabilidadClienteBLL()
        {
            _clRepository = new ConectorBancoBLL();
        }
        public ConsultaContactabilidadResponse ConsultarContactabilidadCliente(ConsultaContactabilidadRequest request)
        {
            try
            {
                ConsultaContactabilidadResponse response = new ConsultaContactabilidadResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaContactabilidadResponseBody bodyResponse = new ConsultaContactabilidadResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Identificacion;
                var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;

                Log.Info("BalconServicios/ConsultarContactabilidadCliente: ConsultarContactabilidadCliente -> INICIO");
                var resultadoPersona = _clRepository.ConsultarContactabilidadCliente(tipoIdentificacion, nutCliente, nutCliente, request.HeaderRequest.UserName,
                   request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultarContactabilidadCliente: ConsultarContactabilidadCliente -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Contactabilidad = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultarContactabilidadCliente: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EdicionContactabilidadResponse EditarContactabilidadCliente(EdicionContactabilidadRequest request)
        {
            try
            {
                EdicionContactabilidadResponse response = new EdicionContactabilidadResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EdicionContactabilidadResponseBody bodyResponse = new EdicionContactabilidadResponseBody();

                var valoresPersona = request.BodyRequest.Contactabilidad;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Contactabilidad.Dcto_Identidad_Cliente;

                bool resultadoPersona = false;

                Log.Info("BalconServicios/EditarContactabilidadCliente: EdicionContactabilidadCliente -> INICIO");
                resultadoPersona = _clRepository.EdicionContactabilidadCliente(valoresPersona, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/EditarContactabilidadCliente: EdicionContactabilidadCliente -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Editado = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EditarContactabilidad: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
