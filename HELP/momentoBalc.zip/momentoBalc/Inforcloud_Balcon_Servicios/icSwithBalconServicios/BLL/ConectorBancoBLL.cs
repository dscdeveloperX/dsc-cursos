﻿using icCommonFramework.ManejoErrores;
using icCommonFramework.ManejoErrores.Utils;
using icCommonFramework.Modelos;
using Newtonsoft.Json;
using log4net;
using icSwithBalconServicios.DTOs;
using icSwithBalconServicios.DTOs.AS400.Request.CuentaCorriente;
using icSwithBalconServicios.DTOs.AS400.Response.CuentaCorriente;
using icSwithBalconServicios.DTOs.Request.CuentaAhorro;
using icSwithBalconServicios.DTOs.Request.PersonaJuridica;
using icSwithBalconServicios.DTOs.Request.PersonaNatural;
using icSwithBalconServicios.DTOs.Response.CuentaAhorro;
using icSwithBalconServicios.DTOs.Response.PersonaJuridica;
using icSwithBalconServicios.DTOs.Response.PersonaNatural;
using System;
using System.Collections.Generic;
using icSwithBalconServicios.Utils;
using icSwithBalconServicios.DTOs.AS400.Request.ContactabilidadCliente;
using icSwithBalconServicios.DTOs.AS400.Response.ContactabilidadCliente;
using icSwithBalconServicios.DTOs.AS400.Request.PersonaNatural;
using icSwithBalconServicios.DTOs.AS400.Response.PersonaNatural;
using IBM.Data.DB2.iSeries;
using icCommonFramework.ConexionAS400;

namespace icSwithBalconServicios.BLL
{
    public class ConectorBancoBLL
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ConectorBancoBLL));

        private readonly ConectorAS400BLL _apiConnector;
        private readonly MapeoMensajesError _errorHelper;

        public ConectorBancoBLL()
        {
            _apiConnector = new ConectorAS400BLL();
            _errorHelper = new MapeoMensajesError();
        }

        #region PERSONA JURIDICA
        public DatosPersonaJuridica<RepLegalInEdit,AccionistaInEdit, RefComercialesInEdit, RefBancariaInEdit> ConsultarClienteJuridica(string tipoIdentificacion, string identificacion, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaPersonaJuridicaRequest envelope = new ConsultaPersonaJuridicaRequest
            {
                Dcto_Identidad_Cliente = identificacion,
                Tipo_Identidad_Cliente = tipoIdentificacion, 
            };

            string serviceName = Constantes.Servicios.CONSULTA_PERSONA_JURIDICA;

            Log.Info($"ConectorBancoBLL/ConsultarClienteJuridica: {serviceName.Replace(Environment.NewLine,"")} -> REQUEST API BANCO");

            ConsultaPersonaJuridicaResponse result = _apiConnector.MakeRequest<ConsultaPersonaJuridicaResponse, ConsultaPersonaJuridicaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/ConsultarClienteJuridica: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            DatosPersonaJuridica<RepLegalInEdit,AccionistaInEdit, RefComercialesInEdit, RefBancariaInEdit> resultadoDatos = new DatosPersonaJuridica<RepLegalInEdit,AccionistaInEdit, RefComercialesInEdit, RefBancariaInEdit>();

            if (result.DatosPersona != null)
            {
                result.DatosPersona.EsCliente = true;
                resultadoDatos = result.DatosPersona;
            }

            return resultadoDatos;
        }

        public bool CreacionClienteJuridica(DatosPersonaJuridica<RepLegalInCreate,AccionistaInCreate, RefComercialesInCreate, RefBancariaInCreate> clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionPersonaJuridicaRequest envelope = new CreacionPersonaJuridicaRequest
            {
                DatosPersona = clienteNatural
            };

            string serviceName = Constantes.Servicios.CREACION_PERSONA_JURIDICA;

            Log.Info($"ConectorBancoBLL/CreacionClienteJuridica: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            CreacionPersonaJuridicaResponse result = _apiConnector.MakeRequest<CreacionPersonaJuridicaResponse, CreacionPersonaJuridicaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/CreacionClienteJuridica: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }

        public bool EdicionClienteJuridica(DatosPersonaJuridica<RepLegalInEdit,AccionistaInEdit, RefComercialesInEdit, RefBancariaInEdit> clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionPersonaJuridicaRequest envelope = new EdicionPersonaJuridicaRequest
            {
                DatosPersona = clienteNatural
            };

            string serviceName = Constantes.Servicios.EDICION_PERSONA_JURIDICA;

            Log.Info($"ConectorBancoBLL/EdicionClienteJuridica: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            EdicionPersonaJuridicaResponse result = _apiConnector.MakeRequest<EdicionPersonaJuridicaResponse, EdicionPersonaJuridicaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/EdicionClienteJuridica: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }
        #endregion

        #region PERSONA NATURAL
        public DatosPersonaNatural<RefComercialesInEdit, RefPersonalesInEdit, RefBancariaInEdit> ConsultarClienteNatural(string tipoIdentificacion, string identificacion, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaPersonaNaturalRequest envelope = new ConsultaPersonaNaturalRequest
            {
                Dcto_Identidad_Cliente = identificacion,
                Tipo_Identidad_Cliente = tipoIdentificacion
            };

            string serviceName = Constantes.Servicios.CONSULTA_PERSONA_NATURAL;

            Log.Info($"ConectorBancoBLL/ConsultarClienteNatural: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");
            //dsc1977
            ConsultaPersonaNaturalResponse result = _apiConnector.MakeRequest<ConsultaPersonaNaturalResponse, ConsultaPersonaNaturalRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/ConsultarClienteNatural: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            DatosPersonaNatural<RefComercialesInEdit, RefPersonalesInEdit, RefBancariaInEdit> resultadoDatos = new DatosPersonaNatural<RefComercialesInEdit, RefPersonalesInEdit, RefBancariaInEdit>();

            if (result.DatosPersona != null)
            {
                result.DatosPersona.EsCliente = true;
                result.DatosPersona.Sin_Registro_Civil = "N";
                resultadoDatos = result.DatosPersona;
            }

            return resultadoDatos;
        }

        public bool CreacionClienteNatural(DatosPersonaNatural<RefComercialesInCreate, RefPersonalesInCreate, RefBancariaInCreate> clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionPersonaNaturalRequest envelope = new CreacionPersonaNaturalRequest
            {
                DatosPersona = clienteNatural
            };

            string serviceName = Constantes.Servicios.CREACION_PERSONA_NATURAL;

            Log.Info($"ConectorBancoBLL/CreacionClienteNatural: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            CreacionPersonaNaturalResponse result = _apiConnector.MakeRequest<CreacionPersonaNaturalResponse, CreacionPersonaNaturalRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/CreacionClienteNatural: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }

        public bool EdicionClienteNatural(DatosPersonaNatural<RefComercialesInEdit, RefPersonalesInEdit, RefBancariaInEdit> clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionPersonaNaturalRequest envelope = new EdicionPersonaNaturalRequest
            {
                DatosPersona = clienteNatural
            };

            string serviceName = Constantes.Servicios.EDICION_PERSONA_NATURAL;

            Log.Info($"ConectorBancoBLL/EdicionClienteNatural: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            EdicionPersonaNaturalResponse result = _apiConnector.MakeRequest<EdicionPersonaNaturalResponse, EdicionPersonaNaturalRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/EdicionClienteNatural: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }





        public bool EdicionClienteNaturalFallecido(DatosPersonaNaturalFallecido clienteNaturalFallecido, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionPersonaNaturalFallecidoRequest envelope = new EdicionPersonaNaturalFallecidoRequest
            {
                TipoIdentificacion = clienteNaturalFallecido.TipoIdentificacion,
                Identificacion = clienteNaturalFallecido.Identificacion,
                CondicionCedula = clienteNaturalFallecido.CondicionCedula,
                CampoCaptacion = clienteNaturalFallecido.CampoCaptacion
            };
            
            string serviceName = Constantes.Servicios.EDICION_PERSONA_NATURAL_FALLECIDO;//SCLY105

            Log.Info($"ConectorBancoBLL/EdicionClienteNaturalFallecido: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            EdicionPersonaNaturalFallecidoResponse result = _apiConnector.MakeRequest<EdicionPersonaNaturalFallecidoResponse, EdicionPersonaNaturalFallecidoRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/EdicionClienteNaturalFallecido: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }


        #region CUENTA AHORRO
        public DatosCuentaAhorro ConsultarCuentaAhorroPersonaNatural(string tipoIdentificacion, string identificacion, string cuenta, string prefijo, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaCuentaAhorroRequest envelope = new ConsultaCuentaAhorroRequest
            {
                Dcto_Identidad_Cliente = identificacion,
                Tipo_Identidad_Cliente = tipoIdentificacion,
                Cuenta = cuenta,
                Prefijo = prefijo
            };

            string serviceName = Constantes.Servicios.CONSULTA_CUENTA_AHORRO_PN;

            Log.Info($"ConectorBancoBLL/ConsultarCuentaAhorro: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            ConsultaCuentaAhorroResponse result = _apiConnector.MakeRequest<ConsultaCuentaAhorroResponse, ConsultaCuentaAhorroRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/ConsultarCuentaAhorro: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            DatosCuentaAhorro resultadoDatos = new DatosCuentaAhorro();

            if (result.DatosCuenta != null)
            {
                string serialized = JsonConvert.SerializeObject(result.DatosCuenta);
                if (!string.IsNullOrEmpty(serialized))
                {
                    resultadoDatos = JsonConvert.DeserializeObject<DatosCuentaAhorro>(serialized);
                    resultadoDatos.Tipo_Identidad_Cliente = tipoIdentificacion;
                    resultadoDatos.Dcto_Identidad_Cliente = identificacion;
                    resultadoDatos.Cuenta = cuenta;
                    resultadoDatos.Prefijo = prefijo;
                }

            }

            return resultadoDatos;
        }

        public CreacionCuentaAhorroResult CreacionCuentaAhorroPersonaNatural(DatosCuentaAhorro clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionCuentaAhorroRequest envelope = new CreacionCuentaAhorroRequest
            {
                CuentaAhorro = new CreacionDatosCuentaAhorro
                {
                    Agencia = clienteNatural.Agencia,
                    Canal = clienteNatural.Canal,
                    Clase_Cuenta = clienteNatural.Clase_Cuenta,
                    Cuenta = clienteNatural.Cuenta,
                    Dcto_Identidad_Cliente = clienteNatural.Dcto_Identidad_Cliente,
                    Documento_Representante_Legal = clienteNatural.Documento_Representante_Legal,
                    Documento_Titular = clienteNatural.Documento_Titular,
                    Estacion_Trabajo = clienteNatural.Estacion_Trabajo,
                    Fecha1 = clienteNatural.Fecha1,
                    Fecha2 = clienteNatural.Fecha2,
                    Lin_Libreta = clienteNatural.Lin_Libreta,
                    Moneda = clienteNatural.Moneda,
                    Nombre = clienteNatural.Nombre,
                    Nombre_Representante_Legal = clienteNatural.Nombre_Representante_Legal,
                    Nombre_Titular = clienteNatural.Nombre_Titular,
                    Numero_Libreta = clienteNatural.Numero_Libreta,
                    Num_Trabajo = clienteNatural.Num_Trabajo,
                    Oficial = clienteNatural.Oficial,
                    Prefijo = clienteNatural.Prefijo,
                    Producto = clienteNatural.Producto,
                    Programa = clienteNatural.Programa,
                    SubProducto = clienteNatural.SubProducto,
                    Tipo_Cuenta = clienteNatural.Tipo_Cuenta,
                    Tipo_Documento_Representante_Legal = clienteNatural.Tipo_Documento_Representante_Legal,
                    Tipo_Documento_Titular = clienteNatural.Tipo_Documento_Titular,
                    Tipo_Identidad_Cliente = clienteNatural.Tipo_Identidad_Cliente,
                    Tipo_Producto = clienteNatural.Tipo_Producto,
                    Usuario_Creacion = clienteNatural.Usuario_Creacion,
                    Zona = clienteNatural.Zona,
                    Cotitulares = clienteNatural.Cotitulares
                }
            };

            string serviceName = Constantes.Servicios.CREACION_CUENTA_AHORRO_PN;

            Log.Info($"ConectorBancoBLL/CreacionCuentaAhorro: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            CreacionCuentaAhorroResponse result = _apiConnector.MakeRequest<CreacionCuentaAhorroResponse, CreacionCuentaAhorroRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/CreacionCuentaAhorro: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return new CreacionCuentaAhorroResult { 
                Cuenta = result.DatosCuenta.Cuenta,
                Prefijo = result.DatosCuenta.Prefijo
            };
        }

        public bool EdicionCuentaAhorroPersonaNatural(DatosCuentaAhorro clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionCuentaAhorroRequest envelope = new EdicionCuentaAhorroRequest
            {
                CuentaAhorro = new CreacionDatosCuentaAhorro { 
                    Moneda = clienteNatural.Moneda,
                    Agencia = clienteNatural.Agencia,
                    Canal = clienteNatural.Canal,
                    Clase_Cuenta = clienteNatural.Clase_Cuenta,
                    Cotitulares = clienteNatural.Cotitulares,
                    Cuenta = clienteNatural.Cuenta,
                    Dcto_Identidad_Cliente = clienteNatural.Dcto_Identidad_Cliente,
                    Documento_Representante_Legal = clienteNatural.Documento_Representante_Legal,
                    Documento_Titular = clienteNatural.Documento_Titular,
                    Estacion_Trabajo = clienteNatural.Estacion_Trabajo,
                    Fecha1 = clienteNatural.Fecha1,
                    Fecha2 = clienteNatural.Fecha2,
                    Lin_Libreta = clienteNatural.Lin_Libreta,
                    Nombre = clienteNatural.Nombre,
                    Nombre_Representante_Legal = clienteNatural.Nombre_Representante_Legal,
                    Nombre_Titular = clienteNatural.Nombre_Titular,
                    Numero_Libreta = clienteNatural.Numero_Libreta,
                    Num_Trabajo = clienteNatural.Num_Trabajo,
                    Oficial = clienteNatural.Oficial,
                    Prefijo = clienteNatural.Prefijo,
                    Producto = clienteNatural.Producto,
                    Programa = clienteNatural.Programa,
                    SubProducto = clienteNatural.SubProducto,
                    Tipo_Cuenta = clienteNatural.Tipo_Cuenta,
                    Tipo_Documento_Representante_Legal = clienteNatural.Tipo_Documento_Representante_Legal,
                    Tipo_Documento_Titular = clienteNatural.Tipo_Documento_Titular,
                    Tipo_Identidad_Cliente = clienteNatural.Tipo_Identidad_Cliente,
                    Tipo_Producto = clienteNatural.Tipo_Producto,
                    Usuario_Creacion = clienteNatural.Usuario_Creacion,
                    Zona = clienteNatural.Zona
                }
            };

            string serviceName = Constantes.Servicios.EDICION_CUENTA_AHORRO_PN;

            Log.Info($"ConectorBancoBLL/EdicionCuentaAhorro: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            EdicionCuentaAhorroResponse result = _apiConnector.MakeRequest<EdicionCuentaAhorroResponse, EdicionCuentaAhorroRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/EdicionCuentaAhorro: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }

        #endregion

        #region CUENTA CORRIENTE
        public DatosCuentaCorriente ConsultarCuentaCorrientePersonaNatural(string tipoIdentificacion, string identificacion, string cuenta, string prefijo, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaCuentaCorrienteRequest envelope = new ConsultaCuentaCorrienteRequest
            {
                Dcto_Identidad_Cliente = identificacion,
                Tipo_Identidad_Cliente = tipoIdentificacion,
                Cuenta = cuenta,
                Prefijo = prefijo
            };

            string serviceName = Constantes.Servicios.CONSULTA_CUENTA_CORRIENTE_PN;

            Log.Info($"ConectorBancoBLL/ConsultarCuentaCorriente: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            ConsultaCuentaCorrienteResponse result = _apiConnector.MakeRequest<ConsultaCuentaCorrienteResponse, ConsultaCuentaCorrienteRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/ConsultarCuentaCorriente: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            DatosCuentaCorriente resultadoDatos = new DatosCuentaCorriente();

            if (result.DatosCuenta != null)
            {
                string serialized = JsonConvert.SerializeObject(result.DatosCuenta);
                if (!string.IsNullOrEmpty(serialized))
                {
                    resultadoDatos = JsonConvert.DeserializeObject<DatosCuentaCorriente>(serialized);
                    resultadoDatos.Tipo_Identidad_Cliente = tipoIdentificacion;
                    resultadoDatos.Dcto_Identidad_Cliente = identificacion;
                    resultadoDatos.Cuenta = cuenta;
                    resultadoDatos.Prefijo = prefijo;
                }

            }

            return resultadoDatos;
        }

        public CreacionCuentaCorrienteResult CreacionCuentaCorrientePersonaNatural(DatosCuentaCorriente clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionCuentaCorrienteRequest envelope = new CreacionCuentaCorrienteRequest
            {
                CuentaCorriente = new CreacionDatosCuentaCorriente
                {
                    Agencia = clienteNatural.Agencia,
                    Canal = clienteNatural.Canal,
                    Clase_Cuenta = clienteNatural.Clase_Cuenta,
                    Cuenta = clienteNatural.Cuenta,
                    DatosGeneralChequera = clienteNatural.DatosGeneralChequera,
                    Dcto_Identidad_Cliente = clienteNatural.Dcto_Identidad_Cliente,
                    Documento_Representante_Legal = clienteNatural.Documento_Representante_Legal,
                    Documento_Titular = clienteNatural.Documento_Titular,
                    //Lin_Libreta = clienteNatural.Lin_Libreta,
                    Moneda = clienteNatural.Moneda,
                    MontoApertura = clienteNatural.MontoApertura,
                    Nombre = clienteNatural.Nombre,
                    Nombre_Representante_Legal = clienteNatural.Nombre_Representante_Legal,
                    Nombre_Titular = clienteNatural.Nombre_Titular,
                    //Numero_Libreta = clienteNatural.Numero_Libreta,
                    Oficial = clienteNatural.Oficial,
                    Prefijo = clienteNatural.Prefijo,
                    Producto = clienteNatural.Producto,
                    SubProducto = clienteNatural.SubProducto,
                    Tipo_Cuenta = clienteNatural.Tipo_Cuenta,
                    Tipo_Documento_Representante_Legal = clienteNatural.Tipo_Documento_Representante_Legal,
                    Tipo_Documento_Titular = clienteNatural.Tipo_Documento_Titular,
                    Tipo_Identidad_Cliente = clienteNatural.Tipo_Identidad_Cliente,
                    Tipo_Producto = clienteNatural.Tipo_Producto,
                    Zona = clienteNatural.Zona,
                    Fecha_Apertura = clienteNatural.Fecha_Apertura,
                    Hora_Apertura = clienteNatural.Hora_Apertura,
                    Referido_Por = clienteNatural.Referido_Por,
                    Origen_Captacion = clienteNatural.Origen_Captacion,
                    EstadoCuenta = clienteNatural.EstadoCuenta,
                    Dia_Mes = clienteNatural.Dia_Mes,
                    Semana = clienteNatural.Semana,
                    Datos_Retiro_Chequera = clienteNatural.Datos_Retiro_Chequera,
                    
                }
            };

            string serviceName = Constantes.Servicios.CREACION_CUENTA_CORRIENTE_PN;

            Log.Info($"ConectorBancoBLL/CreacionCuentaCorriente: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            CreacionCuentaCorrienteResponse result = _apiConnector.MakeRequest<CreacionCuentaCorrienteResponse, CreacionCuentaCorrienteRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/CreacionCuentaCorriente: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return new CreacionCuentaCorrienteResult { 
                Cuenta = result.DatosCuenta.Cuenta,
                Prefijo = result.DatosCuenta.Prefijo
            };
        }

        public bool EdicionCuentaCorrientePersonaNatural(DatosCuentaCorriente clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionCuentaCorrienteRequest envelope = new EdicionCuentaCorrienteRequest
            {
                CuentaCorriente = new CreacionDatosCuentaCorriente
                {
                    Agencia = clienteNatural.Agencia,
                    Canal = clienteNatural.Canal,
                    Clase_Cuenta = clienteNatural.Clase_Cuenta,
                    Cuenta = clienteNatural.Cuenta,
                    DatosGeneralChequera = clienteNatural.DatosGeneralChequera,
                    Dcto_Identidad_Cliente = clienteNatural.Dcto_Identidad_Cliente,
                    Documento_Representante_Legal = clienteNatural.Documento_Representante_Legal,
                    Documento_Titular = clienteNatural.Documento_Titular,
                    //Lin_Libreta = clienteNatural.Lin_Libreta,
                    Moneda = clienteNatural.Moneda,
                    MontoApertura = clienteNatural.MontoApertura,
                    Nombre = clienteNatural.Nombre,
                    Nombre_Representante_Legal = clienteNatural.Nombre_Representante_Legal,
                    Nombre_Titular = clienteNatural.Nombre_Titular,
                    //Numero_Libreta = clienteNatural.Numero_Libreta,
                    Oficial = clienteNatural.Oficial,
                    Prefijo = clienteNatural.Prefijo,
                    Producto = clienteNatural.Producto,
                    SubProducto = clienteNatural.SubProducto,
                    Tipo_Cuenta = clienteNatural.Tipo_Cuenta,
                    Tipo_Documento_Representante_Legal = clienteNatural.Tipo_Documento_Representante_Legal,
                    Tipo_Documento_Titular = clienteNatural.Tipo_Documento_Titular,
                    Tipo_Identidad_Cliente = clienteNatural.Tipo_Identidad_Cliente,
                    Tipo_Producto = clienteNatural.Tipo_Producto,
                    Zona = clienteNatural.Zona,
                    Fecha_Apertura = clienteNatural.Fecha_Apertura,
                    Hora_Apertura = clienteNatural.Hora_Apertura,
                    Referido_Por = clienteNatural.Referido_Por,
                    Origen_Captacion = clienteNatural.Origen_Captacion,
                    EstadoCuenta = clienteNatural.EstadoCuenta,
                    Dia_Mes = clienteNatural.Dia_Mes,
                    Semana = clienteNatural.Semana,
                    Datos_Retiro_Chequera = clienteNatural.Datos_Retiro_Chequera,

                }
            };

            string serviceName = Constantes.Servicios.EDICION_CUENTA_CORRIENTE_PN;

            Log.Info($"ConectorBancoBLL/EdicionCuentaCorriente: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            EdicionCuentaCorrienteResponse result = _apiConnector.MakeRequest<EdicionCuentaCorrienteResponse, EdicionCuentaCorrienteRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/EdicionCuentaCorriente: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }

        #endregion

        #region NOMBREEMPRESA
        public DatosEmpresa ConsultarNombreEmpresa(string rucEmpresa, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaNombreEmpresaRequest envelope = new ConsultaNombreEmpresaRequest
            {
                RucEmpresa = rucEmpresa
            };

            string serviceName = Constantes.Servicios.CONSULTA_NOMBRE_EMPRESA;

            Log.Info($"ConectorBancoBLL/ConsultarNombreEmpresa: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            ConsultaNombreEmpresaResponse result = _apiConnector.MakeRequest<ConsultaNombreEmpresaResponse, ConsultaNombreEmpresaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/ConsultarNombreEmpresa: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            DatosEmpresa resultadoDatos = new DatosEmpresa();

            if (result.DatosEmpresa != null)
            {
                resultadoDatos = result.DatosEmpresa;
            }

            return resultadoDatos;
        }
        #endregion

        #endregion

        #region CONTACTABILIDA
        public Contactabilidad ConsultarContactabilidadCliente(string tipoIdentificacion, string identificacion, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaContactabilidadRequest envelope = new ConsultaContactabilidadRequest
            {
                Dcto_Identidad_Cliente = identificacion,
                Tipo_Identidad_Cliente = tipoIdentificacion
            };

            string serviceName = Constantes.Servicios.CONSULTA_CONTACTABILIDAD;

            Log.Info($"ConectorBancoBLL/ConsultarContactabilidadCliente: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            ConsultaContactabilidadResponse result = _apiConnector.MakeRequest<ConsultaContactabilidadResponse, ConsultaContactabilidadRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/ConsultarContactabilidadCliente: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            Contactabilidad resultadoDatos = new Contactabilidad();

            if (result.ContactabilidadCliente != null)
            {
                resultadoDatos = result.ContactabilidadCliente;
            }

            return resultadoDatos;
        }        

        public bool EdicionContactabilidadCliente(Contactabilidad clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionContactabilidadRequest envelope = new EdicionContactabilidadRequest
            {
                ContactabilidadCliente = clienteNatural
            };

            string serviceName = Constantes.Servicios.EDICION_CONTACTABILIDAD;

            Log.Info($"ConectorBancoBLL/EdicionContactabilidadCliente: {serviceName.Replace(Environment.NewLine, "")} -> REQUEST API BANCO");

            EdicionContactabilidadResponse result = _apiConnector.MakeRequest<EdicionContactabilidadResponse, EdicionContactabilidadRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Info($"ConectorBancoBLL/EdicionContactabilidadCliente: {serviceName.Replace(Environment.NewLine, "")} -> RESPONSE API BANCO");

            if (mensaje.CodigoOrigen != icCommonFramework.Utils.Constantes.MappingCode.EXITO)
            {
                ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.CodigoRetorno);

                if (codeResponse.CodigoError == icCommonFramework.Utils.Constantes.MappingCode.NO_REGISTRADO)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.Mensaje.CodigoRetorno, result.Mensaje.MensajeRetorno);
                }
                else
                {
                    ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                }
            }

            return true;
        }
        #endregion
    }
}
