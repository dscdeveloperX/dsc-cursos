﻿using icCommonFramework.DTOs.API;
using icCommonFramework.Modelos;
using log4net;
using Newtonsoft.Json;
using icSwithBalconServicios.DTOs;
using icSwithBalconServicios.DTOs.API.Request;
using icSwithBalconServicios.DTOs.API.Response;
using System;
using icSwithBalconServicios.DTOs.API.Response.PersonaJuridica;
using icSwithBalconServicios.DTOs.API.Request.PersonaJuridica;
using icSwithBalconServicios.DTOs.Response.CuentaAhorro;
using icSwithBalconServicios.DTOs.AS400.Response.CuentaCorriente;
using icCommonFramework.Utils;

namespace icSwithBalconServicios.BLL
{
    public class BalconServiciosPersonaJuridica
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(BalconServiciosPersonaJuridica));

        private readonly ConectorBancoBLL _clRepository;
        public BalconServiciosPersonaJuridica()
        {
            _clRepository = new ConectorBancoBLL();
        }
        public ConsultaPersonaJuridicaResponse ConsultarPersonaJuridica(ConsultaPersonaJuridicaRequest request)
        {
            try
            {
                ConsultaPersonaJuridicaResponse response = new ConsultaPersonaJuridicaResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaPersonaJuridicaResponseBody bodyResponse = new ConsultaPersonaJuridicaResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Identificacion;
                var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;

                Log.Info("BalconServicios/ConsultarPersonaJuridica: ConsultarClienteJuridica -> INICIO");
                var resultadoPersona = _clRepository.ConsultarClienteJuridica(tipoIdentificacion, nutCliente, nutCliente, request.HeaderRequest.UserName,
                   request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultarPersonaJuridica: ConsultarClienteJuridica -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.DatosPersona = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultarPersonaJuridica: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionPJCuentaAhorroResponse CreacionCuentaAhorroPersonaJuridica(CreacionPJCuentaAhorroRequest request)
        {
            try
            {
                CreacionPJCuentaAhorroResponse response = new CreacionPJCuentaAhorroResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                CreacionPJCuentaAhorroResponseBody bodyResponse = new CreacionPJCuentaAhorroResponseBody();

                var valoresCuenta = request.BodyRequest.DatosCuenta;

                string nutCliente = valoresCuenta.Documento_Titular;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();


                CreacionCuentaAhorroResult resultado = null;

                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaJuridica: CreacionCuentaAhorro -> INICIO");
                resultado = _clRepository.CreacionCuentaAhorroPersonaNatural(valoresCuenta, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/CreacionCuentaAhorroPersonaJuridica: CreacionCuentaAhorro -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;

                    //Create Body Response
                    bodyResponse.Cuenta = resultado.Cuenta;
                    bodyResponse.Prefijo = resultado.Prefijo;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/CreacionCuentaAhorroPersonaJuridica: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionPJCuentaCorrienteResponse CreacionCuentaCorrientePersonaJuridica(CreacionPJCuentaCorrienteRequest request)
        {
            try
            {
                CreacionPJCuentaCorrienteResponse response = new CreacionPJCuentaCorrienteResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                CreacionPJCuentaCorrienteResponseBody bodyResponse = new CreacionPJCuentaCorrienteResponseBody();

                var valoresCuenta = request.BodyRequest.DatosCuenta;

                string nutCliente = valoresCuenta.Documento_Titular;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                CreacionCuentaCorrienteResult resultado = null;

                Log.Info("BalconServicios/CreacionCuentaCorrientePersonaJuridica: CreacionCuentaCorriente -> INICIO");
                resultado = _clRepository.CreacionCuentaCorrientePersonaNatural(valoresCuenta, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/CreacionCuentaCorrientePersonaJuridica: CreacionCuentaCorriente -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultado != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;

                    //Create Body Response
                    bodyResponse.Cuenta = resultado.Cuenta;
                    bodyResponse.Prefijo = resultado.Prefijo;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/CreacionCuentaCorrientePersonaJuridica: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaPJCuentaCorrienteResponse ConsultaCuentaCorrientePersonaJuridica(ConsultaPJCuentaCorrienteRequest request)
        {
            try
            {
                ConsultaPJCuentaCorrienteResponse response = new ConsultaPJCuentaCorrienteResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaPJCuentaCorrienteResponseBody bodyResponse = new ConsultaPJCuentaCorrienteResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Identificacion;
                var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;
                string cuenta = request.BodyRequest.Cuenta;
                string prefijo = request.BodyRequest.Prefijo;

                Log.Info("BalconServicios/ConsultaCuentaCorrientePersonaJuridica: ConsultarCuentaCorriente -> INICIO");
                var resultadoPersona = _clRepository.ConsultarCuentaCorrientePersonaNatural(tipoIdentificacion, nutCliente, cuenta, prefijo, request.HeaderRequest.UserName,
                   request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultaCuentaCorrientePersonaJuridica: ConsultarCuentaCorriente -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.DatosCuenta = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultaCuentaCorrientePersonaJuridica: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaPJCuentaAhorroResponse ConsultaCuentaAhorroPersonaJuridica(ConsultaPJCuentaAhorroRequest request)
        {
            try
            {
                ConsultaPJCuentaAhorroResponse response = new ConsultaPJCuentaAhorroResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaPJCuentaAhorroResponseBody bodyResponse = new ConsultaPJCuentaAhorroResponseBody();

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.Identificacion;
                var tipoIdentificacion = request.BodyRequest.TipoIdentificacion;
                string cuenta = request.BodyRequest.Cuenta;
                string prefijo = request.BodyRequest.Prefijo;

                Log.Info("BalconServicios/ConsultaCuentaAhorroPersonaJuridica: ConsultarCuentaAhorro -> INICIO");
                var resultadoPersona = _clRepository.ConsultarCuentaAhorroPersonaNatural(tipoIdentificacion, nutCliente, cuenta, prefijo, request.HeaderRequest.UserName,
                   request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/ConsultaCuentaAhorroPersonaJuridica: ConsultarCuentaAhorro -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.DatosCuenta = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultaCuentaAhorroPersonaJuridica: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionPersonaJuridicaResponse CrearPersonaJuridica(CreacionPersonaJuridicaRequest request)
        {
            try
            {
                CreacionPersonaJuridicaResponse response = new CreacionPersonaJuridicaResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                CreacionPersonaJuridicaResponseBody bodyResponse = new CreacionPersonaJuridicaResponseBody();

                var valoresPersona = request.BodyRequest.DatosPersona;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.DatosPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente;

                bool resultadoPersona = false;

                string serializedJson = JsonConvert.SerializeObject(valoresPersona);
                var valoresPersonaCreate = UtilGeneral.DeserializeNeutralizeJson<DatosPersonaJuridica<RepLegalInCreate,AccionistaInCreate, RefComercialesInCreate, RefBancariaInCreate>>(serializedJson);

                Log.Info("BalconServicios/CrearPersonaJuridica: CreacionClienteJuridica -> INICIO");
                resultadoPersona = _clRepository.CreacionClienteJuridica(valoresPersonaCreate, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/CrearPersonaJuridica: CreacionClienteJuridica -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Creado = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/CrearPersonaJuridica: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EdicionPersonaJuridicaResponse EditarPersonaJuridica(EdicionPersonaJuridicaRequest request)
        {
            try
            {
                EdicionPersonaJuridicaResponse response = new EdicionPersonaJuridicaResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EdicionPersonaJuridicaResponseBody bodyResponse = new EdicionPersonaJuridicaResponseBody();

                var valoresPersona = request.BodyRequest.DatosPersona;

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                string nutCliente = request.BodyRequest.DatosPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente;

                bool resultadoPersona = false;

                Log.Info("BalconServicios/EditarPersonaJuridica: EdicionClienteJuridica -> INICIO");
                resultadoPersona = _clRepository.EdicionClienteJuridica(valoresPersona, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "Identificacion", new DateTime(), nutCliente, ref mensaje);
                Log.Info("BalconServicios/EditarPersonaJuridica: EdicionClienteJuridica -> RESPUESTA");

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (resultadoPersona)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = 1;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = 0;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                }
                //Create Body Response
                bodyResponse.Editado = resultadoPersona;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EditarPersonaJuridica: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
