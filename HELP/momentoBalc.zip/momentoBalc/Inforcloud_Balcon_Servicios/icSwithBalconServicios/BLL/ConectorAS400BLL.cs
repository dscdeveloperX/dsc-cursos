﻿using icCommonFramework.ConexionAS400;
using icCommonFramework.Modelos;
using System;

namespace icSwithBalconServicios.BLL
{
    public class ConectorAS400BLL : ConectorAS400
    {
        private readonly icCommonFramework.DB.ProveedorTrama _proveedorTrama;
        public ConectorAS400BLL() : base()
        {
            _proveedorTrama = new icCommonFramework.DB.ProveedorTrama();
        }

        public override long RegistrarRequest(string serviceName, string content, string user, string ipStation, string type, DateTime callDatetime, string valueId, int thread = 1)
        {
            Trama traceLog = new Trama
            {
                TramaId= 0,
                FechaResponse= DateTime.Now,
                TramaResponse="",
                Ip = ipStation,
                TramaRequest = content,
                FechaRequest = callDatetime,
                Servicio = serviceName,
                Hilo = thread,
                Estado = "REQUEST",
                Usuario = user,
                Valor = valueId,
                TipoValor = type
            };
            long traceId = _proveedorTrama.CrearTrama(traceLog);
            return traceId;
        }

        public override void RegistrarResponse(long dispatchId, string content)
        {
            Trama traceLog = new Trama
            {
                TramaId = dispatchId,
                TramaResponse = content,
                Estado = "RESPONSE"
            };
            _proveedorTrama.ActualizarTrama(traceLog);
        }
    }
}
