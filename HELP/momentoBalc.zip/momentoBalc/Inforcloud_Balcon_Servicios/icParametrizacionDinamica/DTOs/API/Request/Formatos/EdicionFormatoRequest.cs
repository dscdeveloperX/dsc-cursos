﻿using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class EdicionFormatoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionFormatoRequestBody BodyRequest { get; set; }
    }
    public class EdicionFormatoRequestBody
    {
        public FormatoCreacionDto Formato { get; set; }
    }
}
