﻿namespace icParametrizacionDinamica.DTOs.API.Request.Modelos
{
    public class ConsultaModeloRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaModeloRequestBody BodyRequest { get; set; }
    }
    public class ConsultaModeloRequestBody
    {
        public long ModeloId { get; set; }
    }
}
