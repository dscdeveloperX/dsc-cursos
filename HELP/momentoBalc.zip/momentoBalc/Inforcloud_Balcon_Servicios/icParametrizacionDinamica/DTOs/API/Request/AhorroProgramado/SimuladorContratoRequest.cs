﻿namespace icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado {
    public class SimuladorContratoRequest {
        public HeaderRequest HeaderRequest { get; set; }
        public SimuladorContratoRequestBody BodyRequest { get; set; }
    }

    public class SimuladorContratoRequestBody {
        public string Producto { get; set; }
        public string MetaAhorro { get; set; }
        public string DepositoInicial { get; set; }
        public string MontoAhorro { get; set; }
        public string DiaDebito { get; set; }
        public string Plazo { get; set; }
    }
}
