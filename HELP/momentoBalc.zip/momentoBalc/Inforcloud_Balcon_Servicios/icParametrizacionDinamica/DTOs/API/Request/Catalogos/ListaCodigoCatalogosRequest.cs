﻿namespace icParametrizacionDinamica.DTOs.API.Request.Catalogos
{
    public class ListaCodigoCatalogosRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaCodigoCatalogosRequestBody BodyRequest { get; set; }
    }
    public class ListaCodigoCatalogosRequestBody
    {
        public string CodigoCatalogo { get; set; }
        public string NombreCatalogo { get; set; }
    }
}
