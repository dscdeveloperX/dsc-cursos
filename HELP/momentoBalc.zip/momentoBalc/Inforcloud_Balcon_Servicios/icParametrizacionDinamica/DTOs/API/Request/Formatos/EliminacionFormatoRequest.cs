﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class EliminacionFormatoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EliminacionFormatoRequestBody BodyRequest { get; set; }
    }
    public class EliminacionFormatoRequestBody
    {
        public List<long> FormatosIds { get; set; }
    }
}
