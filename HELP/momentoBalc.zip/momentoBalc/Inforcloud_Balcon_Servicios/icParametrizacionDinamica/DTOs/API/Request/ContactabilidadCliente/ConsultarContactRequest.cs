﻿namespace icParametrizacionDinamica.DTOs.API.Request.ContactabilidadCliente
{
    public class ConsultarContactRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultarContactRequestBody BodyRequest { get; set; }
    }
    public class ConsultarContactRequestBody
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
    }
}
