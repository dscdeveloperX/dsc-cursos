﻿namespace icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado {
    public class SimuladorCancelacionContratoRequest {
        public HeaderRequest HeaderRequest { get; set; }
        public SimuladorCancelacionContratoRequestBody BodyRequest { get; set; }
    }

    public class SimuladorCancelacionContratoRequestBody {
        public string contrato { get; set; }
        //public string tipoIdentificacion { get; set; }
        //public string identificacion { get; set; }
        //public Decimal cuenta { get; set; }
    }
}
