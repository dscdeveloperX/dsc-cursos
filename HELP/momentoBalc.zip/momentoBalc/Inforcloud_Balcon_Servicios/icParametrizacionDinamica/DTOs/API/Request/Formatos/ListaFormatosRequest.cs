﻿namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class ListaFormatosRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaFormatosRequestBody BodyRequest { get; set; }
    }
    public class ListaFormatosRequestBody
    {
        public string Estado { get; set; }
        public string OrdenarPor { get; set; }
        public bool OrdenDesc { get; set; }
        public string FiltrarPor { get; set; }
        public string ValorFiltro { get; set; }
    }
}
