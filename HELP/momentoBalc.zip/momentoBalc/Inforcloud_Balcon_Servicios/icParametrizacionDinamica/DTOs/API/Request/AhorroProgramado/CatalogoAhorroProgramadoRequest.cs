﻿using icParametrizacionDinamica.DTOs.EXT;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado {
    public class CatalogoAhorroProgramadoRequest{
        public HeaderRequest HeaderRequest { get; set; }
        public CatalogoRequestBody BodyRequest { get; set; }
    }

    public class CatalogoRequestBody {
        public string Argumento { get; set; }
        public int Tabla { get; set; }
    }
}
