﻿namespace icParametrizacionDinamica.DTOs.API.Request.Modelos
{
    public class ListaModelosRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaModelosRequestBody BodyRequest { get; set; }
    }
    public class ListaModelosRequestBody
    {
        public string Estado { get; set; }
        public string OrdenarPor { get; set; }
        public bool OrdenDesc { get; set; }
        public string FiltrarPor { get; set; }
        public string ValorFiltro { get; set; }
        public string Tipo { get; set; }
        public string menuId { get; set; }
    }
}
