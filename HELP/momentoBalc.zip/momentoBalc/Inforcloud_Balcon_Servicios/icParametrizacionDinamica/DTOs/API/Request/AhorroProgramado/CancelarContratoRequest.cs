﻿using System;

namespace icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado {
    public class CancelarContratoRequest {
        public HeaderRequest HeaderRequest { get; set; }
        public CancelarContratoRequestBody BodyRequest { get; set; }
    }

    public class CancelarContratoRequestBody {
        public decimal Contrato { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }
        public Decimal Cuenta { get; set; }
        public string Canal { get; set; }
        public string Oficial { get; set; }
        public string MotivoCancelacion { get; set; }
        public string UserAS { get; set; }
        public string CorreoElectronico { get; set; }
    }
}
