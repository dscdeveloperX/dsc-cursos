﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class CalcularCampoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CalcularCampoRequestBody BodyRequest { get; set; }
    }
    public class CalcularCampoRequestBody
    {
        public string CampoCalculado { get; set; }
        public string NombreCalculo { get; set; }
        public Dictionary<string,string> ValoresCalculo { get; set; }
    }
}
