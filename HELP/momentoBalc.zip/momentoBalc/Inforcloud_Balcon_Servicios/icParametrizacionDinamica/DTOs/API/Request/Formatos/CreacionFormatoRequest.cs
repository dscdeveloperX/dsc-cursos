﻿using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class CreacionFormatoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionFormatoRequestBody BodyRequest { get; set; }
    }
    public class CreacionFormatoRequestBody
    {
        public FormatoCreacionDto Formato { get; set; }
    }
}
