﻿using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class EnviarFormularioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EnviarFormularioRequestBody BodyRequest { get; set; }
    }
    public class EnviarFormularioRequestBody
    {
        public InfoUsuario InfoUsuario { get;set;}
        public FormatoSolicitudFormularioDto Formulario { get; set; }
    }

    public class InfoUsuario { 
        public string Rol { get; set; }
        public string Correo { get; set; }
        public string ExecutiveCode { get; set; }
        public string AgencyCode { get; set; }
        public string AgenciaSolicitud { get; set; }/*CAMBIO RF-2023-046 // ACT2*/
    }
}
