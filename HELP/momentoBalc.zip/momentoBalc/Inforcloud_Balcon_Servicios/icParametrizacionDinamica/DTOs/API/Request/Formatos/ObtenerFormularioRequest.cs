﻿using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class ObtenerFormularioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ObtenerFormularioRequestBody BodyRequest { get; set; }
    }
    public class ObtenerFormularioRequestBody
    {
        public string TipoPersona { get; set; }
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public string TipoCliente { get; set; }
        public long Producto { get; set; }
    }
}
