﻿namespace icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios
{
    public class ListaSolicitudCambiosRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaSolicitudCambiosRequestBody BodyRequest { get; set; }
    }
    public class ListaSolicitudCambiosRequestBody
    {
        public string Estado { get; set; }
        public string OrdenarPor { get; set; }
        public bool OrdenDesc { get; set; }
        public string FiltrarPor { get; set; }
        public string ValorFiltro { get; set; }
        public string Funcionalidad { get; set; }
        public string AgenciaSolicitud { get; set; }/*CAMBIO RF-2023-046 // ACT2*/
    }
}
