﻿using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Request.Modelos
{
    public class CreacionModeloRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionModeloRequestBody BodyRequest { get; set; }
    }
    public class CreacionModeloRequestBody
    {
        public ModeloDto Modelo { get; set; }
    }
}
