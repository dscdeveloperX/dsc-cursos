﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Request.Modelos
{
    public class EliminacionModeloRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EliminacionModeloRequestBody BodyRequest { get; set; }
    }
    public class EliminacionModeloRequestBody
    {
        public List<long> ModelosIds { get; set; }
    }
}
