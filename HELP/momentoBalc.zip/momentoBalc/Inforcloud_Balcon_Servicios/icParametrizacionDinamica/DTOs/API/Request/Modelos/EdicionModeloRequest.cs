﻿using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Request.Modelos
{
    public class EdicionModeloRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionModeloRequestBody BodyRequest { get; set; }
    }
    public class EdicionModeloRequestBody
    {
        public ModeloDto Modelo { get; set; }
    }
}
