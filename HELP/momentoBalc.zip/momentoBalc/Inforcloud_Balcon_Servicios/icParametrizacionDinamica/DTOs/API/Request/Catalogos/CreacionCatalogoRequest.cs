﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Request.Catalogos
{
    public class CreacionCatalogoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionCatalogoRequestBody BodyRequest { get; set; }
    }
    public class CreacionCatalogoRequestBody
    {
        public CatalogoCreacion Catalogo { get; set; }
    }

    public class CatalogoCreacion
    {
        public string Nombre { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string Complemento { get; set; }
        public string Estado { get; set; }
    }
}
