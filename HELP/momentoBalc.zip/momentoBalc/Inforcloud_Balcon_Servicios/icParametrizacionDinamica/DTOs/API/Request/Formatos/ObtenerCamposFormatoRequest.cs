﻿namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class ObtenerCamposFormatoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ObtenerCamposFormatoRequestBody BodyRequest { get; set; }
    }
    public class ObtenerCamposFormatoRequestBody
    {
        public string Persona { get; set; }
        public string Producto { get; set; }
    }
}
