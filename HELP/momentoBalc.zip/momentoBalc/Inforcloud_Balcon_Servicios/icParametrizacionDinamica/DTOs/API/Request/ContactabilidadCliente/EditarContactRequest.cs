﻿using icParametrizacionDinamica.DTOs.EXT;
namespace icParametrizacionDinamica.DTOs.API.Request.ContactabilidadCliente
{
    public class EditarContactRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EditarContactRequestBody BodyRequest { get; set; }
    }
    public class EditarContactRequestBody
    {
        public Contactabilidad Contactabilidad { get; set; }
    }
}
