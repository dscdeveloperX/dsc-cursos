﻿namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class ListaNombreEmpresaRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ListaNombreEmpresaRequestBody BodyRequest { get; set; }
    }
    public class ListaNombreEmpresaRequestBody
    {
        public string RucEmpresa { get; set; }
    }
}
