﻿namespace icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios
{
    public class ConsultaSolicitudCambioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaSolicitudCambioRequestBody BodyRequest { get; set; }
    }
    public class ConsultaSolicitudCambioRequestBody
    {
        public long CambioId { get; set; }
    }
}
