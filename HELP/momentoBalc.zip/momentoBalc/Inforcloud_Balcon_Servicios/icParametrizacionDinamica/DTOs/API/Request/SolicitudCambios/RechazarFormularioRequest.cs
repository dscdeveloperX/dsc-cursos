﻿namespace icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios
{
    public class RechazarFormularioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public RechazarFormularioRequestBody BodyRequest { get; set; }
    }
    public class RechazarFormularioRequestBody
    {
        public long CambioId { get; set; }
        public string RazonRechazo { get; set; }
    }
}
