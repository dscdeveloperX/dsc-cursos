﻿namespace icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios
{
    public class AprobarFormularioRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public AprobarFormularioRequestBody BodyRequest { get; set; }
    }
    public class AprobarFormularioRequestBody
    {
        public long CambioId { get; set; }
    }
}
