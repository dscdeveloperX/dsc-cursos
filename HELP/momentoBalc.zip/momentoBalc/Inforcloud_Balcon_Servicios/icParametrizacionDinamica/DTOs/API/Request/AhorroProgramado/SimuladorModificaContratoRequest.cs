﻿namespace icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado
{
    public class SimuladorModificaContratoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public SimuladorModificaContratoRequestBody BodyRequest { get; set; }
    }

    public class SimuladorModificaContratoRequestBody
    {
        public decimal Contrato { get; set; }
        public decimal MontoDebito { get; set; }
        public decimal Plazo { get; set; }
    }
}
