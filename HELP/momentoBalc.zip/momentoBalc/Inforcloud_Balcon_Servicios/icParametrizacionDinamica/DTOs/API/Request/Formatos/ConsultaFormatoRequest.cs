﻿namespace icParametrizacionDinamica.DTOs.API.Request.Formatos
{
    public class ConsultaFormatoRequest
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaFormatoRequestBody BodyRequest { get; set; }
    }
    public class ConsultaFormatoRequestBody
    {
        public long FormatoId { get; set; }
    }
}
