﻿namespace icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios
{
    public class ValoresDetalleResumen
    {
        public string Etiqueta { get; set; }
        public string Valor { get; set; }
    }
}
