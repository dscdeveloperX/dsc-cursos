﻿using icCommon.DTOs.API;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.Catalogos
{
    public class ListaCodigoCatalogosResponse : BaseResponse
    {
        public ListaCodigoCatalogosResponseBody BodyResponse { get; set; }

        public ListaCodigoCatalogosResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaCodigoCatalogosResponseBody();
        }

    }
    public class ListaCodigoCatalogosResponseBody
    {
        public List<string> CodigoCatalogos { get; set; }
        public List<string> DescripcionCatalogos { get; set; }
        public ListaCodigoCatalogosResponseBody()
        {
            this.CodigoCatalogos = new List<string>();
            this.DescripcionCatalogos = new List<string>();
        }
    }
}
