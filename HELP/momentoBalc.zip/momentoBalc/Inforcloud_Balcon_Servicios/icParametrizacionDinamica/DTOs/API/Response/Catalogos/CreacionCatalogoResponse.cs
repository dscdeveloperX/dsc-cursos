﻿using icCommon.DTOs.API;
namespace icParametrizacionDinamica.DTOs.API.Response.Catalogos
{
    public class CreacionCatalogoResponse : BaseResponse
    {
        public CreacionCatalogoResponseBody BodyResponse { get; set; }
        public CreacionCatalogoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionCatalogoResponseBody();
        }
    }
    public class CreacionCatalogoResponseBody
    {
        public int CatalogosCreados { get; set; }
        public CreacionCatalogoResponseBody()
        {
            this.CatalogosCreados = 0;
        }
    }
}
