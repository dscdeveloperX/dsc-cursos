﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Response.Catalogos
{
    public class ConsultaCatalogoResponse : BaseResponse
    {
        public ConsultaCatalogoResponseBody BodyResponse { get; set; }
    }
    public class ConsultaCatalogoResponseBody
    {
        public Catalogo Catalogo { get; set; }
    }
}
