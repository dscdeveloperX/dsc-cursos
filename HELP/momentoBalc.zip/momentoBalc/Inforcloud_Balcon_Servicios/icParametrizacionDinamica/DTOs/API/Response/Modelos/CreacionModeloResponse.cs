﻿using icCommon.DTOs.API;

namespace icParametrizacionDinamica.DTOs.API.Response.Modelos
{
    public class CreacionModeloResponse : BaseResponse
    {
        public CreacionModeloResponseBody BodyResponse { get; set; }
        public CreacionModeloResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionModeloResponseBody();
        }
    }
    public class CreacionModeloResponseBody
    {
        public long ModeloId { get; set; }
        public CreacionModeloResponseBody()
        {
            this.ModeloId = 0;
        }
    }
}
