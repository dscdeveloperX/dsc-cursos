﻿using icCommon.DTOs.API;

namespace icParametrizacionDinamica.DTOs.API.Response.Modelos
{
    public class EdicionModeloResponse : BaseResponse
    {
        public EdicionModeloResponseBody BodyResponse { get; set; }
        public EdicionModeloResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionModeloResponseBody();
        }
    }
    public class EdicionModeloResponseBody
    {
        public int ModelosEditados { get; set; }
        public EdicionModeloResponseBody()
        {
            this.ModelosEditados = 0;
        }
    }
}
