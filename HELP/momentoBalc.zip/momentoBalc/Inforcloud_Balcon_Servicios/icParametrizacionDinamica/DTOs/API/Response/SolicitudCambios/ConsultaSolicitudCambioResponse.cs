﻿using icCommon.DTOs.API;
using icCommon.Modelos;

namespace icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios
{
    public class ConsultaSolicitudCambioResponse : BaseResponse
    {
        public ConsultaSolicitudCambioResponseBody BodyResponse { get; set; }
    }
    public class ConsultaSolicitudCambioResponseBody
    {
        public SolicitudCambioDto SolicitudCambio { get; set; }
    }
}
