﻿using icCommon.DTOs.API;
namespace icParametrizacionDinamica.DTOs.API.Response.Catalogos
{
    public class EliminacionCatalogoResponse : BaseResponse
    {
        public EliminacionCatalogoResponseBody BodyResponse { get; set; }

        public EliminacionCatalogoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EliminacionCatalogoResponseBody();
        }

    }
    public class EliminacionCatalogoResponseBody
    {
        public int CatalogosEliminados { get; set; }
        public EliminacionCatalogoResponseBody()
        {
            this.CatalogosEliminados = 0;
        }
    }
}
