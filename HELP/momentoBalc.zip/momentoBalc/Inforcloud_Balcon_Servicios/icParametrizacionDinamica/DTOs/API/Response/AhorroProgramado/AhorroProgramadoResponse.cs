﻿using icCommon.DTOs.API;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.AhorroProgramado
{
    public class AhorroProgramadoResponse : BaseResponse
    {
        public AhorroProgramadoResponseBody BodyResponse { get; set; }
    }

    public class AhorroProgramadoResponseBody
    {
        public string Mensaje { get; set; }
        public Dictionary<string, dynamic> Resultado { get; set; }
    }
}
