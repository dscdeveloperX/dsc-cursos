﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class EnviarFormularioResponse : BaseResponse
    {
        public EnviarFormularioResponseBody BodyResponse { get; set; }
    }
    public class EnviarFormularioResponseBody
    {
        public string Mensaje { get; set; }
        public Dictionary<string, dynamic> Resultado { get; set; }
        public List<ValoresDetalleResumen> Detalles { get; set; }
        public Dictionary<string, string> Firmantes { get; set; }
    }
}
