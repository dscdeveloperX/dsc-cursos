﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.API.Response.ContactabilidadCliente
{
    public class ConsultarContactResponse : BaseResponse
    {
        public ConsultarContactResponseBody BodyResponse { get; set; }
    }
    public class ConsultarContactResponseBody
    {
        public Contactabilidad Contactabilidad { get; set; }
    }
}
