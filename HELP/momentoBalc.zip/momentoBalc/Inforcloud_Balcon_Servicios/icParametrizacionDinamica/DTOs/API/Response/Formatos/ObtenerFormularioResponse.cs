﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class ObtenerFormularioResponse : BaseResponse
    {
        public ObtenerFormularioResponseBody BodyResponse { get; set; }

        public ObtenerFormularioResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ObtenerFormularioResponseBody();
        }
    }
    public class ObtenerFormularioResponseBody
    {
        public FormatoClienteDto Formato { get; set; }
    }
}
