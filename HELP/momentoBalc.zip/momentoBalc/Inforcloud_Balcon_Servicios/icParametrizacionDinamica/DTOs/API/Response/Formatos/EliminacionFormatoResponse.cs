﻿using icCommon.DTOs.API;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class EliminacionFormatoResponse : BaseResponse
    {
        public EliminacionFormatoResponseBody BodyResponse { get; set; }

        public EliminacionFormatoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EliminacionFormatoResponseBody();
        }

    }
    public class EliminacionFormatoResponseBody
    {
        public int FormatosEliminados { get; set; }
        public EliminacionFormatoResponseBody()
        {
            this.FormatosEliminados = 0;
        }
    }
}
