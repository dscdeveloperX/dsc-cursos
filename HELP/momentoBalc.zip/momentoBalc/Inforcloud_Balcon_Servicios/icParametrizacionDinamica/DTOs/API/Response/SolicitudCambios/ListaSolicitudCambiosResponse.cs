﻿using icCommon.DTOs.API;
using icCommon.Modelos;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios
{
    public class ListaSolicitudCambiosResponse : BaseResponse
    {
        public ListaSolicitudCambiosResponseBody BodyResponse { get; set; }
        public ListaSolicitudCambiosResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaSolicitudCambiosResponseBody();
        }

    }
    public class ListaSolicitudCambiosResponseBody
    {
        public List<SolicitudCambio> SolicitudCambios { get; set; }
        public ListaSolicitudCambiosResponseBody()
        {
            this.SolicitudCambios = new List<SolicitudCambio>();
        }
    }
}
