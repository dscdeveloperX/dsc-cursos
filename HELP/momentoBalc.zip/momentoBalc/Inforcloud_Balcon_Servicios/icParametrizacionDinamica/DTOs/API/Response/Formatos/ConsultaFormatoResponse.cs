﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class ConsultaFormatoResponse : BaseResponse
    {
        public ConsultaFormatoResponseBody BodyResponse { get; set; }

        public ConsultaFormatoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultaFormatoResponseBody();
        }
    }
    public class ConsultaFormatoResponseBody
    {
        public FormatoDto Formato { get; set; }
    }
}
