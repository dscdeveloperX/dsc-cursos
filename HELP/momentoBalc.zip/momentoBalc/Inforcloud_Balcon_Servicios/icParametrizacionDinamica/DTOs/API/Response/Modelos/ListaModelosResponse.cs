﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.Models;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.Modelos
{
    public class ListaModelosResponse : BaseResponse
    {
        public ListaModelosResponseBody BodyResponse { get; set; }

        public ListaModelosResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaModelosResponseBody();
        }

    }
    public class ListaModelosResponseBody
    {
        public List<Modelo> Modelos { get; set; }
        public ListaModelosResponseBody()
        {
            this.Modelos = new List<Modelo>();
        }
    }
}
