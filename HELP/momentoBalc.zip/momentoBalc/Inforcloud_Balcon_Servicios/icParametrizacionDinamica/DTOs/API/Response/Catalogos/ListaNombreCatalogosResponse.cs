﻿using icCommon.DTOs.API;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.Catalogos
{
    public class ListaNombreCatalogosResponse : BaseResponse
    {
        public ListaNombreCatalogosResponseBody BodyResponse { get; set; }

        public ListaNombreCatalogosResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaNombreCatalogosResponseBody();
        }

    }
    public class ListaNombreCatalogosResponseBody
    {
        public List<string> NombreCatalogos { get; set; }
        public ListaNombreCatalogosResponseBody()
        {
            this.NombreCatalogos = new List<string>();
        }
    }
}
