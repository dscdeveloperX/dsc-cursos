﻿using icCommon.DTOs.API;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class CreacionFormatoResponse : BaseResponse
    {
        public CreacionFormatoResponseBody BodyResponse { get; set; }
        public CreacionFormatoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionFormatoResponseBody();
        }
    }
    public class CreacionFormatoResponseBody
    {
        public long FormatoId { get; set; }
        public CreacionFormatoResponseBody()
        {
            this.FormatoId = 0;
        }
    }
}
