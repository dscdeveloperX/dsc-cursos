﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Response.Modelos
{
    public class ConsultaModeloResponse : BaseResponse
    {
        public ConsultaModeloResponseBody BodyResponse { get; set; }
    }
    public class ConsultaModeloResponseBody
    {
        public ModeloDto Modelo { get; set; }
    }
}
