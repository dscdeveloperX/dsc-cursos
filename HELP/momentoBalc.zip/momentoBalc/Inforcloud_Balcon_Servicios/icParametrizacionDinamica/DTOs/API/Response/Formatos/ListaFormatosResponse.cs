﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.DTOs.DB.Response.Formatos;
using icParametrizacionDinamica.Models;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class ListaFormatosResponse : BaseResponse
    {
        public ListaFormatosResponseBody BodyResponse { get; set; }
        public ListaFormatosResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ListaFormatosResponseBody();
        }

    }
    public class ListaFormatosResponseBody
    {
        public List<FormatoQuery> Formatos { get; set; }
        public ListaFormatosResponseBody()
        {
            this.Formatos = new List<FormatoQuery>();
        }
    }
}
