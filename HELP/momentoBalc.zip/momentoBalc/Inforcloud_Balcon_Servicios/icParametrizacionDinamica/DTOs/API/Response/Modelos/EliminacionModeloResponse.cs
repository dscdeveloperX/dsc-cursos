﻿using icCommon.DTOs.API;

namespace icParametrizacionDinamica.DTOs.API.Response.Modelos
{
    public class EliminacionModeloResponse : BaseResponse
    {
        public EliminacionModeloResponseBody BodyResponse { get; set; }

        public EliminacionModeloResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EliminacionModeloResponseBody();
        }

    }
    public class EliminacionModeloResponseBody
    {
        public int ModelosEliminados { get; set; }
        public EliminacionModeloResponseBody()
        {
            this.ModelosEliminados = 0;
        }
    }
}
