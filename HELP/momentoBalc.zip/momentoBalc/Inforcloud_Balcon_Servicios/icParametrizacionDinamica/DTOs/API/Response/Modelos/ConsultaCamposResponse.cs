﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.Models;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.API.Response.Modelos
{
    public class ConsultaCamposResponse : BaseResponse
    {
        public ConsultaCamposResponseBody BodyResponse { get; set; }

        public ConsultaCamposResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultaCamposResponseBody();
        }

    }
    public class ConsultaCamposResponseBody
    {
        public List<Campo> Campos { get; set; }
        public ConsultaCamposResponseBody()
        {
            this.Campos = new List<Campo>();
        }
    }
}
