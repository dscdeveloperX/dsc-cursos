﻿using icCommon.DTOs.API;

namespace icParametrizacionDinamica.DTOs.API.Response.ContactabilidadCliente
{
    public class EditarContactResponse : BaseResponse
    {
        public EditarContactResponseBody BodyResponse { get; set; }
        public EditarContactResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EditarContactResponseBody();
        }
    }
    public class EditarContactResponseBody
    {
        public bool Editado { get; set; }
        public EditarContactResponseBody()
        {
            this.Editado = false;
        }
    }
}
