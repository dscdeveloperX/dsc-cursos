﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class ObtenerCamposFormatoResponse : BaseResponse
    {
        public ObtenerCamposFormatoResponseBody BodyResponse { get; set; }
    }
    public class ObtenerCamposFormatoResponseBody
    {
        public CamposFormatoDto Formato { get; set; }
    }
}
