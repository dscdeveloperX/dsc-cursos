﻿using icCommon.DTOs.API;

namespace icParametrizacionDinamica.DTOs.API.Response.Formatos
{
    public class EdicionFormatoResponse : BaseResponse
    {
        public EdicionFormatoResponseBody BodyResponse { get; set; }
        public EdicionFormatoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionFormatoResponseBody();
        }
    }
    public class EdicionFormatoResponseBody
    {
        public int FormatosEditados { get; set; }
        public EdicionFormatoResponseBody()
        {
            this.FormatosEditados = 0;
        }
    }
}
