﻿using FluentValidation;
using icParametrizacionDinamica.DTOs.API.Request.Modelos;

namespace icParametrizacionDinamica.DTOs.API.Validators
{
    public class ConsultaModeloValidator : AbstractValidator<ConsultaModeloRequest>
    {
        public ConsultaModeloValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.ModeloId).GreaterThanOrEqualTo(0);
        }
    }

    public class ListaModelosValidator : AbstractValidator<ListaModelosRequest>
    {
        public ListaModelosValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            //RuleFor(x => x.BodyRequest.NombreModelo).GreaterThanOrEqualTo(0);
        }
    }
    public class CreacionModeloValidator : AbstractValidator<CreacionModeloRequest>
    {
        public CreacionModeloValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Modelo.Nombre).NotEmpty();
            RuleFor(x => x.BodyRequest.Modelo.Descripcion).NotEmpty();
            RuleFor(x => x.BodyRequest.Modelo.Codigo).NotEmpty();
            //RuleFor(x => x.bodyRequest.name).NotEmpty();
            //RuleFor(x => x.bodyRequest.companyId).NotEmpty();
            //RuleFor(x => x.bodyRequest.key).NotEmpty();
            //RuleFor(x => x.bodyRequest.value).NotEmpty();
        }
    }
    public class EdicionModeloValidator : AbstractValidator<EdicionModeloRequest>
    {
        public EdicionModeloValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Modelo.ModeloId).GreaterThan(0);
            RuleFor(x => x.BodyRequest.Modelo.Descripcion).NotEmpty();
        }
    }
    public class EliminacionModeloValidator : AbstractValidator<EliminacionModeloRequest>
    {
        public EliminacionModeloValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.ModelosIds).NotEmpty();
        }
    }
}
