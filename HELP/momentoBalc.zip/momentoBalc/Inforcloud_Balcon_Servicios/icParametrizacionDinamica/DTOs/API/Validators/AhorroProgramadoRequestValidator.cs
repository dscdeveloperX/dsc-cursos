﻿using FluentValidation;
using icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado;

namespace icParametrizacionDinamica.DTOs.API.Validators {

    public class CancelarContratoValidator : AbstractValidator<CancelarContratoRequest> {
        public CancelarContratoValidator() {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Contrato).NotEmpty().WithMessage("DEBE INDICAR EL NÚMERO CONTRATO.");
            RuleFor(x => x.BodyRequest.TipoDocumento).NotEmpty().WithMessage("DEBE INDICAR EL NÚMERO DE IDENTIFICACIÓN.");
            RuleFor(x => x.BodyRequest.Documento).NotEmpty().WithMessage("DEBE INDICAR EL NÚMERO DE IDENTIFICACIÓN.");
            RuleFor(x => x.BodyRequest.Cuenta).NotEmpty().WithMessage("DEBE INDICAR EL NÚMERO DE CUENTA.");
            RuleFor(x => x.BodyRequest.Canal).NotEmpty().WithMessage("DEBE INDICAR EL CANAL.");
            RuleFor(x => x.BodyRequest.Oficial).NotEmpty().WithMessage("DEBE INDICAR EL OFICIAL.");
            RuleFor(x => x.BodyRequest.MotivoCancelacion).NotEmpty().WithMessage("DEBE INDICAR EL MOTIVO DE LA CANCELACIÓN.");
            RuleFor(x => x.BodyRequest.UserAS).NotEmpty().WithMessage("DEBE INDICAR EL USUARIO.");
            RuleFor(x => x.BodyRequest.CorreoElectronico).NotEmpty().WithMessage("DEBE INDICAR EL CORREO.");
        }
    }

    public class SolicitarContratoValidator : AbstractValidator<SolicitudAhorroProgramadoRequest> {
        public SolicitarContratoValidator() {
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.CodAgencia).NotNull();
            RuleFor(x => x.BodyRequest.TipoDocumento).NotNull();
            RuleFor(x => x.BodyRequest.Documento).NotNull();
            RuleFor(x => x.BodyRequest.CuentaDebitar).NotNull();
            RuleFor(x => x.BodyRequest.CuentaAhorro).NotNull();
            RuleFor(x => x.BodyRequest.Canal).NotNull();
            RuleFor(x => x.BodyRequest.Servicio).NotNull();
            RuleFor(x => x.BodyRequest.MontoMeta).NotNull();
            RuleFor(x => x.BodyRequest.CuotaAhorro).NotNull();
            RuleFor(x => x.BodyRequest.CodMetaAhorro).NotNull();
            RuleFor(x => x.BodyRequest.MotivoAhorro).NotNull();
            RuleFor(x => x.BodyRequest.Oficial).NotNull();
            RuleFor(x => x.BodyRequest.Plazo).NotNull();
            RuleFor(x => x.BodyRequest.DepositoInicial).NotNull();
            RuleFor(x => x.BodyRequest.DiaDebito).NotNull();
            RuleFor(x => x.BodyRequest.UserAS).NotNull();
            RuleFor(x => x.BodyRequest.CorreoElectronico).NotNull();
        }
    }

    public class SimuladorCancelacionContratoValidator : AbstractValidator<SimuladorCancelacionContratoRequest> {
        public SimuladorCancelacionContratoValidator() {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.contrato).NotEmpty().WithMessage("DEBE INDICAR EL NÚMERO CONTRATO.");
        }
    }

    public class SimuladorContratoValidator : AbstractValidator<SimuladorContratoRequest>
    {
        public SimuladorContratoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Producto).NotEmpty().WithMessage("DEBE INDICAR EL PRODUCTO.");
            RuleFor(x => x.BodyRequest.MetaAhorro).NotEmpty().WithMessage("DEBE INDICAR LA META.");
            RuleFor(x => x.BodyRequest.DepositoInicial).NotEmpty().WithMessage("DEBE INDICAR EL DEPOSITO INICIAL.");
            RuleFor(x => x.BodyRequest.MontoAhorro).NotEmpty().WithMessage("DEBE INDICAR EL MONTO.");
            RuleFor(x => x.BodyRequest.DiaDebito).NotEmpty().WithMessage("DEBE INDICAR EL DIA DE DEBITO.");
            RuleFor(x => x.BodyRequest.Plazo).NotEmpty().WithMessage("DEBE INDICAR EL PLAZO.");
        }
    }

    public class SimuladorModificaContratoValidator : AbstractValidator<SimuladorModificaContratoRequest>
    {
        public SimuladorModificaContratoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Contrato).NotEmpty().WithMessage("DEBE INDICAR EL CONTRATO.");
            RuleFor(x => x.BodyRequest.Plazo).NotEmpty().WithMessage("DEBE INDICAR EL CONTRATO.");
            RuleFor(x => x.BodyRequest.MontoDebito).NotEmpty().WithMessage("DEBE INDICAR EL CONTRATO.");
        }
    }
}
