﻿using FluentValidation;
using icParametrizacionDinamica.DTOs.API.Request.ContactabilidadCliente;

namespace icParametrizacionDinamica.DTOs.API.Validators
{
    public class ConsultarContactValidator : AbstractValidator<ConsultarContactRequest>
    {
        public ConsultarContactValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();

            RuleFor(x => x.BodyRequest.TipoIdentificacion).NotEmpty();
            RuleFor(x => x.BodyRequest.Identificacion).NotEmpty();
        }
    }

    public class EditarContactValidator : AbstractValidator<EditarContactRequest>
    {
        public EditarContactValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();

            RuleFor(x => x.BodyRequest).NotEmpty();
            RuleFor(x => x.BodyRequest.Contactabilidad).NotEmpty();
            RuleFor(x => x.BodyRequest.Contactabilidad.Dcto_Identidad_Cliente).NotEmpty();
            RuleFor(x => x.BodyRequest.Contactabilidad.Tipo_Identidad_Cliente).NotEmpty();
        }
    }
}
