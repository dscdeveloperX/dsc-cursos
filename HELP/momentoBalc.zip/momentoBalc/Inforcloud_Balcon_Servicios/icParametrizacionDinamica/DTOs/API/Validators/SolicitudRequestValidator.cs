﻿using FluentValidation;
using icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios;

namespace icParametrizacionDinamica.DTOs.API.Validators
{
    public class ListaSolicitudCambiosValidator : AbstractValidator<ListaSolicitudCambiosRequest>
    {
        public ListaSolicitudCambiosValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

        }
    }

    public class ConsultaSolicitudCambioValidator : AbstractValidator<ConsultaSolicitudCambioRequest>
    {
        public ConsultaSolicitudCambioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.CambioId).GreaterThanOrEqualTo(0);
        }
    }

    public class AprobarFormularioValidator : AbstractValidator<AprobarFormularioRequest>
    {
        public AprobarFormularioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.CambioId).GreaterThanOrEqualTo(0);
        }
    }

    public class RechazarFormularioValidator : AbstractValidator<RechazarFormularioRequest>
    {
        public RechazarFormularioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.CambioId).GreaterThanOrEqualTo(0);
            RuleFor(x => x.BodyRequest.RazonRechazo).NotEmpty();
        }
    }
}
