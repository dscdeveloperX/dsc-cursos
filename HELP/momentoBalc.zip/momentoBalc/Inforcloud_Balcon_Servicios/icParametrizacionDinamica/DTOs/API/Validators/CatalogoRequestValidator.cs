﻿using FluentValidation;
using icParametrizacionDinamica.DTOs.API.Request.Catalogos;

namespace icParametrizacionDinamica.DTOs.API.Validators
{
    public class ConsultaCatalogoValidator : AbstractValidator<ConsultaCatalogoRequest>
    {
        public ConsultaCatalogoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.CatalogoId).GreaterThanOrEqualTo(0);
        }
    }

    public class ListaCatalogosValidator : AbstractValidator<ListaCatalogosRequest>
    {
        public ListaCatalogosValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            //RuleFor(x => x.BodyRequest.NombreCatalogo).GreaterThanOrEqualTo(0);
        }
    }
    public class ListaNombreCatalogosValidator : AbstractValidator<ListaNombreCatalogosRequest>
    {
        public ListaNombreCatalogosValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.NombreCatalogo).NotNull();
        }
    }
    public class CreacionCatalogoValidator : AbstractValidator<CreacionCatalogoRequest>
    {
        public CreacionCatalogoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            //RuleFor(x => x.bodyRequest.name).NotEmpty();
            //RuleFor(x => x.bodyRequest.companyId).NotEmpty();
            //RuleFor(x => x.bodyRequest.key).NotEmpty();
            //RuleFor(x => x.bodyRequest.value).NotEmpty();
        }
    }
    public class EdicionCatalogoValidator : AbstractValidator<EdicionCatalogoRequest>
    {
        public EdicionCatalogoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Catalogo.CatalogoId).GreaterThan(0);
            RuleFor(x => x.BodyRequest.Catalogo.Descripcion).NotEmpty();
        }
    }
    public class EliminacionCatalogoValidator : AbstractValidator<EliminacionCatalogoRequest>
    {
        public EliminacionCatalogoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.CatalogoIds).NotEmpty();
        }
    }
}
