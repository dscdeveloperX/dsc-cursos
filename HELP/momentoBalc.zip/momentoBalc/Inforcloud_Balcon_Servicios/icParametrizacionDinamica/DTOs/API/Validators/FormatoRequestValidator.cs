﻿using FluentValidation;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;

namespace icParametrizacionDinamica.DTOs.API.Validators
{
    public class ConsultaFormatoValidator : AbstractValidator<ConsultaFormatoRequest>
    {
        public ConsultaFormatoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.FormatoId).GreaterThanOrEqualTo(0);
        }
    }

    public class ObtenerCamposFormatoValidator : AbstractValidator<ObtenerCamposFormatoRequest>
    {
        public ObtenerCamposFormatoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Persona).NotEmpty();
        }
    }

    public class ListaFormatosValidator : AbstractValidator<ListaFormatosRequest>
    {
        public ListaFormatosValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            //RuleFor(x => x.BodyRequest.NombreFormato).GreaterThanOrEqualTo(0);
        }
    }
    public class CreacionFormatoValidator : AbstractValidator<CreacionFormatoRequest>
    {
        public CreacionFormatoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            //RuleFor(x => x.bodyRequest.name).NotEmpty();
            //RuleFor(x => x.bodyRequest.companyId).NotEmpty();
            //RuleFor(x => x.bodyRequest.key).NotEmpty();
            //RuleFor(x => x.bodyRequest.value).NotEmpty();
        }
    }
    public class EdicionFormatoValidator : AbstractValidator<EdicionFormatoRequest>
    {
        public EdicionFormatoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.Formato.FormatoId).GreaterThan(0);
            RuleFor(x => x.BodyRequest.Formato.Descripcion).NotEmpty();
        }
    }
    public class EliminacionFormatoValidator : AbstractValidator<EliminacionFormatoRequest>
    {
        public EliminacionFormatoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.FormatosIds).NotEmpty();
        }
    }

    public class ObtenerFormularioValidator : AbstractValidator<ObtenerFormularioRequest>
    {
        public ObtenerFormularioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.TipoPersona).NotEmpty();
            RuleFor(x => x.BodyRequest.TipoIdentificacion).NotEmpty();
            RuleFor(x => x.BodyRequest.Identificacion).NotEmpty();
            RuleFor(x => x.BodyRequest.TipoCliente).NotEmpty();
            RuleFor(x => x.BodyRequest.Identificacion).NotEmpty().WithMessage("DEBE INDICAR EL NÚMERO DE IDENTIFICACIÓN.");
        }
    }

    public class EnviarFormularioValidator : AbstractValidator<EnviarFormularioRequest>
    {
        public EnviarFormularioValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);
        }
    }
    public class CalcularCampoValidator : AbstractValidator<CalcularCampoRequest>
    {
        public CalcularCampoValidator()
        {
            //Header Validation
            RuleFor(x => x.HeaderRequest).NotEmpty();
            RuleFor(x => x.HeaderRequest.UserName).NotEmpty();
            RuleFor(x => x.HeaderRequest.StationIp).NotEmpty();
            RuleFor(x => x.HeaderRequest.PageSize).NotEqual(0);
            RuleFor(x => x.HeaderRequest.PageRequested).NotEqual(0);

            RuleFor(x => x.BodyRequest.NombreCalculo).NotEmpty();
            RuleFor(x => x.BodyRequest.CampoCalculado).NotEmpty();
        }
    }
    
}
