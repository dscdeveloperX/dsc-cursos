﻿using System;
using System.Collections.Generic;
using static icCommon.Utils.ObjectReflection;

namespace icParametrizacionDinamica.DTOs.EXT
{
    [Reflectable]
    public class DatosCuentaAhorro
    {
        public string Prefijo { get; set; }
        public string Cuenta { get; set; }
        public string Tipo_Identidad_Cliente { get; set; }
        public string Dcto_Identidad_Cliente { get; set; }
        public string Zona { get; set; }
        public string Agencia { get; set; }
        public string Moneda { get; set; }
        public string Tipo_Producto { get; set; }
        public string Producto { get; set; }
        public string SubProducto { get; set; }
        public string Nombre { get; set; }
        public string Oficial { get; set; }
        public string Tipo_Cuenta { get; set; }
        public string Clase_Cuenta { get; set; }
        public string Numero_Libreta { get; set; }
        public string Lin_Libreta { get; set; }
        public string Usuario_Creacion { get; set; }
        public string IdentificacionUsuario { get; set; }
        public string Programa { get; set; }
        public string Estacion_Trabajo { get; set; }
        public string Num_Trabajo { get; set; }
        public DateTime Fecha1 { get; set; }
        public DateTime Fecha2 { get; set; }
        public string Canal { get; set; }
        public string Tipo_Documento_Representante_Legal { get; set; }
        public string Documento_Representante_Legal { get; set; }
        public string Nombre_Representante_Legal { get; set; }
        public string Tipo_Documento_Titular { get; set; }
        public string Documento_Titular { get; set; }
        public string Nombre_Titular { get; set; }

        public List<CoTitularIn> Cotitulares { get; set; }

        //CREACION
        public string ProgramaCreacion { get; set; }
        public string UsuarioCreacion { get; set; }
        public string EstacionCreacion { get; set; }
        public string IPCreacion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime HoraCreacion { get; set; }
        //ULTIMA ACTUALIZACION 
        public string ProgramaUltima { get; set; }
        public string UsuarioUltima { get; set; }
        public string EstacionUltima { get; set; }
        public string IPUltima { get; set; }
        public DateTime FechaUltima { get; set; }
        public DateTime HoraUltima { get; set; }
        //PENULTIMA ACTUALIZACION
        public string ProgramaPenultima { get; set; }
        public string UsuarioPenultima { get; set; }
        public string EstacionPenultima { get; set; }
        public string IPPenultima { get; set; }
        public DateTime FechaPenultima { get; set; }
        public DateTime HoraPenultima { get; set; }
    }
    [Coded("COTITU")]
    public class CoTitularIn
    {
        public string AccionCRUD { get; set; }
        public string TipoDocumento { get; set; }
        public string NumeroDocumento { get; set; }
        public int TipoMoneda { get; set; }
        public string NombreCoTitular { get; set; }
    }
}
