﻿using System;
using System.Collections.Generic;
using static icCommon.Utils.ObjectReflection;

namespace icParametrizacionDinamica.DTOs.EXT
{
    [Reflectable]
    public class DatosPersonaJuridica
    {
		public bool EsCliente { get; set; }

		public PNInformacionGeneral SP_Informacion_General { get; set; }
		public PNInformacionDirecciones SP_Informacion_Direcciones { get; set; }
		public PNInformacionFinanciera SP_Informacion_Financiera { get; set; }
		public PNInformacionResidenciaExtranjero SP_Informacion_Residencia_Extranjera { get; set; }
		public PNInformacionAdicional SP_Informacion_Adicional { get; set; }
		public PNInformacionRepresentanteLegal SP_Informacion_Representante_Legal { get; set; } //campo 88
		public PNInformacionAccionistas SP_Informacion_Accionistas { get; set; } //campo 89
		public PNInformacionReferencias SP_Informacion_Referencias { get; set; }
		public DatosAuditoriaPN Datos_Auditoria { get; set; }

	}

	[Reflectable]
	public class PNInformacionGeneral
	{
		public DatosBasicosEmpresa Datos_Basicos { get; set; }

		public DatosGeneralesEmpresa Datos_Generales { get; set; }

		[Reflectable]
		public class DatosBasicosEmpresa
		{
			public string Tipo_Persona { get; set; } //TipoPersona
			public string Nombre_Empresa { get; set; }
			public string PEPS { get; set; }

			//CAMPO API
			public string Listas_Negras { get; set; }


			public string Fondos_Terceros_SoN { get; set; } //N
			public string Campana_Politica_SoN { get; set; } //N
			public DateTime Fecha_Constitucion { get; set; }
			//[ASField("P_LUGCON", iDB2DbType.iDB2Decimal, 4, 0)]
			public string Lugar_Constitucion { get; set; }
			public string Pais_Origen { get; set; } //PaisOrigen
			public string Nacionalidad { get; set; }
			public string Clasificacion_Empresa { get; set; }
			public string Tipo_Empresa { get; set; }
			public string Actividad_Economica { get; set; }
			public DateTime Fecha_Inscripcion_Negocio { get; set; }

		}

		[Reflectable]
		public class DatosGeneralesEmpresa
		{
			public string Tipo_Identidad_Cliente { get; set; } //TipoIdentificacion en caso de empresa siempre sera R=RUC o E=Extranjero
															   //[ASField("P_IDENTI", iDB2DbType.iDB2Char, 15, IgnoreOut = true)]
			public string Dcto_Identidad_Cliente { get; set; }
			public string Estado_Cliente { get; set; }
			public string Codigo_Agencia { get; set; } //Cod. Agencia
			public string Ejecutivo_Oficial { get; set; } //Ejecutivo/Oficial
			public string Producto_Captado { get; set; } // 9999
			public string Tipo_Relacion { get; set; }
			public string Tipo_Cliente { get; set; } // TipoCliente			
		}
	}
	[Reflectable]
	public class PNInformacionDirecciones
	{
		public DireccionEmpresa Direccion { get; set; }
	}

	[Reflectable]
	public class DireccionEmpresa
	{
		public string Provincia { get; set; }
		public string Canton { get; set; }
		public string Parroquia { get; set; }
		public string Direccion { get; set; }
		public string Referencia { get; set; }
		//ELIMINAR
		public string Ciudad { get; set; } //NULL
										   //ELIMINAR
		public string Fax { get; set; } //NULL
										//TELEFONO
		public string Codigo_Internacional { get; set; }
		public string Codigo_Area { get; set; }
		public string Telefono { get; set; }
		public string Celular { get; set; }

		//EMAIL
		public string Correo_Electronico1 { get; set; }
		public string Correo_Electronico2 { get; set; }
		public int Direccion_General { get; set; } // 1 o 0
		public int Envio_Correspondencia { get; set; } // 1 o 0
	}

	[Reflectable]
	public class PNInformacionRepresentanteLegal
	{
		public List<RepresentanteLegal> Representantes { get; set; }
	}

	[Coded("REPLEGAL")]
	public class RepresentanteLegal
	{
		public string AccionCRUD { get; set; }
		public string NumeroSecuencia { get; set; }
		public string Tipo_Identidad_Representante { get; set; } //TipoIdentificacion
		public string Dcto_Identidad_Representante { get; set; }
		public string Codigo_Dactilar { get; set; }
		public string Nombre_Representante { get; set; }
		public string Cargo { get; set; }
		public string Fecha_Vencimiento { get; set; }
		public string EstadoCivil { get; set; }
		public string Nombres_Apellidos_Conyuge { get; set; }
		public string Direccion { get; set; }
		public string Celular { get; set; }
		public string Correo_Electronico { get; set; }
		public string Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador { get; set; }
		public string Seleccione_Pais { get; set; }
		public string Numero_Id_Tributaria { get; set; } //Numero de identificacion tributaria
		public string Direccion_Residencia_Fiscal { get; set; }
		//FATCA
		public string Pais_Nacionalidad { get; set; }
		public string Tiene_Otra_Nacionalidad_SoN { get; set; } //tiene otra nacionalidad
		public string Indique_otra_Nacionalidad { get; set; }
		public string Pais_Nacimiento_Padres_es_EEUU_SoN { get; set; }
		public string Tiene_Tarjeta_Residencia_Legal_en_EEUU_SoN { get; set; }
		public string Estuvo_al_menos_183_dias_en_EEUU_este_anio_SoN { get; set; }
		public string FATCA { get; set; }
		public string Direccion_EEUU { get; set; }
		public string Telefono_EEUU { get; set; }
		public string GIIN { get; set; }
		public string TIN { get; set; }
		public string Social_Security { get; set; }
		public string Employer_ID_Numero { get; set; } //Numero de identificacion tributaria
	}

	[Reflectable]
	public class PNInformacionAccionistas
	{
		public int Cantidad_Accionistas { get; set; }
		public DateTime Fecha_Formulario { get; set; }
		public decimal Capital_Suscrito { get; set; }
		public List<Accionista> Accionistas { get; set; }
	}


	[Coded("ACCIONISTA")]
	public class Accionista
	{
		public string AccionCRUD { get; set; }
		public string NumeroSecuencia { get; set; }
		public string Tipo_Persona { get; set; }
		public string Tipo_Identidad_Accionista { get; set; } //TipoIdentificacion
		public string Dcto_Identidad_Accionista { get; set; }
		public string Codigo_Dactilar_Accionista { get; set; }
		public string Nombre_Accionista { get; set; }
		public decimal Valor_Aporte { get; set; }
		public decimal Porcentaje_Participacion { get; set; }
		public string Direccion { get; set; }
		public string Celular { get; set; }
		public string Correo_Electronico { get; set; }
		public string Nacionalidad { get; set; }
		//SI EL VALOR DE APORTE ES MAYOR AL 10%
		public string Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador { get; set; }
		public string Seleccione_Pais { get; set; }
		public string Numero_Id_Tributaria { get; set; } //Numero de identificacion tributaria
		public string Direccion_Residencia_Fiscal { get; set; }
		public string Pais_Nacionalidad { get; set; }
		public string Tiene_Otra_Nacionalidad_SoN { get; set; } //tiene otra nacionalidad
		public string Indique_otra_Nacionalidad { get; set; }
		public string Pais_Nacimiento_Padres_es_EEUU_SoN { get; set; }
		public string Tiene_Tarjeta_Residencia_Legal_en_EEUU_SoN { get; set; }
		public string Estuvo_al_menos_183_dias_en_EEUU_este_anio_SoN { get; set; }
		public string FATCA { get; set; }
		public string Direccion_EEUU { get; set; }
		public string Telefono_EEUU { get; set; }
		public string GIIN { get; set; }
		public string TIN { get; set; }
		public string Social_Security { get; set; }
		public string Employer_ID_Numero { get; set; } //Numero de identificacion tributaria
	}


	[Reflectable]
	public class PNInformacionFinanciera
	{
		public PNIngresoPatrimonio Ingreso_Patrimonio { get; set; }
		[Reflectable]
		public class PNIngresoPatrimonio
		{
			public string Tipo_Estado_Situacion_Financiera { get; set; }
			public string Tiene_Otros_Ingresos_SoN { get; set; }
			public string Indique_Fuente_Otros_Ingresos { get; set; } //USO FUTURO S o N
			public decimal Total_Activos { get; set; }
			public decimal Total_Pasivos { get; set; }
			public decimal Patrimonio { get; set; } //CALCULADOS
			public decimal Ingresos_Mensuales { get; set; }
			public decimal Egresos_Mensuales { get; set; }
			public decimal Otros_Ingresos_Mensuales { get; set; }
			public decimal Total_Ingresos_Mensuales { get; set; } //CALCULADOS
			public decimal Ingreso_Neto_Mensual { get; set; } //CALCULADOS
			public decimal Ventas_Anuales { get; set; }
			//CALCULADOS
			public decimal Ingresos_Anuales { get; set; }
			public decimal Otros_Ingresos_Anuales { get; set; }

			public decimal Total_Ingresos_Anuales { get; set; } //CALCULADOS
			public decimal Egresos_Anuales { get; set; } //CALCULADOS
			public decimal Ingreso_Neto_Anual { get; set; } //CALCULADOS
			public decimal Ingreso_Neto_Mensual_Promedio { get; set; } //CALCULADOS
			public DateTime Fecha_Informacion { get; set; }
			public DateTime Fecha_Ingreso { get; set; }
			public string Usuario { get; set; }

			//CAMPO API
			public string IdentificacionUsuario { get; set; }

			public DateTime Fecha_Sistema { get; set; }
			public DateTime Hora_Sistema { get; set; }
		}
	}
	[Reflectable]
	public class PNInformacionReferencias
	{
		//CAMPO API
		public string Posee_Cuentas_Otros_Bancos_SoN { get; set; }

		public List<RefBancariaIn> Referencias_Bancarias { get; set; }
		public List<RefComercialesIn> Referencias_Comerciales { get; set; }
	}
	[Reflectable]
	public class PNInformacionResidenciaExtranjero
	{
		public string FATCA { get; set; }
		public string Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador { get; set; }
		public string Seleccione_Pais { get; set; }
		public string Numero_Id_Tributaria { get; set; } //Numero de identificacion tributaria
		public string Direccion_Residencia_Fiscal { get; set; }
	}
	[Reflectable]
	public class PNInformacionAdicional
	{
		public DatosBasicosAdicionalesPN Datos_Basicos { get; set; }
		public IngresoInformacionAdicionalPN Ingreso_Informacion_Adicional { get; set; }
		public DatosDeudorPN Datos_Deudor { get; set; }
	}

	[Reflectable]
	public class DatosBasicosAdicionalesPN
	{
		public string Proposito_Relacion_Comercial { get; set; }
	}

	[Reflectable]
	public class IngresoInformacionAdicionalPN
	{
		//ELIMINAR
		public decimal? Compra_Divisas { get; set; } //NULL
		public decimal? Venta_Divisas { get; set; } //NULL
		public decimal? Deposito_Efectivo { get; set; } //NULL
		public decimal? Prestamos { get; set; } //NULL
		public decimal? Trans_Enviadas { get; set; } //NULL
		public decimal? Trans_Recibidas { get; set; } //NULL
		public decimal? Inversiones { get; set; } //NULL
		public decimal? Pago_Tarj_Cred { get; set; } //NULL
		public decimal? Inv_Tarj_Cr { get; set; } //NULL
		public decimal? Aper_Ctas_Inte { get; set; } //NULL
													 //CALCULADO
		public decimal PTP_Mensual { get; set; }
		public decimal PTP_Mensual_Maximo { get; set; }
		public decimal PMM_Ingresos_Mensuales { get; set; }
	}
	[Reflectable]
	public class DatosDeudorPN
	{
		//DATOS DEUDOR
		public DateTime Fecha_Ingreso_Laboral_Anterior { get; set; }
		public DateTime Fecha_Salida_Laboral_Anterior { get; set; }
		public int Tipo_Ingreso_Deudor { get; set; }
		//LLENAR CON DATOS ANTERIORES
		public string Tipo_Documento_Conyuge { get; set; }
		public string Identificacion_Conyuge { get; set; }
		public string Nombre_Conyuge { get; set; }
		//LLENAR CON DATOS ANTERIORES END 
		public string Profesion_Conyuge { get; set; }
		public string Direccion_Oficina { get; set; }
		public string Telefono { get; set; }
		public string Situacion_Bienes { get; set; }
	}

	[Reflectable]
	public class DatosAuditoriaPN //Identica a persona natural
	{
		//CREACION
		public string ProgramaCreacion { get; set; }
		public string UsuarioCreacion { get; set; }
		public string EstacionCreacion { get; set; }
		public string IPCreacion { get; set; }
		public DateTime FechaCreacion { get; set; }
		public DateTime HoraCreacion { get; set; }
		//ULTIMA ACTUALIZACION 
		public string ProgramaUltima { get; set; }
		public string UsuarioUltima { get; set; }
		public string EstacionUltima { get; set; }
		public string IPUltima { get; set; }
		public DateTime FechaUltima { get; set; }
		public DateTime HoraUltima { get; set; }
		//PENULTIMA ACTUALIZACION
		public string ProgramaPenultima { get; set; }
		public string UsuarioPenultima { get; set; }
		public string EstacionPenultima { get; set; }
		public string IPPenultima { get; set; }
		public DateTime FechaPenultima { get; set; }
		public DateTime HoraPenultima { get; set; }
	}		
}
