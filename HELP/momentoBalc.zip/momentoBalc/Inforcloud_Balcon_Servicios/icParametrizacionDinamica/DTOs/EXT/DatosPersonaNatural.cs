﻿using icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using static icCommon.Utils.ObjectReflection;

namespace icParametrizacionDinamica.DTOs.EXT
{
	[Reflectable]
	public class DatosPersonaNatural
	{
		public string Sin_Registro_Civil { get; set; }
		public bool EsCliente { get; set; }
		public SPInformacionGeneral SP_Informacion_General { get; set; }
		public SPInformacionDirecciones SP_Informacion_Direcciones { get; set; }
		public SPInformacionLaboral SP_Informacion_Laboral { get; set; }
		public SPInformacionFinanciera SP_Informacion_Financiera { get; set; }
		public SPInformacionResidenciaExtranjero SP_Informacion_Residencia_Extranjera { get; set; }
		public SPInformacionAdicional SP_Informacion_Adicional { get; set; }
		public SPInformacionReferencias SP_Informacion_Referencias { get; set; }
		public SPDatosAhorroProgramado SP_DatosAhorroProgramado { get; set; }
	}

	[Reflectable]
	public class SPInformacionGeneral
	{


		public DatosBasicos Datos_Basicos { get; set; }


		public DatosGenerales Datos_Generales { get; set; }


		public Conyuge Datos_Conyuge { get; set; }

		[Reflectable]
		public class DatosBasicos
		{
			public string Tipo_Persona { get; set; } //TipoPersona
			public string Nombres_Apellidos { get; set; }
			public string PEPS { get; set; }

			public string Listas_Negras { get; set; }

			public string Fondos_Terceros_SoN { get; set; } //N
			public string Campana_Politica_SoN { get; set; } //N
			public DateTime Fecha_Nacimiento { get; set; }
			public string Lugar_Nacimiento { get; set; }
			public string Pais_Origen { get; set; } //PaisOrigen
			public string Sexo { get; set; }
			public string Nacionalidad { get; set; }
			public string Estado_Civil { get; set; }
			public int Cargas_Familiares_Dependientes { get; set; }
			public string Condicion_Cedulado { get; set; } = string.Empty; //dsc: campo fallido

        }

		[Reflectable]
		public class DatosGenerales
		{
			public string Tipo_Identidad_Cliente { get; set; } //TipoIdentificacion
			public string Dcto_Identidad_Cliente { get; set; }

			public string Codigo_Dactilar { get; set; }


			//EXTRANJERO
			public string? Tipo_Identidad_Extranjero { get; set; }
			public string? Numero_Pasaporte { get; set; }
			public string? Codigo_SBE { get; set; } //USO FUTURO



			public string? Ciudad_Nacimiento { get; set; } //USO FUTURO


			public string Estado_Cliente { get; set; }
			public string Codigo_Agencia { get; set; } //Cod. Agencia
			public string Ejecutivo_Oficial { get; set; } //Ejecutivo/Oficial
			public string Producto_Captado { get; set; } // 9999
			public string Tipo_Relacion { get; set; }
			public string Tipo_Cliente { get; set; } // TipoCliente

            public string TipEmp_RucEmpresa { get; set; } // TCT129414
            public string TipEmp_Empresa { get; set; }// TCT129414
        }
	}
	[Reflectable]
	public class SPInformacionDirecciones
	{
		public DireccionDomicilio DireccionesDomicilio { get; set; }
		public DireccionClienteOficina DireccionesOficina { get; set; }
	}
	[Reflectable]
	public class SPInformacionLaboral
	{

		public DatosEconomicos Datos_Economicos { get; set; }

		public DatosLaborales Datos_Laborales { get; set; }
		[Reflectable]
		public class DatosEconomicos
		{
			public string Actividad_Economica_No_Economica { get; set; }
		}
		[Reflectable]
		public class DatosLaborales
		{
			public string Relacion_Laboral { get; set; }
			public string Nivel_Estudios { get; set; }
			public string Cargo { get; set; }
			public string Profesion { get; set; }
			public string Origen_Recursos { get; set; }
			public DateTime? Fecha_Ingreso_Laboral_Actual { get; set; }
			public int Tiempo_Actual_Trabajo { get; set; }
			public DateTime? Fecha_Jubilado { get; set; }
			public DateTime? Fecha_Inicio_Negocio { get; set; }
			public string Actividad_Empresa_Donde_Trabaja { get; set; }
		}
	}
	[Reflectable]
	public class SPInformacionFinanciera
	{


		public IngresoPatrimonio Ingreso_Patrimonio { get; set; }
		[Reflectable]
		public class IngresoPatrimonio
		{
			public string Tipo_Estado_Situacion_Financiera { get; set; }
			public string Tiene_Otros_Ingresos_SoN { get; set; }
			public string Indique_Fuente_Otros_Ingresos { get; set; } //USO FUTURO


			public decimal Total_Activos { get; set; }
			public decimal Total_Pasivos { get; set; }
			public decimal Patrimonio { get; set; } //CALCULADOS


			public decimal Ingresos_Mensuales { get; set; }
			public decimal Egresos_Mensuales { get; set; }
			public decimal Otros_Ingresos_Mensuales { get; set; }
			public decimal Total_Ingresos_Mensuales { get; set; } //CALCULADOS
			public decimal Ingreso_Neto_Mensual { get; set; } //CALCULADOS


			public decimal Ventas_Anuales { get; set; }
			//CALCULADOS
			public decimal Ingresos_Anuales { get; set; }
			public decimal Otros_Ingresos_Anuales { get; set; }


			public decimal Total_Ingresos_Anuales { get; set; } //CALCULADOS


			public decimal Egresos_Anuales { get; set; } //CALCULADOS
			public decimal Ingreso_Neto_Anual { get; set; } //CALCULADOS
			public decimal Ingreso_Neto_Mensual_Promedio { get; set; } //CALCULADOS
			public DateTime Fecha_Informacion { get; set; }
			public DateTime Fecha_Ingreso { get; set; }
			public string Usuario { get; set; }
			public string IdentificacionUsuario { get; set; }
			public DateTime Fecha_Sistema { get; set; }
			public DateTime Hora_Sistema { get; set; }
		}

	}
	[Reflectable]
	public class SPInformacionReferencias
	{
		public string Posee_Cuentas_Otros_Bancos_SoN { get; set; }
		public List<RefBancariaIn> Referencias_Bancarias { get; set; }
		public List<RefPersonalesIn> Referencias_Personales { get; set; }
		public List<RefComercialesIn> Referencias_Comerciales { get; set; }
	}

	[Reflectable]
	public class SPInformacionResidenciaExtranjero
	{
		public FatcaCuestionario FATCA_Cuestionario { get; set; }
		public string FATCA { get; set; }
		public FatcaIndicios FATCA_Indicios { get; set; }
		public DatosGeneralesFiscal Datos_Generales { get; set; }
	}
	[Reflectable]
	public class FatcaCuestionario
	{
		public string Pais_Nacionalidad { get; set; }
		public string Tiene_Otra_Nacionalidad_SoN { get; set; } //tiene otra nacionalidad
		public string Indique_otra_Nacionalidad { get; set; }
		public string Pais_Nacimiento_Padres_es_EEUU_SoN { get; set; }
		public string Tiene_Tarjeta_Residencia_Legal_en_EEUU_SoN { get; set; }
		public string Estuvo_al_menos_183_dias_en_EEUU_este_anio_SoN { get; set; }
	}
	[Reflectable]
	public class FatcaIndicios
	{
		//SI ES FATCA
		public string? Direccion_EEUU { get; set; }
		public string? Telefono_EEUU { get; set; }
		public string? GIIN { get; set; }
		public string? TIN { get; set; }
		public string? Social_Security { get; set; }
		public string? Employer_ID_Numero { get; set; } //Numero de identificacion tributaria
	}
	[Reflectable]
	public class DatosGeneralesFiscal
	{
		public string Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador { get; set; }
		public string Seleccione_Pais { get; set; }
		public string Numero_Id_Tributaria { get; set; } //Numero de identificacion tributaria
		public string Direccion_Residencia_Fiscal { get; set; }
	}
	[Reflectable]
	public class SPInformacionAdicional
	{
		public DatosBasicos Datos_Basicos { get; set; }

		public DatosVivienda Datos_Vivienda { get; set; }

		public IngresoInformacionAdicional Ingreso_Informacion_Adicional { get; set; }

		public DatosDeudor Datos_Deudor { get; set; }

		public DatosAuditoria Datos_Auditoria { get; set; }
	}

	[Reflectable]
	public class DatosBasicos
	{
		public string Proposito_Relacion_Comercial { get; set; }
	}
	[Reflectable]
	public class DatosVivienda
	{
		public string Tipo_Vivienda { get; set; }
		public decimal Valor_Vivienda { get; set; }
		public int Tiempo_Residencia_Vivienda_Actual { get; set; }
	}
	[Reflectable]
	public class IngresoInformacionAdicional
	{
		//ELIMINAR
		public decimal? Compra_Divisas { get; set; } //NULL
		public decimal? Venta_Divisas { get; set; } //NULL
		public decimal? Deposito_Efectivo { get; set; } //NULL
		public decimal? Prestamos { get; set; } //NULL
		public decimal? Trans_Enviadas { get; set; } //NULL
		public decimal? Trans_Recibidas { get; set; } //NULL
		public decimal? Inversiones { get; set; } //NULL
		public decimal? Pago_Tarj_Cred { get; set; } //NULL
		public decimal? Inv_Tarj_Cr { get; set; } //NULL
		public decimal? Aper_Ctas_Inte { get; set; } //NULL

		//CALCULADO
		public decimal PTP_Mensual { get; set; }
		public decimal PTP_Mensual_Maximo { get; set; }
		public decimal PMM_Ingresos_Mensuales { get; set; }


		public DateTime? Fecha_Expedicion_Pasaporte { get; set; } //USO FUTURO
		public DateTime? Fecha_Caducidad_Pasaporte { get; set; } //USO FUTURO
		public DateTime? Fecha_Ingreso_Pais { get; set; } //USO FUTURO
		public string? Estado_Migratorio { get; set; } //USO FUTURO
	}
	[Reflectable]
	public class DatosDeudor
	{
		//DATOS DEUDOR
		public DateTime Fecha_Ingreso_Laboral_Anterior { get; set; }
		public DateTime Fecha_Salida_Laboral_Anterior { get; set; }
		public int Tipo_Ingreso_Deudor { get; set; }

		//LLENAR CON DATOS ANTERIORES
		public string Nombre_Conyuge { get; set; }
		public string Tipo_Documento_Conyuge { get; set; }
		public string Identificacion_Conyuge { get; set; }
		//LLENAR CON DATOS ANTERIORES END 

		public string Profesion_Conyuge { get; set; }
		public string Direccion_Oficina { get; set; }
		public string Telefono { get; set; }
		public string Situacion_Bienes { get; set; }
	}
	[Reflectable]
	public class DatosAuditoria
	{
		//CREACION
		public string ProgramaCreacion { get; set; }
		public string UsuarioCreacion { get; set; }
		public string EstacionCreacion { get; set; }
		public string IPCreacion { get; set; }
		public DateTime FechaCreacion { get; set; }
		public DateTime HoraCreacion { get; set; }
		//ULTIMA ACTUALIZACION 
		public string ProgramaUltima { get; set; }
		public string UsuarioUltima { get; set; }
		public string EstacionUltima { get; set; }
		public string IPUltima { get; set; }
		public DateTime FechaUltima { get; set; }
		public DateTime HoraUltima { get; set; }
		//PENULTIMA ACTUALIZACION
		public string ProgramaPenultima { get; set; }
		public string UsuarioPenultima { get; set; }
		public string EstacionPenultima { get; set; }
		public string IPPenultima { get; set; }
		public DateTime FechaPenultima { get; set; }
		public DateTime HoraPenultima { get; set; }
	}

	[Reflectable]
	public class Conyuge
	{
		public string Tipo_Identificacion_Conyuge { get; set; }
		public string Identificacion_Conyuge { get; set; }
		//public string Identificacion_Extranjero_Conyuge { get; set; }
		public string Nombres_Apellidos_Conyuge { get; set; }
		
	}
	[Reflectable]
	public class DireccionDomicilio
	{
		public string Provincia { get; set; }
		public string Canton { get; set; }
		public string Parroquia { get; set; }
		public string Direccion { get; set; }
		public string Referencia { get; set; }
		//ELIMINAR
		public string? Ciudad { get; set; } //NULL
		public string? Fax { get; set; } //NULL	

		//TELEFONO
		public string Codigo_Internacional { get; set; }
		public string Codigo_Area { get; set; }
		public string? Telefono { get; set; }
		public string? Celular { get; set; }
		//EMAIL
		public string Correo_Electronico1 { get; set; }
		public string Correo_Electronico2 { get; set; }

		public int Direccion_General { get; set; } // 1 o 0
		public int Envio_Correspondencia { get; set; } // 1 o 0
	}
	[Reflectable]
	public class DireccionClienteOficina
	{
		public string Provincia { get; set; }
		public string Canton { get; set; }
		public string Parroquia { get; set; }
		public string Direccion { get; set; }
		public string Referencia { get; set; }
		//ELIMINAR
		public string? Ciudad { get; set; } //NULL
											//ELIMINAR
		public string? Fax { get; set; } //NULL
										 //TELEFONO
		public string Codigo_Internacional { get; set; }
		public string Codigo_Area { get; set; }
		public string? Telefono { get; set; }
		public string? Celular { get; set; }
		

		//EMAIL
		public string Correo_Electronico1 { get; set; }
		public string Correo_Electronico2 { get; set; }
	}
	[Coded("REFCOM")]
	public class RefComercialesIn
	{
		public string AccionCRUD { get; set; }
		public string NumeroSecuencia { get; set; }

		public string NombreEstablecimiemto { get; set; }

		public string TipoTelefono { get; set; }

		public string NumeroTelefono { get; set; }

		public string ArticuloAdquirido { get; set; }

		public int AniAdquisicion { get; set; }

		public decimal MontoAdquisicion { get; set; }

		public string FormaPago { get; set; }
	}
	[Coded("REFPER")]
	public class RefPersonalesIn
	{
		public string AccionCRUD { get; set; }
		public string NumeroSecuencia { get; set; }

		public string NombresApellidos { get; set; }

		public string Parentesco { get; set; }

		public string Direccion { get; set; }

		public string TipoTelefono { get; set; }

		public string Telefono { get; set; }
	}
	[Coded("REFBAN")]
	public class RefBancariaIn
	{
		public string AccionCRUD { get; set; }
		public string NumeroSecuencia { get; set; }

		public string TipoEntidadFinanciera { get; set; }

		public string InstitucionFinanciera { get; set; }

		public string TipoProducto { get; set; }

		public string NumeroTarjeta { get; set; }
	}

	[Reflectable]
	public class SPDatosAhorroProgramado {
		public List<CuentaActivaAhorroProgramado> ListaCuentasActivasAhorroProgramado { get; set; }
		public List<CuentaCliente> ListaCuentasCliente { get; set; }
		public List<DatosContratoExt> ListaDatosContrato { get; set; }
		public List<CatalogoAhorroProgramado> ListaCatalogo { get; set; }
		public SimuladorContrato SimuladorContrato { get; set; }
		public List<Plazos> Plazos { get; set; }
	}
}
