﻿using System;
using System.Collections.Generic;
using static icCommon.Utils.ObjectReflection;

namespace icParametrizacionDinamica.DTOs.EXT
{

    public class DatosContrato
    {
        public string AccionCRUD { get; set; }
        public Decimal contrato { get; set; }
        public string CiudadAgencia { get; set; }
        public string TipoDocumento { get; set; }
        public Decimal Documento { get; set; }
        public string Cliente { get; set; }
        public String CodigoProducto { get; set; }
        public string DescripcionProducto { get; set; }
        public string TipoCtaDebito { get; set; }
        public Decimal CuentaDebito { get; set; }
        public string NombreCuentaDebito { get; set; }
        public string TipoCtaAhorro { get; set; }
        public Decimal CuentaAhorro { get; set; }
        public string CanalApertura { get; set; }
        public string DescCanalApertura { get; set; }
        public Decimal FechaApertura { get; set; }
        public Decimal HoraApertura { get; set; }
        public Decimal FechaVencimiento { get; set; }
        public string MetaAhorro { get; set; }
        public string MotivoAhorro { get; set; }
        public Decimal MontoAhorro { get; set; }
        public Decimal MontoInicial { get; set; }
        public Decimal MontoMeta { get; set; }
        public Decimal DiaDebito { get; set; }
        public Decimal FechaProximoDebito { get; set; }
        public string CodigoOficial { get; set; }
        public string Oficial { get; set; }
        public string CargoOficial { get; set; }
        //public Decimal ValorAhorro { get; set; }
        public Decimal Plazo { get; set; }
        public Decimal TasaApertura { get; set; }
        public string FormaDebito { get; set; }
        public string AplicaReintento { get; set; }
        public string RenovacionAutomatica { get; set; }
        public string FormaRenovacion { get; set; }
        public Decimal FechaULTRenovacion { get; set; }
        public Decimal CantidadRenovacion { get; set; }
        public Decimal MontoDebitoAhorro { get; set; }
        public Decimal MontoBloqueo { get; set; }
        public Decimal MontoTotalAhorro { get; set; }
        public Decimal InteresGanado { get; set; }
        public string ContratoRenovado { get; set; }
    }

    [Coded("CON_AHR_AP")]
    public class DatosContratoExt
    {
        public string AccionCRUD { get; set; }
        public Decimal contrato { get; set; }
        public string CiudadAgencia { get; set; }
        public string TipoDocumento { get; set; }
        public Decimal Documento { get; set; }
        public string Cliente { get; set; }
        public String CodigoProducto { get; set; }
        public string DescripcionProducto { get; set; }
        public string TipoCtaDebito { get; set; }
        public Decimal CuentaDebito { get; set; }
        public string NombreCuentaDebito { get; set; }
        public string TipoCtaAhorro { get; set; }
        public Decimal CuentaAhorro { get; set; }
        public string CanalApertura { get; set; }
        public string DescCanalApertura { get; set; }
        public string FechaApertura { get; set; }
        public Decimal HoraApertura { get; set; }
        public string FechaVencimiento { get; set; }
        public string MetaAhorro { get; set; }
        public string MotivoAhorro { get; set; }
        public Decimal MontoAhorro { get; set; }
        public Decimal MontoInicial { get; set; }
        public Decimal MontoMeta { get; set; }
        public Decimal DiaDebito { get; set; }
        public string FechaProximoDebito { get; set; }
        public string CodigoOficial { get; set; }
        public string Oficial { get; set; }
        public string CargoOficial { get; set; }
        public Decimal Plazo { get; set; }
        public Decimal TasaApertura { get; set; }
        public string FormaDebito { get; set; }
        public string AplicaReintento { get; set; }
        public string RenovacionAutomatica { get; set; }
        public string FormaRenovacion { get; set; }
        public string FechaULTRenovacion { get; set; }
        public Decimal CantidadRenovacion { get; set; }
        public Decimal MontoDebitoAhorro { get; set; }
        public Decimal MontoBloqueo { get; set; }
        public Decimal MontoTotalAhorro { get; set; }
        public Decimal InteresGanado { get; set; }
        public string ContratoRenovado { get; set; }
    }

    public class AhorroProcesado
    {
        public Decimal Referencia { get; set; }
        public Decimal ReferenciaOrigen { get; set; }
        public Decimal CuentaDebito { get; set; }
        public Decimal CuentaAhorro { get; set; }
        public string TipoDebito { get; set; }
        public Decimal MontoDebitar { get; set; }
        public Decimal MontoDebitado { get; set; }
        public Decimal FechaDebito { get; set; }
        public Decimal HoraDebito { get; set; }
        public Decimal NumeroInterno { get; set; }
        public string Canal { get; set; }
    }

    public class AhorroFallido : AhorroProcesado
    {
        public string Motivo { get; set; }
    }

    [Reflectable]
    [Coded("CTAAHPR")]
    public class CuentaActivaAhorroProgramado
    {
        public decimal Agencia { get; set; }
        public string Cuenta { get; set; }
        public string Producto { get; set; }
        public string TipoCuenta { get; set; }
        public string Oficial { get; set; }
        public string NombreOficial { get; set; }

        public Parametros Parametros { get; set; }
        public List<TasaPorRango> listaTasaPorRango { get; set; }
    }

    [Reflectable]
    [Coded("PLZAP")]
    public class Plazos
    {
        public string Id { get; set; }
        public string Descripcion { get; set; }
    }

    [Reflectable]
    public class SimulacionCancelacionAP
    {
        public decimal ContratoS { get; set; }
        public int Agencia { get; set; }
        public decimal MontoAhorrado { get; set; }
        public decimal TasaAperturaS { get; set; }
        public decimal InteresGanadoS { get; set; }
        public decimal TasaReal { get; set; }
        public decimal InteresReal { get; set; }
        public decimal CuentaAhorros { get; set; }
    }

    public class CatalogoAhorroProgramado
    {
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
    }

    public class CancelarContrato
    {
        public Decimal contrato { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }
        public Decimal CuentaAhorro { get; set; }
        public string Canal { get; set; }
        public string CodigoOficial { get; set; }
        public string MotivoCancelacion { get; set; }
        public decimal DepositoInicial { get; set; }
        public decimal MetaAhorro { get; set; }
        public decimal MontoAhorrado { get; set; }
        public decimal InteresReal { get; set; }
        public decimal MontoMeta { get; set; }
        public string UserAS { get; set; }
        public string CorreoElectronico { get; set; }
    }

    public class Parametros
    {
        public string FormaDebito { get; set; }
        public string AplicaRedondeo { get; set; }
        public string AplicaReintento { get; set; }
        public string Renovacion { get; set; }
        public Decimal MontoMinimo { get; set; }
        public Decimal MontoMaximo { get; set; }
        public string FrecuenciaDebito { get; set; }
        public Decimal PeriodoMaximoAhorro { get; set; }
    }

    public class TasaPorRango
    {
        public Decimal MesInicio { get; set; }
        public Decimal MesFin { get; set; }
        public Decimal Tasa { get; set; }
    }

    [Reflectable]
    public class SimuladorContrato
    {
        public string Producto { get; set; }
        public string CodigoMotivoAhorro { get; set; }
        public string MotivoAhorro { get; set; }
        public string MetaAhorro { get; set; }
        public string DepositoInicial { get; set; }
        public string MontoAhorro { get; set; }
        public string DiaDebito { get; set; }
        public string Plazo { get; set; }
        public string CuentaAhorro { get; set; }
        public string CuentaDebito { get; set; }
        public string Correo_Electronico1 { get; set; }
        public string FechaVcto { get; set; }
    }

    public class SolicitarContrato
    {
        public int CodAgencia { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }
        public decimal CuentaDebitar { get; set; }
        public decimal CuentaAhorro { get; set; }
        public string Canal { get; set; }
        public decimal Servicio { get; set; }
        public decimal MontoMeta { get; set; }
        public decimal CuotaAhorro { get; set; }
        public string CodMetaAhorro { get; set; }
        public string MotivoAhorro { get; set; }
        public string Oficial { get; set; }
        public decimal Plazo2 { get; set; }
        public decimal DepositoInicial { get; set; }
        public decimal DiaDebito { get; set; }
        public string UserAS { get; set; }
        public string CorreoElectronico { get; set; }
    }

    public class SolicitarContratoA
    {
        public int CodAgencia { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }
        public decimal CuentaDebitar { get; set; }
        public decimal CuentaAhorro { get; set; }
        public string Canal { get; set; }
        public decimal Servicio { get; set; }
        public string CodMetaAhorro { get; set; }
        public string MotivoAhorro { get; set; }
        public string Oficial { get; set; }
        public decimal Plazo { get; set; }
        public decimal DiaDebito { get; set; }
        public string UserAS { get; set; }
        public string CorreoElectronico { get; set; }
    }

    public class CuentaCliente {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public string NombreCliente { get; set; }
        public string Cuenta { get; set; }
        public string Producto { get; set; }
        public string DscProducto { get; set; }
    }

    public class MonitorBalconRequestBody
    {
        public string CodigoProceso { get; set; }
        public string fecha { get; set; }
        public string Hora { get; set; }
        public string CodigoEvento { get; set; }
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public string Cuenta { get; set; }
        public string Oficial { get; set; }
        public string Agencia { get; set; }
        public string? Referencia { get; set; }
        public string Contrato { get; set; }
        public string Canal { get; set; }
        public string? TarjetaCredito { get; set; }
        public string TipoProducto { get; set; }
        public string Producto { get; set; }
        public string SubProducto { get; set; }
        public decimal? ValorTransaccion1 { get; set; }
        public decimal? ValorTransaccion2 { get; set; }
        public decimal? ValorTransaccion3 { get; set; }
        public string? Trama { get; set; }
        public string? TramaJSON { get; set; }
    }

    public class SecuencialAhorroProgramado
    {
        public string Identificacion { get; set; }
    }
	
	public class DatosActualizacionContrato
    {
        public decimal TasaApertura { get; set; }
        public decimal InteresGanado { get; set; }
        public decimal MontoAhorrado { get; set; }
        public decimal FechaFin { get; set; }
    }
}
