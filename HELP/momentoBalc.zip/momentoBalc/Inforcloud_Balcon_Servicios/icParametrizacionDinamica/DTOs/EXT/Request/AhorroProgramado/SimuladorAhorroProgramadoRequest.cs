﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado
{
    public class SimuladorAhorroProgramadoRequest : ApiExternoRequest<SimuladorAhorroProgramadoRequest>
    {
        public string Producto { get; set; }
        public decimal MetaAhorro { get; set; }
        public decimal DepositoInicial { get; set; }
        public decimal MontoAhorro { get; set; }
        public int DiaDebito { get; set; }
        public int Plazo { get; set; }
    }
}
