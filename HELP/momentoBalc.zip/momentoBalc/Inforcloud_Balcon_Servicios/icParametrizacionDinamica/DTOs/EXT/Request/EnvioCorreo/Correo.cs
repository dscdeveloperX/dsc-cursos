﻿using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.EnvioCorreo
{
    public class Correo
    {
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string Asunto { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string Body { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string CanalEnvia { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public int CodigoProceso { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string ConCopia { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string Destinatario { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string IsHtml { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public int NumeroReitento { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string Remitente { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string RutaAdjunto { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string UsuarioNotifica { get; set; }
        [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
        public string UsuarioProceso { get; set; }
    }
}
