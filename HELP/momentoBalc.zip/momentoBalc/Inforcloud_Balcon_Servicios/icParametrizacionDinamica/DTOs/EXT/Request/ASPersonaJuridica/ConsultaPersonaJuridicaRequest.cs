﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaJuridica
{
    public class ConsultaPersonaJuridicaRequest : ApiExternoRequest<ConsultaPersonaJuridicaRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaPersonaJuridicaRequestBody BodyRequest { get; set; }
    }
    public class ConsultaPersonaJuridicaRequestBody
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
    }
}
