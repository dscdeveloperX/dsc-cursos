﻿using System;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASContactabilidad
{
    public class HeaderRequest
    {
        public string UserName { get; set; }
        public string StationIp { get; set; }
        public DateTime DateTime { get; set; }
    }
}
