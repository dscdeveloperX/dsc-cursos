﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaNatural
{
    public class EdicionPersonaNaturalFallecidoRequest : ApiExternoRequest<EdicionPersonaNaturalFallecidoRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionPersonaNaturalFallecidoRequestBody BodyRequest { get; set; }
    }
    public class EdicionPersonaNaturalFallecidoRequestBody
    {
        public DatosPersonaNaturalFallecido DatosPersona { get; set; }
    }
}
