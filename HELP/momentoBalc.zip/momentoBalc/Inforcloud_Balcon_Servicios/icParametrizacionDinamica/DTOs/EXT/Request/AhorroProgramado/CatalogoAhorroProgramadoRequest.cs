﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado {
    public class CatalogoAhorroProgramadoRequest : ApiExternoRequest<CatalogoAhorroProgramadoRequest> {
        public string Argumento { get; set; }
        public int Tabla { get; set; }
    }
}
