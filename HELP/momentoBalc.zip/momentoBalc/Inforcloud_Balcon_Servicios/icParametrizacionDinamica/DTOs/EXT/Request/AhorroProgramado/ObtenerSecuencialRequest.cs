﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado
{
    public class ObtenerSecuencialRequest : ApiExternoRequest<ObtenerSecuencialRequest>
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public string Usuario { get; set; }
        public string PuntoAcceso { get; set; }
    }
}
