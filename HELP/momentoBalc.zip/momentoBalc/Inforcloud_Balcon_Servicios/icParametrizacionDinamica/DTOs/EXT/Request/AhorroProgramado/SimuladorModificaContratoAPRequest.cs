﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado
{
    public class SimuladorModificaContratoAPRequest : ApiExternoRequest<SimuladorModificaContratoAPRequest>
    {
        public decimal Contrato { get; set; }
        public decimal Plazo { get; set; }
        public decimal Monto { get; set; }
    }
}