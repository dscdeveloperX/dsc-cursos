﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.EnvioCorreo
{
    public class EnvioInternoRequest
    {
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<EnvioInternoRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }
		}

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public EnvioInterno EnvioInterno { get; set; }
		}

		public class EnvioInterno
		{
			[XmlElement(elementName: Constantes.ElementTag.Correo, Namespace = Constantes.XmlNamespace.Tem)]
			public Correo Correo { get; set; }
		}
	}
}
