﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaJuridica
{
    public class EdicionPersonaJuridicaRequest : ApiExternoRequest<EdicionPersonaJuridicaRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionPersonaJuridicaRequestBody BodyRequest { get; set; }
    }
    public class EdicionPersonaJuridicaRequestBody
    {
        public DatosPersonaJuridica DatosPersona { get; set; }
    }
}
