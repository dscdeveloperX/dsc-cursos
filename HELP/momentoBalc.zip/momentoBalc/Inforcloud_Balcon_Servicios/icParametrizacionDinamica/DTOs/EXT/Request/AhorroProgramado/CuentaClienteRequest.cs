﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado {
    public class CuentaClienteRequest : ApiExternoRequest<CuentaClienteRequest> {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }

    }
}
