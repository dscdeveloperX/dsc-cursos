﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.PersonaService
{
    public class ConsultarDatosRegistroCivilCedulaRequest
    {
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<ConsultarDatosRegistroCivilCedulaRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }
		}

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public ConsultarDatosRegistroCivilNacional ConsultarDatosRegistroCivilCedula { get; set; }
		}

		public class ConsultarDatosRegistroCivilNacional
		{
			[XmlElement(elementName: Constantes.ElementTag.Datos, Namespace = Constantes.XmlNamespace.Tem)]
			public DatosRegistroCivil Datos { get; set; }
		}

		public class DatosRegistroCivil
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string NutCliente { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string PuntoAcceso { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string TipoPuntoAcceso { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string Usuario { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm1)]
			public string Canal { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm1)]
			public string Identificacion { get; set; }
		}
	}
}
