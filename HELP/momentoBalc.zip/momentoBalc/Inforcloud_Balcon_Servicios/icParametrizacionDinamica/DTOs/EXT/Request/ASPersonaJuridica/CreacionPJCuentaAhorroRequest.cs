﻿using icCommon.DTOs.EXT;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaJuridica
{
	public class CreacionPJCuentaAhorroRequest : ApiExternoRequest<CreacionPJCuentaAhorroRequest>
	{
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionPJCuentaAhorroRequestBody BodyRequest { get; set; }
    }
    public class CreacionPJCuentaAhorroRequestBody
    {
        public DatosCuentaAhorro DatosCuenta { get; set; }
    }
}
