﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASContactabilidad
{
    public class EdicionContactabilidadRequest : ApiExternoRequest<EdicionContactabilidadRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionContactabilidadRequestBody BodyRequest { get; set; }
    }
    public class EdicionContactabilidadRequestBody
    {
        public Contactabilidad Contactabilidad { get; set; }
    }
}
