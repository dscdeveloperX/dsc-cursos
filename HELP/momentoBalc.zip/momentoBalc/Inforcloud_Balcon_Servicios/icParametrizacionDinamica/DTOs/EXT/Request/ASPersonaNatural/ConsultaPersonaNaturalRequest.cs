﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaNatural
{
	public class ConsultaPersonaNaturalRequest : ApiExternoRequest<ConsultaPersonaNaturalRequest>
	{
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaPersonaNaturalRequestBody BodyRequest { get; set; }
    }
    public class ConsultaPersonaNaturalRequestBody
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
    }
}
