﻿using icCommon.DTOs.EXT;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaNatural
{
	public class CreacionPNCuentaAhorroRequest : ApiExternoRequest<CreacionPNCuentaAhorroRequest>
	{
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionPNCuentaAhorroRequestBody BodyRequest { get; set; }
    }
    public class CreacionPNCuentaAhorroRequestBody
    {
        public DatosCuentaAhorro DatosCuenta { get; set; }
    }
}
