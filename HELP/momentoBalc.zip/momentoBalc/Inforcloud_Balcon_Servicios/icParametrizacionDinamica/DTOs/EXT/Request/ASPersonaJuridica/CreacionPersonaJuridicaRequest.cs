﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaJuridica
{
    public class CreacionPersonaJuridicaRequest : ApiExternoRequest<CreacionPersonaJuridicaRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionPersonaJuridicaRequestBody BodyRequest { get; set; }
    }
    public class CreacionPersonaJuridicaRequestBody
    {
        public DatosPersonaJuridica DatosPersona { get; set; }
    }
}
