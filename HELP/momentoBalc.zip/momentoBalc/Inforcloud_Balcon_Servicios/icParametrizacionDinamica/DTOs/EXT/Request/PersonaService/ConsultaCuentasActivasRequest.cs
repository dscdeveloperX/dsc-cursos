﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.PersonaService
{
    public class ConsultaCuentasActivasRequest : ApiExternoRequest<ConsultaCuentasActivasRequest>
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
    }
}
