﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado
{
    public class SolicitarContratoRequest : ApiExternoRequest<SolicitarContratoRequest>
    {
        public int CodAgencia { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }

        public decimal CuentaDebitar { get; set; }
        public decimal CuentaAhorro { get; set; }
        public string Canal { get; set; }
        public decimal Servicio { get; set; }
        public decimal MontoMeta { get; set; }
        public decimal CuotaAhorro { get; set; }
        public string CodMetaAhorro { get; set; }
        public string MotivoAhorro { get; set; }
        public string Oficial { get; set; }
        public decimal Plazo { get; set; }
        public decimal DepositoInicial { get; set; }
        public decimal DiaDebito { get; set; }
        public string UserAS { get; set; }
        public string CorreoElectronico { get; set; }
    }
}
