﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.EnvioCorreo
{
    public class EnvioExternoRequest
    {
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<EnvioExternoRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }
		}

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public EnvioExterno EnvioExterno { get; set; }
		}

		public class EnvioExterno
		{
			[XmlElement(elementName: Constantes.ElementTag.Correo, Namespace = Constantes.XmlNamespace.Tem)]
			public Correo Correo { get; set; }
		}
	}
}
