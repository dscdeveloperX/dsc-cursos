﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaNatural
{
    public class EdicionPersonaNaturalRequest : ApiExternoRequest<EdicionPersonaNaturalRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public EdicionPersonaNaturalRequestBody BodyRequest { get; set; }
    }
    public class EdicionPersonaNaturalRequestBody
    {
        public DatosPersonaNatural DatosPersona { get; set; }
    }
}
