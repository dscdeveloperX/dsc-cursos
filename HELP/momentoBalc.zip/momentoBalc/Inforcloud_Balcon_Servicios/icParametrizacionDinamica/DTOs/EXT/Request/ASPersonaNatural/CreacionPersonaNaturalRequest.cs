﻿using icCommon.DTOs.EXT;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaNatural
{
	public class CreacionPersonaNaturalRequest : ApiExternoRequest<CreacionPersonaNaturalRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionPersonaNaturalRequestBody BodyRequest { get; set; }
    }
    public class CreacionPersonaNaturalRequestBody
    {
        public DatosPersonaNatural DatosPersona { get; set; }
    }
}
