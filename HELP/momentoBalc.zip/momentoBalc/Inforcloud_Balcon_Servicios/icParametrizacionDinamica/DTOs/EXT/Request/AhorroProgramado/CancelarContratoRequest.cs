﻿using icCommon.DTOs.EXT;
using System;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado
{

    public class CancelarContratoRequest : ApiExternoRequest<CancelarContratoRequest> {
        public decimal Contrato { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }
        public Decimal Cuenta { get; set; }
        public string Canal { get; set; }
        public string Oficial { get; set; }
        public string MotivoCancelacion { get; set; }
        public string UserAS { get; set; }
        public string CorreoElectronico { get; set; }
    }
}
