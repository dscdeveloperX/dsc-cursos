﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado {
    public class ValidaCuentaRequest: ApiExternoRequest<ValidaCuentaRequest>  {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public decimal Cuenta { get; set; }
    }
}
