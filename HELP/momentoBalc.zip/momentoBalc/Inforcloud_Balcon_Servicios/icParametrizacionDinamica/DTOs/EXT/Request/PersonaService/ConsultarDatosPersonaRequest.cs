﻿using icCommon.DTOs.EXT;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Request.PersonaService
{
    public class ConsultarDatosPersonaRequest 
	{
		[XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
		public class Envelope : ApiExternoRequest<ConsultarDatosPersonaRequest.Envelope>
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Header Header { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
			public Body Body { get; set; }
        }

		public class Header
		{

		}

		public class Body
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
			public ConsultarDatosPersona ConsultarDatosPersona { get; set; }
		}

		public class ConsultarDatosPersona
		{
			[XmlElement(elementName: Constantes.ElementTag.Datos, Namespace = Constantes.XmlNamespace.Tem)]
			public DatosPersona Datos { get; set; }
		}

		public class DatosPersona
		{
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string NutCliente { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string PuntoAcceso { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string TipoPuntoAcceso { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
			public string Usuario { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm1)]
			public string TipoIdentificacion { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm1)]
			public string Identificacion { get; set; }
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm1)]
			public int ConsultarFATCA { get; set; } //1 o 0
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm1)]
			public int ConsultarPEPS { get; set; }//1 o 0
			[XmlElement(Namespace = Constantes.XmlNamespace.Bm1)]
			public int ConsultarListasNegras { get; set; }//1 o 0
		}
	}
}
