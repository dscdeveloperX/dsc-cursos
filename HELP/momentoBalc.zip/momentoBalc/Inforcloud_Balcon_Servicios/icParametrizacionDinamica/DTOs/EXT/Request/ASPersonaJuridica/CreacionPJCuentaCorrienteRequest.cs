﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaJuridica
{
    public class CreacionPJCuentaCorrienteRequest : ApiExternoRequest<CreacionPJCuentaCorrienteRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionPJCuentaCorrienteRequestBody BodyRequest { get; set; }
    }
    public class CreacionPJCuentaCorrienteRequestBody
    {
        public DatosCuentaCorriente DatosCuenta { get; set; }
    }
}
