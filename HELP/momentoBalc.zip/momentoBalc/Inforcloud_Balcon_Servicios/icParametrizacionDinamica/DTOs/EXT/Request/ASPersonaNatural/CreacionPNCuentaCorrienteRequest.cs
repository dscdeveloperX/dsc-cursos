﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaNatural
{
    public class CreacionPNCuentaCorrienteRequest : ApiExternoRequest<CreacionPNCuentaCorrienteRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public CreacionPNCuentaCorrienteRequestBody BodyRequest { get; set; }
    }
    public class CreacionPNCuentaCorrienteRequestBody
    {
        public DatosCuentaCorriente DatosCuenta { get; set; }
    }
}
