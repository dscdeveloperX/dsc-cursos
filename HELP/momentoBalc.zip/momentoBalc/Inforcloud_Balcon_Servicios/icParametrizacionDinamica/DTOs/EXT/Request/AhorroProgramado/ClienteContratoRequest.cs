﻿using icCommon.DTOs.EXT;
using System;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado {
    public class ClienteContratoRequest : ApiExternoRequest<ClienteContratoRequest> { 
        public string Contrato { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }
        public Decimal Cuenta { get; set; }
    }
        
}
