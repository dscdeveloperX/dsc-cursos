﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado
{
    public class PlazosRequest : ApiExternoRequest<PlazosRequest>
    {
        public decimal TipoProducto { get; set; }
        public decimal Producto { get; set; }
        public decimal SubProducto { get; set; }
    }
}
