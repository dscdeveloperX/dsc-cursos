﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.ASContactabilidad
{
    public class ConsultaContactabilidadRequest : ApiExternoRequest<ConsultaContactabilidadRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaContactabilidadRequestBody BodyRequest { get; set; }
    }
    public class ConsultaContactabilidadRequestBody
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
    }
}
