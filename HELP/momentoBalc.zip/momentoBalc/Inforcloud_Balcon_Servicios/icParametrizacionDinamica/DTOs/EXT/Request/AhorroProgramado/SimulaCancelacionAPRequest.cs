﻿using icCommon.DTOs.EXT;

namespace icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado {
    public class SimulaCancelacionAPRequest : ApiExternoRequest<SimulaCancelacionAPRequest> {
        public decimal Contrato { get; set; }
    }
}
