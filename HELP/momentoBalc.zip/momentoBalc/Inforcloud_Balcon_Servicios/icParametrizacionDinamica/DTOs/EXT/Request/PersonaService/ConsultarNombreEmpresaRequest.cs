﻿using icCommon.DTOs.EXT;
using icParametrizacionDinamica.DTOs.API.Request;

namespace icParametrizacionDinamica.DTOs.EXT.Request.PersonaService
{
    public class ConsultarNombreEmpresaRequest : ApiExternoRequest<ConsultarNombreEmpresaRequest>
    {
        public HeaderRequest HeaderRequest { get; set; }
        public ConsultaNombreEmpresaRequestBody BodyRequest { get; set; }
    }
    public class ConsultaNombreEmpresaRequestBody
    {
        public string RucEmpresa { get; set; }
    }
}
