﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.EXT
{
    public class Contactabilidad
    {
        public string Tipo_Identidad_Cliente { get; set; }
        public string Dcto_Identidad_Cliente { get; set; }
        public string Nombre_Cliente { get; set; }
        public List<ContactClienteIn> ContactClientes { get; set; }
    }

    public class ContactClienteIn
    {
        public string AccionCRUD { get; set; }
        public string NumeroSecuencia { get; set; }
        public string Tipo_Identidad { get; set; }
        public string Numero_Identidad { get; set; }
        public string Nombre { get; set; }
        public string Celular { get; set; }
        public string Correo_Electronico { get; set; }
        public string Direccion_Oficina { get; set; }
        public int Tiempo_Actual_Trabajo { get; set; }
        public string Direccion_Domicilio { get; set; }
        public decimal Ingresos_Mensuales { get; set; }
        public decimal Egresos_Mensuales { get; set; }
    }
}
