﻿using icCommon.DTOs.EXT;
using System.Collections.Generic;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado {
    public class SimuladorModificaContratoAPResponse : ApiExternoResponse<SimuladorModificaContratoAPResponse> {
        public DatosActualizacionContrato SimulacionActualizacion { get; set; }
        public int CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }
        public SimuladorModificaContratoAPResponse() {
            this.SimulacionActualizacion = new DatosActualizacionContrato();
            this.CodigoRetorno = new int();
        }

        public override SimuladorModificaContratoAPResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }

}
