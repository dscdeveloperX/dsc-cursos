﻿using icCommon.DTOs.EXT;
using icCommon.Utils;
using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.PersonaService
{
    public class ConsultarDatosPersonaResponse
    {
        [XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ConsultarDatosPersonaResponseDto ConsultarDatosPersonaResponseDto { get; set; }
        }
        public class ConsultarDatosPersonaResponseDto : ApiExternoResponse<ConsultarDatosPersonaResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ConsultarDatosPersonaResult ConsultarDatosPersonaResult { get; set; }
            public MensajeAuth Mensaje { get; set; }

            public override ConsultarDatosPersonaResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList consultaResponse = soap.GetElementsByTagName("ConsultarDatosPersonaResponseDto", Constantes.XmlNamespace.Tem);

                if (consultaResponse.Count > 0)
                {
                    XmlNode consultaNode = consultaResponse.Item(0);
                    string xmlInput = SerializadorXmlSoap.ObtenerXMLLimpio(consultaNode);

                    ConsultarDatosPersonaResult respuestaExterno = SerializadorXmlSoap.DeserializarObjeto<ConsultarDatosPersonaResult>(xmlInput);

                    return new ConsultarDatosPersonaResponseDto
                    {
                        ConsultarDatosPersonaResult = respuestaExterno,
                        Mensaje = new MensajeAuth()
                    };
                }
                else
                {
                    return new ConsultarDatosPersonaResponseDto
                    {
                        Mensaje = new MensajeAuth(soap)
                    };
                }
            }
        }

        public class ConsultarDatosPersonaResult
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public bool EsCliente { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string TipoPersona { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string TipoIdentificacion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Identificacion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Nombres { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string PaisOrigen { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string LugarNacimiento { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public DateTime FechaNacimiento { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Genero { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string EstadoCivil { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public Conyuge Conyuge { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public int CargasFamiliares { get; set; }
            [XmlArray("Direcciones",Namespace = Constantes.XmlNamespace.Bm)]
            [XmlArrayItem("DireccionCliente", Namespace = Constantes.XmlNamespace.Bm)]
            public List<DireccionCliente> Direcciones { get; set; }
            [XmlArray("Telefonos", Namespace = Constantes.XmlNamespace.Bm)]
            [XmlArrayItem("TelefonoCliente", Namespace = Constantes.XmlNamespace.Bm)]
            public List<TelefonoCliente> Telefonos { get; set; }
            [XmlArray("CorreosElectronicos", Namespace = Constantes.XmlNamespace.Bm)]
            [XmlArrayItem("CorreosCliente", Namespace = Constantes.XmlNamespace.Bm)]
            public List<CorreosCliente> CorreosCliente { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public int NivelEstudios { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string RelacionLaboral { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Cargo { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public int CodigoAgenciaApertura { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string AgenciaApertura { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string TipoRelacion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public OficialCredito OficialCredito { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public bool EsFatca { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public bool DocumentacionFatca { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public bool EsPEPS { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public bool EnListasNegras { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public bool Vinculado { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public DateTime FechaIngreso { get; set; }

        }

        public class OficialCredito {
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Codigo { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Usuario { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Nombres { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Correo { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public int CodigoAgencia { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public int DescripcionAgencia { get; set; }
        }

        public class CorreosCliente { 
            public string Correo1 { get; set; }
            public string Correo2 { get; set; }
        }

        public class DireccionCliente { 
            public string Provincia { get; set; }
            public string Canton { get; set; }
            public string Parroquia { get; set; }
            public string Ciudad { get; set; }
            public string Direccion { get; set; }
            public string Referencia { get; set; }
        }

        public class TelefonoCliente
        {
            public string FAX { get; set; }
            public string Convencional { get; set; }
            public string Movil { get; set; }
        }

        public class Conyuge {
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string TipoIdentificacion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Identificacion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Bm)]
            public string Nombres { get; set; }
        }
    }
}
