﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural
{
    public class CreacionPersonaNaturalResponse : ApiExternoResponse<CreacionPersonaNaturalResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public CreacionPersonaNaturalResponseBody BodyResponse { get; set; }

        public CreacionPersonaNaturalResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionPersonaNaturalResponseBody();
        }

        public override CreacionPersonaNaturalResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class CreacionPersonaNaturalResponseBody
    {
        public bool Creado { get; set; }
        public CreacionPersonaNaturalResponseBody()
        {
            this.Creado = false;
        }
    }
}
