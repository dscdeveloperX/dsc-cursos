﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural
{
    public class CreacionPNCuentaCorrienteResponse : ApiExternoResponse<CreacionPNCuentaCorrienteResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public CreacionPNCuentaCorrienteResponseBody BodyResponse { get; set; }

        public CreacionPNCuentaCorrienteResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionPNCuentaCorrienteResponseBody();
        }

        public override CreacionPNCuentaCorrienteResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class CreacionPNCuentaCorrienteResponseBody
    {
        public string Prefijo { get; set; }
        public string Cuenta { get; set; }
    }
}
