﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica
{
    public class CreacionPJCuentaCorrienteResponse : ApiExternoResponse<CreacionPJCuentaCorrienteResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public CreacionPJCuentaCorrienteResponseBody BodyResponse { get; set; }

        public CreacionPJCuentaCorrienteResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionPJCuentaCorrienteResponseBody();
        }

        public override CreacionPJCuentaCorrienteResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class CreacionPJCuentaCorrienteResponseBody
    {
        public string Prefijo { get; set; }
        public string Cuenta { get; set; }
    }
}
