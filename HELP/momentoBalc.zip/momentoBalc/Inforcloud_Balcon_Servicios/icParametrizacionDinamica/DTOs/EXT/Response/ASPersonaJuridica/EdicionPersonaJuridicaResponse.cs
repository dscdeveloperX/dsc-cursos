﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica
{
    public class EdicionPersonaJuridicaResponse : ApiExternoResponse<EdicionPersonaJuridicaResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public EdicionPersonaJuridicaResponseBody BodyResponse { get; set; }

        public EdicionPersonaJuridicaResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionPersonaJuridicaResponseBody();
        }

        public override EdicionPersonaJuridicaResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class EdicionPersonaJuridicaResponseBody
    {
        public bool Editado { get; set; }
        public EdicionPersonaJuridicaResponseBody()
        {
            this.Editado = false;
        }
    }
}
