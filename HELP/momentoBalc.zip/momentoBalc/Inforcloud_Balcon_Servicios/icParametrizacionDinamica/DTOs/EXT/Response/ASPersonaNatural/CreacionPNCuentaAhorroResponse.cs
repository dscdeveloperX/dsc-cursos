﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural
{
    public class CreacionPNCuentaAhorroResponse : ApiExternoResponse<CreacionPNCuentaAhorroResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public CreacionPNCuentaAhorroResponseBody BodyResponse { get; set; }

        public CreacionPNCuentaAhorroResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionPNCuentaAhorroResponseBody();
        }

        public override CreacionPNCuentaAhorroResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class CreacionPNCuentaAhorroResponseBody
    {
        public string Prefijo { get; set; }
        public string Cuenta { get; set; }
    }
}

