﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica
{
    public class CreacionPersonaJuridicaResponse : ApiExternoResponse<CreacionPersonaJuridicaResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public CreacionPersonaJuridicaResponseBody BodyResponse { get; set; }

        public CreacionPersonaJuridicaResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionPersonaJuridicaResponseBody();
        }

        public override CreacionPersonaJuridicaResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class CreacionPersonaJuridicaResponseBody
    {
        public bool Creado { get; set; }
        public CreacionPersonaJuridicaResponseBody()
        {
            this.Creado = false;
        }
    }
}
