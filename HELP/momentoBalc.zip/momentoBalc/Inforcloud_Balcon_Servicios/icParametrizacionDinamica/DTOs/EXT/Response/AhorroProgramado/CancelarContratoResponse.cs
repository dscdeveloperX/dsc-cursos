﻿using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado
{
    public class CancelarContratoResponse : ApiExternoResponse<CancelarContratoResponse>{
        public string RutaDoc { get; set; }
        public byte[] Documento { get; set; }
        public decimal CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public CancelarContratoResponse() {
            this.CodigoRetorno = new int();
            //this.MensajeRetorno = new string();
        }

        public override CancelarContratoResponse? DeserializarSoap(XmlDocument soap) {
            return this;
        }
    }
}
