﻿using icCommon.DTOs.EXT;
using System.Collections.Generic;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado
{
    public class SimulaCancelacionAPResponse : ApiExternoResponse<SimulaCancelacionAPResponse> {
        public List<SimulacionCancelacionAP> ListaSimulacionCancelacion { get; set; }
        public List<DatosContrato> ListaDatosContrato { get; set; }
        public int CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public SimulaCancelacionAPResponse() {
            this.ListaSimulacionCancelacion = new List<SimulacionCancelacionAP>();
            this.ListaDatosContrato = new List<DatosContrato>();
            this.CodigoRetorno = new int();
        }
        public override SimulaCancelacionAPResponse? DeserializarSoap(XmlDocument soap) {
            return this;
        }
    }
}
