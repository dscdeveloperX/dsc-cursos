﻿using icCommon.DTOs.EXT;
using System.Collections.Generic;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado
{
    public class PlazosResponse : ApiExternoResponse<PlazosResponse>
    {

        public List<Plazos> ListaPlazos { get; set; }
        public decimal CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }
        public PlazosResponse()
        {
            this.ListaPlazos = new List<Plazos>();
            this.CodigoRetorno = new int();
        }
        public override PlazosResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
}
