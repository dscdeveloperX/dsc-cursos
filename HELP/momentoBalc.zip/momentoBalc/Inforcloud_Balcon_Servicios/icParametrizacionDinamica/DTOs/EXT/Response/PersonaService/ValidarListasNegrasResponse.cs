﻿using icCommon.DTOs.EXT;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.PersonaService
{
    public class ValidarListasNegrasResponse
    {
        [XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ValidarListasNegrasResponseDto ValidarListasNegrasResponse { get; set; }
        }
        public class ValidarListasNegrasResponseDto : ApiExternoResponse<ValidarListasNegrasResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public bool ValidarListasNegrasResult { get; set; }
            public MensajeAuth Mensaje { get; set; }

            public override ValidarListasNegrasResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList consultaResponse = soap.GetElementsByTagName("ValidarListasNegrasResult", Constantes.XmlNamespace.Tem);
                if (consultaResponse.Count > 0)
                {
                    XmlNode consultaNode = consultaResponse.Item(0);
                    bool result = false;
                    if (consultaNode != null) result = consultaNode.InnerText.Trim() == "true";

                    ValidarListasNegrasResponseDto respuestaExterno = new ValidarListasNegrasResponseDto
                    {
                        ValidarListasNegrasResult = result,
                        Mensaje = new MensajeAuth()
                    };

                    return respuestaExterno;
                }
                else
                {
                    return new ValidarListasNegrasResponseDto
                    {
                        Mensaje = new MensajeAuth(soap)
                    };
                }
            }
        }
    }
}
