﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural
{
    public class EdicionPersonaNaturalResponse : ApiExternoResponse<EdicionPersonaNaturalResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public EdicionPersonaNaturalResponseBody BodyResponse { get; set; }

        public EdicionPersonaNaturalResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionPersonaNaturalResponseBody();
        }

        public override EdicionPersonaNaturalResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class EdicionPersonaNaturalResponseBody 
    {
        public bool Editado { get; set; }
        public EdicionPersonaNaturalResponseBody()
        {
            this.Editado = false;
        }
    }
}
