﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica
{
    public class CreacionPJCuentaAhorroResponse : ApiExternoResponse<CreacionPJCuentaAhorroResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public CreacionPJCuentaAhorroResponseBody BodyResponse { get; set; }

        public CreacionPJCuentaAhorroResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new CreacionPJCuentaAhorroResponseBody();
        }

        public override CreacionPJCuentaAhorroResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class CreacionPJCuentaAhorroResponseBody
    {
        public string Prefijo { get; set; }
        public string Cuenta { get; set; }
    }
}

