﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASContactabilidad
{
    public class EdicionContactabilidadResponse : ApiExternoResponse<EdicionContactabilidadResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public EdicionContactabilidadResponseBody BodyResponse { get; set; }

        public EdicionContactabilidadResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionContactabilidadResponseBody();
        }

        public override EdicionContactabilidadResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class EdicionContactabilidadResponseBody
    {
        public bool Editado { get; set; }
        public EdicionContactabilidadResponseBody()
        {
            this.Editado = false;
        }
    }
}
