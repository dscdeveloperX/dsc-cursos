﻿using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado
{
    public class SimuladorAhorroProgramadoResponse : ApiExternoResponse<SimuladorAhorroProgramadoResponse>
    {
        public decimal MetaAhorro { get; set; }
        public decimal DepositoInicial { get; set; }
        public decimal MontoAhorro { get; set; }
        public decimal Tasa { get; set; }
        public decimal Interes { get; set; }
        public decimal TotalAhorro { get; set; }
        public int CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }
        public string FechaVcto { get; set; }

        public SimuladorAhorroProgramadoResponse()
        {
            this.MetaAhorro = MetaAhorro;
            this.DepositoInicial = DepositoInicial;
            this.MontoAhorro = MontoAhorro;
            this.Tasa = Tasa;
            this.Interes = Interes;
            this.TotalAhorro = TotalAhorro;
            this.CodigoRetorno = new int();
        }

        public override SimuladorAhorroProgramadoResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
}
