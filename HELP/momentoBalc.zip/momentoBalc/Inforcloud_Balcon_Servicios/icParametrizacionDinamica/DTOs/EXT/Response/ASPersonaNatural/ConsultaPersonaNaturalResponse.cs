﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural
{
    public class ConsultaPersonaNaturalResponse : ApiExternoResponse<ConsultaPersonaNaturalResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public ConsultaPersonaNaturalResponseBody BodyResponse { get; set; }

        public ConsultaPersonaNaturalResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultaPersonaNaturalResponseBody();
        }

        public override ConsultaPersonaNaturalResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class ConsultaPersonaNaturalResponseBody 
    {
        public DatosPersonaNatural DatosPersona { get; set; }
        public ConsultaPersonaNaturalResponseBody()
        {
            this.DatosPersona = null;
        }
    }
}
