﻿using System.Collections.Generic;
using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado { 
    public class ClienteContratoResponse : ApiExternoResponse<ClienteContratoResponse>{
        public List<DatosContrato> ListaDatosContrato { get; set; }
        public List<AhorroProcesado> ListaAhorroProcesado { get; set; }
        public List<AhorroFallido> ListaAhorroFallido { get; set; }
        public int CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public ClienteContratoResponse() {
            this.ListaDatosContrato = new List<DatosContrato>();
            this.ListaAhorroProcesado = new List<AhorroProcesado>();
            this.ListaAhorroFallido = new List<AhorroFallido>();
            this.CodigoRetorno = new int();
            //this.MensajeRetorno = new string();
        }

        public override ClienteContratoResponse? DeserializarSoap(XmlDocument soap) {
            return this;
        }
    }
        
}
