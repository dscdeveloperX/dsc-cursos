﻿using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.EnvioCorreo
{
    public class EnvioExternoResponse
    {
        [XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public EnvioExternoResponseDto EnvioExternoResponse { get; set; }
        }
        public class EnvioExternoResponseDto : ApiExternoResponse<EnvioExternoResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public EnvioExternoResult EnvioExternoResult { get; set; }
            public string ValiacionMensaje { get; set; }

            public override EnvioExternoResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList valiacionMensaje = soap.GetElementsByTagName("valiacionMensaje", Constantes.XmlNamespace.Tem);

                if (valiacionMensaje.Count == 0)
                {
                    XmlNodeList consultaResponse = soap.GetElementsByTagName("EnvioExternoResult", Constantes.XmlNamespace.Tem);
                    XmlNode consultaNode = consultaResponse.Item(0);
                    string xmlInput = SerializadorXmlSoap.ObtenerXMLLimpio(consultaNode);

                    EnvioExternoResult respuestaExterno = SerializadorXmlSoap.DeserializarObjeto<EnvioExternoResult>(xmlInput);

                    return new EnvioExternoResponseDto
                    {
                        EnvioExternoResult = respuestaExterno,
                        ValiacionMensaje = respuestaExterno.MensajeControl
                    };
                }
                else
                {
                    return new EnvioExternoResponseDto
                    {
                        ValiacionMensaje = valiacionMensaje.Item(0).InnerText
                    };
                }
            }
        }

        public class EnvioExternoResult
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
            public int CodigoControl { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
            public string MensajeControl { get; set; }

        }
    }
}
