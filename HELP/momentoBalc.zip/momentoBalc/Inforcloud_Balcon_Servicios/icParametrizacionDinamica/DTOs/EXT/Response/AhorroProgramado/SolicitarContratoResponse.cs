﻿using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado
{
    public class SolicitarContratoResponse : ApiExternoResponse<SolicitarContratoResponse>
    {
        public decimal Contrato { get; set; }
        public string RutaDoc { get; set; }
        public byte[] Documento { get; set; }
        public decimal CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public SolicitarContratoResponse()
        {
            this.Contrato = Contrato;
            this.CodigoRetorno = CodigoRetorno;
        }
        public override SolicitarContratoResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
}
