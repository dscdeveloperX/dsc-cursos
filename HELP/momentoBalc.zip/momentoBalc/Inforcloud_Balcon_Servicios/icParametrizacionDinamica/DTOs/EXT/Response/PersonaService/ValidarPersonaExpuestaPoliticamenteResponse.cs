﻿using icCommon.DTOs.EXT;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.PersonaService
{
    public class ValidarPersonaExpuestaPoliticamenteResponse
    {
        [XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ValidarPersonaExpuestaPoliticamenteResponseDto ValidarPersonaExpuestaPoliticamenteResponse { get; set; }
        }
        public class ValidarPersonaExpuestaPoliticamenteResponseDto : ApiExternoResponse<ValidarPersonaExpuestaPoliticamenteResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public bool ValidarPersonaExpuestaPoliticamenteResult { get; set; }
            public MensajeAuth Mensaje { get; set; }

            public override ValidarPersonaExpuestaPoliticamenteResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList consultaResponse = soap.GetElementsByTagName("ValidarPersonaExpuestaPoliticamenteResult", Constantes.XmlNamespace.Tem);
                if (consultaResponse.Count > 0)
                {
                    XmlNode consultaNode = consultaResponse.Item(0);
                    bool result = false;
                    if (consultaNode != null) result = consultaNode.InnerText.Trim() == "true";

                    ValidarPersonaExpuestaPoliticamenteResponseDto respuestaExterno = new ValidarPersonaExpuestaPoliticamenteResponseDto
                    {
                        ValidarPersonaExpuestaPoliticamenteResult = result,
                        Mensaje = new MensajeAuth()
                    };

                    return respuestaExterno;
                }
                else
                {
                    return new ValidarPersonaExpuestaPoliticamenteResponseDto
                    {
                        Mensaje = new MensajeAuth(soap)
                    };
                }
            }
        }
    }
}
