﻿using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.EnvioCorreo
{
    public class EnvioInternoResponse
    {
        [XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public EnvioInternoResponseDto EnvioInternoResponse { get; set; }
        }
        public class EnvioInternoResponseDto : ApiExternoResponse<EnvioInternoResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public EnvioInternoResult EnvioInternoResult { get; set; }
            public string ValiacionMensaje { get; set; }

            public override EnvioInternoResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList valiacionMensaje = soap.GetElementsByTagName("valiacionMensaje", Constantes.XmlNamespace.Tem);

                if (valiacionMensaje.Count == 0)
                {
                    XmlNodeList consultaResponse = soap.GetElementsByTagName("EnvioInternoResult", Constantes.XmlNamespace.Tem);
                    XmlNode consultaNode = consultaResponse.Item(0);
                    string xmlInput = SerializadorXmlSoap.ObtenerXMLLimpio(consultaNode);

                    EnvioInternoResult respuestaInterno = SerializadorXmlSoap.DeserializarObjeto<EnvioInternoResult>(xmlInput);

                    return new EnvioInternoResponseDto
                    {
                        EnvioInternoResult = respuestaInterno,
                        ValiacionMensaje = respuestaInterno.MensajeControl
                    };
                }
                else
                {
                    return new EnvioInternoResponseDto
                    {
                        ValiacionMensaje = valiacionMensaje.Item(0).InnerText
                    };
                }
            }
        }

        public class EnvioInternoResult
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
            public int CodigoControl { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespace.Cor)]
            public string MensajeControl { get; set; }

        }
    }
}
