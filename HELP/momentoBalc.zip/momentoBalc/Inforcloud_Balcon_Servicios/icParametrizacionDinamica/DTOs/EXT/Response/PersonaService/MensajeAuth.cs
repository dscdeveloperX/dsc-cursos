﻿using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.PersonaService
{
    public class MensajeAuth
    {
        public string Codigo { get; set; }
        public string Mensaje { get; set; }

        public MensajeAuth()
        {
            Codigo = icCommon.Utils.Constantes.MappingCode.EXITO;
            Mensaje = icCommon.Utils.Constantes.MappingCode.EXITO;
        }

        public MensajeAuth(XmlDocument xmlDocument)
        {
            XmlNodeList errorResponse = xmlDocument.GetElementsByTagName("Fault", Constantes.XmlNamespace.Envelope);
            XmlNode? consultaNode = errorResponse.Item(0);

            string? codigo = null;
            string? mensaje = null;

            if (consultaNode != null && consultaNode.ChildNodes.Count > 0)
            {
                var detalle = consultaNode.ChildNodes.Item(2)?.ChildNodes.Item(0);
                codigo = consultaNode.ChildNodes.Item(0)?.InnerText;
                mensaje = detalle.ChildNodes.Item(0)?.InnerText;
            }

            this.Codigo = codigo == null ? "ErrorGeneral" : codigo;
            this.Mensaje = mensaje == null ? "Error General" : mensaje;
        }
    }
}
