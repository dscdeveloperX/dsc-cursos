﻿using icCommon.DTOs.EXT;
using System.Xml;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.EXT.Response.PersonaService
{
    public class ConsultaCuentasActivasResponse : ApiExternoResponse<ConsultaCuentasActivasResponse>
    {
        public List<CuentaActivaAhorroProgramado> ListaCuentasActivas { get; set; }
        public int CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public ConsultaCuentasActivasResponse()
        {
            this.ListaCuentasActivas = new List<CuentaActivaAhorroProgramado>();
            this.CodigoRetorno = new int();
            //this.MensajeRetorno = new string();
        }

        public override ConsultaCuentasActivasResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
}
