﻿using icCommon.DTOs.EXT;
using icCommon.Utils;
using Serilog;
using System;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.PersonaService
{
    public class ConsultarDatosRegistroCivilCedulaResponse
    {
        [XmlRoot(Namespace = Constantes.XmlNamespace.Envelope)]
        public class Envelope
        {
            //Campo
            [XmlElement(Namespace = Constantes.XmlNamespace.Envelope)]
            public Body Body { get; set; }
        }

        public class Body
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ConsultarDatosRegistroCivilCedulaResponseDto ConsultarDatosRegistroCivilCedulaResponse { get; set; }
        }
        public class ConsultarDatosRegistroCivilCedulaResponseDto : ApiExternoResponse<ConsultarDatosRegistroCivilCedulaResponseDto>
        {
            [XmlElement(Namespace = Constantes.XmlNamespace.Tem)]
            public ConsultarDatosRegistroCivilCedulaResult ConsultarDatosRegistroCivilCedulaResult { get; set; }
            public MensajeAuth Mensaje { get; set; }

            public override ConsultarDatosRegistroCivilCedulaResponseDto DeserializarSoap(XmlDocument soap)
            {
                XmlNodeList consultaResponse = soap.GetElementsByTagName("ConsultarDatosRegistroCivilCedulaResponse", Constantes.XmlNamespace.Tem);

                if (consultaResponse.Count > 0)
                {
                    XmlNode consultaNode = consultaResponse.Item(0);
                    string xmlInput = SerializadorXmlSoap.ObtenerXMLLimpio(consultaNode);
                                        
                    ConsultarDatosRegistroCivilCedulaResult respuestaExterno;
                    try
                    {
                        respuestaExterno = SerializadorXmlSoap.DeserializarObjeto<ConsultarDatosRegistroCivilCedulaResult>(xmlInput);
                    }
                    catch (InvalidOperationException)
                    {
                        respuestaExterno = null;
                        Log.Information("ConectorBancoBLL / ConsultarDatosRegistroCivil: error => NO SE PUDO DESERIALIZAR RESPUESTA, REVISAR MODELO");
                    }
                    

                    return new ConsultarDatosRegistroCivilCedulaResponseDto
                    {
                        ConsultarDatosRegistroCivilCedulaResult = respuestaExterno,
                        Mensaje = new MensajeAuth()
                    };
                }
                else
                {
                    return new ConsultarDatosRegistroCivilCedulaResponseDto
                    {
                        Mensaje = new MensajeAuth(soap)
                    };
                }

            }
        }

        public class ConsultarDatosRegistroCivilCedulaResult
        {
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string CondicionCedulado { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string Apellidos { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string Nombres { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string ApellidosNombres { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public DateTime FechaNacimiento { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string LugarNacimiento { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string CodigoSexo { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string CodigoNacionalidad { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string CodigoPais { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string CodigoEstadoCivil { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string NombreConyuge { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public DateTime FechaMatrimonio { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string CodigoNivelEducacion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string CodigoProfesion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string FechaExpedicion { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string FotoCedula { get; set; }
            [XmlElement(Namespace = Constantes.XmlNamespaceResponse.A)]
            public string Firma { get; set; }
        }
    }
}
