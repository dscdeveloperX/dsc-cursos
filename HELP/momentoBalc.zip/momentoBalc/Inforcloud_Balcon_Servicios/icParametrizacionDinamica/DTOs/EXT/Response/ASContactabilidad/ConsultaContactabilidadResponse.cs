﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASContactabilidad
{
    public class ConsultaContactabilidadResponse : ApiExternoResponse<ConsultaContactabilidadResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public ConsultaContactabilidadResponseBody BodyResponse { get; set; }

        public ConsultaContactabilidadResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultaContactabilidadResponseBody();
        }

        public override ConsultaContactabilidadResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class ConsultaContactabilidadResponseBody
    {
        public Contactabilidad Contactabilidad { get; set; }
        public ConsultaContactabilidadResponseBody()
        {
            this.Contactabilidad = null;
        }
    }
}
