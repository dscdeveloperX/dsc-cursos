﻿using icCommon.DTOs.EXT;
using System.Xml;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado
{
    public class ObtenerSecuencialResponse : ApiExternoResponse<ObtenerSecuencialResponse>
    {
        public string Identificacion { get; set; }
        public int CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public ObtenerSecuencialResponse()
        {
            //this.Idenficacion = new string();
            this.CodigoRetorno = new int();
            //this.MensajeRetorno = new string();
        }

        public override ObtenerSecuencialResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
}
