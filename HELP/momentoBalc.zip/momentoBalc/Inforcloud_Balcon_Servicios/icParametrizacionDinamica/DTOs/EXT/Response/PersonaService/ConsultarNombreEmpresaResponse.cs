﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.PersonaService
{
    public class ConsultarNombreEmpresaResponse : ApiExternoResponse<ConsultarNombreEmpresaResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public ConsultaNombreEmpresaResponseBody BodyResponse { get; set; }

        public ConsultarNombreEmpresaResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultaNombreEmpresaResponseBody();
        }

        public override ConsultarNombreEmpresaResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class ConsultaNombreEmpresaResponseBody
    {
        public DatosEmpresa DatosEmpresa { get; set; }
        public ConsultaNombreEmpresaResponseBody()
        {
            this.DatosEmpresa = null;
        }
    }
}
