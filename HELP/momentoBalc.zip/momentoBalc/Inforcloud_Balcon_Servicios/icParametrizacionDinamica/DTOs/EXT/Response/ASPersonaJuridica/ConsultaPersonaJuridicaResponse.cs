﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica
{
    public class ConsultaPersonaJuridicaResponse : ApiExternoResponse<ConsultaPersonaJuridicaResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public ConsultaPersonaJuridicaResponseBody BodyResponse { get; set; }

        public ConsultaPersonaJuridicaResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new ConsultaPersonaJuridicaResponseBody();
        }

        public override ConsultaPersonaJuridicaResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class ConsultaPersonaJuridicaResponseBody
    {
        public DatosPersonaJuridica DatosPersona { get; set; }
        public ConsultaPersonaJuridicaResponseBody()
        {
            this.DatosPersona = null;
        }
    }
}
