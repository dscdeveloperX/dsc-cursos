﻿using icCommon.DTOs.EXT;
using System.Collections.Generic;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado {
    public class ValidaCuentaResponse : ApiExternoResponse<ValidaCuentaResponse> {
        public Parametros Parametros { get; set; }
        public List<TasaPorRango> listaTasaPorRango { get; set; }
        public decimal CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }
        public ValidaCuentaResponse() {
            this.Parametros = new Parametros();
            this.listaTasaPorRango = new List<TasaPorRango>();
            this.CodigoRetorno = new int();
        }
        public override ValidaCuentaResponse? DeserializarSoap(XmlDocument soap) {
            return this;
        }
    }
}
