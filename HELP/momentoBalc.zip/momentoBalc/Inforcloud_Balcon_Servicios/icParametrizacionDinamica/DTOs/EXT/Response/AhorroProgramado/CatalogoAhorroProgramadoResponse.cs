﻿using icCommon.DTOs.EXT;
using System.Collections.Generic;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado {
    public class CatalogoAhorroProgramadoResponse : ApiExternoResponse<CatalogoAhorroProgramadoResponse> {
        public List<CatalogoAhorroProgramado> ListaCatalogoAP { get; set; }
        public decimal CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public CatalogoAhorroProgramadoResponse() {
            this.ListaCatalogoAP = new List<CatalogoAhorroProgramado>();
            this.CodigoRetorno = new int();
        }

        public override CatalogoAhorroProgramadoResponse? DeserializarSoap(XmlDocument soap) {
            return this;
        }
    }
}
