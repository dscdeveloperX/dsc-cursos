﻿using icCommon.DTOs.API;
using icCommon.DTOs.EXT;
using icCommon.Utils;
using System.Xml;
using System.Xml.Serialization;

namespace icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural
{
    public class EdicionPersonaNaturalFallecidoResponse : ApiExternoResponse<EdicionPersonaNaturalFallecidoResponse>
    {
        public HeaderResponse HeaderResponse { get; set; }
        public EdicionPersonaNaturalFallecidoResponseBody BodyResponse { get; set; }

        public EdicionPersonaNaturalFallecidoResponse()
        {
            this.HeaderResponse = new HeaderResponse();
            this.BodyResponse = new EdicionPersonaNaturalFallecidoResponseBody();
        }

        public override EdicionPersonaNaturalFallecidoResponse? DeserializarSoap(XmlDocument soap)
        {
            return this;
        }
    }
    public class EdicionPersonaNaturalFallecidoResponseBody 
    {
        public bool Editado { get; set; }
        public EdicionPersonaNaturalFallecidoResponseBody()
        {
            this.Editado = false;
        }
    }
}
