﻿using icCommon.DTOs.EXT;
using System.Collections.Generic;
using System.Xml;

namespace icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado {
    public class CuentaClienteResponse : ApiExternoResponse<CuentaClienteResponse> {
        public List<CuentaCliente> ListaCuentasCliente { get; set; }
        public int CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }

        public CuentaClienteResponse() {
            this.ListaCuentasCliente = new List<CuentaCliente>();
            this.CodigoRetorno = new int();
        }

        public override CuentaClienteResponse? DeserializarSoap(XmlDocument soap) {
            return this;
        }
    }
}
