﻿namespace icParametrizacionDinamica.DTOs.EXT
{
    public class DatosEmpresa
    {
        public string RucEmpresa { get; set; }
        public string NombreEmpresa { get; set; }
    }
}
