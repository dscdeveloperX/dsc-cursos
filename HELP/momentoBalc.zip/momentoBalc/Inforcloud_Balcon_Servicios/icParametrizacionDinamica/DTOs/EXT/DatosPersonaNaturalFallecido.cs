﻿using icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using static icCommon.Utils.ObjectReflection;

namespace icParametrizacionDinamica.DTOs.EXT
{
    [Reflectable]
    public class DatosPersonaNaturalFallecido
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public string CondicionCedula { get; set; }
        public string CampoCaptacion { get; set; }


    }

}