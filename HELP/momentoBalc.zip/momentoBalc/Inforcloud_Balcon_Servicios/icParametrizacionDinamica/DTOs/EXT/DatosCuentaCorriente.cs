﻿using icCommon.Utils;
using System;

namespace icParametrizacionDinamica.DTOs.EXT
{
    [ObjectReflection.Reflectable]
    public class DatosCuentaCorriente
    {
        public string Prefijo { get; set; }
        public string Cuenta { get; set; }
        public string Tipo_Identidad_Cliente { get; set; }
        public string Dcto_Identidad_Cliente { get; set; }
        public string Nombre { get; set; }
        public string Zona { get; set; }
        public string Agencia { get; set; }
        public string Moneda { get; set; }
        public string Tipo_Producto { get; set; }
        public string Producto { get; set; }
        public string SubProducto { get; set; }
        public string Oficial { get; set; }
        public string Tipo_Cuenta { get; set; }
        public string Clase_Cuenta { get; set; }
        //public string Numero_Libreta { get; set; }
        //public string Lin_Libreta { get; set; }
        public string Canal { get; set; }
        public string Tipo_Documento_Representante_Legal { get; set; }
        public string Documento_Representante_Legal { get; set; }
        public string Nombre_Representante_Legal { get; set; }
        public string Tipo_Documento_Titular { get; set; }
        public string Documento_Titular { get; set; }
        public string Nombre_Titular { get; set; }

        public DatosGeneralChequera DatosGeneralChequera { get; set; }
        public DateTime Fecha_Apertura { get; set; }
        public DateTime Hora_Apertura { get; set; }
        public string Referido_Por { get; set; }
        public string Origen_Captacion { get; set; }
        public decimal EstadoCuenta { get; set; }
        public decimal Dia_Mes { get; set; }
        public decimal Semana { get; set; }
        public DatosRetiroChequera Datos_Retiro_Chequera { get; set; }

        //CREACION
        public string ProgramaCreacion { get; set; }
        public string UsuarioCreacion { get; set; }
        public string EstacionCreacion { get; set; }
        public string IPCreacion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime HoraCreacion { get; set; }
        //ULTIMA ACTUALIZACION 
        public string ProgramaUltima { get; set; }
        public string UsuarioUltima { get; set; }
        public string EstacionUltima { get; set; }
        public string IPUltima { get; set; }
        public DateTime FechaUltima { get; set; }
        public DateTime HoraUltima { get; set; }
        //PENULTIMA ACTUALIZACION
        public string ProgramaPenultima { get; set; }
        public string UsuarioPenultima { get; set; }
        public string EstacionPenultima { get; set; }
        public string IPPenultima { get; set; }
        public DateTime FechaPenultima { get; set; }
        public DateTime HoraPenultima { get; set; }
    }

    [ObjectReflection.Reflectable]
    public class DatosRetiroChequera
    {
        public string Tipo_Doc_Persona_Aut_Retiro_Chequera { get; set; }
        public string Numero_Doc_Persona_Aut_Retiro_Chequera { get; set; }
        public string Nombre_Persona_Aut_Retiro_Chequera { get; set; }
    }
    [ObjectReflection.Reflectable]
    public class DatosGeneralChequera
    {
        public decimal MontoApertura { get; set; }
        public string TipoChequera { get; set; }
        public string TipoCheques { get; set; }
        public decimal CantidadCheques { get; set; }
        public string NumeroImprenta { get; set; }

        public DatosChequera DatosChequera { get; set; }
    }
    [ObjectReflection.Reflectable]
    public class DatosChequera
    {
        public decimal CantidadChequera { get; set; }
        public string Nombre1 { get; set; }
        public string Nombre2 { get; set; }
    }
}
