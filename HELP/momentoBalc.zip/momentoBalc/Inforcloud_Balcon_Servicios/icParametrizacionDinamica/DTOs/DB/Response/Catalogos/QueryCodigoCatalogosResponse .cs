﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.DB.Response.Catalogos
{
    public class QueryCodigoCatalogosResponse
    {
        public List<string> CodigoCatalogos { get; set; }
        public List<string> DescripcionCatalogos { get; set; }
    }
}
