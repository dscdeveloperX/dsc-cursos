﻿using icParametrizacionDinamica.Models;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.DB.Response.Formatos
{
    public class QueryFormatosResponse
    {
        public List<FormatoQuery> Formatos { get; set; }
        public int Total { get; set; }
    }

    public class FormatoQuery
    {
        public long FormatoId { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string TipoPersona { get; set; }
        public string TipoIdentificacion { get; set; }
        public string TipoCliente { get; set; }
        public string Persona { get; set; }
        public string Producto { get; set; } 
    }
}
