﻿namespace icParametrizacionDinamica.DTOs.DB.Response.Modelos
{
    public class QuerySeccionesResponse
    {
        public string Seccion { get; set; }
        public int OrdenSeccion { get; set; }
        public string Subseccion { get; set; }
        public int OrdenSubseccion { get; set; }
    }
}
