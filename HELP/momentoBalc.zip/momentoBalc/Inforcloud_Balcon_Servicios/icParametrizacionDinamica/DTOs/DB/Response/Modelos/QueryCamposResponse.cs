﻿using icParametrizacionDinamica.Models;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.DB.Response.Modelos
{
    public class QueryCamposResponse
    {
        public List<Campo> Campos { get; set; }
        public int Total { get; set; }
    }
}
