﻿using icParametrizacionDinamica.Models;
using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.DB.Response.Catalogos
{
    public class QueryCatalogosResponse
    {
        public List<Catalogo> Catalogos { get; set; }
        public int Total { get; set; }
    }
}
