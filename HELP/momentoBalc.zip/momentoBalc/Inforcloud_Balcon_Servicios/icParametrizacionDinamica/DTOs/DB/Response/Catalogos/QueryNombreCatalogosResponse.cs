﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.DTOs.DB.Response.Catalogos
{
    public class QueryNombreCatalogosResponse
    {
        public List<string> NombreCatalogos { get; set; }
        public int Total { get; set; }
    }
}
