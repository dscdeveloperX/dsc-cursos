﻿using icCommon.DTOs.API;
using icCommon.ManejoErrores.Utils;
using icCommon.Modelos;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.ContactabilidadCliente;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.ContactabilidadCliente;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios;
using icParametrizacionDinamica.DTOs.EXT;
using icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado;
using icParametrizacionDinamica.Models;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using System.IO;
using icParametrizacionDinamica.DLL;
using System.Globalization;
using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.DB.Response.Catalogos;
using icParametrizacionDinamica.DTOs.API.Response.Catalogos;
using icParametrizacionDinamica.DTOs.API.Request.Catalogos;
using Microsoft.AspNetCore.Authentication;

namespace icParametrizacionDinamica.BLL
{
    public class BalconServicios : IBalconServicios
    {
        private readonly IFormatoDLL _clHelper;
        private readonly IMonitorBalconDLL _mbHelper;
        private readonly ICatalogoBLL _clRepository;
        private readonly IConectorBancoBLL _sBanco;
        private readonly ISolicitudCambiosBLL _aprobador;
        private Common _Common;
        private readonly IConfigurationRoot builder;
        public BalconServicios(IFormatoDLL dHelper, IConectorBancoBLL sBanco, ISolicitudCambiosBLL aprobador, IMonitorBalconDLL mbHelper, ICatalogoBLL catalogoBLL)
        {
            _clHelper = dHelper;
            _mbHelper = mbHelper;
            _sBanco = sBanco;
            _aprobador = aprobador;
            _clRepository = catalogoBLL;
            _Common = new();
            builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("icAppConfig.json").Build();
        }

        public EnviarFormularioResponse CalcularCampoEnLinea(CalcularCampoRequest request) 
        {
            try
            {
                EnviarFormularioResponse response = new EnviarFormularioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EnviarFormularioResponseBody bodyResponse = new EnviarFormularioResponseBody();
                
                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                Dictionary<string, dynamic> resultados = new Dictionary<string, dynamic>();

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                switch (request.BodyRequest.NombreCalculo) {
                    case "ObtenerNombreCliente":
                        DatosPersonaNatural valoresPersona = new DatosPersonaNatural();

                        if (request.BodyRequest.ValoresCalculo != null && request.BodyRequest.ValoresCalculo.Values.Count > 1) {
                            string tipo = request.BodyRequest.ValoresCalculo.Values.ToList()[0];
                            string cedula = request.BodyRequest.ValoresCalculo.Values.ToList()[1];

                            if (string.IsNullOrEmpty(tipo) || string.IsNullOrEmpty(cedula)) {
                                ErrorUtil.ThrowAppException("ObtenerNombreCliente", "INVALID_ARGUMENT", "Faltan campos");
                            }
                            //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                            ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                            Log.Information("BalconServicios/CalcularCampoEnLinea: Consulta API BANCO CLIENTES -> INICIO");
                            valoresPersona = _sBanco.ConsultarClienteNatural(tipo, cedula, nutCliente, request.HeaderRequest.UserName,
                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                            Log.Information("BalconServicios/CalcularCampoEnLinea: Consulta API BANCO CLIENTES -> RESPUESTA");

                            if (valoresPersona != null)
                            {
                                if (valoresPersona.EsCliente)
                                {
                                    resultados.Add(request.BodyRequest.CampoCalculado, valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos);
                                }
                                else {
                                    resultados.Add(request.BodyRequest.CampoCalculado, "");
                                }
                            }
                            else {
                                resultados.Add(request.BodyRequest.CampoCalculado, "");
                            }
                        }
                        break;
                    case "ObtenerInfoRegistroCivil":
                        DatosPersonaNatural valoresRegistro = new DatosPersonaNatural();

                        if (request.BodyRequest.ValoresCalculo != null && request.BodyRequest.ValoresCalculo.Values.Count > 1)
                        {
                            string tipo = request.BodyRequest.ValoresCalculo.Values.ToList()[0];
                            string cedula = request.BodyRequest.ValoresCalculo.Values.ToList()[1];

                            if (string.IsNullOrEmpty(tipo) || string.IsNullOrEmpty(cedula))
                            {
                                ErrorUtil.ThrowAppException("ObtenerNombreCliente", "INVALID_ARGUMENT", "Faltan campos");
                            }
                            if ((tipo == "N" || tipo == "R") && !string.IsNullOrEmpty(cedula) && cedula.Length >= 10)
                            {
                                cedula = cedula.Substring(0, 10);
                                //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO (dsc1977)
                                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/CalcularCampoEnLinea: ConsultarDatosRegistroCivil -> INICIO");
                                valoresRegistro = _sBanco.ConsultarDatosRegistroCivil("N", cedula, nutCliente, request.HeaderRequest.UserName,
                                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                Log.Information("BalconServicios/CalcularCampoEnLinea: ConsultarDatosRegistroCivil -> RESPUESTA");

                                if (valoresRegistro != null)
                                {
                                    Log.Information("BalconServicios/CalcularCampoEnLinea: Conexion ConsultarDatosRegistroCivil -> " + valoresRegistro.Sin_Registro_Civil);

                                    resultados.Add(request.BodyRequest.CampoCalculado, valoresRegistro.Sin_Registro_Civil);
                                    if (valoresRegistro.Sin_Registro_Civil == "N")
                                    {
                                        switch (request.BodyRequest.CampoCalculado)
                                        {
                                            case "REGISTRO_CIVIL_REP":
                                                string nombresConyuge = valoresRegistro.SP_Informacion_General.Datos_Conyuge?.Nombres_Apellidos_Conyuge;

                                                resultados.Add("NOMBRE_REP", valoresRegistro.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos);
                                                resultados.Add("ESTADO_CIVIL_REP", valoresRegistro.SP_Informacion_General.Datos_Basicos.Estado_Civil);
                                                resultados.Add("NOMBRE_CONYUGE_REP", nombresConyuge != null ? nombresConyuge : "");
                                                break;
                                            case "REGISTRO_CIVIL_ACC":
                                                resultados.Add("NOMBRE_ACC", valoresRegistro.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos);
                                                break;
                                            case "REGISTRO_CIVIL_CONYUGE":
                                                resultados.Add("NOMBRE_CONYUGE", valoresRegistro.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos);
                                                break;
                                        }
                                    }
                                    else {
                                        switch (request.BodyRequest.CampoCalculado)
                                        {
                                            case "REGISTRO_CIVIL_REP":
                                                resultados.Add("NOMBRE_REP", "");
                                                resultados.Add("ESTADO_CIVIL_REP", "");
                                                resultados.Add("NOMBRE_CONYUGE_REP", "");
                                                break;
                                            case "REGISTRO_CIVIL_ACC":
                                                resultados.Add("NOMBRE_ACC", "");
                                                break;
                                            case "REGISTRO_CIVIL_CONYUGE":
                                                resultados.Add("NOMBRE_CONYUGE", "");
                                                break;
                                        }
                                    }
                                }
                            }

                            if (resultados.Keys.Count == 0)
                            {
                                resultados.Add(request.BodyRequest.CampoCalculado, "S");

                                switch (request.BodyRequest.CampoCalculado)
                                {
                                    case "REGISTRO_CIVIL_REP":
                                        resultados.Add("NOMBRE_REP", "");
                                        resultados.Add("ESTADO_CIVIL_REP", "");
                                        resultados.Add("NOMBRE_CONYUGE_REP", "");
                                        break;
                                    case "REGISTRO_CIVIL_ACC":
                                        resultados.Add("NOMBRE_ACC", "");
                                        break;
                                    case "REGISTRO_CIVIL_CONYUGE":
                                        resultados.Add("NOMBRE_CONYUGE", "");
                                        break;
                                }
                            }
                        }
                        break;
                    //dsc
                    /*case "ObtenerCatalogoPorCodigo":
                        DatosPersonaNatural valoresEmpresa = new DatosPersonaNatural();

                        if (request.BodyRequest.ValoresCalculo != null && request.BodyRequest.ValoresCalculo.Values.Count > 1)
                        {
                            string catalogoNombre = request.BodyRequest.ValoresCalculo.Values.ToList()[0];
                            string catalogoCodigo = request.BodyRequest.ValoresCalculo.Values.ToList()[1];
                            short rucCaracteres = 9;
                            
                            if (string.IsNullOrEmpty(catalogoNombre) || string.IsNullOrEmpty(catalogoCodigo))
                            {
                                ErrorUtil.ThrowAppException("ObtenerNombreEmpresa", "INVALID_ARGUMENT", "Faltan campos");
                            }

                            if (catalogoCodigo.Length >= rucCaracteres)
                            {
                                catalogoCodigo = catalogoCodigo.Substring(0, rucCaracteres);
                                //
                                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/CalcularCampoEnLinea: Consulta API BANCO CLIENTES -> INICIO");
                                HeaderRequest header = request.HeaderRequest;
                                ListaCodigoCatalogosRequestBody body = new ListaCodigoCatalogosRequestBody();
                                ListaCodigoCatalogosRequest listaCodigoCatalogosRequest = new ListaCodigoCatalogosRequest();

                                listaCodigoCatalogosRequest.HeaderRequest = header;
                                listaCodigoCatalogosRequest.BodyRequest = body;
                                body.CodigoCatalogo = catalogoCodigo;//ruc
                                body.NombreCatalogo = catalogoNombre;//"ROLPAGO_EMPRESA";
                                //recibe el catalo de producto
                                ListaCodigoCatalogosResponse listaCodigoCatalogosResponse = new();
                                listaCodigoCatalogosResponse = _clRepository.ListarCodigoCatalogos(listaCodigoCatalogosRequest);
                                //                                    
                                Log.Information("BalconServicios/CalcularCampoEnLinea: Consulta API BANCO CLIENTES -> RESPUESTA");
                                
                            if (valoresEmpresa != null)
                            {
                                    resultados.Add("CODIGO_CATALOGO", listaCodigoCatalogosResponse.BodyResponse.CodigoCatalogos[0]);
                                    resultados.Add("DESCRIPCION_CATALOGO", listaCodigoCatalogosResponse.BodyResponse.DescripcionCatalogos[0]);
                            }
                            else
                            {
                                resultados.Add(request.BodyRequest.CampoCalculado, "");
                            }
                        }
                }
                        break;*/





                    case "ObtenerNombreEmpresa":
                        DatosPersonaNatural valoresEmpresa = new DatosPersonaNatural();

                        if (request.BodyRequest.ValoresCalculo != null && request.BodyRequest.ValoresCalculo.Values.Count > 0)
                        {
                            string empresaRuc = request.BodyRequest.ValoresCalculo.Values.ToList()[0];
                            short rucCaracteres = 13;

                            if (string.IsNullOrEmpty(empresaRuc))
                            {
                                ErrorUtil.ThrowAppException("ObtenerNombreEmpresa", "INVALID_ARGUMENT", "Faltan campos");
                            }

                            if (empresaRuc.Length == rucCaracteres)
                            {
                                empresaRuc = empresaRuc.Substring(1, rucCaracteres-1);//sin el cero
                                //
                                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/CalcularCampoEnLinea: Consulta API BANCO CLIENTES -> INICIO");
                                //HeaderRequest header = request.HeaderRequest;
                                //ListaNombreEmpresaRequestBody body = new ListaNombreEmpresaRequestBody();
                                //ListaNombreEmpresaRequest listaNombreEmpresaRequest = new ListaNombreEmpresaRequest();

                                //listaNombreEmpresaRequest.HeaderRequest = header;
                                //listaNombreEmpresaRequest.BodyRequest = body;
                                //body.RucEmpresa = empresaRuc;//ruc
                                //recibe el catalo de producto
                                //ListaNombreEmpresaResponse listaNombreEmpresaResponse = new();
                                DatosEmpresa datosEmpresa = _sBanco.ConsultarNombreEmpresa(empresaRuc, nutCliente, request.HeaderRequest.UserName,
                                                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                //                                    
                                Log.Information("BalconServicios/CalcularCampoEnLinea: Consulta API BANCO CLIENTES -> RESPUESTA");

                                if (valoresEmpresa != null)
                                {
                                    //RP_RUC, RP_NOMEMP, CONSULTAR_NOMBRE_EMPRESA

                                    resultados.Add("RP_RUC", ((datosEmpresa.RucEmpresa.Length == 12)? "0" + datosEmpresa.RucEmpresa:datosEmpresa.RucEmpresa));
                                    resultados.Add("RP_NOMEMP", datosEmpresa.NombreEmpresa);
                                    resultados.Add("CONSULTAR_NOMBRE_EMPRESA", (datosEmpresa.NombreEmpresa != null && datosEmpresa.NombreEmpresa.Length > 0?"S":"N"));
                                }
                                else
                                {
                                    resultados.Add(request.BodyRequest.CampoCalculado, "");
                                }
                            }
                        }
                        break;
                }

                
                if (resultados != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Resultado = resultados;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/CalcularCampoEnLinea: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EnviarFormularioResponse EnviarFormularioPersona(EnviarFormularioRequest request) {
            try {
                EnviarFormularioResponse response = new EnviarFormularioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                EnviarFormularioResponseBody bodyResponse = new EnviarFormularioResponseBody();
                bool respuesta = false;

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                bool datosSensiblesModificados = false;
                

                Dictionary<string, dynamic> resultados = new Dictionary<string, dynamic>();
                List<ValoresDetalleResumen> detalles = new List<ValoresDetalleResumen>();
                Dictionary<string, string> firmantes = new Dictionary<string, string>();

                Dictionary<string, dynamic> dictPersona = null;
                Dictionary<string, dynamic> dictValoresAntes = new Dictionary<string, dynamic>();
                Dictionary<string, dynamic> dictValoresDespues = new Dictionary<string, dynamic>();
                SecuencialAhorroProgramado secuencialDocume = new();

                if (request.BodyRequest.Formulario.TipoPersona == "N") {
                    if (request.BodyRequest.Formulario.Formulario != null && request.BodyRequest.Formulario.Formulario.Secciones != null && request.BodyRequest.Formulario.Formulario.Secciones.Count > 0) {
                        dictPersona = ConvertirFormularioADiccionario(request.BodyRequest.Formulario.Formulario.Secciones, typeof(DatosPersonaNatural), ref dictValoresAntes, ref dictValoresDespues, ref datosSensiblesModificados);
                    }

                    #region CREACION PERSONA NATURAL
                    if (dictPersona != null) {
                        DatosPersonaNatural valoresPersona = ConvertirDiccionarioAObjeto<DatosPersonaNatural>(dictPersona);

                        valoresPersona.SP_Informacion_Financiera.Ingreso_Patrimonio.Usuario = valoresPersona.SP_Informacion_Financiera.Ingreso_Patrimonio.IdentificacionUsuario;

                        


                        string nombre = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos;
                        //DSC: quito cero al numeor de ruc
                        string TipEmp_RucEmpresa = valoresPersona.SP_Informacion_General.Datos_Generales.TipEmp_RucEmpresa == null?String.Empty: valoresPersona.SP_Informacion_General.Datos_Generales.TipEmp_RucEmpresa;
         	   	       valoresPersona.SP_Informacion_General.Datos_Generales.TipEmp_RucEmpresa = ((TipEmp_RucEmpresa.Length ==13)? TipEmp_RucEmpresa.Substring(1,12): TipEmp_RucEmpresa);

                        //CREACION/EDICION CLIENTE PERSONA NATURAL SIN PRODUCTO
                        if (valoresPersona.EsCliente) {
                            ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                            string MensajeGeneral = "Lo sentimos su transacción no pudo ser procesada. Por favor inténtelo más tarde";
                            List<object> obj = new();
                            string OPC = request.BodyRequest.Formulario.Formulario.Codigo;
                            switch (OPC) {
                                case "APCLTE": //--> Simulacion de Cancelación del Contrato en Ahorro Programado
                                    #region Ahorro Programado Cancelación de Contrato. 
                                    Decimal contrato = 0;
                                    if(valoresPersona.SP_DatosAhorroProgramado.ListaDatosContrato == null ) {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", "Debe seleccionar la cuenta a cancelar.");
                                    }
                                    foreach (DatosContratoExt item in valoresPersona.SP_DatosAhorroProgramado.ListaDatosContrato) {
                                        if (item.AccionCRUD == "D") {
                                            contrato = item.contrato;
                                            break;
                                        }
                                    }
                                    if(contrato != 0) { 
                                        Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API AhorroProgramado ConsultarClienteContratos -> INICIO");
                                        List<DatosContratoExt> ClienteContrato = _sBanco.ConsultarClienteContratos(contrato.ToString(), "", "0", 0, nutCliente, request.HeaderRequest.UserName,
                                                               request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                        Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API AhorroProgramado ConsultarClienteContratos -> RESPUESTA");

                                        Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API AhorroProgramado SimulaCancelacionAP -> INICIO");
                                        SimulaCancelacionAPResponse SimulaCancelacion = _sBanco.SimulaCancelacionAP(contrato,
                                            nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                        Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API AhorroProgramado SimulaCancelacionAP -> RESPUESTA");

                                        obj.Add(SimulaCancelacion.ListaSimulacionCancelacion[0]);
                                        obj.Add(ClienteContrato[0]);
                                        //obj.Add(valoresPersona.SP_Informacion_General.Datos_Generales.Ejecutivo_Oficial);
                                        //obj.Add(valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Correo_Electronico1);
                                        if ((SimulaCancelacion != null) && (SimulaCancelacion.ListaSimulacionCancelacion.Count > 0)
                                            && (ClienteContrato != null) && (ClienteContrato.Count > 0)) {
                                            if (SimulaCancelacion.CodigoRetorno != 0) {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", SimulaCancelacion.MensajeRetorno.ToString());
                                            }
                                            resultados = _Common.DeserializaObj(obj);
                                            //resultados.Add("", valoresPersona.SP_Informacion_General.Datos_Generales.Ejecutivo_Oficial);
                                            resultados.Add("CorreoElectronico", valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Correo_Electronico1);
                                            respuesta = true;
                                        } else {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", MensajeGeneral);
                                        }
                                    } else {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", "Debe seleccionar la cuenta a cancelar.");
                                    }
                                    #endregion
                                    break;
                                case "CONT_AHPR": //--> Simulacion de Apertura de Ahorro programado
                                    #region Ahorro programado Simulacion en Apertura
                                    var cuenta = valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.CuentaAhorro;
                                    decimal DiaDebito = _Common.StringDecimal(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.DiaDebito);
                                    decimal MontoAhorro = _Common.StringDecimal(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.MontoAhorro);
                                    decimal DepositoInicial = _Common.StringDecimal(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.DepositoInicial);

                                    //Obtengo secuencial de identificación
                                    ErrorMapeoMensaje mensajeObtenerSecuencial = new ErrorMapeoMensaje();
                                    Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTE ObtenerSecuencial -> INICIO");
                                    secuencialDocume = _sBanco.ObtenerSecuencial(valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente, valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente, nutCliente, request.HeaderRequest.UserName,
                                        request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeObtenerSecuencial);
                                    Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTES ObtenerSecuencial -> RESPUESTA");

                                    Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API SimularContratoAhorroProgramado -> INICIO");
                                    ValidaCuentaResponse ValidaCuenta = _sBanco.ValidaCuentaAhorroProgramado(valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente,
                                        secuencialDocume.Identificacion, _Common.StringDecimal(cuenta),
                                        nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                    Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO SimularContratoAhorroProgramado -> RESPUESTA");

                                    if(ValidaCuenta.CodigoRetorno != 0) {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "ValidaCuenta", ValidaCuenta.MensajeRetorno.ToString().Trim()); 
                                    }else if (MontoAhorro < ValidaCuenta.Parametros.MontoMinimo || MontoAhorro > ValidaCuenta.Parametros.MontoMaximo) {
                                        string mensajeMonto = ((MontoAhorro < ValidaCuenta.Parametros.MontoMinimo) ? "MontoAhorro minimo permitido es "+ ValidaCuenta.Parametros.MontoMinimo.ToString() : "MontoAhorro Exede el monto maximo permitido "+ ValidaCuenta.Parametros.MontoMaximo.ToString());
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "MontoAhorro", mensajeMonto);
                                    } else if(DiaDebito < 0 && DiaDebito > 30) {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "DiaDebito", "No es un día valido.");
                                    } else if(DepositoInicial < 0) {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "DepositoInicial", "Deposito Inicial tiene un monto no permitido.");
                                    }
                                    string Producto = string.Empty;
                                    //var combo = request.BodyRequest.Formulario.Formulario.Secciones[1].Secciones[0].Campos[2].ValoresCombobox;
                                    var Secciones = request.BodyRequest.Formulario.Formulario.Secciones;
                                    string[] ParametrosDatosCuenta = builder.GetSection("ParametrosAhorroProgramado:ParametrosDatosCuenta").Value.Split("|");
                                    bool aux = false;
                                    foreach (var IAAP in Secciones) {
                                        if(IAAP.Nombre.Trim() == ParametrosDatosCuenta[0]) {
                                            foreach (var DatosCta in IAAP.Secciones) {
                                                if(DatosCta.Nombre == ParametrosDatosCuenta[1]) {
                                                    foreach (var campo in DatosCta.Campos) {
                                                        if(campo.Codigo == ParametrosDatosCuenta[2] && campo.ValoresCombobox.Count > 0) {
                                                            foreach (var ValoresCombobox in campo.ValoresCombobox) {
                                                                string Codigo = ValoresCombobox.Codigo;
                                                                string complemento = ValoresCombobox.Complemento;
                                                                if (string.Equals(_Common.convertirDecimalString(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.CuentaAhorro), Codigo)) { 
                                                                    Producto = complemento; aux = true; break; 
                                                                }
                                                            }
                                                        }
                                                        if (aux) { break; }
                                                    }
                                                }
                                                if (aux) { break; }
                                            }
                                        }
                                        if (aux) { break; }
                                    }
                                    decimal MetaAhorro = _Common.StringDecimal(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.MontoAhorro) * _Common.StringDecimal(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.Plazo);
                                    Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API SimularContratoAhorroProgramado -> INICIO");
                                    SimuladorAhorroProgramadoResponse simulaContratacion = _sBanco.SimuladorAhorroProgramado(Producto, MetaAhorro, _Common.StringDecimal(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.DepositoInicial),
                                        _Common.StringDecimal(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.MontoAhorro), int.Parse(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.DiaDebito), int.Parse(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.Plazo),
                                        nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                    Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO SimularContratoAhorroProgramado -> RESPUESTA");
                                    SolicitarContratoA SolicitarContrato = new() {
                                        CodAgencia = int.Parse(valoresPersona.SP_Informacion_General.Datos_Generales.Codigo_Agencia),
                                        TipoDocumento = valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente,
                                        Documento = valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente,
                                        CuentaDebitar = decimal.Parse(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.CuentaDebito),
                                        CuentaAhorro = decimal.Parse(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.CuentaAhorro),
                                        CodMetaAhorro = valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.CodigoMotivoAhorro,
                                        MotivoAhorro = valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.MotivoAhorro,
                                        Oficial = valoresPersona.SP_Informacion_General.Datos_Generales.Ejecutivo_Oficial,
                                        Plazo = int.Parse(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.Plazo),
                                        DiaDebito = int.Parse(valoresPersona.SP_DatosAhorroProgramado.SimuladorContrato.DiaDebito),
                                        CorreoElectronico = valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Correo_Electronico1
                                    };
                                    obj.Add(simulaContratacion);
                                    obj.Add(SolicitarContrato);
                                    if (simulaContratacion != null) {
                                        if (simulaContratacion.CodigoRetorno != 0) {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", simulaContratacion.MensajeRetorno.ToString());
                                        }
                                        resultados = _Common.DeserializaObj(obj);
                                        respuesta = true;
                                    } else {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", MensajeGeneral);
                                    }
                                    #endregion
                                    break;
                                default:

                                    #region RF-2024-040 MEJORAS EN LA CALIDAD DE DATOS DEL DOMINIO DE CLIENTES - LDSB 20240318

                                    //Declaracion variables para validar
                                    string APENOM = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos.Trim();
                                    DateTime? FECNAC = valoresPersona.SP_Informacion_General.Datos_Basicos.Fecha_Nacimiento;
                                    string SEXO = valoresPersona.SP_Informacion_General.Datos_Basicos.Sexo.Trim();
                                    string ESTCIV = valoresPersona.SP_Informacion_General.Datos_Basicos.Estado_Civil.Trim();
                                    string APENOMCYG = valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge.Trim();
                                    string DIRDOM = valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Direccion.Trim();
                                    string DIROFI = valoresPersona.SP_Informacion_Direcciones.DireccionesOficina.Direccion.Trim();
                                    string CELDOM = valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Celular.Trim();

                                        #region VALIDACIONES PARA TODOS LOS CAMPOS OBTENIDOS DE REGISTRO CIVIL

                                            //validacion Apellido y Nombres
                                            if (String.IsNullOrEmpty(APENOM))
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_Y_APELLIDOS", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRES Y APELLIDOS.");
                                            }

                                            //validacion Fecha de Nacimiento
                                            if (!FECNAC.HasValue)
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_FECHA_DE_NACIMIENTO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO DE FECHA DE NACIMIENTO.");
                                            }

                                            //validacion Sexo
                                            if (String.IsNullOrEmpty(SEXO))
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_SEXO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO SEXO.");
                                            }

                                            //validacion Estado Civil
                                            if (String.IsNullOrEmpty(ESTCIV))
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_ESTADO_CIVIL", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO ESTADO CIVIL.");
                                            }

                                            //validacion Apellidos y Nombres de Conyuge
                                            if (ESTCIV == "C" || ESTCIV == "U")
                                            {
                                                if (String.IsNullOrEmpty(APENOMCYG))
                                                {
                                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_Y_APELLIDOS_DEL_CONYUGE", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRES Y APELLIDOS DEL CONYUGE.");
                                                }
                                            }


                                        #endregion

                                        #region Validacion Dirección de Domicilio
                                        if (String.IsNullOrEmpty(DIRDOM) || (DIRDOM.Length < 10 || DIRDOM.Length > 200))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_DOMICILIO", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE DOMICILIO.");
                                        }

                                        if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIRDOM))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_DOMICILIO", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE DOMICILIO.");
                                        }
                                        #endregion

                                        #region Validacion Dirección de Oficina
                                        if (!String.IsNullOrEmpty(DIROFI))
                                        {
                                            if (DIROFI.Length < 10 || DIROFI.Length > 200)
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_OFICINA", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE OFICINA.");
                                            }

                                            if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIROFI))
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_OFICINA", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE OFICINA.");
                                            }
                                        }

                                        #endregion

                                        #region Validacion Celular Domicilio

                                        if (string.IsNullOrEmpty(CELDOM))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO CELULAR DOMICILIO.");
                                        }

                                        if (!Validaciones.IniciaConCero(CELDOM))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "EL CAMPO CELULAR DOMICILIO DEBE INICIAR CON 0.");
                                        }

                                        if (Validaciones.TieneSeisCaracteresIgualesConsecutivosRegex(CELDOM))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "EL CAMPO CELULAR DOMICILIO EXCEDE LA CANTIDAD DE CARACTERES REPETIDOS CONSECUTIVAMENTE.");
                                        }
                                        #endregion
                                    
                                    #endregion

                                    #region Solicitud de cambio  

                                    SolicitudCambio solicitudCambio = new SolicitudCambio
                                    {
                                        UsuarioSolicitante = request.HeaderRequest.UserName,
                                        FechaSolicitud = DateTime.Now,
                                        Estado = "PENDIENTE",
                                        Data = JsonConvert.SerializeObject(valoresPersona),
                                        Accion = "EDICION",
                                        Funcionalidad = "PERSONA_NATURAL",
                                        DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                                        DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                                        TipoRol = request.BodyRequest.InfoUsuario.Rol,
                                        IdentificadorFuncionalidad = 1,
                                        DescripcionFuncionalidad = "PERSONA_NATURAL",
                                        IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente,
                                        DescripcionCambio = nombre,
                                        AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud, /*CAMBIO RF-2023-046 // ACT2*/
                                    };



                                    //SI NO TIENE DATOS SENSIBLES EDITADOS, SE APRUEBA AUTOMATICAMENTE
                                    if (!datosSensiblesModificados)
                                    {
                                        //CREAR SOLICITUD CAMBIOS
                                        long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);

                                        bodyResponse.Mensaje = "¡Actualización del cliente exitosa!";
                                        respuesta = _aprobador.AprobarSolicitudCambio(cambioId, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);

                                        firmantes.Add("TIPO", request.BodyRequest.Formulario.TipoPersona);
                                        firmantes.Add("FIRMANTE", valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos);
                                        firmantes.Add("FIRMANTE_DOC", valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente);
                                        firmantes.Add("FIRMANTE_CONYUGE", valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge);
                                        firmantes.Add("FIRMANTE_CONYUGE_DOC", valoresPersona.SP_Informacion_General.Datos_Conyuge.Identificacion_Conyuge);
                                    }
                                    else
                                    {
                                        solicitudCambio.CorreoClienteSolicitud = valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Correo_Electronico1;
                                        solicitudCambio.CorreoEjecutivoSolicitud = request.BodyRequest.InfoUsuario.Correo;
                                        //CREAR SOLICITUD CAMBIOS
                                        long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);
                                        Log.Information("BalconServicios/EnviarFormulario: Se crea cambio con id -> " + cambioId.ToString());
                                        respuesta = true;
                                        /*
                                        SE MODIFICO RF-2023-046 CONTINUAR CON EL PROCESO, MIENTRAS SE ESPERA QUE APRUEBEN LA SOLICITUD DE CAMBIOS //ACT 1
                                        headerResponseDto.returnCode = "PENDING";
                                        bodyResponse.Mensaje = "Se modificaron datos sensibles. Se envió una solicitud de aprobación a su supervisor. Aprobada la solicitud podrá continuar con el proceso.";*/

                                        headerResponseDto.returnCode = "OK";
                                        bodyResponse.Mensaje = "Se modificaron datos sensibles. Se envió una solicitud de aprobación a su supervisor. Aprobada la solicitud podrá continuar con el proceso.";


                                        firmantes.Add("TIPO", request.BodyRequest.Formulario.TipoPersona);
                                        firmantes.Add("FIRMANTE", valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos);
                                        firmantes.Add("FIRMANTE_DOC", valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente);
                                        firmantes.Add("FIRMANTE_CONYUGE", valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge);
                                        firmantes.Add("FIRMANTE_CONYUGE_DOC", valoresPersona.SP_Informacion_General.Datos_Conyuge.Identificacion_Conyuge);

                                        string tipoIdenti = valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente.Trim();
                                        switch (tipoIdenti)
                                        {
                                            case "N":
                                                tipoIdenti = "C";
                                                break;
                                            case "E":
                                                tipoIdenti = "P";
                                                break;
                                        }

                                        detalles.Add(new ValoresDetalleResumen
                                        {
                                            Etiqueta = "Tipo de Identificación",
                                            Valor = tipoIdenti
                                        });
                                        detalles.Add(new ValoresDetalleResumen
                                        {
                                            Etiqueta = "Identificación",
                                            Valor = valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente
                                        });
                                        detalles.Add(new ValoresDetalleResumen
                                        {
                                            Etiqueta = "Nombre",
                                            Valor = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos
                                        });
                                    }
                                    #endregion
                                    break;
                            }
                        }
                        else
                        {
                            #region RF-2024-040 MEJORAS EN LA CALIDAD DE DATOS DEL DOMINIO DE CLIENTES - LDSB 20240318

                                //Declaracion variables para validar
                                string APENOM = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos.Trim();
                                DateTime? FECNAC = valoresPersona.SP_Informacion_General.Datos_Basicos.Fecha_Nacimiento;
                                string SEXO = valoresPersona.SP_Informacion_General.Datos_Basicos.Sexo.Trim();
                                string ESTCIV = valoresPersona.SP_Informacion_General.Datos_Basicos.Estado_Civil.Trim();
                                string APENOMCYG = valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge.Trim();
                                string DIRDOM = valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Direccion.Trim();
                                string DIROFI = valoresPersona.SP_Informacion_Direcciones.DireccionesOficina.Direccion.Trim();
                                string CELDOM = valoresPersona.SP_Informacion_Direcciones.DireccionesDomicilio.Celular.Trim();

                                #region VALIDACIONES PARA TODOS LOS CAMPOS OBTENIDOS DE REGISTRO CIVIL

                                    //validacion Apellido y Nombres
                                    if (String.IsNullOrEmpty(APENOM))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_Y_APELLIDOS", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRES Y APELLIDOS.");
                                    }

                                    //validacion Fecha de Nacimiento
                                    if (!FECNAC.HasValue)
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_FECHA_DE_NACIMIENTO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO DE FECHA DE NACIMIENTO.");
                                    }

                                    //validacion Sexo
                                    if (String.IsNullOrEmpty(SEXO))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_SEXO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO SEXO.");
                                    }

                                    //validacion Estado Civil
                                    if (String.IsNullOrEmpty(ESTCIV))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_ESTADO_CIVIL", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO ESTADO CIVIL.");
                                    }

                                    //validacion Apellidos y Nombres de Conyuge
                                    if (ESTCIV == "C" || ESTCIV == "U")
                                    {
                                        if (String.IsNullOrEmpty(APENOMCYG))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_Y_APELLIDOS_DEL_CONYUGE", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRES Y APELLIDOS DEL CONYUGE.");
                                        }
                                    }


                                #endregion

                                #region Validacion Dirección de Domicilio
                                    if (String.IsNullOrEmpty(DIRDOM) || (DIRDOM.Length < 10 || DIRDOM.Length > 200))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_DOMICILIO", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE DOMICILIO.");
                                    }

                                    if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIRDOM))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_DOMICILIO", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE DOMICILIO.");
                                    }
                                #endregion

                                #region Validacion Dirección de Oficina
                                    if (!String.IsNullOrEmpty(DIROFI))
                                    {
                                        if (DIROFI.Length < 10 || DIROFI.Length > 200)
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_OFICINA", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE OFICINA.");
                                        }

                                        if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIROFI))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_OFICINA", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE OFICINA.");
                                        }
                                    }

                                #endregion

                                #region Validacion Celular Domicilio

                                    if (string.IsNullOrEmpty(CELDOM))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO CELULAR DOMICILIO.");
                                    }

                                    if (!Validaciones.IniciaConCero(CELDOM))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "EL CAMPO CELULAR DOMICILIO DEBE INICIAR CON 0.");
                                    }

                                    if (Validaciones.TieneSeisCaracteresIgualesConsecutivosRegex(CELDOM))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "EL CAMPO CELULAR DOMICILIO EXCEDE LA CANTIDAD DE CARACTERES REPETIDOS CONSECUTIVAMENTE.");
                                    }
                                #endregion

                            #endregion
                            
                            SolicitudCambio solicitudCambio = new SolicitudCambio
                            {
                                UsuarioSolicitante = request.HeaderRequest.UserName,
                                FechaSolicitud = DateTime.Now,
                                Estado = "PENDIENTE",
                                Data = JsonConvert.SerializeObject(valoresPersona),
                                Accion = "CREACION",
                                Funcionalidad = "PERSONA_NATURAL",
                                DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                                DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                                TipoRol = "",
                                IdentificadorFuncionalidad = 1,
                                DescripcionFuncionalidad = "PERSONA_NATURAL",
                                IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente,
                                DescripcionCambio = nombre,
                                AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud /*CAMBIO RF-2023-046 // ACT2*/
                            };

                            //Inicio: Validar si es PEPs o Lista Negra
                            if (valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente != "E")
                            {
                                string cedula = valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente.Substring(0, 10);
                                ErrorMapeoMensaje mensajePeps = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO PEPS -> INICIO");
                                bool esPeps = _sBanco.ValidarPersonaExpuestaPoliticamente(cedula, nutCliente, request.HeaderRequest.UserName,
                                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajePeps);
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO PEPS -> RESPUESTA");
                                if (esPeps)
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_PEPS", "Por restricciones en el sistema, no puede continuar con el proceso.");
                                }
                            }

                            //Verificar Lista Negra
                            ErrorMapeoMensaje mensajeListasNegras = new ErrorMapeoMensaje();
                            Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO LISTAS NEGRAS -> INICIO");

                            bool enListasNegras = _sBanco.ValidarListasNegras(valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos, valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente, valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente, nutCliente, request.HeaderRequest.UserName,
                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeListasNegras);

                            Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO LISTAS NEGRAS -> RESPUESTA");

                            if (enListasNegras)
                            {
                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_LISTA_NEGRA", "Por restricciones en el sistema, no puede continuar con el proceso.");
                            }

                            //End: Validar si es PEPs o Lista Negra

                            //CREAR SOLICITUD CAMBIOS
                            long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);

                            respuesta = _aprobador.AprobarSolicitudCambio(cambioId, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);
                                                        
                            firmantes.Add("TIPO", request.BodyRequest.Formulario.TipoPersona);
                            firmantes.Add("FIRMANTE", valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos);
                            firmantes.Add("FIRMANTE_DOC", valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente);
                            firmantes.Add("FIRMANTE_CONYUGE", valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge);
                            firmantes.Add("FIRMANTE_CONYUGE_DOC", valoresPersona.SP_Informacion_General.Datos_Conyuge.Identificacion_Conyuge);

                            bodyResponse.Mensaje = "¡Creación del cliente exitosa!";
                        }
                    }
                    #endregion
                }
                else if (request.BodyRequest.Formulario.TipoPersona == "J")
                {
                    if (request.BodyRequest.Formulario.Formulario != null && request.BodyRequest.Formulario.Formulario.Secciones != null && request.BodyRequest.Formulario.Formulario.Secciones.Count > 0)
                    {
                        dictPersona = ConvertirFormularioADiccionario(request.BodyRequest.Formulario.Formulario.Secciones, typeof(DatosPersonaJuridica), ref dictValoresAntes, ref dictValoresDespues, ref datosSensiblesModificados);
                    }

                    #region CREACION PERSONA JURIDICA
                    if (dictPersona != null)
                    {
                        DatosPersonaJuridica valoreJuridico = ConvertirDiccionarioAObjeto<DatosPersonaJuridica>(dictPersona);

                        valoreJuridico.SP_Informacion_Financiera.Ingreso_Patrimonio.Usuario = valoreJuridico.SP_Informacion_Financiera.Ingreso_Patrimonio.IdentificacionUsuario;

                        int cantidadAccionistas = 0;
                        if (valoreJuridico.SP_Informacion_Accionistas.Accionistas != null)
                        {
                            cantidadAccionistas = valoreJuridico.SP_Informacion_Accionistas.Accionistas.FindAll(x => x.AccionCRUD != "D").Count;
                        }


                        #region RF-2024-040 MEJORAS EN LA CALIDAD DE DATOS DEL DOMINIO DE CLIENTES - LDSB 20240318

                            //Declaracion variables para validar
                            string NOMEMP = valoreJuridico.SP_Informacion_General.Datos_Basicos.Nombre_Empresa.Trim();
                            string DIREMP = valoreJuridico.SP_Informacion_Direcciones.Direccion.Direccion.Trim();
                            string CELEMP = valoreJuridico.SP_Informacion_Direcciones.Direccion.Celular.Trim();

                            #region VALIDACIONES PARA NOMBRES DE EMPRESA

                                //validacion Nombre de Empresa
                                if (String.IsNullOrEmpty(NOMEMP))
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_EMPRESA", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRE EMPRESA.");
                                }

                            #endregion

                            #region Validacion Dirección de Empresa
                                if (String.IsNullOrEmpty(DIREMP) || (DIREMP.Length < 10 || DIREMP.Length > 200))
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_EMPRESA", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE EMPRESA.");
                                }

                                if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIREMP))
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_EMPRESA", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE EMPRESA.");
                                }
                            #endregion

                            #region Validacion Celular Empresa

                                if (string.IsNullOrEmpty(CELEMP))
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_EMPRESA", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO CELULAR EMPRESA.");
                                }

                                if (!Validaciones.IniciaConCero(CELEMP))
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_EMPRESA", "EL CAMPO CELULAR EMPRESA DEBE INICIAR CON 0.");
                                }

                                if (Validaciones.TieneSeisCaracteresIgualesConsecutivosRegex(CELEMP))
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_EMPRESA", "EL CAMPO CELULAR EMPRESA EXCEDE LA CANTIDAD DE CARACTERES REPETIDOS CONSECUTIVAMENTE.");
                                }
                            #endregion


                        #endregion


                        #region VALIDAR ACCIONISTAS
                        if (valoreJuridico.SP_Informacion_Accionistas.Accionistas == null || cantidadAccionistas == 0)
                        {
                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "PORCENTAJE_ACCIONISTAS", "PORCENTAJE NO IGUAL AL 100%.");
                        }
                        else
                        {                            
                            if (valoreJuridico.SP_Informacion_Accionistas.Cantidad_Accionistas != cantidadAccionistas)
                            {
                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CANTIDAD_ACCIONISTAS", "DEBE INGRESAR LA MISMA CANTIDAD DE LOS ACCIONISTAS INGRESADO EN CANTIDAD ACCIONISTAS");
                            }
                            decimal suma = 0m;
                            for (int i = 0; i < valoreJuridico.SP_Informacion_Accionistas.Accionistas.Count; i++)
                            {
                                var accionista = valoreJuridico.SP_Informacion_Accionistas.Accionistas[i];
                                suma += accionista.AccionCRUD != "D" ? accionista.Valor_Aporte : 0;

                                if (accionista.AccionCRUD != "D")
                                {
                                    if (!Validaciones.ValidarIdentificacion(accionista.Tipo_Identidad_Accionista, accionista.Dcto_Identidad_Accionista))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_ACCIONISTAS", $"IDENTIFICACIÓN DEL ACCIONISTA {accionista.Nombre_Accionista} NO VÁLIDA");
                                    }
                                }

                                #region RF-2024-040 MEJORAS EN LA CALIDAD DE DATOS DEL DOMINIO DE CLIENTES - LDSB 20240318

                                    //Declaracion variables para validar  
                                    string NOMACCI = accionista.Nombre_Accionista.Trim();  
                                    string DIRACCI = accionista.Direccion.Trim();
                                    string CELACCI = accionista.Celular.Trim();

                                    #region Valida Nombre O Razón Social del Accionista
                                    if (String.IsNullOrEmpty(NOMACCI))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_ACCIONISTA", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRE O RAZON SOCIAL DEL ACCIONISTA.");
                                        }
                                    #endregion

                                    #region Valida Direccion Domicilio del Accionista
                                        if (String.IsNullOrEmpty(DIRACCI) || (DIRACCI.Length < 10 || DIRACCI.Length > 200))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_ACCIONISTA", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DEL DOMICILIO DEL ACCIONISTA.");
                                        }

                                        if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIRACCI))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_ACCIONISTA", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DEL DOMICILIO DEL ACCIONISTA.");
                                        }
                                    #endregion

                                    #region Valida Celular del Accionista
                                        if (string.IsNullOrEmpty(CELACCI))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_ACCIONISTA", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO CELULAR DEL ACCIONISTA.");
                                        }

                                        if (!Validaciones.IniciaConCero(CELACCI))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_ACCIONISTA", "EL CAMPO CELULAR DEL ACCIONISTA DEBE INICIAR CON 0.");
                                        }

                                        if (Validaciones.TieneSeisCaracteresIgualesConsecutivosRegex(CELACCI))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_ACCIONISTA", "EL CAMPO CELULAR DEL ACCIONISTA EXCEDE LA CANTIDAD DE CARACTERES REPETIDOS CONSECUTIVAMENTE.");
                                        }
                                    #endregion
                                #endregion 


                                #region Validar si accionista es representante legal
                                for (int l = 0; l < valoreJuridico.SP_Informacion_Representante_Legal.Representantes.Count; l++)
                                {
                                    var repLegal = valoreJuridico.SP_Informacion_Representante_Legal.Representantes[l];
                                    if (repLegal.Dcto_Identidad_Representante == accionista.Dcto_Identidad_Accionista && repLegal.Tipo_Identidad_Representante == accionista.Tipo_Identidad_Accionista)
                                    {
                                        if (accionista.Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador != repLegal.Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador)
                                        {
                                            //TODO: ERROR POR DIFERENCIA EN S/N RESIDENCIA FISCAL
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "ERROR", $"EL ACCIONISTA {accionista.Nombre_Accionista} TAMBIEN ES REPRESENTANTE LEGAL Y TIENE RESPUESTA DIFERENTE EN RESIDENCIA FISCAL");
                                        }

                                        if (accionista.Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador == "S" && repLegal.Tiene_Residencia_Fiscal_Pais_Diferente_Ecuador == "S")
                                        {
                                            if (accionista.Seleccione_Pais != repLegal.Seleccione_Pais)
                                            {
                                                //TODO: ERROR POR DIFERENCIA EN SELECCION DE PAIS RESIDENCIA FISCAL
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "ERROR", $"EL ACCIONISTA {accionista.Nombre_Accionista} TAMBIEN ES REPRESENTANTE LEGAL Y TIENE RESPUESTA DIFERENTE EN RESIDENCIA FISCAL");
                                            }

                                            if (accionista.Numero_Id_Tributaria != repLegal.Numero_Id_Tributaria)
                                            {
                                                //TODO: ERROR POR DIFERENCIA EN ID TRIBUTARIA DE PAIS RESIDENCIA FISCAL
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "ERROR", $"EL ACCIONISTA {accionista.Nombre_Accionista} TAMBIEN ES REPRESENTANTE LEGAL Y TIENE RESPUESTA DIFERENTE EN RESIDENCIA FISCAL");
                                            }

                                            if (accionista.Direccion_Residencia_Fiscal != repLegal.Direccion_Residencia_Fiscal)
                                            {
                                                //TODO: ERROR POR DIFERENCIA EN ID TRIBUTARIA DE PAIS RESIDENCIA FISCAL
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "ERROR", $"EL ACCIONISTA {accionista.Nombre_Accionista} TAMBIEN ES REPRESENTANTE LEGAL Y TIENE RESPUESTA DIFERENTE EN RESIDENCIA FISCAL");
                                            }
                                        }
                                        
                                    }
                                }
                                #endregion

                                bool clienteBanco = false;

                                //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO CLIENTES -> INICIO");
                                var valoresPersona = _sBanco.ConsultarClienteNatural(accionista.Tipo_Identidad_Accionista, accionista.Dcto_Identidad_Accionista, nutCliente, request.HeaderRequest.UserName,
                                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO CLIENTES -> RESPUESTA");

                                if (valoresPersona != null)
                                {
                                    clienteBanco = valoresPersona.EsCliente;
                                    if (clienteBanco)
                                    {
                                        //verificar actualizacion datos
                                        //VALIDAR FECHA ULTIMA ACTUALIZACION
                                        DateTime fechaAct = valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaCreacion;

                                        if ((valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima != null
                                            && valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima.Year > 1)
                                            || valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima > fechaAct)
                                        {
                                            fechaAct = valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima;
                                        }

                                        DateTime today = DateTime.Today;

                                        if (today.Subtract(fechaAct).Days > 365)
                                        {
                                            headerResponseDto.returnMessage = "ACTUALIZAR DATOS";
                                        }

                                        //validar peps
                                        if (accionista.Tipo_Identidad_Accionista != "E" && accionista.Tipo_Persona != "J" && accionista.AccionCRUD != "D")
                                        {
                                            
                                            //string cedula = accionista.Dcto_Identidad_Accionista.Substring(0, 10);
                                            string cedula = accionista.Dcto_Identidad_Accionista;
                                            ErrorMapeoMensaje mensajePeps = new ErrorMapeoMensaje();
                                            Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO PEPS -> INICIO");
                                            bool esPeps = _sBanco.ValidarPersonaExpuestaPoliticamente(cedula, nutCliente, request.HeaderRequest.UserName,
                                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajePeps);
                                            Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO PEPS -> RESPUESTA");
                                            if (esPeps)
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_PEPS", "Por restricciones en el sistema, no puede continuar con el proceso.");
                                            }
                                        }
                                        
                                    }
                                }

                                if (accionista.AccionCRUD != "D")
                                {
                                    //verificar lista negra, peps
                                    ErrorMapeoMensaje mensajeListasNegras = new ErrorMapeoMensaje();
                                    Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO LISTAS NEGRAS -> INICIO");
                                    Log.Information($"BalconServicios/EnviarFormularioPersona: {accionista.Nombre_Accionista} | {accionista.Tipo_Identidad_Accionista} | {accionista.Dcto_Identidad_Accionista}");
                                    bool enListasNegras = _sBanco.ValidarListasNegras(accionista.Nombre_Accionista, accionista.Tipo_Identidad_Accionista, accionista.Dcto_Identidad_Accionista, nutCliente, request.HeaderRequest.UserName,
                                        request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeListasNegras);
                                    Log.Information($"BalconServicios/EnviarFormularioPersona: Consulta API BANCO LISTAS NEGRAS -> RESPUESTA {enListasNegras}");

                                    if (enListasNegras)
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_LISTA_NEGRA", "Por restricciones en el sistema, no puede continuar con el proceso.");
                                    }
                                }
                            }

                            if (suma != valoreJuridico.SP_Informacion_Accionistas.Capital_Suscrito) {
                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "PORCENTAJE_ACCIONISTAS", "PORCENTAJE NO IGUAL AL 100%.");
                            }
                        }
                        #endregion

                        #region VALIDAR REPLEGAL
                        if (valoreJuridico.SP_Informacion_Representante_Legal.Representantes != null && valoreJuridico.SP_Informacion_Representante_Legal.Representantes.Count > 0)
                        {

                            for (int i = 0; i < valoreJuridico.SP_Informacion_Representante_Legal.Representantes.Count; i++)
                            {
                                var replegal = valoreJuridico.SP_Informacion_Representante_Legal.Representantes[i];

                                if (!Validaciones.ValidarIdentificacion(replegal.Tipo_Identidad_Representante, replegal.Dcto_Identidad_Representante))
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_ACCIONISTAS", $"IDENTIFICACIÓN DEL REP. LEGAL {replegal.Nombre_Representante} NO VÁLIDA");
                                }

                                #region RF-2024-040 MEJORAS EN LA CALIDAD DE DATOS DEL DOMINIO DE CLIENTES - LDSB 20240318

                                    //Declaracion variables para validar  
                                    string NOMREP = replegal.Nombre_Representante.Trim();
                                    string DIRREP = replegal.Direccion;
                                    string CELREP = replegal.Celular.Trim();

                                    #region Valida Nombre O Razón Social del Accionista
                                    if (String.IsNullOrEmpty(NOMREP))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_REPRESENTANTE_LEGAL", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRE DEL REPRESENTANTE LEGAL.");
                                    }
                                    #endregion

                                    #region Valida Direccion Domicilio del Accionista
                                    if (String.IsNullOrEmpty(DIRREP) || (DIRREP.Length < 10 || DIRREP.Length > 200))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_REPRESENTANTE_LEGAL", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DEL DOMICILIO DEL REPRESENTANTE LEGAL.");
                                    }

                                    if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIRREP))
                                    {
                                        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_REPRESENTANTE_LEGAL", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DEL DOMICILIO DEL REPRESENTANTE LEGAL.");
                                    }
                                    #endregion

                                    #region Valida Celular del Accionista
                                    if (!string.IsNullOrEmpty(CELREP))
                                    {
                                        //ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_REPRESENTANTE_LEGAL", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO CELULAR DEL ACCIONISTA.");
                                        if (!Validaciones.IniciaConCero(CELREP))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_REPRESENTANTE_LEGAL", "EL CAMPO CELULAR DEL REPRESENTANTE LEGAL DEBE INICIAR CON 0.");
                                        }

                                        if (Validaciones.TieneSeisCaracteresIgualesConsecutivosRegex(CELREP))
                                        {
                                            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_REPRESENTANTE_LEGAL", "EL CAMPO CELULAR DEL REPRESENTANTE LEGAL EXCEDE LA CANTIDAD DE CARACTERES REPETIDOS CONSECUTIVAMENTE.");
                                        }
                                    }

                                    #endregion
                                #endregion

                                bool clienteBanco = false;

                                //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO CLIENTES -> INICIO");
                                var valoresPersona = _sBanco.ConsultarClienteNatural(replegal.Tipo_Identidad_Representante, replegal.Dcto_Identidad_Representante, nutCliente, request.HeaderRequest.UserName,
                                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO CLIENTES -> RESPUESTA");

                                if (valoresPersona != null)
                                {
                                    clienteBanco = valoresPersona.EsCliente;
                                    if (clienteBanco)
                                    {
                                        //verificar actualizacion datos
                                        //VALIDAR FECHA ULTIMA ACTUALIZACION
                                        DateTime fechaAct = valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaCreacion;

                                        if ((valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima != null
                                            && valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima.Year > 1)
                                            || valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima > fechaAct)
                                        {
                                            fechaAct = valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima;
                                        }

                                        DateTime today = DateTime.Today;

                                        if (today.Subtract(fechaAct).Days > 365)
                                        {
                                            headerResponseDto.returnMessage = "ACTUALIZAR DATOS";
                                        }

                                        //validar peps
                                        if (replegal.Tipo_Identidad_Representante != "E")
                                        {
                                            string cedula = replegal.Dcto_Identidad_Representante.Substring(0, 10);
                                            ErrorMapeoMensaje mensajePeps = new ErrorMapeoMensaje();
                                            Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO PEPS -> INICIO");
                                            bool esPeps = _sBanco.ValidarPersonaExpuestaPoliticamente(cedula, nutCliente, request.HeaderRequest.UserName,
                                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajePeps);
                                            Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO PEPS -> RESPUESTA");
                                            if (esPeps)
                                            {
                                                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_PEPS", "Por restricciones en el sistema, no puede continuar con el proceso.");
                                            }
                                        }

                                    }
                                }

                                //verificar lista negra, peps
                                ErrorMapeoMensaje mensajeListasNegras = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO LISTAS NEGRAS -> INICIO");

                                bool enListasNegras = _sBanco.ValidarListasNegras(replegal.Nombre_Representante, replegal.Tipo_Identidad_Representante, replegal.Dcto_Identidad_Representante, nutCliente, request.HeaderRequest.UserName,
                                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeListasNegras);
                                Log.Information("BalconServicios/EnviarFormularioPersona: Consulta API BANCO LISTAS NEGRAS -> RESPUESTA");

                                if (enListasNegras)
                                {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "CEDULA_LISTA_NEGRA", "Por restricciones en el sistema, no puede continuar con el proceso.");
                                }
                            }
                        }
                        #endregion

                        string nombre = valoreJuridico.SP_Informacion_General.Datos_Basicos.Nombre_Empresa;
                        //CREACION/EDICION CLIENTE PERSONA NATURAL SIN PRODUCTO
                        if (valoreJuridico.EsCliente)
                        {
                            SolicitudCambio solicitudCambio = new SolicitudCambio
                            {
                                UsuarioSolicitante = request.HeaderRequest.UserName,
                                FechaSolicitud = DateTime.Now,
                                Estado = "PENDIENTE",
                                Data = JsonConvert.SerializeObject(valoreJuridico),
                                Accion = "EDICION",
                                Funcionalidad = "PERSONA_JURIDICA",
                                DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                                DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                                TipoRol = "",
                                IdentificadorFuncionalidad = 2,
                                DescripcionFuncionalidad = "PERSONA_JURIDICA",
                                IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoreJuridico.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente,
                                DescripcionCambio = nombre,
                                AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud /*CAMBIO RF-2023-046 // ACT2*/
                            };

                            //SI NO TIENE DATOS SENSIBLES EDITADOS, SE APRUEBA AUTOMATICAMENTE
                            if (!datosSensiblesModificados)
                            {
                                //CREAR SOLICITUD CAMBIOS
                                long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);
                                Log.Information("BalconServicios/EnviarFormulario: Se crea cambio con id -> " + cambioId.ToString());
                                bodyResponse.Mensaje = "¡Actualización del cliente exitosa!";
                                respuesta = _aprobador.AprobarSolicitudCambio(cambioId, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);

                                var representante = valoreJuridico.SP_Informacion_Representante_Legal.Representantes.First();

                                firmantes.Add("TIPO", request.BodyRequest.Formulario.TipoPersona);
                                firmantes.Add("FIRMANTE", representante.Nombre_Representante);
                                firmantes.Add("FIRMANTE_DOC", representante.Dcto_Identidad_Representante);
                            }
                            else
                            {
                                solicitudCambio.CorreoClienteSolicitud = valoreJuridico.SP_Informacion_Direcciones.Direccion.Correo_Electronico1;
                                solicitudCambio.CorreoEjecutivoSolicitud = request.BodyRequest.InfoUsuario.Correo;
                                //CREAR SOLICITUD CAMBIOS
                                long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);
                                Log.Information("BalconServicios/EnviarFormulario: Se crea cambio con id -> " + cambioId.ToString());
                                respuesta = true;
                                /*headerResponseDto.returnCode = "PENDING";
                                bodyResponse.Mensaje = "Se modificaron datos sensibles. Se envió una solicitud de aprobación a su supervisor. Aprobada la solicitud podrá continuar con el proceso.";
                                SE MODIFICO RF-2023-046 CONTINUAR CON EL PROCESO, MIENTRAS SE ESPERA QUE APRUEBEN LA SOLICITUD DE CAMBIOS //ACT 1
                                */

                                headerResponseDto.returnCode = "OK";
                                bodyResponse.Mensaje = "Se modificaron datos sensibles. Se envió una solicitud de aprobación a su supervisor. Aprobada la solicitud podrá continuar con el proceso.";

                                var representante = valoreJuridico.SP_Informacion_Representante_Legal.Representantes.First();

                                firmantes.Add("TIPO", request.BodyRequest.Formulario.TipoPersona);
                                firmantes.Add("FIRMANTE", representante.Nombre_Representante);
                                firmantes.Add("FIRMANTE_DOC", representante.Dcto_Identidad_Representante);


                                detalles.Add(new ValoresDetalleResumen
                                {
                                    Etiqueta = "Tipo de Identificación",
                                    Valor = valoreJuridico.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente
                                });
                                detalles.Add(new ValoresDetalleResumen
                                {
                                    Etiqueta = "Identificación",
                                    Valor = valoreJuridico.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente
                                });
                                detalles.Add(new ValoresDetalleResumen
                                {
                                    Etiqueta = "Nombre Empresa",
                                    Valor = valoreJuridico.SP_Informacion_General.Datos_Basicos.Nombre_Empresa
                                });
                            }

                        }
                        else
                        {
                            SolicitudCambio solicitudCambio = new SolicitudCambio
                            {
                                UsuarioSolicitante = request.HeaderRequest.UserName,
                                FechaSolicitud = DateTime.Now,
                                Estado = "PENDIENTE",
                                Data = JsonConvert.SerializeObject(valoreJuridico),
                                Accion = "CREACION",
                                Funcionalidad = "PERSONA_JURIDICA",
                                DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                                DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                                TipoRol = "",
                                IdentificadorFuncionalidad = 2,
                                DescripcionFuncionalidad = "PERSONA_JURIDICA",
                                IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoreJuridico.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente,
                                DescripcionCambio = nombre,
                                AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud /*CAMBIO RF-2023-046 // ACT2*/
                            };

                            //CREAR SOLICITUD CAMBIOS
                            long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);

                            respuesta = _aprobador.AprobarSolicitudCambio(cambioId, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);

                            var representante = valoreJuridico.SP_Informacion_Representante_Legal.Representantes.First();

                            firmantes.Add("TIPO", request.BodyRequest.Formulario.TipoPersona);
                            firmantes.Add("FIRMANTE", representante.Nombre_Representante);
                            firmantes.Add("FIRMANTE_DOC", representante.Dcto_Identidad_Representante);

                            bodyResponse.Mensaje = "¡Creación del cliente exitosa!";

                        }
                    }
                    #endregion
                }
                
                if (respuesta)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                    bodyResponse.Mensaje = "";

                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "ERROR_SWITCH", "Por un problema con los servicios, no se puede continuar con el proceso.");
                }
                //Create Body Response
                bodyResponse.Resultado = resultados;
                bodyResponse.Detalles = detalles;
                bodyResponse.Firmantes = firmantes;
                //bodyResponse.Mensaje = "OK";

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EnviarFormulario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
        
        public EnviarFormularioResponse EnviarFormularioProducto(EnviarFormularioRequest request) {
            try {
                EnviarFormularioResponse response = new EnviarFormularioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EnviarFormularioResponseBody bodyResponse = new EnviarFormularioResponseBody();
                bool respuesta = false;

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                bool datosSensibles = false;
                Dictionary<string, dynamic> resultados = new Dictionary<string, dynamic>();
                List<ValoresDetalleResumen> detalles = new List<ValoresDetalleResumen>();
                Dictionary<string, string> firmantes = new Dictionary<string, string>();

                Dictionary<string, dynamic> dictProducto = null;
                Dictionary<string, dynamic> dictValoresAntes = new Dictionary<string, dynamic>();
                Dictionary<string, dynamic> dictValoresDespues = new Dictionary<string, dynamic>();
                SecuencialAhorroProgramado secuencialDocume = new();

                ErrorMapeoMensaje mensajeObtenerSecuencial = new ErrorMapeoMensaje();

                if (request.BodyRequest.Formulario.TipoPersona == "N") {
                    var opcSwitch = request.BodyRequest.Formulario.Formulario.Codigo;
                    if (request.BodyRequest.Formulario.Formulario != null && request.BodyRequest.Formulario.Formulario.Secciones != null && request.BodyRequest.Formulario.Formulario.Secciones.Count > 0) {
                        dictProducto = ConvertirFormularioADiccionario(request.BodyRequest.Formulario.Formulario.Secciones, typeof(DatosCuentaAhorro), ref dictValoresAntes, ref dictValoresDespues, ref datosSensibles);
                    }
                    //var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("icAppConfig.json").Build();
                    string canal = builder.GetSection("ParametrosAhorroProgramado:IdCanal").Value;
                    string servicio = builder.GetSection("ParametrosAhorroProgramado:Servicio").Value;
                    ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                    object obj ;
                    var datetime = DateTime.Now;
                    //HeaderRequest header = request.HeaderRequest;
                    MonitorBalconRequestBody body = new MonitorBalconRequestBody();
                    long MonitorBalcon;
                    string contra;
                    switch (opcSwitch) {
                        #region seccion que no es de Ahorro Programado
                        case "AHO":
                            if (request.BodyRequest.Formulario.TipoCliente != "01") {
                                ErrorUtil.ThrowAppException("EnviarFormularioProducto", "", ".");
                            } 
                            DatosCuentaAhorro valoresCuentaAhorro = ConvertirDiccionarioAObjeto<DatosCuentaAhorro>(dictProducto);
                            if (valoresCuentaAhorro.Cotitulares != null && valoresCuentaAhorro.Cotitulares.Count > 0) {
                                valoresCuentaAhorro.Cotitulares.ForEach(cotitu => {
                                    cotitu.TipoMoneda = 1;
                                    if (int.TryParse(valoresCuentaAhorro.Moneda, out int valInt)) {
                                        cotitu.TipoMoneda = valInt;
                                    }
                                });
                            }
                            valoresCuentaAhorro.Usuario_Creacion = valoresCuentaAhorro.IdentificacionUsuario;
                            SolicitudCambio solicitudCambioAHO = new SolicitudCambio {
                                UsuarioSolicitante = request.HeaderRequest.UserName,
                                FechaSolicitud = DateTime.Now,
                                Estado = "PENDIENTE",
                                Data = JsonConvert.SerializeObject(valoresCuentaAhorro),
                                Accion = "CREACION",
                                Funcionalidad = "CUENTA_AHORRO_PN",
                                DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                                DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                                TipoRol = "",
                                IdentificadorFuncionalidad = 3,
                                DescripcionFuncionalidad = "CUENTA_AHORRO_PN",
                                IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoresCuentaAhorro.Dcto_Identidad_Cliente,
                                AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud, /*RF-2023-046*/
                            };
                            //CREAR SOLICITUD CAMBIOS
                            long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambioAHO);
                            respuesta = _aprobador.AprobarSolicitudCambio(cambioId, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);
                            /*firmantes.Add("FIRMANTE", valoresCuentaAhorro.Nombre_Representante_Legal);
                            firmantes.Add("FIRMANTE_DOC", valoresCuentaAhorro.Documento_Representante_Legal);
                            firmantes.Add("FIRMANTE_CONYUGE", valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge);
                            firmantes.Add("FIRMANTE_CONYUGE_DOC", valoresPersona.SP_Informacion_General.Datos_Conyuge.Identificacion_Conyuge);*/
                            break;
                        case "CTE":
                            /*if (request.BodyRequest.Formulario.Formulario != null && request.BodyRequest.Formulario.Formulario.Secciones != null && request.BodyRequest.Formulario.Formulario.Secciones.Count > 0) {
                                dictProducto = ConvertirFormularioADiccionario(request.BodyRequest.Formulario.Formulario.Secciones, typeof(DatosCuentaCorriente), ref dictValoresAntes, ref dictValoresDespues, ref datosSensibles);
                            }*/
                            DatosCuentaCorriente valoresCuentaCorriente = ConvertirDiccionarioAObjeto<DatosCuentaCorriente>(dictProducto);
                            //valoresCuentaCorriente.DatosGeneralChequera.TipoChequera = valoresCuentaCorriente.DatosGeneralChequera.TipoChequera.Split("-").First();
                            SolicitudCambio solicitudCambioCTE = new SolicitudCambio {
                                UsuarioSolicitante = request.HeaderRequest.UserName,
                                FechaSolicitud = DateTime.Now,
                                Estado = "PENDIENTE",
                                Data = JsonConvert.SerializeObject(valoresCuentaCorriente),
                                Accion = "CREACION",
                                Funcionalidad = "CUENTA_CORRIENTE_PN",
                                DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                                DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                                TipoRol = "",
                                IdentificadorFuncionalidad = 4,
                                DescripcionFuncionalidad = "CUENTA_CORRIENTE_PN",
                                IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoresCuentaCorriente.Dcto_Identidad_Cliente,
                                AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud, /*RF-2023-046*/
                            };
                            //CREAR SOLICITUD CAMBIOS
                            long cambioIdCTE = _aprobador.CrearSolicitudCambio(solicitudCambioCTE);
                            respuesta = _aprobador.AprobarSolicitudCambio(cambioIdCTE, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);
                            /*firmantes.Add("FIRMANTE", valoresCuentaCorriente.Nombre_Representante_Legal);
                            firmantes.Add("FIRMANTE_DOC", valoresCuentaCorriente.Documento_Representante_Legal);
                            firmantes.Add("0FIRMANTE_CONYUGE", valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge);
                            firmantes.Add("FIRMANTE_CONYUGE_DOC", valoresPersona.SP_Informacion_General.Datos_Conyuge.Identificacion_Conyuge);*/
                            break;
                        #endregion
                        case "CAN_AHPR": //--> Cancelacion de Ahorro Programado
                            CancelarContrato cancelarContrato = ConvertirDiccionarioAObjeto<CancelarContrato>(dictProducto);
                            //cancelarContrato.CorreoElectronico = request.BodyRequest.InfoUsuario.Correo;
                            cancelarContrato.UserAS = "";
                            CancelarContratoResponse cancelarContratoExtResponse = new();

                            //ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                            Log.Information("AhorroProgramado/CancelarContrato: Consulta API CancelarContratoAhorroProgramado -> INICIO");
                            cancelarContratoExtResponse = _sBanco.CancelarContrato(cancelarContrato.contrato, cancelarContrato.TipoDocumento, cancelarContrato.Documento,
                                cancelarContrato.CuentaAhorro, canal, request.BodyRequest.InfoUsuario.ExecutiveCode, cancelarContrato.MotivoCancelacion, "BalconAP",
                                cancelarContrato.CorreoElectronico, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp,
                                "NutCliente", new DateTime(), nutCliente, ref mensaje);
                            Log.Information("AhorroProgramado/CancelarContrato: Consulta API BANCO CancelarContratoAhorroProgramado -> RESPUESTA");
                            obj = cancelarContratoExtResponse;
                            if (cancelarContratoExtResponse != null) {
                                if (cancelarContratoExtResponse.CodigoRetorno != 0) {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", cancelarContratoExtResponse.MensajeRetorno.ToString());
                                }
                                resultados = _Common.DeserializaObj(obj);
                                respuesta = true;
                                detalles.Add(new ValoresDetalleResumen() { Etiqueta = "Cuenta", Valor = cancelarContrato.CuentaAhorro.ToString() });
                            } else {
                                resultados.Add("CodigoRetornoS", string.Empty);
                                resultados.Add("MensajeRetornoS", "Error");
                            }
                            contra = _Common.convertirDecimalString(cancelarContrato.contrato);
                            body.CodigoProceso = "10002";
                            body.fecha = datetime.ToShortDateString();
                            body.Hora = datetime.ToShortTimeString();
                            body.CodigoEvento = "1433";
                            body.TipoIdentificacion = cancelarContrato.TipoDocumento;
                            body.Identificacion = cancelarContrato.Documento.PadLeft(10, '0');
                            body.Cuenta = cancelarContrato.CuentaAhorro.ToString();
                            body.Oficial = request.BodyRequest.InfoUsuario.ExecutiveCode;
                            body.Agencia = request.BodyRequest.InfoUsuario.AgencyCode;
                            body.Referencia = cancelarContratoExtResponse.MensajeRetorno == null ? "" : cancelarContratoExtResponse.MensajeRetorno;
                            body.Contrato = contra;
                            body.Canal = "1014";
                            body.TarjetaCredito = "";
                            body.TipoProducto = "01";
                            body.Producto = "04";
                            body.SubProducto = "01";
                            body.ValorTransaccion1 = cancelarContrato.MontoAhorrado;
                            body.ValorTransaccion2 = cancelarContrato.InteresReal;
                            body.ValorTransaccion3 = cancelarContrato.MontoMeta;
                            body.Trama = "";
                            body.TramaJSON = "";
                            MonitorBalcon = _mbHelper.CrearMonitorBalcon(request.HeaderRequest, body);
                            break;
                        case "CON_AHPR": //--> Contratacion de Ahorro Programado
                            SolicitarContrato solicitudContrato = ConvertirDiccionarioAObjeto<SolicitarContrato>(dictProducto);
                            Log.Information("AhorroProgramadoServicios/SolicitudContratoAP: Consulta API SolicitudContratoAP -> INICIO");
                            
                            //Obtengo secuencial de identificación
                            Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTE ObtenerSecuencial -> INICIO");
                            secuencialDocume = _sBanco.ObtenerSecuencial(solicitudContrato.TipoDocumento, solicitudContrato.Documento, nutCliente, request.HeaderRequest.UserName,
                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeObtenerSecuencial);
                            Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTES ObtenerSecuencial -> RESPUESTA");

                            var solicitarContratoResponse = _sBanco.SolicitudContrato(solicitudContrato.CodAgencia, solicitudContrato.TipoDocumento, secuencialDocume.Identificacion, solicitudContrato.CuentaDebitar, solicitudContrato.CuentaAhorro,
                                            canal, _Common.StringDecimal(servicio), solicitudContrato.MontoMeta, solicitudContrato.CuotaAhorro, solicitudContrato.CodMetaAhorro, solicitudContrato.MotivoAhorro,
                                            request.BodyRequest.InfoUsuario.ExecutiveCode, solicitudContrato.Plazo2, solicitudContrato.DepositoInicial, solicitudContrato.DiaDebito, "BalconAP", solicitudContrato.CorreoElectronico,
                                            nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                            Log.Information("BalconServicios/SolicitudContratoAP: Consulta API BANCO SolicitudContratoAP -> RESPUESTA");
                            obj = solicitarContratoResponse;
                            if (solicitarContratoResponse != null) {
                                if (solicitarContratoResponse.CodigoRetorno != 0) {
                                    ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", solicitarContratoResponse.MensajeRetorno.ToString());
                                }
                                resultados = _Common.DeserializaObj(obj);
                                respuesta = true;
                                detalles.Add(new ValoresDetalleResumen() { Etiqueta = "Contrato", Valor = _Common.convertirDecimalString(solicitarContratoResponse.Contrato.ToString()) });
                            } else {
                                resultados.Add("CodigoRetornoS", string.Empty);
                                resultados.Add("MensajeRetornoS", "Error");
                            }
                            contra = _Common.convertirDecimalString(solicitarContratoResponse.Contrato);
                            body.CodigoProceso = "10001";
                            body.fecha = datetime.ToShortDateString();
                            body.Hora = datetime.ToShortTimeString();
                            body.CodigoEvento = "1431";
                            body.TipoIdentificacion = solicitudContrato.TipoDocumento;
                            body.Identificacion = solicitudContrato.Documento;
                            body.Cuenta = solicitudContrato.CuentaAhorro.ToString();
                            body.Oficial = request.BodyRequest.InfoUsuario.ExecutiveCode;
                            body.Agencia = request.BodyRequest.InfoUsuario.AgencyCode;
                            body.Referencia = solicitarContratoResponse.MensajeRetorno == null ? "" : solicitarContratoResponse.MensajeRetorno;
                            body.Contrato = contra;
                            body.Canal = "1014";
                            body.TarjetaCredito = "";
                            body.TipoProducto = "01";
                            body.Producto = "04";
                            body.SubProducto = "01";
                            body.ValorTransaccion1 = solicitudContrato.DepositoInicial;
                            body.ValorTransaccion2 = solicitudContrato.MontoMeta;
                            body.ValorTransaccion3 = solicitudContrato.CuotaAhorro;
                            body.Trama = "";
                            body.TramaJSON = "";
                            MonitorBalcon = _mbHelper.CrearMonitorBalcon(request.HeaderRequest, body);
                            break;
                        case "MOD_AHPR":
                            // ModificarContrato modificarContrato = ConvertirDiccionarioAObjeto<SolicitarContrato>(dictProducto);
                            Log.Information("AhorroProgramadoServicios/ModificarContratoAP: Consulta API ModificarContratoAP -> INICIO");
                            //var modificarContratoResponse = _sBanco.ModificaContrato(modificarContrato.CodAgencia, modificarContrato.TipoDocumento, modificarContrato.Documento, modificarContrato.CuentaDebitar, modificarContrato.CuentaAhorro,
                            //                canal, _Common.StringDecimal(servicio), modificarContrato.MontoMeta, modificarContrato.CuotaAhorro, modificarContrato.CodMetaAhorro, modificarContrato.MotivoAhorro,
                            //                request.BodyRequest.InfoUsuario.ExecutiveCode, modificarContrato.Plazo2, modificarContrato.DepositoInicial, modificarContrato.DiaDebito, "BalconAP", modificarContrato.CorreoElectronico,
                            //                nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                            Log.Information("AhorroProgramadoServicios/ModificarContratoAP: Consulta API BANCO SolicitudContratoAP -> RESPUESTA");
                            //obj = modificarContratoResponse;
                            //if (modificarContratoResponse != null)
                            //{
                            //    if (modificarContratoResponse.CodigoRetorno != 0)
                            //    {
                            //        ErrorUtil.ThrowAppException("EnviarFormularioPersona", "Simulacion", modificarContratoResponse.MensajeRetorno.ToString());
                            //    }
                            //    resultados = _Common.DeserializaObj(obj);
                            //    respuesta = true;
                            //    detalles.Add(new ValoresDetalleResumen() { Etiqueta = "Contrato", Valor = _Common.convertirDecimalString(modificarContratoResponse.Contrato.ToString()) });
                            //}
                            //else
                            //{
                            //    resultados.Add("CodigoRetornoS", string.Empty);
                            //    resultados.Add("MensajeRetornoS", "Error");
                            //}
                            break;
                        default:
                            break;
                    }
                }
                else if (request.BodyRequest.Formulario.TipoPersona == "J")
                {
                    if (request.BodyRequest.Formulario.Formulario.Codigo == "AHO")
                    {
                        if (request.BodyRequest.Formulario.Formulario != null && request.BodyRequest.Formulario.Formulario.Secciones != null && request.BodyRequest.Formulario.Formulario.Secciones.Count > 0)
                        {
                            dictProducto = ConvertirFormularioADiccionario(request.BodyRequest.Formulario.Formulario.Secciones, typeof(DatosCuentaAhorro), ref dictValoresAntes, ref dictValoresDespues, ref datosSensibles);
                        }

                        DatosCuentaAhorro valoresCuentaAhorro = ConvertirDiccionarioAObjeto<DatosCuentaAhorro>(dictProducto);

                        if (valoresCuentaAhorro.Cotitulares != null && valoresCuentaAhorro.Cotitulares.Count > 0)
                        {
                            valoresCuentaAhorro.Cotitulares.ForEach(cotitu => {
                                cotitu.TipoMoneda = 1;
                                if (int.TryParse(valoresCuentaAhorro.Moneda, out int valInt))
                                {
                                    cotitu.TipoMoneda = valInt;
                                }
                            });
                        }
                        valoresCuentaAhorro.Usuario_Creacion = valoresCuentaAhorro.IdentificacionUsuario;

                        SolicitudCambio solicitudCambio = new SolicitudCambio
                        {
                            UsuarioSolicitante = request.HeaderRequest.UserName,
                            FechaSolicitud = DateTime.Now,
                            Estado = "PENDIENTE",
                            Data = JsonConvert.SerializeObject(valoresCuentaAhorro),
                            Accion = "CREACION",
                            Funcionalidad = "CUENTA_AHORRO_PJ",
                            DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                            DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                            TipoRol = "",
                            IdentificadorFuncionalidad = 3,
                            DescripcionFuncionalidad = "CUENTA_AHORRO_PJ",
                            IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoresCuentaAhorro.Dcto_Identidad_Cliente,
                            AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud, /*CAMBIO RF-2023-046 // ACT2*/

                        };

                        //CREAR SOLICITUD CAMBIOS
                        long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);

                        respuesta = _aprobador.AprobarSolicitudCambio(cambioId, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);

                        firmantes.Add("FIRMANTE", valoresCuentaAhorro.Nombre_Representante_Legal);
                        firmantes.Add("FIRMANTE_DOC", valoresCuentaAhorro.Documento_Representante_Legal);
                    }
                    //CREACION CLIENTE PERSONA NATURAL CUENTA CORRIENTE
                    else if (request.BodyRequest.Formulario.Formulario.Codigo == "CTE")
                    {
                        if (request.BodyRequest.Formulario.Formulario != null && request.BodyRequest.Formulario.Formulario.Secciones != null && request.BodyRequest.Formulario.Formulario.Secciones.Count > 0)
                        {
                            dictProducto = ConvertirFormularioADiccionario(request.BodyRequest.Formulario.Formulario.Secciones, typeof(DatosCuentaCorriente), ref dictValoresAntes, ref dictValoresDespues, ref datosSensibles);
                        }

                        DatosCuentaCorriente valoresCuentaCorriente = ConvertirDiccionarioAObjeto<DatosCuentaCorriente>(dictProducto);

                        //valoresCuentaCorriente.DatosGeneralChequera.TipoChequera = valoresCuentaCorriente.DatosGeneralChequera.TipoChequera.Split("-").First();

                        SolicitudCambio solicitudCambio = new SolicitudCambio
                        {
                            UsuarioSolicitante = request.HeaderRequest.UserName,
                            FechaSolicitud = DateTime.Now,
                            Estado = "PENDIENTE",
                            Data = JsonConvert.SerializeObject(valoresCuentaCorriente),
                            Accion = "CREACION",
                            Funcionalidad = "CUENTA_CORRIENTE_PJ",
                            DetallesDataAntes = JsonConvert.SerializeObject(dictValoresAntes),
                            DetallesDataDespues = JsonConvert.SerializeObject(dictValoresDespues),
                            TipoRol = "",
                            IdentificadorFuncionalidad = 4,
                            DescripcionFuncionalidad = "CUENTA_CORRIENTE_PJ",
                            IdentificadorCambio = request.BodyRequest.Formulario.TipoIdentificacion + "-" + valoresCuentaCorriente.Dcto_Identidad_Cliente,
                            AgenciaSolicitud = request.BodyRequest.InfoUsuario.AgenciaSolicitud, /*CAMBIO RF-2023-046 // ACT2*/

                        };

                        //CREAR SOLICITUD CAMBIOS
                        long cambioId = _aprobador.CrearSolicitudCambio(solicitudCambio);

                        respuesta = _aprobador.AprobarSolicitudCambio(cambioId, Constantes.USUARIO_AUTOMATICO, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);

                        firmantes.Add("FIRMANTE", valoresCuentaCorriente.Nombre_Representante_Legal);
                        firmantes.Add("FIRMANTE_DOC", valoresCuentaCorriente.Documento_Representante_Legal);
                    }
                }

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (respuesta)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    if(request.BodyRequest.Formulario.Formulario.Codigo == "INV" || request.BodyRequest.Formulario.Formulario.Codigo == "CRE")
                    {
                        headerResponseDto.currentPage = 1;
                        headerResponseDto.pageSize = itemsPerPage;
                        headerResponseDto.totalRecords = 1;
                        headerResponseDto.totalPages = 1;
                    }else
                    {
                        headerResponseDto.currentPage = 0;
                        headerResponseDto.pageSize = itemsPerPage;
                        headerResponseDto.totalRecords = 0;
                        headerResponseDto.totalPages = 0; 
                        ErrorUtil.ThrowAppException("EnviarFormularioProducto", "ERROR_SWITCH", "Por un problema con los servicios, no se puede continuar con el proceso.");
                    }
                }
                //Create Body Response
                 bodyResponse.Resultado = resultados;
                bodyResponse.Detalles = detalles;
                bodyResponse.Firmantes = firmantes;
                //bodyResponse.Mensaje = "OK";

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EnviarFormulario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ObtenerFormularioResponse ObtenerFormulario(ObtenerFormularioRequest request)
        {
            try
            {
                ObtenerFormularioResponse response = new ObtenerFormularioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ObtenerFormularioResponseBody bodyResponse = new ObtenerFormularioResponseBody();
                FormatoClienteDto Formato = new FormatoClienteDto();
                List<CuentaActivaAhorroProgramado> CuentasActivas = new();
                List<Plazos> plazos = new();
                List<DatosContratoExt> ClienteContratos = new();
                SecuencialAhorroProgramado secuencialDocume = new();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                object valores = null;

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                #region OBTENER DATOS PERSONA
                if (request.BodyRequest.TipoPersona == "N")
                {
                    if (Validaciones.ValidarIdentificacion(request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion))
                    {
                        #region CONSULTA PERSONA NATURAL
                        DatosPersonaNatural valoresPersona = new DatosPersonaNatural();

                        bool esPeps = false;

                        //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                        ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO CLIENTES -> INICIO");
                        valoresPersona = _sBanco.ConsultarClienteNatural(request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion, nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO CLIENTES -> RESPUESTA");
                        

                        if (valoresPersona != null) {


                                                  


                            if (valoresPersona.EsCliente)
                            {


                                //Valida el tipo de persona
                                if (valoresPersona.SP_Informacion_General.Datos_Basicos.Tipo_Persona != "N")
                                {
                                    ErrorUtil.ThrowAppException("ObtenerFormulario", "", "El Tipo de persona a consultar es incorrecto.");
                                }

                                if (valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Cliente != "01" && request.BodyRequest.TipoCliente == "01" && request.BodyRequest.Producto > 0) 
                                {
                                    valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Cliente = request.BodyRequest.TipoCliente;
                                } 

                                if (request.BodyRequest.TipoIdentificacion != "R")
                                {
                                    valoresPersona.SP_Informacion_Financiera.Ingreso_Patrimonio.Tipo_Estado_Situacion_Financiera = "P";
                                }
                            } else {

                                
                                valoresPersona.SP_Informacion_General = new SPInformacionGeneral {
                                    Datos_Generales = new SPInformacionGeneral.DatosGenerales
                                    {
                                        Tipo_Cliente = request.BodyRequest.TipoCliente,
                                        Dcto_Identidad_Cliente = request.BodyRequest.Identificacion,
                                        Tipo_Identidad_Cliente = request.BodyRequest.TipoIdentificacion
                                    },
                                    Datos_Basicos = new SPInformacionGeneral.DatosBasicos { 
                                        Tipo_Persona = request.BodyRequest.TipoPersona,
                                    }
                                };
                                if (request.BodyRequest.TipoIdentificacion != "R")
                                {
                                    valoresPersona.SP_Informacion_Financiera = new SPInformacionFinanciera
                                    {
                                        Ingreso_Patrimonio = new SPInformacionFinanciera.IngresoPatrimonio
                                        {
                                            Tipo_Estado_Situacion_Financiera = "P"
                                        }
                                    };
                                }




                            }
                                                     
                        }

                        
                        if (request.BodyRequest.TipoIdentificacion != "E") {
                            string cedula = request.BodyRequest.Identificacion.Substring(0, 10);

                            ErrorMapeoMensaje mensajeRegistroCivil = new ErrorMapeoMensaje();
                            Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO REGISTRO CIVIL -> INICIO");
                            //dsc1977
                            //DatosPersonaNatural? valoresRegistro = new();
                            DatosPersonaNatural? valoresRegistro = _sBanco.ConsultarDatosRegistroCivil("O", cedula, nutCliente, request.HeaderRequest.UserName,
                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeRegistroCivil);




                            Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO REGISTRO CIVIL -> RESPUESTA");



                            //dsc1977: valida campo fallecido ***********************************

                            //no se pudo conectar
                            if (valoresRegistro.Sin_Registro_Civil == "S")
                            {
                                valoresPersona.SP_Informacion_General.Datos_Basicos.Condicion_Cedulado = string.Empty;
                            }

                            string condicionCedulado = valoresPersona.SP_Informacion_General.Datos_Basicos.Condicion_Cedulado;
                            string tipoPersona = valoresPersona.SP_Informacion_General.Datos_Basicos.Tipo_Persona;

                            DatosPersonaNaturalFallecido datosPersonaNaturalFallecido = new DatosPersonaNaturalFallecido()
                            {
                                TipoIdentificacion = request.BodyRequest.TipoIdentificacion,
                                Identificacion = request.BodyRequest.Identificacion,
                                CondicionCedula = condicionCedulado == "7" ? "S":"N",//fallecido
                                CampoCaptacion = "O" //oficina
                            };
                            //dsc:fin






                            if ((valoresPersona == null || !valoresPersona.EsCliente))//No es cliente
                            {//obj null O no cliente
                                //Inicio: validar PEPS
                                ErrorMapeoMensaje mensajePeps = new ErrorMapeoMensaje();
                                Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO PEPS -> INICIO");
                                esPeps = _sBanco.ValidarPersonaExpuestaPoliticamente(cedula, nutCliente, request.HeaderRequest.UserName,
                                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajePeps);
                                Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO PEPS -> RESPUESTA");
                                valoresPersona.SP_Informacion_General.Datos_Basicos.PEPS = esPeps ? "S" : "N";

                                if (esPeps)
                                {
                                    ErrorUtil.ThrowAppException("ObtenerFormulario", "CEDULA_PEPS", "Por restricciones en el sistema, no puede continuar con el proceso.");
                                }
                                //Fin: validar PEPS

                                //datos obtenidos registro civil
                                valoresPersona = valoresRegistro;




                                //dsc: valida campo fallecido ******************* 

                                if (condicionCedulado == "7" && tipoPersona == "N")
                                {
                                    //fallecida = true | cliente = true | persona natural = true
                                    ErrorUtil.ThrowAppException("ObtenerFormulario", "", "SU SOLICITUD NO PROCEDE");
                                }

                                //dsc:fin


                                valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente = request.BodyRequest.TipoIdentificacion;
                                valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente = request.BodyRequest.Identificacion;
                                
                                /*valoresPersona.SP_Informacion_General.Datos_Generales.Producto_Captado = "99999";*/
                                valoresPersona.SP_Informacion_General.Datos_Generales.Producto_Captado = "66666";
                                valoresPersona.SP_Informacion_General.Datos_Generales.Estado_Cliente = "I";
                                valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Cliente = request.BodyRequest.TipoCliente;

                                if (request.BodyRequest.TipoIdentificacion != "R")
                                {
                                    valoresPersona.SP_Informacion_Financiera = new SPInformacionFinanciera
                                    {
                                        Ingreso_Patrimonio = new SPInformacionFinanciera.IngresoPatrimonio
                                        {
                                            Tipo_Estado_Situacion_Financiera = "P"
                                        }
                                    };
                                }
                            } else {//Si es cliente
                                //NO SE PUDO CONECTAR AL REGISTRO CIVIL
                                if (valoresRegistro.Sin_Registro_Civil == "S") {
                                    valoresPersona.Sin_Registro_Civil = "S";
                                } else {
                                
                                    valoresPersona.Sin_Registro_Civil = "N";
                                    valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos = valoresRegistro.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos;
                                    valoresPersona.SP_Informacion_General.Datos_Basicos.Fecha_Nacimiento = valoresRegistro.SP_Informacion_General.Datos_Basicos.Fecha_Nacimiento;
                                    //valoresPersona.SP_Informacion_General.Datos_Basicos.Lugar_Nacimiento = valoresRegistro.SP_Informacion_General.Datos_Basicos.Lugar_Nacimiento;
                                    valoresPersona.SP_Informacion_General.Datos_Basicos.Sexo = valoresRegistro.SP_Informacion_General.Datos_Basicos.Sexo;
                                    //valoresPersona.SP_Informacion_General.Datos_Basicos.Pais_Origen = valoresRegistro.SP_Informacion_General.Datos_Basicos.Pais_Origen;
                                    //valoresPersona.SP_Informacion_General.Datos_Basicos.Nacionalidad = valoresRegistro.SP_Informacion_General.Datos_Basicos.Nacionalidad;
                                    valoresPersona.SP_Informacion_General.Datos_Basicos.Estado_Civil = valoresRegistro.SP_Informacion_General.Datos_Basicos.Estado_Civil;
                                    //valoresPersona.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge = valoresRegistro.SP_Informacion_General.Datos_Conyuge.Nombres_Apellidos_Conyuge;
                                    //valoresPersona.SP_Informacion_Laboral.Datos_Laborales.Nivel_Estudios = valoresRegistro.SP_Informacion_Laboral.Datos_Laborales.Nivel_Estudios;
                                    //valoresPersona.SP_Informacion_Laboral.Datos_Laborales.Profesion = valoresRegistro.SP_Informacion_Laboral.Datos_Laborales.Profesion;
                                    //valoresPersona.SP_Informacion_Residencia_Extranjera.FATCA_Cuestionario.Pais_Nacionalidad = valoresRegistro.SP_Informacion_Residencia_Extranjera.FATCA_Cuestionario.Pais_Nacionalidad;

                                }

                                //dsc: valida campo fallecido ******************* 
                                

                                if (tipoPersona == "N")
                                {

                                    Log.Information("BalconServicios/ObtenerFormulario: Actualiza campo fallecido -> INICIO");
                                    //llamo a metodo actualizar campo fallecido
                                    bool actualizacionCampoFallidoExitosa = _sBanco.EdicionClienteNaturalFallecido(datosPersonaNaturalFallecido, nutCliente, request.HeaderRequest.UserName,
                                          request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);

                                    if (actualizacionCampoFallidoExitosa)
                                    {
                                        Log.Information("BalconServicios/ObtenerFormulario: Actualiza campo fallecido -> RESPUESTA");
                                    }
                                    else
                                    {
                                        Log.Information("BalconServicios/ObtenerFormulario: Actualiza campo fallecido -> ERROR");
                                    }

                                    //fallecida = true | cliente = true | persona natural = true
                                    ErrorUtil.ThrowAppException("ObtenerFormulario", "", "SU SOLICITUD NO PROCEDE");
                                }

                                //dsc:fin


                                //#region Ahorro Programado (ConsultarCuentasActivas - ClienteContrato)

                                ////Obtengo secuencial de identificación
                                //ErrorMapeoMensaje mensajeObtenerSecuencial = new ErrorMapeoMensaje();
                                //Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTE ObtenerSecuencial -> INICIO");
                                //secuencialDocume = _sBanco.ObtenerSecuencial(request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion, nutCliente, request.HeaderRequest.UserName,
                                //    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeObtenerSecuencial);
                                //Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTES ObtenerSecuencial -> RESPUESTA");

                                ////var opcSwitch = request.BodyRequest.Producto; //Formulario.Formulario.Codigo;
                                //var SP_DatosAhorroProgramado = new SPDatosAhorroProgramado();
                                ////switch (opcSwitch) {
                                ////    case 29: //---> Contratacion
                                ////OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                                //ErrorMapeoMensaje mensajeCuentasActivas = new ErrorMapeoMensaje();
                                //Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTE CuentasActivas -> INICIO");
                                //CuentasActivas = _sBanco.ConsultarCuentasActivas(request.BodyRequest.TipoIdentificacion, secuencialDocume.Identificacion, nutCliente, request.HeaderRequest.UserName,
                                //    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeCuentasActivas);
                                //Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTES CuentasActivas -> RESPUESTA");
                                ////if (CuentasActivas.Count == 0 || CuentasActivas == null) {
                                ////    ErrorUtil.ThrowAppException("ObtenerFormulario", "CuentasActivas", "Cliente no posee cuenta de ahorro.");
                                ////}
                                //SP_DatosAhorroProgramado.ListaCuentasActivasAhorroProgramado = CuentasActivas;

                                ////OBTENER INFORMACION DE PLAZOS PARA AHORRO PROGRAMADO EN EL BANCO
                                //ErrorMapeoMensaje mensajePlazos = new ErrorMapeoMensaje();
                                //Log.Information("BalconServicios/Plazos: Consulta API BANCO CLIENTE Plazos -> INICIO");
                                //plazos = _sBanco.ConsultarPlazo("10401", nutCliente, request.HeaderRequest.UserName,
                                //    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeCuentasActivas);
                                //Log.Information("BalconServicios/Plazos: Consulta API BANCO CLIENTES Plazos -> RESPUESTA");
                                //SP_DatosAhorroProgramado.Plazos = plazos;

                                //ErrorMapeoMensaje mensajeCuentaCliente = new ErrorMapeoMensaje();
                                //Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTE CuentasActivas -> INICIO");
                                //List<CuentaCliente> ListaCuentasCliente = _sBanco.ConsultarCuentasCliente(request.BodyRequest.TipoIdentificacion, secuencialDocume.Identificacion, nutCliente, request.HeaderRequest.UserName,
                                //    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeCuentaCliente);
                                //Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTES CuentasActivas -> RESPUESTA");
                                //SP_DatosAhorroProgramado.ListaCuentasCliente = ListaCuentasCliente;

                                //string Argumento = builder.GetSection("ParametrosAhorroProgramado:CatalogoArgumento").Value;
                                //int Tabla = int.Parse(builder.GetSection("ParametrosAhorroProgramado:CatalogoTabla").Value);
                                //ErrorMapeoMensaje mensajeCatalogoAhorroProgramado = new ErrorMapeoMensaje();
                                //Log.Information("BalconServicios/CatalogoAhorroProgramado: Consulta API BANCO CLIENTE CatalogoAhorroProgramado -> INICIO");
                                //List<CatalogoAhorroProgramado> catalogoAhorroProgramado = _sBanco.CatalogoAhorroProgramado(Argumento, Tabla, nutCliente, request.HeaderRequest.UserName,
                                //                                                                request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeCatalogoAhorroProgramado);
                                //Log.Information("BalconServicios/CatalogoAhorroProgramado: Consulta API BANCO CLIENTES CatalogoAhorroProgramado -> RESPUESTA");
                                //SP_DatosAhorroProgramado.ListaCatalogo = catalogoAhorroProgramado;
                                //    //    break;
                                //    //case 21: //---> Cancelacion contrato
                                //ErrorMapeoMensaje mensajeClienteContrato = new ErrorMapeoMensaje();
                                //Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTE ClienteContrato -> INICIO");
                                //ClienteContratos = _sBanco.ConsultarClienteContratos("0", request.BodyRequest.TipoIdentificacion, secuencialDocume.Identificacion, 0, nutCliente, request.HeaderRequest.UserName,
                                //                                                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeClienteContrato);
                                //Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTES ClienteContrato -> RESPUESTA");
                                //SP_DatosAhorroProgramado.ListaDatosContrato = ClienteContratos;
                                ////        break;
                                ////}
                                //valoresPersona.SP_DatosAhorroProgramado = SP_DatosAhorroProgramado;
                                //#endregion
                            }


                        }
                        else
                        {
                            if ((valoresPersona == null || !valoresPersona.EsCliente))//obj null O no cliente
                            {
                                valoresPersona.SP_Informacion_General = new SPInformacionGeneral
                                {
                                    Datos_Generales = new SPInformacionGeneral.DatosGenerales{
                                        /*Producto_Captado = "99999",*/
                                        Producto_Captado = "88888",
                                        Estado_Cliente = "I",
                                        Tipo_Cliente = request.BodyRequest.TipoCliente,
                                        Tipo_Identidad_Cliente = request.BodyRequest.TipoIdentificacion,
                                        Dcto_Identidad_Cliente = request.BodyRequest.Identificacion,
                                        Numero_Pasaporte = request.BodyRequest.Identificacion
                                    },
                                    Datos_Basicos = new SPInformacionGeneral.DatosBasicos
                                    { 
                                        Tipo_Persona = request.BodyRequest.TipoPersona
                                    }
                                };
                                valoresPersona.SP_Informacion_Financiera = new SPInformacionFinanciera
                                {
                                    Ingreso_Patrimonio = new SPInformacionFinanciera.IngresoPatrimonio
                                    {
                                        Tipo_Estado_Situacion_Financiera = "P"
                                    }
                                };
                            }                            
                        }







                        #region Ahorro Programado (ConsultarCuentasActivas - ClienteContrato)

                        //Obtengo secuencial de identificación
                        ErrorMapeoMensaje mensajeObtenerSecuencial = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTE ObtenerSecuencial -> INICIO");
                        secuencialDocume = _sBanco.ObtenerSecuencial(request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion, nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeObtenerSecuencial);
                        Log.Information("BalconServicios/ObtenerSecuencial: Consulta API BANCO CLIENTES ObtenerSecuencial -> RESPUESTA");

                        //var opcSwitch = request.BodyRequest.Producto; //Formulario.Formulario.Codigo;
                        var SP_DatosAhorroProgramado = new SPDatosAhorroProgramado();
                        //switch (opcSwitch) {
                        //    case 29: //---> Contratacion
                        //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                        ErrorMapeoMensaje mensajeCuentasActivas = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTE CuentasActivas -> INICIO");
                        CuentasActivas = _sBanco.ConsultarCuentasActivas(request.BodyRequest.TipoIdentificacion, secuencialDocume.Identificacion, nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeCuentasActivas);
                        Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTES CuentasActivas -> RESPUESTA");
                        //if (CuentasActivas.Count == 0 || CuentasActivas == null) {
                        //    ErrorUtil.ThrowAppException("ObtenerFormulario", "CuentasActivas", "Cliente no posee cuenta de ahorro.");
                        //}
                        SP_DatosAhorroProgramado.ListaCuentasActivasAhorroProgramado = CuentasActivas;

                        //OBTENER INFORMACION DE PLAZOS PARA AHORRO PROGRAMADO EN EL BANCO
                        ErrorMapeoMensaje mensajePlazos = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/Plazos: Consulta API BANCO CLIENTE Plazos -> INICIO");
                        plazos = _sBanco.ConsultarPlazo("10401", nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajePlazos);
                        Log.Information("BalconServicios/Plazos: Consulta API BANCO CLIENTES Plazos -> RESPUESTA");
                        SP_DatosAhorroProgramado.Plazos = plazos;

                        ErrorMapeoMensaje mensajeCuentaCliente = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTE CuentasActivas -> INICIO");
                        List<CuentaCliente> ListaCuentasCliente = _sBanco.ConsultarCuentasCliente(request.BodyRequest.TipoIdentificacion, secuencialDocume.Identificacion, nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeCuentaCliente);
                        Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTES CuentasActivas -> RESPUESTA");
                        SP_DatosAhorroProgramado.ListaCuentasCliente = ListaCuentasCliente;

                        string Argumento = builder.GetSection("ParametrosAhorroProgramado:CatalogoArgumento").Value;
                        int Tabla = int.Parse(builder.GetSection("ParametrosAhorroProgramado:CatalogoTabla").Value);
                        ErrorMapeoMensaje mensajeCatalogoAhorroProgramado = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/CatalogoAhorroProgramado: Consulta API BANCO CLIENTE CatalogoAhorroProgramado -> INICIO");
                        List<CatalogoAhorroProgramado> catalogoAhorroProgramado = _sBanco.CatalogoAhorroProgramado(Argumento, Tabla, nutCliente, request.HeaderRequest.UserName,
                                                                                        request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeCatalogoAhorroProgramado);
                        Log.Information("BalconServicios/CatalogoAhorroProgramado: Consulta API BANCO CLIENTES CatalogoAhorroProgramado -> RESPUESTA");
                        SP_DatosAhorroProgramado.ListaCatalogo = catalogoAhorroProgramado;
                        //    break;
                        //case 21: //---> Cancelacion contrato
                        ErrorMapeoMensaje mensajeClienteContrato = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTE ClienteContrato -> INICIO");
                        ClienteContratos = _sBanco.ConsultarClienteContratos("0", request.BodyRequest.TipoIdentificacion, secuencialDocume.Identificacion, 0, nutCliente, request.HeaderRequest.UserName,
                                                                                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeClienteContrato);
                        Log.Information("BalconServicios/ObtenerCuentasActivas: Consulta API BANCO CLIENTES ClienteContrato -> RESPUESTA");
                        SP_DatosAhorroProgramado.ListaDatosContrato = ClienteContratos;
                        //        break;
                        //}
                        valoresPersona.SP_DatosAhorroProgramado = SP_DatosAhorroProgramado;
                        #endregion

                        ErrorMapeoMensaje mensajeListasNegras = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO LISTAS NEGRAS -> INICIO");

                        bool enListasNegras = _sBanco.ValidarListasNegras(valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos, request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion, nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeListasNegras);
                            //false;
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO LISTAS NEGRAS -> RESPUESTA");
                        //false;
                        if (enListasNegras)
                        {
                            ErrorUtil.ThrowAppException("ObtenerFormulario", "CEDULA_LISTA_NEGRA", "Por restricciones en el sistema, no puede continuar con el proceso.");
                        }

                        //SI es cliente
                        if ((valoresPersona != null && valoresPersona.EsCliente))
                        {
                            //VALIDAR FECHA ULTIMA ACTUALIZACION
                            DateTime fechaAct = valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaCreacion;

                            if ((valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima != null 
                                && valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima.Year > 1)
                                || valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima > fechaAct) {
                                fechaAct = valoresPersona.SP_Informacion_Adicional.Datos_Auditoria.FechaUltima;
                            }

                            DateTime today = DateTime.Today;

                            if (today.Subtract(fechaAct).Days > 365) {
                                headerResponseDto.returnMessage = "ACTUALIZAR DATOS";
                            }                            
                        }                        
                        
                        valores = valoresPersona;
                        #endregion
                    }
                    else 
                    {
                        ErrorUtil.ThrowAppException("ObtenerFormulario", "CEDULA_NO_VALIDA", "El número de identificación ingresado no es válido.");
                    }
                }
                else if (request.BodyRequest.TipoPersona == "J")
                {
                    if (Validaciones.ValidarIdentificacion(request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion))
                    {
                        #region CONSULTA PERSONA JURIDICA
                        DatosPersonaJuridica valoresPersona = new DatosPersonaJuridica();

                        //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                        ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API ConsultarClienteJuridica -> INICIO");
                        valoresPersona = _sBanco.ConsultarClienteJuridica(request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion, nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API ConsultarClienteJuridica -> RESPUESTA");

                        if (valoresPersona != null)
                        {
                            if (valoresPersona.EsCliente)
                            {
                                //Valida el tipo de persona
                                if (valoresPersona.SP_Informacion_General.Datos_Basicos.Tipo_Persona != "J")
                                {
                                    ErrorUtil.ThrowAppException("ObtenerFormulario", "", "El Tipo de persona a consultar es incorrecto.");
                                }

                                valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Cliente = request.BodyRequest.TipoCliente;
                                if (request.BodyRequest.TipoIdentificacion != "R")
                                {
                                    valoresPersona.SP_Informacion_Financiera.Ingreso_Patrimonio.Tipo_Estado_Situacion_Financiera = "P";
                                }
                            }
                            else
                            {
                                valoresPersona.SP_Informacion_General = new PNInformacionGeneral
                                {
                                    Datos_Generales = new PNInformacionGeneral.DatosGeneralesEmpresa
                                    {
                                        Tipo_Cliente = request.BodyRequest.TipoCliente,
                                        Tipo_Identidad_Cliente = request.BodyRequest.TipoIdentificacion,
                                        Dcto_Identidad_Cliente = request.BodyRequest.Identificacion,
                                        /*Producto_Captado = "99999",*/
                                        Producto_Captado = "7777",
                                        Estado_Cliente = "I"
                                    },
                                    Datos_Basicos = new PNInformacionGeneral.DatosBasicosEmpresa { 
                                        Tipo_Persona = request.BodyRequest.TipoPersona,
                                    }
                                };
                            }
                        }

                        if ((valoresPersona != null && valoresPersona.EsCliente))
                        {

                            //VALIDAR FECHA ULTIMA ACTUALIZACION
                            DateTime fechaAct = valoresPersona.Datos_Auditoria.FechaCreacion;

                            if ((valoresPersona.Datos_Auditoria.FechaUltima != null 
                                && valoresPersona.Datos_Auditoria.FechaUltima.Year > 1)
                                || valoresPersona.Datos_Auditoria.FechaUltima > fechaAct)
                            {
                                fechaAct = valoresPersona.Datos_Auditoria.FechaUltima;
                            }

                            DateTime today = DateTime.Today;

                            if (today.Subtract(fechaAct).Days > 365)
                            {
                                headerResponseDto.returnMessage = "ACTUALIZAR DATOS";
                            }
                        }

                        ErrorMapeoMensaje mensajeListasNegras = new ErrorMapeoMensaje();
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO LISTAS NEGRAS -> INICIO");

                        bool enListasNegras = _sBanco.ValidarListasNegras(valoresPersona.SP_Informacion_General.Datos_Basicos.Nombre_Empresa, valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente, request.BodyRequest.Identificacion, nutCliente, request.HeaderRequest.UserName,
                            request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensajeListasNegras);
                        Log.Information("BalconServicios/ObtenerFormulario: Consulta API BANCO LISTAS NEGRAS -> RESPUESTA");

                        if (enListasNegras)
                        {
                            ErrorUtil.ThrowAppException("ObtenerFormulario", "CEDULA_LISTA_NEGRA", "Por restricciones en el sistema, no puede continuar con el proceso.");
                        }

                        valores = valoresPersona;
                        #endregion
                    }
                    else
                    {
                        ErrorUtil.ThrowAppException("ObtenerFormulario", "CEDULA_NO_VALIDA", "El número de identificación ingresado no es válido.");
                    }
                }
                #endregion
                Log.Information("BalconServicios/ObtenerFormulario: Consulta DB -> INICIO");
                Formato = _clHelper.ObtenerFormulario(request.HeaderRequest, request.BodyRequest, valores);
                Log.Information("BalconServicios/ObtenerFormulario: Consulta DB -> RESPUESTA");

                if (Formato != null && Formato.Producto != null)
                {
                    if (Formato.Producto.Codigo == "CON_AHPR")
                    {
                        Log.Information("BalconServicios/ObtenerFormulario: Valida Cuentas");
                        if (CuentasActivas.Count == 0 || CuentasActivas == null)
                        {
                            ErrorUtil.ThrowAppException("ObtenerFormulario", "CuentasActivas", "Cliente no posee cuenta de ahorro.");
                        }
                    }

                    if (Formato.Producto.Codigo == "CAN_AHPR")
                    {
                        Log.Information("BalconServicios/ObtenerFormulario: Valida Cuentas");
                        if (ClienteContratos.Count == 0 || ClienteContratos == null)
                        {
                            ErrorUtil.ThrowAppException("ObtenerFormulario", "ContratosActivos", "Cliente no posee contratos activos.");
                        }
                    }
                }
                
                //DSC: cambiar ruc de empleado a agregarle un 0 al inicio para visualizar
                for (int i = 0; i< Formato.Cliente.Secciones.Count; i++) {
                    for (int a = 0; a < Formato.Cliente.Secciones[i].Secciones.Count;a++) {
                        for (int b = 0; b < Formato.Cliente.Secciones[i].Secciones[a].Campos.Count; b++)
                        {
                            for (int c = 0; c < Formato.Cliente.Secciones[i].Secciones[a].Campos.Count; c++)
                            {
                                    if (Formato.Cliente.Secciones[i].Secciones[a].Campos[c].Codigo == "RP_RUC")
                                    {
                                    string? rucConCero = Formato.Cliente.Secciones[i].Secciones[a].Campos[c].Valor;
                                    Formato.Cliente.Secciones[i].Secciones[a].Campos[c].Valor = ((rucConCero.Length < 13)? "0" + rucConCero: rucConCero);
                                    break;
                                    }
                            }
                        }
                    }
                }






                //Create Header response
                if (Formato != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Formato = Formato;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;

                    ErrorUtil.ThrowAppException("ObtenerFormulario", "FORMATO_NO_ENCONTRADO", "No existe un formato configurado para los valores seleccionados.");
                }                

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ObtenerFormulario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        private Dictionary<string, dynamic> ConvertirFormularioADiccionario(List<Seccion<FormatoDetalleFormularioDto>> formatoFormulario, Type type, ref Dictionary<string, dynamic> valoresAntes, ref Dictionary<string, dynamic> valoresDespues, ref bool datosSensibles) {


            Dictionary<string, dynamic> resultado = new Dictionary<string, dynamic>();

            Dictionary<string, Type> children = ObjectReflection.GetDictCodedChildrenTypes(type);

            foreach (var seccion in formatoFormulario)
            {
                AgregarValoresSeccion("",resultado, seccion, children, ref valoresAntes, ref valoresDespues, ref datosSensibles);
            }

            return resultado;
        }

        private void AgregarValoresSeccion(string nombreSeccion, Dictionary<string, dynamic> resultado, Seccion<FormatoDetalleFormularioDto> seccion, Dictionary<string, Type> dicttype, ref Dictionary<string, dynamic> valoresAntes, ref Dictionary<string, dynamic> valoresDespues, ref bool datosSensibles)
        {
            string secc = string.IsNullOrEmpty(nombreSeccion) ? seccion.Nombre : (nombreSeccion + "\\" + seccion.Nombre);

            if (seccion.Campos != null && seccion.Campos.Count > 0)
            {
                foreach (var campo in seccion.Campos)
                {
                    AgregarValorCampo(secc,resultado, campo, dicttype, ref valoresAntes, ref valoresDespues, ref datosSensibles);
                }
            }

            if (seccion.Secciones != null && seccion.Secciones.Count > 0)
            {
                foreach (var subseccion in seccion.Secciones)
                {
                    AgregarValoresSeccion(secc, resultado, subseccion, dicttype, ref valoresAntes, ref valoresDespues, ref datosSensibles);
                }
            }
            
        }

        public string ObtenerValorString(dynamic value)
        {
            return Convert.ToString(value).Replace("[]", "").Trim().ToUpper();
        }

        private void AgregarValorCampo(string nombreSeccion, Dictionary<string, dynamic> resultado, FormatoDetalleFormularioDto campo, Dictionary<string, Type> dicttype, ref Dictionary<string, dynamic> valoresAntes, ref Dictionary<string, dynamic> valoresDespues, ref bool datosSensibles)
        {
            string nombreCampoSensible = nombreSeccion + "\\"+ campo.EtiquetaDetalle + (campo.DatoSensible ? "*" : "");

            if (campo.TipoValor == "VALOR")
            {
                dynamic valor = GetValueFromJsonValue(campo.Valor);
                dynamic valorAnterior = GetValueFromJsonValue(campo.ValorAnterior);

                if (!string.IsNullOrEmpty(campo.CampoAS400)) {
                    resultado.Add(campo.CampoAS400, valor);

                    if (campo.DatoSensible) {
                        string valorStr = ObtenerValorString(valor);
                        string valorAnteriorStr = ObtenerValorString(valorAnterior);
                        if (valorStr != valorAnteriorStr) {
                            datosSensibles = true;
                            nombreCampoSensible = (campo.Enmascarar ? "[CX]": "[C]") + nombreCampoSensible;
                        }
                    }

                    if (campo.TipoCampo != "CALCULADO" && campo.Editable == true && campo.Visible == true)
                    {
                        if (campo.TipoCampo == "COMBOBOX")
                        {
                            var valorAnteriorCat = campo.ValoresCombobox.Find(x => x.Codigo == valorAnterior);

                            string valorAnteriorDesc = (valorAnteriorCat == null ? valorAnterior : valorAnteriorCat.Codigo + "|" + GetDescripcionCatalogo(campo.OrigenEtiqueta, valorAnteriorCat));

                            var valorCat = campo.ValoresCombobox.Find(x => x.Codigo == valor);

                            string valorDesc =  (valorCat == null ? valor : valorCat.Codigo + "|" + GetDescripcionCatalogo(campo.OrigenEtiqueta, valorCat));

                            valoresAntes.Add(nombreCampoSensible, valorAnteriorDesc);
                            valoresDespues.Add(nombreCampoSensible, valorDesc);
                        }
                        else 
                        {                            
                            valoresAntes.Add(nombreCampoSensible, valorAnterior);
                            valoresDespues.Add(nombreCampoSensible, valor);
                        }                        
                    }                   
                }
            }
            else if (campo.TipoValor == "LISTA")
            {
                if (dicttype.TryGetValue(campo.TipoDato, out Type campoType))
                {
                    var listType = typeof(List<>);
                    var constructedType = listType.MakeGenericType(campoType);

                    var valores = (IList) Activator.CreateInstance(constructedType); 
                    Dictionary<string, FormatoDetalleFormularioDto> camposDiccionarios = campo.FormatoModeloLista.ToDictionary(x => x.Codigo, y => y);

                    List<Dictionary<string, dynamic>> valoresAntesItems = new List<Dictionary<string, dynamic>>();
                    List<Dictionary<string, dynamic>> valoresDespuesItems = new List<Dictionary<string, dynamic>>();

                    //var valoresAnterior = (IList)Activator.CreateInstance(constructedType);
                    dynamic valorAnterior = GetValueFromJsonValue(campo.ValorAnterior);
                    if (valorAnterior != null)
                    {
                        List<ValoresModeloDto>? valoresAnt = JsonConvert.DeserializeObject<List<ValoresModeloDto>>(valorAnterior.ToString());

                        if (valoresAnt != null && valoresAnt.Count > 0)
                        {
                            foreach (var valorItem in valoresAnt)
                            {
                                Dictionary<string, dynamic> valor = new Dictionary<string, dynamic>();

                                if (valorItem != null && valorItem.Campos != null && valorItem.Campos.Count > 0)
                                {
                                    foreach (var campoValor in valorItem.Campos)
                                    {
                                        if (camposDiccionarios.TryGetValue(campoValor.Codigo, out FormatoDetalleFormularioDto detalleCampo))
                                        {
                                            dynamic valorJson = campoValor.Valor;
                                            if (!string.IsNullOrEmpty(detalleCampo.CampoAS400))
                                            {
                                                if (detalleCampo.TipoCampo == "COMBOBOX")
                                                {
                                                    var valorAnteriorCat = detalleCampo.ValoresCombobox.Find(x => x.Codigo == valorJson);

                                                    valorJson = (valorAnteriorCat == null ? valorJson : valorAnteriorCat.Codigo + "|" + GetDescripcionCatalogo(detalleCampo.OrigenEtiqueta, valorAnteriorCat));
                                                }
                                                valor.Add(detalleCampo.CampoAS400, valorJson);
                                            }
                                        }
                                    }
                                }
                                valoresAntesItems.Add(valor);
                            }
                        }                        
                    }

                    if (campo.ValoresLista != null && campo.ValoresLista.Count > 0)
                    {
                        foreach (var valorItem in campo.ValoresLista)
                        {
                            Dictionary<string, dynamic> valorDespues = new Dictionary<string, dynamic>();
                            Dictionary<string, dynamic> valor = new Dictionary<string, dynamic>();

                            if (valorItem != null && valorItem.Campos != null && valorItem.Campos.Count > 0)
                            {
                                foreach (var campoValor in valorItem.Campos)
                                {
                                    if (camposDiccionarios.TryGetValue(campoValor.Codigo, out FormatoDetalleFormularioDto detalleCampo))
                                    {
                                        dynamic valorJson = GetValueFromJsonValue(campoValor.Valor);
                                        if (!string.IsNullOrEmpty(detalleCampo.CampoAS400))
                                        {
                                            valor.Add(detalleCampo.CampoAS400, valorJson);
                                            if (detalleCampo.TipoCampo == "COMBOBOX")
                                            {
                                                var valorAnteriorCat = detalleCampo.ValoresCombobox.Find(x => x.Codigo == valorJson);

                                                valorJson = (valorAnteriorCat == null ? valorJson : valorAnteriorCat.Codigo + "|" + GetDescripcionCatalogo(detalleCampo.OrigenEtiqueta, valorAnteriorCat));
                                            }
                                            valorDespues.Add(detalleCampo.CampoAS400, valorJson);
                                        }                                        
                                    }
                                }
                            }
                            valoresDespuesItems.Add(valorDespues);
                            var item = ObjectReflection.GetObjectFromFieldValues(campoType, valor);
                            valores.Add(item);
                        }
                        resultado.Add(campo.CampoAS400, valores);
                    }
                    else
                    {
                        resultado.Add(campo.CampoAS400, null);
                    }

                    valoresAntes.Add(nombreCampoSensible, valoresAntesItems);
                    valoresDespues.Add(nombreCampoSensible, valoresDespuesItems);
                }
            }
        }

        private string GetDescripcionCatalogo(string? origenEtiqueta, ValorCombobox? valorAnteriorCat = null)
        {
            if (valorAnteriorCat == null) return "";

            string resultado = "";
            switch (origenEtiqueta?.Trim())
            {
                case "CODIGO":
                    resultado = valorAnteriorCat?.Codigo;
                    break;
                case "ETIQUETA":
                    resultado = valorAnteriorCat?.Descripcion;
                    break;
                case "COMPLEMENTO":
                    resultado = valorAnteriorCat?.Complemento;
                    break;
                case "CODETIQUETA":
                    resultado = valorAnteriorCat?.Codigo + " - " + valorAnteriorCat?.Descripcion;
                    break;
            }

            return resultado;
        }

        private static dynamic GetValueFromJsonValue(dynamic campo)
        {
            dynamic result = campo;
            if (!(campo is null)) {
                switch (campo.ValueKind)
                {
                    case JsonValueKind.Null:
                        result = null;
                        break;
                    case JsonValueKind.Number:
                        result = campo.GetDouble();
                        break;
                    case JsonValueKind.False:
                        result = false;
                        break;
                    case JsonValueKind.True:
                        result = true;
                        break;
                    case JsonValueKind.Undefined:
                        result = null;
                        break;
                    case JsonValueKind.String:
                        result = campo.GetString()?.Trim().ToUpper();
                        break;
                }
            }            

            return result;
        }

        private T ConvertirDiccionarioAObjeto<T>(Dictionary<string, dynamic> diccionario)
        {
            Type type = typeof(T);

            T resultado = (T) ObjectReflection.GetObjectFromFieldValues(type, diccionario);

            return resultado;
        }

        public ConsultarContactResponse ConsultarContactabilidad(ConsultarContactRequest request)
        {
            try
            {
                ConsultarContactResponse response = new ConsultarContactResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultarContactResponseBody bodyResponse = new ConsultarContactResponseBody();
                Contactabilidad Formato = new Contactabilidad();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                Log.Information("BalconServicios/ConsultarContactabilidad: ConsultarContactabilidad -> INICIO");
                Formato = _sBanco.ConsultarContactabilidad(request.BodyRequest.TipoIdentificacion, request.BodyRequest.Identificacion, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("BalconServicios/ConsultarContactabilidad: ConsultarContactabilidad -> RESPUESTA");


                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                
                //Create Header response

                if (Formato != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Contactabilidad = Formato;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;

                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/ConsultarContactabilidad: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EditarContactResponse EditarContactabilidad(EditarContactRequest request)
        {
            try
            {
                EditarContactResponse response = new EditarContactResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EditarContactResponseBody bodyResponse = new EditarContactResponseBody();
                bool Formato = false;

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                //OBTENER INFORMACION GUARDADA DEL CLIENTE EN EL BANCO
                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
                Log.Information("BalconServicios/EdicionContactabilidad: EdicionContactabilidad -> INICIO");
                Formato = _sBanco.EdicionContactabilidad(request.BodyRequest.Contactabilidad, nutCliente, request.HeaderRequest.UserName,
                    request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("BalconServicios/EdicionContactabilidad: EdicionContactabilidad -> RESPUESTA");


                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                //Create Header response

                if (Formato)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                    headerResponseDto.returnCode = mensaje.CodigoError;
                    headerResponseDto.returnMessage = mensaje.DescripcionError;

                }
                bodyResponse.Editado = Formato;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("BalconServicios/EdicionContactabilidad: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
