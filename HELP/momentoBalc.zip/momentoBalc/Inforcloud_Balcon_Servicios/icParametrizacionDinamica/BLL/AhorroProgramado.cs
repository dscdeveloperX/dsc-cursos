﻿using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado;
using icParametrizacionDinamica.DTOs.API.Response.AhorroProgramado;
using Serilog;
using System;
using icCommon.DTOs.API;
using icCommon.Modelos;
using icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.IO;
using icParametrizacionDinamica.DLL;

namespace icParametrizacionDinamica.BLL
{
    public class AhorroProgramado : IAhorroProgramado {
        private readonly IConectorBancoBLL _sBanco;
        protected icCommon.ConexionApi.IProveedorRutas _routeHelper;
        private Common _Common;

        public AhorroProgramado(icCommon.ConexionApi.IProveedorRutas routeHelper, IConectorBancoBLL sBanco) {
            _sBanco = sBanco;
            _routeHelper = routeHelper;
            _Common = new();
        }
        public AhorroProgramadoResponse SolicitudContratoAP(SolicitudAhorroProgramadoRequest request) {
            try {
                AhorroProgramadoResponse response = new();
                HeaderResponse headerResponseDto = new();
                AhorroProgramadoResponseBody bodyResponse = new();
                Dictionary<string, dynamic> resultados = new Dictionary<string, dynamic>();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                SolicitarContratoResponse solicitarContratoResponse = new();
                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                Log.Information("AhorroProgramadoServicios/SolicitudContratoAP: Consulta API SolicitudContratoAP -> INICIO");
                solicitarContratoResponse = _sBanco.SolicitudContrato(request.BodyRequest.CodAgencia, request.BodyRequest.TipoDocumento, request.BodyRequest.Documento, request.BodyRequest.CuentaDebitar, request.BodyRequest.CuentaAhorro,
                                request.BodyRequest.Canal, request.BodyRequest.Servicio, request.BodyRequest.MontoMeta, request.BodyRequest.CuotaAhorro, request.BodyRequest.CodMetaAhorro, request.BodyRequest.MotivoAhorro, 
                                request.BodyRequest.Oficial, request.BodyRequest.Plazo, request.BodyRequest.DepositoInicial, request.BodyRequest.DiaDebito, request.BodyRequest.UserAS, request.BodyRequest.CorreoElectronico,
                                nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("BalconServicios/SolicitudContratoAP: Consulta API BANCO SolicitudContratoAP -> RESPUESTA");
                
                if (solicitarContratoResponse != null) {
                    resultados = _Common.DeserializaObj(solicitarContratoResponse);
                } else {
                    resultados = _Common.DeserializaObj(new SolicitarContratoResponse());
                }
                if (resultados != null) {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Mensaje = "OK";
                    bodyResponse.Resultado = resultados;
                } else {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            } catch (ArgumentOutOfRangeException e) {
                Log.Error("BalconServicios/ObtenerFormulario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public AhorroProgramadoResponse CancelarContrato(CancelarContratoRequest request) {
            try {
                AhorroProgramadoResponse response = new AhorroProgramadoResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                AhorroProgramadoResponseBody bodyResponse = new AhorroProgramadoResponseBody();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                Dictionary<string, dynamic> resultados = new Dictionary<string, dynamic>();

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("icAppConfig.json").Build();
                string canal = builder.GetSection("ParametrosAhorroProgramado:IdCanal").Value;

                CancelarContratoResponse cancelarContratoExtResponse = new();
                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                Log.Information("AhorroProgramado/CancelarContrato: Consulta API CancelarContratoAhorroProgramado -> INICIO");
                cancelarContratoExtResponse = _sBanco.CancelarContrato(request.BodyRequest.Contrato, request.BodyRequest.TipoDocumento, request.BodyRequest.Documento,
                    request.BodyRequest.Cuenta, canal, request.BodyRequest.Oficial, request.BodyRequest.MotivoCancelacion, request.BodyRequest.UserAS,
                    request.BodyRequest.CorreoElectronico, nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, 
                    "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("AhorroProgramado/CancelarContrato: Consulta API BANCO CancelarContratoAhorroProgramado -> RESPUESTA");

                if (cancelarContratoExtResponse != null) {
                    resultados = _Common.DeserializaObj(cancelarContratoExtResponse);
                } else {
                    resultados = _Common.DeserializaObj(new CancelarContratoResponse());
                }

                if (resultados != null) {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Mensaje = "OK";
                    bodyResponse.Resultado = resultados;
                } else {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                    bodyResponse.Mensaje = "Error";
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e) {
                Log.Error("AhorroProgramado/CancelarContrato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public AhorroProgramadoResponse SimuladorCancelacionContrato(SimuladorCancelacionContratoRequest request) {
            try {
                AhorroProgramadoResponse response = new AhorroProgramadoResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                AhorroProgramadoResponseBody bodyResponse = new AhorroProgramadoResponseBody();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                Dictionary<string, dynamic> resultados = new Dictionary<string, dynamic>();

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

                Log.Information("AhorroProgramado/CancelarContrato: Consulta API CancelarContratoAhorroProgramado -> INICIO");
                var SimulaCancelacion = _sBanco.SimulaCancelacionAP(decimal.Parse(request.BodyRequest.contrato), 
                    nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("AhorroProgramado/CancelarContrato: Consulta API BANCO CancelarContratoAhorroProgramado -> RESPUESTA");

                Log.Information("AhorroProgramado/CancelarContrato: Consulta API CancelarContratoAhorroProgramado -> INICIO");
                var ClienteContratos = _sBanco.ConsultarClienteContratos(request.BodyRequest.contrato, "", "0", 0, nutCliente, request.HeaderRequest.UserName,
                                       request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("AhorroProgramado/CancelarContrato: Consulta API BANCO CancelarContratoAhorroProgramado -> RESPUESTA");

                List<object> obj = new();
                obj.Add(SimulaCancelacion.ListaSimulacionCancelacion[0]);
                obj.Add(ClienteContratos[0]);

                if ((SimulaCancelacion != null) && (SimulaCancelacion.ListaSimulacionCancelacion.Count > 0)
                    && (ClienteContratos != null) && (ClienteContratos.Count > 0)) {
                    resultados = _Common.DeserializaObj(obj);
                } else {
                    resultados.Add("CodigoRetornoS", string.Empty);
                    resultados.Add("MensajeRetornoS", "Error");
                }

                if (resultados != null) {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Mensaje = "OK";
                    bodyResponse.Resultado = resultados;
                } else {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e) {
                Log.Error("AhorroProgramado/CancelarContrato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public AhorroProgramadoResponse SimuladorContrato(SimuladorContratoRequest request) {
            try {
                AhorroProgramadoResponse response = new();
                HeaderResponse headerResponseDto = new();
                AhorroProgramadoResponseBody bodyResponse = new();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                Dictionary<string, dynamic> resultados = new();

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                ErrorMapeoMensaje mensaje = new();

                Log.Information("AhorroProgramado/CancelarContrato: Consulta API SimularContratoAhorroProgramado -> INICIO");
                var simulaContratacion = _sBanco.SimuladorAhorroProgramado(request.BodyRequest.Producto, decimal.Parse(request.BodyRequest.MetaAhorro), decimal.Parse(request.BodyRequest.DepositoInicial),
                    decimal.Parse(request.BodyRequest.MontoAhorro), int.Parse(request.BodyRequest.DiaDebito), int.Parse(request.BodyRequest.Plazo),
                    nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("AhorroProgramado/CancelarContrato: Consulta API BANCO SimularContratoAhorroProgramado -> RESPUESTA");

                if (simulaContratacion != null) {
                    resultados = _Common.DeserializaObj(simulaContratacion);
                } else {
                    resultados.Add("CodigoRetorno", string.Empty);
                    resultados.Add("MensajeRetorno", "Error");
                }

                if (resultados != null) {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Mensaje = "OK";
                    bodyResponse.Resultado = resultados;
                } else {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            } catch (ArgumentOutOfRangeException e) {
                Log.Error("AhorroProgramado/CancelarContrato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public AhorroProgramadoResponse CatalogoAhorroProgramado(CatalogoAhorroProgramadoRequest request) { 
            try {
                AhorroProgramadoResponse response = new();
                HeaderResponse headerResponseDto = new();
                AhorroProgramadoResponseBody bodyResponse = new();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                Dictionary<string, dynamic> resultados = new();

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                //SolicitarContratoResponse solicitarContratoResponse = new();
                ErrorMapeoMensaje mensaje = new();
                Log.Information("AhorroProgramado/AhorroProgramado: Consulta API CatalogoAhorroProgramado -> INICIO");
                var Catalogo = _sBanco.CatalogoAhorroProgramado(request.BodyRequest.Argumento, request.BodyRequest.Tabla,
                    nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("AhorroProgramado/AhorroProgramado: Consulta API BANCO CatalogoAhorroProgramado -> RESPUESTA");

                if (Catalogo != null) {
                    resultados = _Common.DeserializaObj(Catalogo);
                } else {
                    resultados.Add("CodigoRetorno", string.Empty);
                    resultados.Add("MensajeRetorno", "Error");
                }

                if (resultados != null) {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Mensaje = "OK";
                    bodyResponse.Resultado = resultados;
                } else {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            } catch (ArgumentOutOfRangeException e) {
                Log.Error("AhorroProgramado/Catalogo: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
 
        public AhorroProgramadoResponse SimuladorModificaContrato(SimuladorModificaContratoRequest request)
        {
            try
            {
                AhorroProgramadoResponse response = new();
                HeaderResponse headerResponseDto = new();
                AhorroProgramadoResponseBody bodyResponse = new();

                int itemsPerPage = request.HeaderRequest.PageSize;
                string nutCliente = new Guid().ToString();

                Dictionary<string, dynamic> resultados = new();

                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";

                ErrorMapeoMensaje mensaje = new();

                Log.Information("AhorroProgramado/SimuladorModificaContrato: Consulta API SimuladorModificaContratoAhorroProgramado -> INICIO");
                var simuladorModificaContratoAP = _sBanco.SimuladorModificaContratoAP(request.BodyRequest.Contrato, request.BodyRequest.Plazo, request.BodyRequest.MontoDebito,
                    nutCliente, request.HeaderRequest.UserName, request.HeaderRequest.StationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("AhorroProgramado/SimuladorModificaContrato: Consulta API BANCO SimuladorModificaContratoAhorroProgramado -> RESPUESTA");

                if (simuladorModificaContratoAP != null)
                {
                    resultados = _Common.DeserializaObj(simuladorModificaContratoAP);
                }
                else
                {
                    resultados.Add("CodigoRetorno", string.Empty);
                    resultados.Add("MensajeRetorno", "Error");
                }

                if (resultados != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                    //Create Body Response
                    bodyResponse.Mensaje = "OK";
                    bodyResponse.Resultado = resultados;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("AhorroProgramado/SimuladorModificaContrato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}