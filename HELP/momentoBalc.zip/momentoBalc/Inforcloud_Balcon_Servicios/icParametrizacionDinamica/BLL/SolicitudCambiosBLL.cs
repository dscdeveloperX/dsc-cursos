﻿using icCommon.DTOs.API;
using icCommon.DTOs.DB;
using icCommon.ManejoErrores.Utils;
using icCommon.Modelos;
using icCommon.SolicitudCambios;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios;
using icParametrizacionDinamica.DTOs.EXT;
using icParametrizacionDinamica.DTOs.EXT.Request.EnvioCorreo;
using icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica;
using icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace icParametrizacionDinamica.BLL
{
    public class SolicitudCambiosBLL : ISolicitudCambiosBLL
    {
        private readonly IConectorBancoBLL _sBanco;
        private readonly IAprobadorCambios _aprobador;
        private readonly ICorreoDLL _correo;
        private readonly icCommon.ConexionApi.IProveedorRutas _proveedorRutas;
        private readonly string _rutaLogo;
        public SolicitudCambiosBLL(IConectorBancoBLL sBanco, IAprobadorCambios aprobador, ICorreoDLL correo, icCommon.ConexionApi.IProveedorRutas proveedorRutas)
        {
            _sBanco = sBanco;
            _aprobador = aprobador;
            _correo = correo;
            _proveedorRutas = proveedorRutas;

            var ruta = _proveedorRutas.ObtenerRutaPorCodigo(Constantes.Tramas.LOGO_BANCO);
            
            _rutaLogo = ruta != null ? ruta.Endpoint + ruta.Resource : "";
        }

        public long CrearSolicitudCambio(SolicitudCambio solicitudCambio)
        {
            return _aprobador.CrearSolicitudCambioDB(solicitudCambio);
        }

        public bool RechazarSolicitudCambio(long cambioId, string usuarioAprobador, string razon, string ipstation)
        {
            ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();
            SolicitudCambio solicitudCambio = _aprobador.ObtenerSolicitudCambioDB(cambioId);

            solicitudCambio.Estado = Constantes.EstadosAprobacion.RECHAZADO;
            solicitudCambio.UsuarioAprobador = usuarioAprobador;
            solicitudCambio.RazonRechazo = razon;

            long cambio = _aprobador.ModificarSolicitudCambioDB(solicitudCambio);

            //ENVIA MAIL A USUARIO Y RAZON
            icParametrizacionDinamica.Models.Correo correo = _correo.ObtenerCorreoPorCodigo(Constantes.Correos.CORREO_RECHAZO_SOLICITUD_CAMBIO);

            if (!string.IsNullOrEmpty(solicitudCambio.CorreoEjecutivoSolicitud))
            {

                Correo correoCliente = new Correo
                {
                    Asunto = correo.Asunto,
                    Body = correo.Body.Replace("[RAZON_RECHAZO]", razon)
                        .Replace("[NOMBRE]", solicitudCambio.DescripcionCambio)
                        .Replace("[CEDULA]", solicitudCambio.IdentificadorCambio)
                        .Replace("[FECHA_SOLICITUD]", solicitudCambio.FechaSolicitud.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture)),
                    CanalEnvia = "BALCON",
                    CodigoProceso = correo.CodigoProceso,
                    ConCopia = "",
                    Destinatario = solicitudCambio.CorreoEjecutivoSolicitud,
                    IsHtml = correo.IsHtml ? "Si" : "No",
                    NumeroReitento = correo.NumeroReitento,
                    Remitente = correo.Remitente,
                    RutaAdjunto = "",
                    UsuarioNotifica = usuarioAprobador,
                    UsuarioProceso = usuarioAprobador,
                };
                Log.Information("SolicitudCambiosBLL/RechazarSolicitudCambio: EnviarCorreoInterno -> INICIO");
                var respuestaMail = _sBanco.EnviarCorreoInterno(correoCliente, "", usuarioAprobador,
                ipstation, "", new DateTime(), "", ref mensaje);
                string resMail = "ERROR EN RESPUESTA CORREO";
                if (respuestaMail != null)
                {
                    resMail = respuestaMail.MensajeControl.Replace(Environment.NewLine,"");
                }
                Log.Information("SolicitudCambiosBLL/RechazarSolicitudCambio: EnviarCorreoInterno -> RESPUESTA " + resMail);
            }
            return cambio > 0;
        }

        public bool AprobarSolicitudCambio(long cambioId, string usuarioAprobador, string nutCliente, string userName, string stationIp, ref Dictionary<string, dynamic> resultados, ref List<ValoresDetalleResumen> detalles)
        {
            SolicitudCambio solicitudCambio = _aprobador.ObtenerSolicitudCambioDB(cambioId);
            bool respuestaExitosa = false;
            ErrorMapeoMensaje mensaje = new ErrorMapeoMensaje();

            if (solicitudCambio.Funcionalidad == "PERSONA_NATURAL")
            {
                DatosPersonaNatural valoresPersona = JsonConvert.DeserializeObject<DatosPersonaNatural>(solicitudCambio.Data);

                if (solicitudCambio.Accion == "CREACION")
                {
                    //CREACION CLIENTE PERSONA NATURAL SIN PRODUCTO
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionClienteNatural -> INICIO");
                    respuestaExitosa = _sBanco.CreacionClienteNatural(valoresPersona, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionClienteNatural -> RESPUESTA");
                    
                    if (respuestaExitosa)
                    {
                        string tipoIdenti = valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente.Trim();
                        switch (tipoIdenti)
                        {
                            case "N":
                                tipoIdenti = "C";
                                break;
                            case "E":
                                tipoIdenti = "P";
                                break;
                        }

                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Tipo de Identificación",
                            Valor = tipoIdenti
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Identificación",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Nombre",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos
                        });
                    }
                }
                else if (solicitudCambio.Accion == "EDICION")
                {


                    //EDICION CLIENTE PERSONA NATURAL SIN PRODUCTO
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EdicionClienteNatural -> INICIO");
                    respuestaExitosa = _sBanco.EdicionClienteNatural(valoresPersona, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EdicionClienteNatural -> RESPUESTA");

                    if (respuestaExitosa) {

                        string tipoIdenti = valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente.Trim();
                        switch (tipoIdenti)
                        {
                            case "N":
                                tipoIdenti = "C";
                                break;
                            case "E":
                                tipoIdenti = "P";
                                break;
                        }

                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Tipo de Identificación",
                            Valor = tipoIdenti
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Identificación",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Nombre",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombres_Apellidos
                        });                        

                        string detallesstr = string.Empty;
                        string detallesClientestr = string.Empty;
                        List<DetalleSolicitud> detalleSolicitud = ObtenerDatosSensiblesCambio(solicitudCambio, true);

                        if (detalleSolicitud != null && detalleSolicitud.Count > 0)
                        {                            
                            detalleSolicitud.ForEach(campo => {
                                string campoEnmascarado = campo.ValorDespues;

                                if (campoEnmascarado.Contains("|"))
                                {
                                    //es combobox
                                    campoEnmascarado = campoEnmascarado.Split("|")[1];

                                    if (campoEnmascarado.Contains(" - "))
                                    {
                                        campoEnmascarado = campoEnmascarado.Split(" - ")[1];
                                    }
                                }                                

                                detallesstr += $"<li>{campo.Campo}: {campoEnmascarado}</li>";
                                detallesClientestr += $"<tr><td>{campo.Campo}:</td><td>{campoEnmascarado}</td></tr>";
                            });
                        }

                        icParametrizacionDinamica.Models.Correo correoPl = _correo.ObtenerCorreoPorCodigo(Constantes.Correos.CORREO_APROBACION_SOLICITUD_CAMBIO);

                        string bodyMail = correoPl.Body
                                    .Replace("[NOMBRE]", solicitudCambio.DescripcionCambio)
                                    .Replace("[CEDULA]", solicitudCambio.IdentificadorCambio)
                                    .Replace("[FECHA_SOLICITUD]", solicitudCambio.FechaSolicitud.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture))
                                    .Replace("{DETALLES}", detallesstr);

                        icParametrizacionDinamica.Models.Correo correoClientePl = _correo.ObtenerCorreoPorCodigo(Constantes.Correos.CORREO_ACTUALIZACION_DATOS_SENSIBLES);

                        string bodyMailCliente = correoClientePl.Body
                                   .Replace("[LOGO]", _rutaLogo)
                                   .Replace("[NOMBRE]", solicitudCambio.DescripcionCambio)
                                   .Replace("[CEDULA]", solicitudCambio.IdentificadorCambio)
                                   .Replace("[FECHA_SOLICITUD]", solicitudCambio.FechaSolicitud.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture))
                                   .Replace("{DETALLES}", detallesClientestr);

                        if (!string.IsNullOrEmpty(solicitudCambio.CorreoEjecutivoSolicitud)) {

                            //envio usuario
                            Correo correoUsuario = new Correo {
                                Asunto = correoPl.Asunto,
                                Body = bodyMail,
                                CanalEnvia = "BALCON",
                                CodigoProceso = correoPl.CodigoProceso,
                                ConCopia = "",//solicitudCambio.CorreoEjecutivoSolicitud,
                                Destinatario = solicitudCambio.CorreoEjecutivoSolicitud,
                                IsHtml = correoPl.IsHtml ? "Si" : "No",
                                NumeroReitento = correoPl.NumeroReitento,
                                Remitente = correoPl.Remitente,
                                RutaAdjunto = "",
                                UsuarioNotifica = userName,
                                UsuarioProceso = userName,
                            };
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoInterno -> INICIO");
                            ErrorMapeoMensaje men = new ErrorMapeoMensaje();
                            var respuestaMail = _sBanco.EnviarCorreoInterno(correoUsuario, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref men);
                            string resMail = "ERROR EN RESPUESTA CORREO";
                            if (respuestaMail != null)
                            {
                                resMail = respuestaMail.MensajeControl.Replace(Environment.NewLine, "");
                            }
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoInterno -> RESPUESTA "+ resMail);

                            //envio usuario
                            Correo correoCliente = new Correo
                            {
                                Asunto = correoClientePl.Asunto,
                                Body = bodyMailCliente,
                                CanalEnvia = "BALCON",
                                CodigoProceso = correoClientePl.CodigoProceso,
                                ConCopia = "",//solicitudCambio.CorreoEjecutivoSolicitud,
                                Destinatario = solicitudCambio.CorreoClienteSolicitud,
                                IsHtml = correoClientePl.IsHtml ? "Si" : "No",
                                NumeroReitento = correoClientePl.NumeroReitento,
                                Remitente = correoClientePl.Remitente,
                                RutaAdjunto = "",
                                UsuarioNotifica = userName,
                                UsuarioProceso = userName,
                            };
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoExterno -> INICIO");
                            ErrorMapeoMensaje menCli = new ErrorMapeoMensaje();
                            var respuestaMailCli = _sBanco.EnviarCorreoExterno(correoCliente, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref menCli);
                            string resMailCli = "ERROR EN RESPUESTA CORREO";
                            if (respuestaMailCli != null)
                            {
                                resMailCli = respuestaMailCli.MensajeControl.Replace(Environment.NewLine, "");
                            }
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoExterno -> RESPUESTA " + resMailCli);
                        }
                    }
                }
            }
            else if (solicitudCambio.Funcionalidad == "PERSONA_JURIDICA")
            {
                DatosPersonaJuridica valoresPersona = JsonConvert.DeserializeObject<DatosPersonaJuridica>(solicitudCambio.Data);

                if (solicitudCambio.Accion == "CREACION")
                {
                    //CREACION CLIENTE PERSONA NATURAL SIN PRODUCTO
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionClienteJuridico -> INICIO");
                    respuestaExitosa = _sBanco.CreacionClienteJuridico(valoresPersona, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionClienteJuridico -> RESPUESTA");

                    if (respuestaExitosa)
                    {
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Tipo de Identificación",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Identificación",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Nombre Empresa",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombre_Empresa
                        });
                    }
                }
                else if (solicitudCambio.Accion == "EDICION")
                {
                    //EDICION CLIENTE PERSONA NATURAL SIN PRODUCTO
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EdicionClienteJuridica -> INICIO");
                    respuestaExitosa = _sBanco.EdicionClienteJuridica(valoresPersona, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EdicionClienteJuridica -> RESPUESTA");

                    if (respuestaExitosa)
                    {
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Tipo de Identificación",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Generales.Tipo_Identidad_Cliente
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Identificación",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Generales.Dcto_Identidad_Cliente
                        });
                        detalles.Add(new ValoresDetalleResumen
                        {
                            Etiqueta = "Nombre Empresa",
                            Valor = valoresPersona.SP_Informacion_General.Datos_Basicos.Nombre_Empresa
                        });

                        string detallesstr = string.Empty;
                        string detallesClientestr = string.Empty;
                        List<DetalleSolicitud> detalleSolicitud = ObtenerDatosSensiblesCambio(solicitudCambio, true);

                        if (detalleSolicitud != null && detalleSolicitud.Count > 0)
                        {
                            detalleSolicitud.ForEach(campo => {
                                string campoEnmascarado = campo.ValorDespues;

                                if (campoEnmascarado.Contains("|"))
                                {
                                    //es combobox
                                    campoEnmascarado = campoEnmascarado.Split("|")[1];

                                    if (campoEnmascarado.Contains(" - "))
                                    {
                                        campoEnmascarado = campoEnmascarado.Split(" - ")[1];
                                    }
                                }

                                detallesstr += $"<li>{campo.Campo}: {campoEnmascarado}</li>";
                                detallesClientestr += $"<tr><td>{campo.Campo}:</td><td>{campoEnmascarado}</td></tr>";
                            });
                        }

                        icParametrizacionDinamica.Models.Correo correoPl = _correo.ObtenerCorreoPorCodigo(Constantes.Correos.CORREO_APROBACION_SOLICITUD_CAMBIO);

                        string bodyMail = correoPl.Body
                                    .Replace("[NOMBRE]", solicitudCambio.DescripcionCambio)
                                    .Replace("[CEDULA]", solicitudCambio.IdentificadorCambio)
                                    .Replace("[FECHA_SOLICITUD]", solicitudCambio.FechaSolicitud.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture))
                                    .Replace("{DETALLES}", detallesstr);

                        icParametrizacionDinamica.Models.Correo correoClientePl = _correo.ObtenerCorreoPorCodigo(Constantes.Correos.CORREO_ACTUALIZACION_DATOS_SENSIBLES);

                        string bodyMailCliente = correoClientePl.Body
                                   .Replace("[LOGO]", _rutaLogo)
                                   .Replace("[NOMBRE]", solicitudCambio.DescripcionCambio)
                                   .Replace("[CEDULA]", solicitudCambio.IdentificadorCambio)
                                   .Replace("[FECHA_SOLICITUD]", solicitudCambio.FechaSolicitud.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture))
                                   .Replace("{DETALLES}", detallesClientestr);

                        if (!string.IsNullOrEmpty(solicitudCambio.CorreoEjecutivoSolicitud))
                        {

                            //envio usuario
                            Correo correoUsuario = new Correo
                            {
                                Asunto = correoPl.Asunto,
                                Body = bodyMail,
                                CanalEnvia = "BALCON",
                                CodigoProceso = correoPl.CodigoProceso,
                                ConCopia = "",//solicitudCambio.CorreoEjecutivoSolicitud,
                                Destinatario = solicitudCambio.CorreoEjecutivoSolicitud,
                                IsHtml = correoPl.IsHtml ? "Si" : "No",
                                NumeroReitento = correoPl.NumeroReitento,
                                Remitente = correoPl.Remitente,
                                RutaAdjunto = "",
                                UsuarioNotifica = userName,
                                UsuarioProceso = userName,
                            };
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoInterno -> INICIO");
                            ErrorMapeoMensaje men = new ErrorMapeoMensaje();
                            var respuestaMail = _sBanco.EnviarCorreoInterno(correoUsuario, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref men);
                            string resMail = "ERROR EN RESPUESTA CORREO";
                            if (respuestaMail != null)
                            {
                                resMail = respuestaMail.MensajeControl.Replace(Environment.NewLine, "");
                            }
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoInterno -> RESPUESTA " + resMail);

                            //envio usuario
                            Correo correoCliente = new Correo
                            {
                                Asunto = correoClientePl.Asunto,
                                Body = bodyMailCliente,
                                CanalEnvia = "BALCON",
                                CodigoProceso = correoClientePl.CodigoProceso,
                                ConCopia = "",//solicitudCambio.CorreoEjecutivoSolicitud,
                                Destinatario = solicitudCambio.CorreoClienteSolicitud,
                                IsHtml = correoClientePl.IsHtml ? "Si" : "No",
                                NumeroReitento = correoClientePl.NumeroReitento,
                                Remitente = correoClientePl.Remitente,
                                RutaAdjunto = "",
                                UsuarioNotifica = userName,
                                UsuarioProceso = userName,
                            };
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoExterno -> INICIO");
                            ErrorMapeoMensaje menCli = new ErrorMapeoMensaje();
                            var respuestaMailCli = _sBanco.EnviarCorreoExterno(correoCliente, nutCliente, userName,
                        stationIp, "NutCliente", new DateTime(), nutCliente, ref menCli);
                            string resMailCli = "ERROR EN RESPUESTA CORREO";
                            if (respuestaMailCli != null)
                            {
                                resMailCli = respuestaMailCli.MensajeControl.Replace(Environment.NewLine, "");
                            }
                            Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: EnviarCorreoExterno -> RESPUESTA " + resMailCli);
                        }
                    }
                }
            }
            else if (solicitudCambio.Funcionalidad == "CUENTA_AHORRO_PN")
            {
                DatosCuentaAhorro valoresCuentaAhorro = JsonConvert.DeserializeObject<DatosCuentaAhorro>(solicitudCambio.Data);

                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaAhorroClienteNatural -> INICIO");
                CreacionPNCuentaAhorroResponse cuenta = _sBanco.CreacionCuentaAhorroClienteNatural(valoresCuentaAhorro, nutCliente, userName,
                    stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaAhorroClienteNatural -> RESPUESTA");

                if (cuenta != null) 
                {
                    resultados.Add("PREFIJO", cuenta.BodyResponse.Prefijo);
                    resultados.Add("NUMERO_CUENTA", cuenta.BodyResponse.Cuenta);

                    detalles.Add(new ValoresDetalleResumen
                    {
                        Etiqueta = "Tipo de Cuenta",
                        Valor = "Ahorro"
                    });
                    detalles.Add(new ValoresDetalleResumen { 
                        Etiqueta = "Número de Cuenta",
                        Valor = cuenta.BodyResponse.Prefijo + cuenta.BodyResponse.Cuenta
                    });

                    respuestaExitosa = true;
                }

            }
            else if (solicitudCambio.Funcionalidad == "CUENTA_CORRIENTE_PN")
            {
                DatosCuentaCorriente valoresCuentaCorriente = JsonConvert.DeserializeObject<DatosCuentaCorriente>(solicitudCambio.Data);

                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaCorrienteClienteNatural -> INICIO");
                CreacionPNCuentaCorrienteResponse cuenta = _sBanco.CreacionCuentaCorrienteClienteNatural(valoresCuentaCorriente, nutCliente, userName,
                    stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaCorrienteClienteNatural -> RESPUESTA");

                if (cuenta != null)
                {
                    resultados.Add("PREFIJO", cuenta.BodyResponse.Prefijo);
                    resultados.Add("NUMERO_CUENTA", cuenta.BodyResponse.Cuenta);
                    detalles.Add(new ValoresDetalleResumen
                    {
                        Etiqueta = "Tipo de Cuenta",
                        Valor = "Corriente"
                    });
                    detalles.Add(new ValoresDetalleResumen
                    {
                        Etiqueta = "Número de Cuenta",
                        Valor = cuenta.BodyResponse.Prefijo + cuenta.BodyResponse.Cuenta
                    });

                    respuestaExitosa = true;
                }
            }
            else if (solicitudCambio.Funcionalidad == "CUENTA_AHORRO_PJ")
            {
                DatosCuentaAhorro valoresCuentaAhorro = JsonConvert.DeserializeObject<DatosCuentaAhorro>(solicitudCambio.Data);

                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaAhorroClienteJuridica -> INICIO");
                CreacionPJCuentaAhorroResponse cuenta = _sBanco.CreacionCuentaAhorroClienteJuridica(valoresCuentaAhorro, nutCliente, userName,
                    stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaAhorroClienteJuridica -> RESPUESTA");

                if (cuenta != null)
                {
                    resultados.Add("PREFIJO", cuenta.BodyResponse.Prefijo);
                    resultados.Add("NUMERO_CUENTA", cuenta.BodyResponse.Cuenta);
                    detalles.Add(new ValoresDetalleResumen
                    {
                        Etiqueta = "Tipo de Cuenta",
                        Valor = "Ahorro"
                    });
                    detalles.Add(new ValoresDetalleResumen
                    {
                        Etiqueta = "Número de Cuenta",
                        Valor = cuenta.BodyResponse.Prefijo + cuenta.BodyResponse.Cuenta
                    });

                    respuestaExitosa = true;
                }
            }
            else if (solicitudCambio.Funcionalidad == "CUENTA_CORRIENTE_PJ")
            {
                DatosCuentaCorriente valoresCuentaCorriente = JsonConvert.DeserializeObject<DatosCuentaCorriente>(solicitudCambio.Data);

                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaCorrienteClienteJuridica -> INICIO");
                CreacionPJCuentaCorrienteResponse cuenta = _sBanco.CreacionCuentaCorrienteClienteJuridica(valoresCuentaCorriente, nutCliente, userName,
                    stationIp, "NutCliente", new DateTime(), nutCliente, ref mensaje);
                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: CreacionCuentaCorrienteClienteJuridica -> RESPUESTA");

                if (cuenta != null)
                {
                    resultados.Add("PREFIJO", cuenta.BodyResponse.Prefijo);
                    resultados.Add("NUMERO_CUENTA", cuenta.BodyResponse.Cuenta);
                    detalles.Add(new ValoresDetalleResumen
                    {
                        Etiqueta = "Tipo de Cuenta",
                        Valor = "Corriente"
                    });
                    detalles.Add(new ValoresDetalleResumen
                    {
                        Etiqueta = "Número de Cuenta",
                        Valor = cuenta.BodyResponse.Prefijo + cuenta.BodyResponse.Cuenta
                    });

                    respuestaExitosa = true;
                }
            }

            bool respuesta = false;

            if (respuestaExitosa)
            {
                if (usuarioAprobador == Constantes.USUARIO_AUTOMATICO)
                {
                    solicitudCambio.Estado = Constantes.EstadosAprobacion.PROCESADO;
                    solicitudCambio.UsuarioAprobador = Constantes.USUARIO_AUTOMATICO;
                }
                else
                {
                    solicitudCambio.Estado = Constantes.EstadosAprobacion.APROBADO;
                    solicitudCambio.UsuarioAprobador = usuarioAprobador;
                }                

                long cambio = _aprobador.ModificarSolicitudCambioDB(solicitudCambio);

                Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: Se aprueba cambio con id -> " + cambio.ToString());

                respuesta = cambio > 0;
            }
            else {
                if (usuarioAprobador == Constantes.USUARIO_AUTOMATICO) {
                    solicitudCambio.Estado = Constantes.EstadosAprobacion.ELIMINADO;
                    solicitudCambio.UsuarioAprobador = Constantes.USUARIO_AUTOMATICO;

                    long cambio = _aprobador.ModificarSolicitudCambioDB(solicitudCambio);

                    Log.Information("SolicitudCambiosBLL/AprobarSolicitudCambio: Se elimina cambio con id -> " + cambio.ToString());
                }

                ErrorUtil.ThrowAppException("SOLICITUD_CAMBIOS", mensaje.CodigoError, mensaje.DescripcionError);
            }

            return respuesta;
        }

        public EnviarFormularioResponse AprobarFormulario(AprobarFormularioRequest request)
        {
            try
            {
                EnviarFormularioResponse response = new EnviarFormularioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EnviarFormularioResponseBody bodyResponse = new EnviarFormularioResponseBody();

                string guid = Guid.NewGuid().ToString();
                Dictionary<string, dynamic> resultados = new Dictionary<string, dynamic>();
                List<ValoresDetalleResumen> detalles = new List<ValoresDetalleResumen>();
                bool respuesta = AprobarSolicitudCambio(request.BodyRequest.CambioId, request.HeaderRequest.UserName, guid,
                    request.HeaderRequest.UserName, request.HeaderRequest.StationIp, ref resultados, ref detalles);

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "¡Actualización del cliente exitosa!";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;

                if (!respuesta)
                {
                    ErrorUtil.ThrowAppException("AprobarFormulario", "ERROR", "No se puedo procesar la aprobación solicitada.");
                }
                //Create Body Response
                bodyResponse.Resultado = resultados;
                bodyResponse.Detalles = detalles;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("SolicitudCambiosBLL/AprobarFormulario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EnviarFormularioResponse RechazarFormulario(RechazarFormularioRequest request)
        {
            try
            {
                EnviarFormularioResponse response = new EnviarFormularioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                EnviarFormularioResponseBody bodyResponse = new EnviarFormularioResponseBody();

                bool respuesta = RechazarSolicitudCambio(request.BodyRequest.CambioId, request.HeaderRequest.UserName,
                    request.BodyRequest.RazonRechazo, request.HeaderRequest.StationIp);

                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "¡Actualización del cliente ha sido rechazada exitosamente!";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;

                if (!respuesta)
                {
                    ErrorUtil.ThrowAppException("AprobarFormulario", "ERROR", "No se puedo procesar el rechazo solicitado.");
                }
                //Create Body Response
                bodyResponse.Resultado = new Dictionary<string, dynamic>();

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("SolicitudCambiosBLL/RechazarFormulario: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaSolicitudCambiosResponse ListarSolicitudesCambios(ListaSolicitudCambiosRequest request) {
            ListaSolicitudCambiosResponse response = new ListaSolicitudCambiosResponse();
            ListaSolicitudCambiosResponseBody bodyResponse = new ListaSolicitudCambiosResponseBody();
            QuerySolicitudesResponse Formatos;
            HeaderResponse headerResponseDto = new HeaderResponse();
            int page = request.HeaderRequest.PageRequested;
            int itemsPerPage = request.HeaderRequest.PageSize;

            try
            {
                Log.Information("SolicitudCambiosBLL/ListarSolicitudesCambios: Consulta DB -> INICIO");
                Formatos = _aprobador.ObtenerListaSolicitudesCambioDB(page, itemsPerPage, request.BodyRequest.Estado,
                    request.BodyRequest.OrdenarPor, request.BodyRequest.OrdenDesc, request.BodyRequest.FiltrarPor,
                    request.BodyRequest.ValorFiltro, request.BodyRequest.Funcionalidad, request.BodyRequest.AgenciaSolicitud);
                    /*RF-2023-046 ACT2*/
                Log.Information("SolicitudCambiosBLL/ListarSolicitudesCambios: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = Formatos.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.SolicitudCambios = Formatos.SolicitudCambios;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("SolicitudCambiosBLL/ListarSolicitudesCambios: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaSolicitudCambioResponse ConsultarSolicitudCambioPorId(ConsultaSolicitudCambioRequest request)
        {
            try
            {
                ConsultaSolicitudCambioResponse response = new ConsultaSolicitudCambioResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaSolicitudCambioResponseBody bodyResponse = new ConsultaSolicitudCambioResponseBody();
                SolicitudCambio Modelo = new SolicitudCambio();

                int itemsPerPage = request.HeaderRequest.PageSize;

                Log.Information("SolicitudCambiosBLL/ConsultarSolicitudCambioPorId: Consulta DB -> INICIO");
                Modelo = _aprobador.ObtenerSolicitudCambioDB(request.BodyRequest.CambioId);
                Log.Information("SolicitudCambiosBLL/ConsultarSolicitudCambioPorId: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (Modelo != null)
                {
                    List<DetalleSolicitud> detalles = ObtenerDatosSensiblesCambio(Modelo, false);

                    SolicitudCambioDto cambioDto = new SolicitudCambioDto
                    {
                        Accion = Modelo.Accion,
                        DescripcionCambio = Modelo.DescripcionCambio,
                        DescripcionFuncionalidad = Modelo.DescripcionFuncionalidad,
                        FechaAprobacion = Modelo.FechaAprobacion.Year == 1 ? null: Modelo.FechaAprobacion,
                        Estado = Modelo.Estado,
                        FechaSolicitud = Modelo.FechaSolicitud,
                        Funcionalidad = Modelo.Funcionalidad,
                        IdCambio = Modelo.IdCambio,
                        IdentificadorCambio = Modelo.IdentificadorCambio,
                        IdentificadorFuncionalidad = Modelo.IdentificadorFuncionalidad,
                        TipoRol = Modelo.TipoRol,
                        UsuarioSolicitante = Modelo.UsuarioSolicitante,
                        RazonRechazo = Modelo.RazonRechazo,
                        UsuarioAprobador = Modelo.UsuarioAprobador,
                        Detalles = detalles
                    };

                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;

                    //Create Body Response
                    bodyResponse.SolicitudCambio = cambioDto;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("SolicitudCambiosBLL/ConsultarSolicitudCambioPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }


        public List<DetalleSolicitud> ObtenerDatosSensiblesCambio(SolicitudCambio Modelo, bool soloSensible)
        {
            List<DetalleSolicitud> detalles = new List<DetalleSolicitud>();

            Dictionary<string, dynamic> valoresAntes = new Dictionary<string, dynamic>();
            Dictionary<string, dynamic> valoresDespues = new Dictionary<string, dynamic>();

            if (!string.IsNullOrEmpty(Modelo.DetallesDataAntes))
            {
                valoresAntes = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(Modelo.DetallesDataAntes);
            }

            if (!string.IsNullOrEmpty(Modelo.DetallesDataDespues))
            {
                valoresDespues = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(Modelo.DetallesDataDespues);
            }

            foreach (string key in valoresDespues.Keys)
            {
                string nameCampo = key.Split('\\').ToList().Last();
                bool campoCorreo = key.StartsWith("[C]");
                bool campoCorreoEnmascarado = key.StartsWith("[CX]");

                dynamic despues = valoresDespues[key];

                if (valoresAntes.TryGetValue(key, out dynamic valor))
                {
                    dynamic antes = valor;

                    string antesstr = ObtenerValorString(antes);
                    string despuesstr = ObtenerValorString(despues);

                    if (antesstr.Trim('0') != despuesstr.Trim('0'))
                    {
                        if (soloSensible)
                        {
                            if (key.EndsWith("*") && campoCorreo)
                            {
                                detalles.Add(new DetalleSolicitud
                                {
                                    Campo = nameCampo.Replace("*", ""),
                                    ValorAnterior = antesstr,
                                    ValorDespues = despuesstr
                                });
                            }
                            else if (key.EndsWith("*") && campoCorreoEnmascarado)
                            {
                                if (antesstr.Contains('@'))
                                {//es correo
                                    antesstr = UtilGeneral.MaskEmail(antesstr);
                                }
                                else
                                {
                                    if (nameCampo.ToLower().Contains("fono"))
                                    {
                                        antesstr = UtilGeneral.MaskString(antesstr, 2, 1);
                                    }
                                    else
                                    {
                                        antesstr = UtilGeneral.MaskString(antesstr);
                                    }
                                }
                                if (despuesstr.Contains('@'))
                                {//es correo
                                    despuesstr = UtilGeneral.MaskEmail(despuesstr);
                                }
                                else
                                {
                                    if (nameCampo.ToLower().Contains("fono"))
                                    {
                                        despuesstr = UtilGeneral.MaskString(despuesstr, 2, 1);
                                    }
                                    else
                                    {
                                        despuesstr = UtilGeneral.MaskString(despuesstr);
                                    }
                                }
                                detalles.Add(new DetalleSolicitud
                                {
                                    Campo = nameCampo.Replace("*", ""),
                                    ValorAnterior = antesstr,
                                    ValorDespues = despuesstr
                                });
                            }
                        }
                        else 
                        {
                            if (key.EndsWith("*"))
                            {
                                if (antesstr.Contains("|"))
                                {
                                    antesstr = antesstr.Split("|")[1];
                                }
                                if (despuesstr.Contains("|"))
                                {
                                    despuesstr = despuesstr.Split("|")[1];
                                }

                                detalles.Add(new DetalleSolicitud
                                {
                                    Campo = nameCampo,
                                    ValorAnterior = antesstr,
                                    ValorDespues = despuesstr
                                });
                            }

                        }
                        
                    }
                }
                else
                {
                    detalles.Add(new DetalleSolicitud
                    {
                        Campo = nameCampo,
                        ValorAnterior = "",
                        ValorDespues = ObtenerValorString(despues)
                    });
                }
            }

            return detalles;
        }
        public string ObtenerValorString(dynamic value)
        {
            if (value == null) return string.Empty;

            ICollection col = value as ICollection;
            if (col != null) return "";
            if (value.GetType() == typeof(DateTime)) return ((DateTime)value).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            string valorf =  Convert.ChangeType(value, typeof(string)).Replace("[]", "").Trim();
            return valorf;
        }        
    }
}
