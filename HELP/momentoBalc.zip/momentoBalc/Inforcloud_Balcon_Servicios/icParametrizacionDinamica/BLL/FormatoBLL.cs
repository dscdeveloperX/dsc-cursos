﻿using icCommon.DTOs.API;
using icCommon.Modelos;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.DB.Response.Formatos;
using icParametrizacionDinamica.DTOs.EXT.Response;
using icParametrizacionDinamica.Models;
using Serilog;
using System;
using System.Collections.Generic;

namespace icParametrizacionDinamica.BLL
{
    public class FormatoBLL : IFormatoBLL
    {
        private readonly IFormatoDLL _clHelper;
        public FormatoBLL(IFormatoDLL dHelper)
        {
            _clHelper = dHelper;
        }

        public EdicionFormatoResponse ActualizarFormato(EdicionFormatoRequest request)
        {
            EdicionFormatoResponse response = new EdicionFormatoResponse();
            EdicionFormatoResponseBody bodyResponse = new EdicionFormatoResponseBody();
            int FormatoId;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                EdicionFormatoRequestBody body = request.BodyRequest;

                Log.Information("FormatoBLL/ActualizarFormato: Consulta DB -> INICIO");
                FormatoId = _clHelper.ActualizarFormato(header, body);
                Log.Information("FormatoBLL/ActualizarFormato: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.FormatosEditados = FormatoId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("FormatoBLL/ActualizarFormato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionFormatoResponse CrearFormato(CreacionFormatoRequest request)
        {
            CreacionFormatoResponse response = new CreacionFormatoResponse();
            CreacionFormatoResponseBody bodyResponse = new CreacionFormatoResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                CreacionFormatoRequestBody body = request.BodyRequest;

                //int itemsPerPage = header.PageSize;

                //Create Formato
                Log.Information("FormatoBLL/CrearFormato: Consulta DB -> INICIO");
                long Formatos = _clHelper.CrearFormato(header, body);
                Log.Information("FormatoBLL/CrearFormato: Consulta DB -> RESPUESTA");
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.FormatoId = Formatos;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("FormatoBLL/CrearFormato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EliminacionFormatoResponse EliminarFormato(EliminacionFormatoRequest request)
        {
            EliminacionFormatoResponse response = new EliminacionFormatoResponse();
            EliminacionFormatoResponseBody bodyResponse = new EliminacionFormatoResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                EliminacionFormatoRequestBody body = request.BodyRequest;

                Log.Information("FormatoBLL/EliminarFormato: Consulta DB -> INICIO");
                int FormatosDeleted = _clHelper.EliminarFormatos(header, body);
                Log.Information("FormatoBLL/EliminarFormato: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.FormatosEliminados = FormatosDeleted;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("FormatoBLL/EliminarFormato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaFormatosResponse ListarFormatos(ListaFormatosRequest request)
        {
            ListaFormatosResponse response = new ListaFormatosResponse();
            ListaFormatosResponseBody bodyResponse = new ListaFormatosResponseBody();
            QueryFormatosResponse Formatos;
            HeaderResponse headerResponseDto = new HeaderResponse();
            int page = request.HeaderRequest.PageRequested;
            int itemsPerPage = request.HeaderRequest.PageSize;

            try
            {
                Log.Information("FormatoBLL/ListarFormatos: Consulta DB -> INICIO");
                Formatos = _clHelper.ListarFormatos(request.HeaderRequest, request.BodyRequest);
                Log.Information("FormatoBLL/ListarFormatos: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = Formatos.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Formatos = Formatos.Formatos;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("FormatoBLL/ListarFormatos: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ObtenerCamposFormatoResponse ObtenerCamposFormato(ObtenerCamposFormatoRequest request)
        {
            try
            {
                ObtenerCamposFormatoResponse response = new ObtenerCamposFormatoResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ObtenerCamposFormatoResponseBody bodyResponse = new ObtenerCamposFormatoResponseBody();
                CamposFormatoDto Formato = new CamposFormatoDto();

                int itemsPerPage = request.HeaderRequest.PageSize;

                Log.Information("FormatoBLL/ObtenerCamposFormato: Consulta DB -> INICIO");
                Formato = _clHelper.ObtenerCamposFormato(request.HeaderRequest, request.BodyRequest);
                Log.Information("FormatoBLL/ObtenerCamposFormato: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (Formato != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Formato = Formato;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("FormatoBLL/ObtenerCamposFormato: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaFormatoResponse ObtenerFormatoPorId(ConsultaFormatoRequest request)
        {
            try
            {
                ConsultaFormatoResponse response = new ConsultaFormatoResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaFormatoResponseBody bodyResponse = new ConsultaFormatoResponseBody();
                FormatoDto Formato = new FormatoDto();

                int itemsPerPage = request.HeaderRequest.PageSize;

                Log.Information("FormatoBLL/ObtenerFormatoPorId: Consulta DB -> INICIO");
                Formato = _clHelper.ObtenerFormatoPorId(request.HeaderRequest, request.BodyRequest);
                Log.Information("FormatoBLL/ObtenerFormatoPorId: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (Formato != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Formato = Formato;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("FormatoBLL/ObtenerFormatoPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }        
    }
}
