﻿using icCommon.ConexionApi;
using icCommon.ManejoErrores;
using icCommon.ManejoErrores.Utils;
using icCommon.Modelos;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DLL;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.EXT;
using icParametrizacionDinamica.DTOs.EXT.Request.AhorroProgramado;
using icParametrizacionDinamica.DTOs.EXT.Request.ASContactabilidad;
using icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaJuridica;
using icParametrizacionDinamica.DTOs.EXT.Request.ASPersonaNatural;
using icParametrizacionDinamica.DTOs.EXT.Request.EnvioCorreo;
using icParametrizacionDinamica.DTOs.EXT.Request.PersonaService;
using icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado;
using icParametrizacionDinamica.DTOs.EXT.Response.ASContactabilidad;
using icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica;
using icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural;
using icParametrizacionDinamica.DTOs.EXT.Response.EnvioCorreo;
using icParametrizacionDinamica.DTOs.EXT.Response.PersonaService;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;

namespace icParametrizacionDinamica.BLL
{
    public class ConectorBancoBLL : IConectorBancoBLL
    {
        private readonly IConectorApi _apiConnector;
        private readonly IMapeoMensajesError _errorHelper;
        private Common _Common;

        public ConectorBancoBLL(IConectorApi apiConnector, IMapeoMensajesError errorHelper) {
            _apiConnector = apiConnector;
            _errorHelper = errorHelper;
            _Common = new();
        }



        public DatosEmpresa ConsultarNombreEmpresa(string rucEmpresa, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultarNombreEmpresaRequest envelope = new ConsultarNombreEmpresaRequest
            {
                HeaderRequest = new DTOs.EXT.Request.PersonaService.HeaderRequest
                {
                    DateTime = DateTime.Now,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new ConsultaNombreEmpresaRequestBody
                {
                    RucEmpresa = rucEmpresa,
                }
            };

            string serviceName = Constantes.Tramas.CONSULTAR_NOMBRE_EMPRESA;

            Log.Information($"ConectorBancoBLL/ConsultarNombreEmpresa: {serviceName} -> REQUEST API BANCO");

            ConsultarNombreEmpresaResponse result = _apiConnector.PostApi<ConsultarNombreEmpresaResponse, ConsultarNombreEmpresaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            
            Log.Information($"ConectorBancoBLL/ConsultarNombreEmpresa: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / ConsultarNombreEmpresa: ERROR => " + error.Replace(Environment.NewLine, ""));
                //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.HeaderResponse.returnCode);
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, result.HeaderResponse.returnMessage);
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, errorMessage);
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            DatosEmpresa contact = null;

            if (result != null && result.BodyResponse != null && result.BodyResponse.DatosEmpresa != null)
            {
                contact = result.BodyResponse.DatosEmpresa;
            }

            return contact;
        }














        #region Otros metodos que no son de Ahorro Programado 
        public DatosPersonaJuridica ConsultarClienteJuridica(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaPersonaJuridicaRequest envelope = new ConsultaPersonaJuridicaRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaJuridica.HeaderRequest
                {
                    DateTime = DateTime.Now,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new ConsultaPersonaJuridicaRequestBody
                {
                    TipoIdentificacion = tipoIdentificacion,
                    Identificacion = identificacion
                }
            };

            string serviceName = Constantes.Tramas.CONSULTAR_CLIENTE_JURIDICO;

            Log.Information($"ConectorBancoBLL/ConsultarClienteJuridica: {serviceName} -> REQUEST API BANCO");

            ConsultaPersonaJuridicaResponse result = _apiConnector.PostApi<ConsultaPersonaJuridicaResponse, ConsultaPersonaJuridicaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/ConsultarClienteJuridica: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                if (result.HeaderResponse.returnCode == icCommon.Utils.Constantes.MappingCode.CLIENTE_NO_EXISTE_JURIDICO)
                {
                    Log.Error("ConectorBancoBLL / ConsultarClienteJuridica: ERROR => " + (result.HeaderResponse.returnMessage));
                }
                else
                {
                    string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                    Log.Error("ConectorBancoBLL / ConsultarClienteJuridica: ERROR => " + error.Replace(Environment.NewLine, ""));
                    //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.HeaderResponse.returnCode);
                    if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                    {
                        ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, result.HeaderResponse.returnMessage);
                    }
                    else
                    {
                        string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                        ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, errorMessage);
                    }
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            DatosPersonaJuridica resultadoDatos = new DatosPersonaJuridica
            {
                EsCliente = false
            };

            if (result != null && result.BodyResponse != null && result.BodyResponse.DatosPersona != null)
            {
                resultadoDatos = result.BodyResponse.DatosPersona;
                resultadoDatos.EsCliente = true;
            }

            return resultadoDatos;
        }

        public DatosPersonaNatural ConsultarClienteNatural(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaPersonaNaturalRequest envelope = new ConsultaPersonaNaturalRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaNatural.HeaderRequest
                {
                    DateTime = DateTime.Now,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new ConsultaPersonaNaturalRequestBody
                {
                    TipoIdentificacion = tipoIdentificacion,
                    Identificacion = identificacion
                }
            };

            string serviceName = Constantes.Tramas.CONSULTAR_CLIENTE_NATURAL;

            Log.Information($"ConectorBancoBLL/ConsultarClienteNatural: {serviceName} -> REQUEST API BANCO");
            //dsc1977
            ConsultaPersonaNaturalResponse result = _apiConnector.PostApi<ConsultaPersonaNaturalResponse, ConsultaPersonaNaturalRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/ConsultarClienteNatural: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                if (result.HeaderResponse.returnCode == icCommon.Utils.Constantes.MappingCode.CLIENTE_NO_EXISTE) 
                {
                    Log.Error("ConectorBancoBLL / ConsultarClienteNatural: ERROR => " + (result.HeaderResponse.returnMessage));
                }
                else {
                    string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                    Log.Error("ConectorBancoBLL / ConsultarClienteNatural: ERROR => " + error.Replace(Environment.NewLine, ""));
                    //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.HeaderResponse.returnCode);
                    if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                    {
                        ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, result.HeaderResponse.returnMessage);
                    }
                    else 
                    {
                        string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                        ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, errorMessage);
                    }                    
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            DatosPersonaNatural resultadoDatos = new DatosPersonaNatural { 
                EsCliente = false
            };

            if (result != null && result.BodyResponse != null && result.BodyResponse.DatosPersona != null)
            {
                resultadoDatos = result.BodyResponse.DatosPersona;
                resultadoDatos.EsCliente = true;
            }

            return resultadoDatos;
        }



        //dsc: modificar campo cliente fallecido
        public bool EdicionClienteNaturalFallecido(DatosPersonaNaturalFallecido clienteNaturalFallecido, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionPersonaNaturalFallecidoRequest envelope = new EdicionPersonaNaturalFallecidoRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaNatural.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new EdicionPersonaNaturalFallecidoRequestBody
                {
                    DatosPersona = clienteNaturalFallecido
                }
            };

            string serviceName = Constantes.Tramas.EDITAR_CLIENTE_NATURAL_FALLECIDO;

            Log.Information($"ConectorBancoBLL/EdicionClienteNaturalFallecido: {serviceName} -> REQUEST API BANCO");

            EdicionPersonaNaturalFallecidoResponse result = _apiConnector.PostApi<EdicionPersonaNaturalFallecidoResponse, EdicionPersonaNaturalFallecidoRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/EdicionClienteNaturalFallecido: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result?.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / EdicionClienteNaturalFallecido: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return false;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return false;
            }

            return true;
        }

























        public Contactabilidad ConsultarContactabilidad(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ConsultaContactabilidadRequest envelope = new ConsultaContactabilidadRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASContactabilidad.HeaderRequest
                {
                    DateTime = DateTime.Now,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new ConsultaContactabilidadRequestBody
                {
                    TipoIdentificacion = tipoIdentificacion,
                    Identificacion = identificacion
                }
            };

            string serviceName = Constantes.Tramas.CONSULTA_CONTACTABILIDAD;

            Log.Information($"ConectorBancoBLL/ConsultarContactabilidad: {serviceName} -> REQUEST API BANCO");

            ConsultaContactabilidadResponse result = _apiConnector.PostApi<ConsultaContactabilidadResponse, ConsultaContactabilidadRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/ConsultarContactabilidad: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / ConsultarContactabilidad: ERROR => " + error.Replace(Environment.NewLine, ""));
                //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.HeaderResponse.returnCode);
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, result.HeaderResponse.returnMessage);
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, errorMessage);
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            Contactabilidad contact = null;

            if (result != null && result.BodyResponse != null && result.BodyResponse.Contactabilidad != null)
            {
                contact = result.BodyResponse.Contactabilidad;
            }

            return contact;
        }





        public DatosPersonaNatural ConsultarDatosRegistroCivil(string canal, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            //dsc1977
            mensaje = new ErrorMapeoMensaje();

            ConsultarDatosRegistroCivilCedulaRequest.Envelope envelope = new ConsultarDatosRegistroCivilCedulaRequest.Envelope
            {
                Body = new ConsultarDatosRegistroCivilCedulaRequest.Body
                {
                    ConsultarDatosRegistroCivilCedula = new ConsultarDatosRegistroCivilCedulaRequest.ConsultarDatosRegistroCivilNacional
                    {
                        Datos = new ConsultarDatosRegistroCivilCedulaRequest.DatosRegistroCivil
                        {
                            NutCliente = nutCliente,
                            PuntoAcceso = ipStation,
                            TipoPuntoAcceso = "IP",
                            Usuario = usuario,
                            Identificacion = identificacion,
                            Canal = canal
                        }
                    }
                }
            };

            string serviceName = Constantes.Tramas.CONSULTAR_DATOS_REGISTRO_CIVIL;

            Log.Information($"ConectorBancoBLL/ConsultarDatosRegistroCivil: {serviceName} -> REQUEST API BANCO");

            ConsultarDatosRegistroCivilCedulaResponse.ConsultarDatosRegistroCivilCedulaResponseDto result = _apiConnector.PostApi<ConsultarDatosRegistroCivilCedulaResponse.ConsultarDatosRegistroCivilCedulaResponseDto, ConsultarDatosRegistroCivilCedulaRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestNamespaces);

            Log.Information($"ConectorBancoBLL/ConsultarDatosRegistroCivil: {serviceName} -> RESPONSE API BANCO");

            DatosPersonaNatural resultadoDatos = new DatosPersonaNatural
            {
                EsCliente = false,
                Sin_Registro_Civil = "S",
                SP_Informacion_General = new DTOs.EXT.SPInformacionGeneral
                {
                    Datos_Basicos = new DTOs.EXT.SPInformacionGeneral.DatosBasicos
                    {
                        Tipo_Persona = "N"
                    },
                    Datos_Generales = new DTOs.EXT.SPInformacionGeneral.DatosGenerales
                    {
                        Tipo_Identidad_Cliente = "N",
                        Dcto_Identidad_Cliente = identificacion
                    }
                },
            };

            if (result != null && result.Mensaje.Codigo == icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                Log.Information("ConectorBancoBLL / ConsultarDatosRegistroCivil: OK => " + identificacion.Replace(Environment.NewLine, ""));

                if (result.ConsultarDatosRegistroCivilCedulaResult != null)
                {
                   resultadoDatos = new DatosPersonaNatural
                    {
                        EsCliente = false,
                        Sin_Registro_Civil = "N",
                        SP_Informacion_General = new DTOs.EXT.SPInformacionGeneral
                        {
                            Datos_Basicos = new DTOs.EXT.SPInformacionGeneral.DatosBasicos
                            {
                                
                                Nombres_Apellidos = result.ConsultarDatosRegistroCivilCedulaResult.ApellidosNombres,
                                Fecha_Nacimiento = result.ConsultarDatosRegistroCivilCedulaResult.FechaNacimiento,
                                Condicion_Cedulado = result.ConsultarDatosRegistroCivilCedulaResult.CondicionCedulado,//dsc: campo fallido
                                //Lugar_Nacimiento = result.ConsultarDatosRegistroCivilCedulaResult.LugarNacimiento,
                                Sexo = result.ConsultarDatosRegistroCivilCedulaResult.CodigoSexo,
                                //Pais_Origen = result.ConsultarDatosRegistroCivilCedulaResult.CodigoPais,
                                //Nacionalidad = result.ConsultarDatosRegistroCivilCedulaResult.CodigoPais,
                                Estado_Civil = result.ConsultarDatosRegistroCivilCedulaResult.CodigoEstadoCivil,
                                Tipo_Persona = "N"
                            },
                            Datos_Generales = new DTOs.EXT.SPInformacionGeneral.DatosGenerales
                            {
                                Tipo_Identidad_Cliente = "N",
                                Dcto_Identidad_Cliente = identificacion
                            },
                            Datos_Conyuge = new DTOs.EXT.Conyuge
                            {
                                Nombres_Apellidos_Conyuge = result.ConsultarDatosRegistroCivilCedulaResult.NombreConyuge,
                            }
                        },
                        /*SP_Informacion_Laboral = new DTOs.EXT.SPInformacionLaboral
                        {
                            Datos_Laborales = new DTOs.EXT.SPInformacionLaboral.DatosLaborales
                            {
                                Nivel_Estudios = result.ConsultarDatosRegistroCivilCedulaResult.CodigoNivelEducacion,
                                Profesion = result.ConsultarDatosRegistroCivilCedulaResult.CodigoProfesion
                            }
                        }, */
                        /*SP_Informacion_Residencia_Extranjera = new SPInformacionResidenciaExtranjero
                        { 
                            FATCA_Cuestionario = new FatcaCuestionario
                            { 
                                Pais_Nacionalidad = result.ConsultarDatosRegistroCivilCedulaResult.CodigoPais
                            }
                        }*/
                    };
                }
            }
            
            return resultadoDatos;
        }

        public bool CreacionClienteJuridico(DatosPersonaJuridica valoreJuridico, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionPersonaJuridicaRequest envelope = new CreacionPersonaJuridicaRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaJuridica.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new CreacionPersonaJuridicaRequestBody
                {
                    DatosPersona = valoreJuridico
                }
            };

            string serviceName = Constantes.Tramas.CREAR_CLIENTE_JURIDICO;

            Log.Information($"ConectorBancoBLL/CreacionClienteJuridico: {serviceName} -> REQUEST API BANCO");

            CreacionPersonaJuridicaResponse result = _apiConnector.PostApi<CreacionPersonaJuridicaResponse, CreacionPersonaJuridicaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/CreacionClienteJuridico: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL /CreacionClienteJuridico: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return false;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return false;
            }

            return true;
        }

        public bool CreacionClienteNatural(DatosPersonaNatural clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionPersonaNaturalRequest envelope = new CreacionPersonaNaturalRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaNatural.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new CreacionPersonaNaturalRequestBody
                {
                    DatosPersona = clienteNatural
                }
            };

            string serviceName = Constantes.Tramas.CREAR_CLIENTE_NATURAL;

            Log.Information($"ConectorBancoBLL/CreacionClienteNatural: {serviceName} -> REQUEST API BANCO");

            CreacionPersonaNaturalResponse result = _apiConnector.PostApi<CreacionPersonaNaturalResponse, CreacionPersonaNaturalRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/CreacionClienteNatural: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / CreacionClienteNatural: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return false;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return false;
            }

            return true;
        }

        public CreacionPJCuentaAhorroResponse CreacionCuentaAhorroClienteJuridica(DatosCuentaAhorro cuentaAhorro, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionPJCuentaAhorroRequest envelope = new CreacionPJCuentaAhorroRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaJuridica.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new CreacionPJCuentaAhorroRequestBody
                {
                    DatosCuenta = cuentaAhorro
                }
            };

            string serviceName = Constantes.Tramas.CREAR_CUENTA_AHORRO_CLIENTE_JURIDICO;

            Log.Information($"ConectorBancoBLL/CreacionCuentaAhorroClienteJuridica: {serviceName} -> REQUEST API BANCO");

            CreacionPJCuentaAhorroResponse result = _apiConnector.PostApi<CreacionPJCuentaAhorroResponse, CreacionPJCuentaAhorroRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/CreacionCuentaAhorroClienteJuridica: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / CreacionCuentaAhorroClienteJuridica: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return null;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return null;
            }

            return result;
        }

        public CreacionPNCuentaAhorroResponse CreacionCuentaAhorroClienteNatural(DatosCuentaAhorro cuentaAhorro, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionPNCuentaAhorroRequest envelope = new CreacionPNCuentaAhorroRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaNatural.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new CreacionPNCuentaAhorroRequestBody { 
                    DatosCuenta = cuentaAhorro
                }
            };

            string serviceName = Constantes.Tramas.CREAR_CUENTA_AHORRO_CLIENTE_NATURAL;

            Log.Information($"ConectorBancoBLL/CreacionCuentaAhorroClienteNatural: {serviceName} -> REQUEST API BANCO");

            CreacionPNCuentaAhorroResponse result = _apiConnector.PostApi<CreacionPNCuentaAhorroResponse, CreacionPNCuentaAhorroRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/CreacionCuentaAhorroClienteNatural: {serviceName} -> RESPONSE API BANCO");

            if (result == null || result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / CreacionCuentaAhorroClienteNatural: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return null;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return null;
            }

            return result;
        }

        public CreacionPJCuentaCorrienteResponse CreacionCuentaCorrienteClienteJuridica(DatosCuentaCorriente valoresCuentaCorriente, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            CreacionPJCuentaCorrienteRequest envelope = new CreacionPJCuentaCorrienteRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaJuridica.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new CreacionPJCuentaCorrienteRequestBody
                {
                    DatosCuenta = valoresCuentaCorriente
                }
            };

            string serviceName = Constantes.Tramas.CREAR_CUENTA_CORRIENTE_CLIENTE_JURIDICO;

            Log.Information($"ConectorBancoBLL/CreacionCuentaCorrienteClienteJuridica: {serviceName} -> REQUEST API BANCO");

            CreacionPJCuentaCorrienteResponse result = _apiConnector.PostApi<CreacionPJCuentaCorrienteResponse, CreacionPJCuentaCorrienteRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/CreacionCuentaCorrienteClienteJuridica: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / CreacionCuentaCorrienteClienteJuridica: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return null;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return null;
            }

            return result;
        }

    public CreacionPNCuentaCorrienteResponse CreacionCuentaCorrienteClienteNatural(DatosCuentaCorriente cuentaCorriente, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
    {
        mensaje = new ErrorMapeoMensaje();

        CreacionPNCuentaCorrienteRequest envelope = new CreacionPNCuentaCorrienteRequest
        {
            HeaderRequest = new DTOs.EXT.Request.ASPersonaNatural.HeaderRequest
            {
                DateTime = fechaLlamada,
                StationIp = ipStation,
                UserName = usuario,
            },
            BodyRequest = new CreacionPNCuentaCorrienteRequestBody
            {
                DatosCuenta = cuentaCorriente
            }
        };

        string serviceName = Constantes.Tramas.CREAR_CUENTA_CORRIENTE_CLIENTE_NATURAL;

        Log.Information($"ConectorBancoBLL/CreacionCuentaCorrienteClienteNatural: {serviceName} -> REQUEST API BANCO");

        CreacionPNCuentaCorrienteResponse result = _apiConnector.PostApi<CreacionPNCuentaCorrienteResponse, CreacionPNCuentaCorrienteRequest>(serviceName, envelope, usuario,
            ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

        Log.Information($"ConectorBancoBLL/CreacionCuentaCorrienteClienteNatural: {serviceName} -> RESPONSE API BANCO");

        if (result != null && result.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
        {
            string error = result != null ? JsonConvert.SerializeObject(result) : "null";
            Log.Error("ConectorBancoBLL / CreacionCuentaCorrienteClienteNatural: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
            if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
            {
                mensaje.DescripcionError = result.HeaderResponse.returnMessage;
            }
            else
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
            }
            return null;
        }
        else if (result == null)
        {
            mensaje.CodigoError = mensaje.CodigoOrigen;
            string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
            if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
            {
                errorMessage = "Servicio no disponible. Por favor intente más tarde.";
            }
            mensaje.DescripcionError = errorMessage;
            return null;
        }

        return result;
    }

    public bool EdicionClienteJuridica(DatosPersonaJuridica clienteJuridico, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionPersonaJuridicaRequest envelope = new EdicionPersonaJuridicaRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaJuridica.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new EdicionPersonaJuridicaRequestBody
                {
                    DatosPersona = clienteJuridico
                }
            };

            string serviceName = Constantes.Tramas.EDITAR_CLIENTE_JURIDICO;

            Log.Information($"ConectorBancoBLL/EdicionClienteJuridica: {serviceName} -> REQUEST API BANCO");

            EdicionPersonaJuridicaResponse result = _apiConnector.PostApi<EdicionPersonaJuridicaResponse, EdicionPersonaJuridicaRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/EdicionClienteJuridica: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result?.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / EdicionClienteJuridica: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return false;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return false;
            }

            return true;
        }

        public bool EdicionClienteNatural(DatosPersonaNatural clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionPersonaNaturalRequest envelope = new EdicionPersonaNaturalRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASPersonaNatural.HeaderRequest
                { 
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new EdicionPersonaNaturalRequestBody
                {
                   DatosPersona = clienteNatural
                }
            };

            string serviceName = Constantes.Tramas.EDITAR_CLIENTE_NATURAL;

            Log.Information($"ConectorBancoBLL/EdicionClienteNatural: {serviceName} -> REQUEST API BANCO");

            EdicionPersonaNaturalResponse result = _apiConnector.PostApi<EdicionPersonaNaturalResponse, EdicionPersonaNaturalRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/EdicionClienteNatural: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result?.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / EdicionClienteNatural: ERROR => " + error.Replace(Environment.NewLine, ""));
                mensaje.CodigoError = result.HeaderResponse.returnCode;
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    mensaje.DescripcionError = result.HeaderResponse.returnMessage;
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    if (result.HeaderResponse.returnMessage == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
                return false;
            }
            else if (result == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
                return false;
            }

            return true;
        }

        public bool EdicionContactabilidad(Contactabilidad clienteNatural, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EdicionContactabilidadRequest envelope = new EdicionContactabilidadRequest
            {
                HeaderRequest = new DTOs.EXT.Request.ASContactabilidad.HeaderRequest
                {
                    DateTime = fechaLlamada,
                    StationIp = ipStation,
                    UserName = usuario,
                },
                BodyRequest = new EdicionContactabilidadRequestBody
                {
                    Contactabilidad = clienteNatural
                }
            };

            string serviceName = Constantes.Tramas.EDICION_CONTACTABILIDAD;

            Log.Information($"ConectorBancoBLL/EdicionContactabilidad: {serviceName} -> REQUEST API BANCO");

            EdicionContactabilidadResponse result = _apiConnector.PostApi<EdicionContactabilidadResponse, EdicionContactabilidadRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/EdicionContactabilidad: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result?.HeaderResponse.returnCode != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / EdicionContactabilidad: ERROR => " + error.Replace(Environment.NewLine, ""));
                //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.HeaderResponse.returnCode);
                if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                {
                    ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, result.HeaderResponse.returnMessage);
                }
                else
                {
                    string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                    ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, errorMessage);
                }
            }
            else if (result == null)
            {
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, "Servicio no disponible. Por favor intente más tarde.");
            }
            return true;
        }

        public EnvioExternoResponse.EnvioExternoResult EnviarCorreoExterno(Correo correo, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EnvioExternoRequest.Envelope envelope = new EnvioExternoRequest.Envelope
            {
                Body = new EnvioExternoRequest.Body
                {
                    EnvioExterno = new EnvioExternoRequest.EnvioExterno
                    {
                        Correo = correo
                    }
                }
            };

            string serviceName = Constantes.Tramas.ENVIAR_CORREO_EXTERNO;

            Log.Information($"ConectorBancoBLL/EnviarCorreoExterno: {serviceName} -> REQUEST API BANCO");

            EnvioExternoResponse.EnvioExternoResponseDto result = _apiConnector.PostApi<EnvioExternoResponse.EnvioExternoResponseDto, EnvioExternoRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestCorreoNamespaces);

            Log.Information($"ConectorBancoBLL/EnviarCorreoExterno: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.ValiacionMensaje != icCommon.Utils.Constantes.MappingCode.EXITO
                || (result != null && result.EnvioExternoResult != null && result.EnvioExternoResult.CodigoControl != 1))
            {
                //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.Codigo);
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / EnviarCorreoExterno: ERROR => " + error.Replace(Environment.NewLine, ""));
                if (result.EnvioExternoResult != null && result.EnvioExternoResult.CodigoControl != 1)
                {
                    ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.EnvioExternoResult?.CodigoControl.ToString());

                    if (codeResponse.CodigoError == icCommon.Utils.Constantes.MappingCode.NO_REGISTRADO)
                    {
                        mensaje.CodigoError = result.EnvioExternoResult.CodigoControl.ToString();
                        mensaje.DescripcionError = result.EnvioExternoResult.MensajeControl;

                    }
                    else
                    {
                        mensaje.CodigoError = codeResponse.CodigoError;
                        mensaje.DescripcionError = codeResponse.DescripcionError;
                    }
                }
                else
                {
                    mensaje.CodigoError = mensaje.CodigoOrigen;
                    string errorMessage = "Error en el servicio. Comunicarse con sistemas.";
                    if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }
            }
            else if (result == null || result.EnvioExternoResult == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
            }

            return result?.EnvioExternoResult;
        }

        public EnvioInternoResponse.EnvioInternoResult EnviarCorreoInterno(Correo correo, string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            EnvioInternoRequest.Envelope envelope = new EnvioInternoRequest.Envelope
            {
                Body = new EnvioInternoRequest.Body
                {
                    EnvioInterno = new EnvioInternoRequest.EnvioInterno { 
                        Correo = correo
                    }
                }
            };

            string serviceName = Constantes.Tramas.ENVIAR_CORREO_INTERNO;

            Log.Information($"ConectorBancoBLL/EnviarCorreoInterno: {serviceName} -> REQUEST API BANCO");

            EnvioInternoResponse.EnvioInternoResponseDto result = _apiConnector.PostApi<EnvioInternoResponse.EnvioInternoResponseDto, EnvioInternoRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestCorreoNamespaces);

            Log.Information($"ConectorBancoBLL/EnviarCorreoInterno: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.ValiacionMensaje != icCommon.Utils.Constantes.MappingCode.EXITO
                || (result != null && result.EnvioInternoResult != null && result.EnvioInternoResult.CodigoControl != 1))
            {
                string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                Log.Error("ConectorBancoBLL / EnviarCorreoInterno: ERROR => " + error.Replace(Environment.NewLine, ""));


                if (result.EnvioInternoResult != null && result.EnvioInternoResult.CodigoControl != 1)
                {
                    ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.EnvioInternoResult?.CodigoControl.ToString());

                    if (codeResponse.CodigoError == icCommon.Utils.Constantes.MappingCode.NO_REGISTRADO)
                    {
                        mensaje.CodigoError = result.EnvioInternoResult.CodigoControl.ToString();
                        mensaje.DescripcionError = result.EnvioInternoResult.MensajeControl;

                    }
                    else
                    {
                        mensaje.CodigoError = codeResponse.CodigoError;
                        mensaje.DescripcionError = codeResponse.DescripcionError;
                    }
                }
                else {
                    mensaje.CodigoError = mensaje.CodigoOrigen;
                    string errorMessage = "Error en el servicio. Comunicarse con sistemas.";
                    if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                    {
                        errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                    }
                    mensaje.DescripcionError = errorMessage;
                }                
            }
            else if (result == null || result.EnvioInternoResult == null)
            {
                mensaje.CodigoError = mensaje.CodigoOrigen;
                string errorMessage = "Error en el servicio. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                mensaje.DescripcionError = errorMessage;
            }

            return result?.EnvioInternoResult;
        }

        public bool ValidarListasNegras(string nombre, string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ValidarListasNegrasRequest.Envelope envelope = new ValidarListasNegrasRequest.Envelope
            {
                Body = new ValidarListasNegrasRequest.Body
                {
                    ValidarListasNegras = new ValidarListasNegrasRequest.ValidarListasNegras
                    {
                        Datos = new ValidarListasNegrasRequest.DatosListasNegras
                        {
                            NutCliente = nutCliente,
                            PuntoAcceso = ipStation,
                            TipoPuntoAcceso = "IP",
                            Usuario = usuario,
                            IdentificacionCliente = identificacion,
                            TipoIdentificacion = tipoIdentificacion,
                            Nombre = nombre
                        }
                    }
                }
            };

            string serviceName = Constantes.Tramas.VALIDAR_LISTAS_NEGRAS;

            Log.Information($"ConectorBancoBLL/ValidarListasNegras: {serviceName} -> REQUEST API BANCO");

            ValidarListasNegrasResponse.ValidarListasNegrasResponseDto result = _apiConnector.PostApi<ValidarListasNegrasResponse.ValidarListasNegrasResponseDto, ValidarListasNegrasRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestNamespaces);

            Log.Information($"ConectorBancoBLL/ValidarListasNegras: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.Mensaje.Codigo != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.Codigo);
                if (result.Mensaje.Codigo == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoError + "EXT", "Servicio de Validación de Listas Negras no disponible. Por favor intentarlo más tarde.");
                }
                ErrorUtil.ThrowAppException(serviceName, result.Mensaje.Codigo, result.Mensaje.Mensaje);
            }
            else if (result == null ) 
            {
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoError + "EXT", "Servicio de Validación de Listas Negras no disponible. Por favor intentarlo más tarde.");
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoError, "Error en el servicio de Validación de Listas Negras. Por favor intentarlo más tarde.");
            }

            return result.ValidarListasNegrasResult;
        }

        public bool ValidarPersonaExpuestaPoliticamente(string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ValidarPersonaExpuestaPoliticamenteRequest.Envelope envelope = new ValidarPersonaExpuestaPoliticamenteRequest.Envelope
            {
                Body = new ValidarPersonaExpuestaPoliticamenteRequest.Body
                {
                    ValidarPersonaExpuestaPoliticamente = new ValidarPersonaExpuestaPoliticamenteRequest.ValidarPersonaExpuestaPoliticamente
                    {
                        Datos = new ValidarPersonaExpuestaPoliticamenteRequest.PersonaExpuestaPoliticamente
                        {
                            NutCliente = nutCliente,
                            PuntoAcceso = ipStation,
                            TipoPuntoAcceso = "IP",
                            Usuario = usuario,
                            CedulaIdentidad = identificacion
                        }
                    }
                }
            };

            string serviceName = Constantes.Tramas.VALIDAR_PERSONA_EXPUESTA_POLITICAMENTE;

            Log.Information($"ConectorBancoBLL/ValidarPersonaExpuestaPoliticamente: {serviceName} -> REQUEST API BANCO");

            ValidarPersonaExpuestaPoliticamenteResponse.ValidarPersonaExpuestaPoliticamenteResponseDto result = _apiConnector.PostApi<ValidarPersonaExpuestaPoliticamenteResponse.ValidarPersonaExpuestaPoliticamenteResponseDto, ValidarPersonaExpuestaPoliticamenteRequest.Envelope>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje, customRequestNamespaces: Constantes.RequestNamespaces);

            Log.Information($"ConectorBancoBLL/ValidarPersonaExpuestaPoliticamente: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.Mensaje.Codigo != icCommon.Utils.Constantes.MappingCode.EXITO)
            {
                //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.Mensaje.Codigo);
                //ErrorUtil.ThrowAppException(serviceName, codeResponse.CodigoError, codeResponse.DescripcionError);
                if (result.Mensaje.Codigo == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoError + "EXT", "Servicio de Validación de Personas Expuestas Políticamente no disponible. Por favor intentarlo más tarde.");
                }
                ErrorUtil.ThrowAppException(serviceName, result.Mensaje.Codigo, result.Mensaje.Mensaje);
            }
            else if (result == null)
            {
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoError + "EXT", "Servicio de Validación de Personas Expuestas Políticamente no disponible. Por favor intentarlo más tarde.");
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoError, "Error en el servicio de Validación de Personas Expuestas Políticamente. Por favor intentarlo más tarde.");
            }

            return result.ValidarPersonaExpuestaPoliticamenteResult;
        }
        #endregion 

        #region Metodos utilizados para el flujo de Ahorro programado.
        public List<CuentaActivaAhorroProgramado> ConsultarCuentasActivas(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();

            ConsultaCuentasActivasRequest envelope = new ConsultaCuentasActivasRequest {
                TipoIdentificacion = tipoIdentificacion,
                Identificacion = identificacion
            };
            string serviceName = Constantes.Tramas.CONSULTA_CuentasActivas;
            Log.Information($"ConectorBancoBLL/ConsultarCuentasActivas: {serviceName} -> REQUEST API BANCO");
            ConsultaCuentasActivasResponse result = _apiConnector.PostApi<ConsultaCuentasActivasResponse, ConsultaCuentasActivasRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/ConsultarCuentasActivas: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL / ConsultarCuentasActivas: ERROR => " + (result.MensajeRetorno));
                }
            } else if (result == null) {                
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }
            List<CuentaActivaAhorroProgramado> resultadoDatos = new List<CuentaActivaAhorroProgramado>();
            if (result != null && result.ListaCuentasActivas != null && result.CodigoRetorno == 0) {
                foreach (var item in result.ListaCuentasActivas) {
                    item.Cuenta = _Common.convertirDecimalString(item.Cuenta);
                }
                resultadoDatos = result.ListaCuentasActivas;
            }
            return resultadoDatos;
        }

        public List<CuentaCliente> ConsultarCuentasCliente(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();

            CuentaClienteRequest envelope = new CuentaClienteRequest {
                TipoIdentificacion = tipoIdentificacion,
                Identificacion = identificacion
            };
            string serviceName = Constantes.Tramas.CONSULTA_CuentasCliente;
            Log.Information($"ConectorBancoBLL/ConsultarCuentaCliente: {serviceName} -> REQUEST API BANCO");
            CuentaClienteResponse result = _apiConnector.PostApi<CuentaClienteResponse, CuentaClienteRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/ConsultarCuentaCliente: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL / ConsultarCuentasActivas: ERROR => " + (result.MensajeRetorno));
                }
            } else if (result == null) {                
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }
            List<CuentaCliente> resultadoDatos = new List<CuentaCliente>();
            if (result != null && result.ListaCuentasCliente != null && result.CodigoRetorno == 0) {                
                resultadoDatos = result.ListaCuentasCliente;
            }
            return resultadoDatos;
        }
        
        public List<DatosContratoExt> ConsultarClienteContratos(string contrato,string tipoIdentificacion, string identificacion, Decimal cuenta, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();

            ClienteContratoRequest envelope = new ClienteContratoRequest {
                Contrato = contrato,
                TipoDocumento = tipoIdentificacion,
                Documento = identificacion,
                Cuenta = cuenta
            };

            string serviceName = Constantes.Tramas.CONSULTA_ClienteContratos;

            Log.Information($"ConectorBancoBLL/ConsultarClienteContratos: {serviceName} -> REQUEST API BANCO");

            ClienteContratoResponse result = _apiConnector.PostApi<ClienteContratoResponse, ClienteContratoRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);

            Log.Information($"ConectorBancoBLL/ConsultarClienteContratos: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL / ConsultarClienteContratos: ERROR => " + (result.MensajeRetorno));
                }
                /*else
                {
                    string error = result != null ? JsonConvert.SerializeObject(result) : "null";
                    Log.Error("ConectorBancoBLL / ConsultarCuentasActivas: ERROR => " + error.Replace(Environment.NewLine, ""));
                    //ErrorMapeoMensaje codeResponse = _errorHelper.ObtenerMensajeError(serviceName, result.HeaderResponse.returnCode);
                    if (int.TryParse(result.HeaderResponse.returnCode, out int valCode) && valCode > 0)
                    {
                        ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, result.HeaderResponse.returnMessage);
                    }
                    else
                    {
                        string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                        ErrorUtil.ThrowAppException(serviceName, result.HeaderResponse.returnCode, errorMessage);
                    }
                }*/
            } else if (result == null) {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            List<DatosContratoExt> resultadoDatos = new List<DatosContratoExt>();

            if (result != null && result.ListaDatosContrato != null && result.CodigoRetorno == 0) {
                foreach (var item in result.ListaDatosContrato) {
                    DatosContratoExt obj = new();
                    obj.contrato = item.contrato;
                    obj.CiudadAgencia = item.CiudadAgencia;
                    obj.TipoDocumento = item.TipoDocumento;
                    obj.Documento = item.Documento;
                    obj.Cliente = item.Cliente;
                    obj.CodigoProducto = item.CodigoProducto;
                    obj.DescripcionProducto = item.DescripcionProducto;
                    obj.TipoCtaDebito = item.TipoCtaDebito;
                    obj.CuentaDebito = item.CuentaDebito;
                    obj.NombreCuentaDebito = item.NombreCuentaDebito;
                    obj.TipoCtaAhorro = item.TipoCtaAhorro;
                    obj.CuentaAhorro = item.CuentaAhorro;
                    obj.CanalApertura = item.CanalApertura;
                    obj.DescCanalApertura = item.DescCanalApertura;
                    obj.FechaApertura = (item.FechaApertura.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(item.FechaApertura.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                    obj.HoraApertura = item.HoraApertura;
                    obj.FechaVencimiento = (item.FechaVencimiento.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(item.FechaVencimiento.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                    obj.MetaAhorro = item.MetaAhorro;
                    obj.MotivoAhorro = item.MotivoAhorro;
                    obj.MontoAhorro = item.MontoAhorro;
                    obj.MontoInicial = item.MontoInicial;
                    obj.MontoMeta = item.MontoMeta;
                    obj.DiaDebito = item.DiaDebito;
                    obj.FechaProximoDebito = (item.FechaProximoDebito.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(item.FechaProximoDebito.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                    obj.CodigoOficial = item.CodigoOficial;
                    obj.Oficial = item.Oficial;
                    obj.CargoOficial = item.CargoOficial;
                    obj.Plazo = item.Plazo;
                    obj.TasaApertura = item.TasaApertura;
                    obj.FormaDebito = item.FormaDebito;
                    obj.AplicaReintento = item.AplicaReintento;
                    obj.RenovacionAutomatica = item.RenovacionAutomatica;
                    obj.FormaRenovacion = item.FormaRenovacion;
                    obj.FechaULTRenovacion = (item.FechaULTRenovacion.ToString().Length < 10 ) ? "00/00/0000" : DateTime.ParseExact(item.FechaULTRenovacion.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                    obj.CantidadRenovacion = item.CantidadRenovacion;
                    obj.MontoDebitoAhorro = item.MontoDebitoAhorro;
                    obj.MontoBloqueo = item.MontoBloqueo;
                    obj.MontoTotalAhorro = item.MontoTotalAhorro;
                    obj.InteresGanado = item.InteresGanado;
                    obj.ContratoRenovado = item.ContratoRenovado;
                    resultadoDatos.Add(obj);
                }
                //resultadoDatos.EsCliente = true;
            } /*else {
                resultadoDatos.CodigoRetorno = result.CodigoRetorno;
                resultadoDatos.MensajeRetorno = result.MensajeRetorno;
            }*/

            return resultadoDatos;
        }

        public CancelarContratoResponse CancelarContrato(decimal contrato, string tipoIdentificacion, string identificacion, 
            Decimal cuenta, string canal, string oficial, string motivoCancelacion, string userAS, string correo, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();

            CancelarContratoRequest envelope = new CancelarContratoRequest {
                Contrato = contrato,
                TipoDocumento = tipoIdentificacion,
                Documento = identificacion,
                Cuenta = cuenta,
                Canal = canal,
                Oficial = oficial,
                MotivoCancelacion = motivoCancelacion,
                UserAS = userAS.PadRight(10)[..10].Trim(),
                CorreoElectronico = correo
            };
            string serviceName = Constantes.Tramas.Cancelar_Contratos;
            Log.Information($"ConectorBancoBLL/Cancelar_Contratos: {serviceName} -> REQUEST API BANCO");
            CancelarContratoResponse result = _apiConnector.PostApi<CancelarContratoResponse, CancelarContratoRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/Cancelar_Contratos: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL / Cancelar_Contratos: ERROR => " + (result.MensajeRetorno));
                }
            } else if (result == null) {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }
            CancelarContratoResponse resultadoDatos = new CancelarContratoResponse();

            if (result != null && result.CodigoRetorno == 0) {
                resultadoDatos = result;                
                //resultadoDatos.EsCliente = true;
            } else {
                resultadoDatos.CodigoRetorno = result.CodigoRetorno;
                resultadoDatos.MensajeRetorno = "Error al realizar la cancelación del producto.";
            }
            return resultadoDatos;
        }

        public SimuladorAhorroProgramadoResponse SimuladorAhorroProgramado(string producto, decimal MetaAhorro, decimal DepositoInicial, decimal MontoAhorro, int DiaDebito, int Plazo,
            string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();
            SimuladorAhorroProgramadoRequest simuladorAhorroProgramadoRequest = new() {
                Producto = producto,
                MetaAhorro = MetaAhorro,
                DepositoInicial = DepositoInicial,
                MontoAhorro = MontoAhorro,
                DiaDebito = DiaDebito,
                Plazo = Plazo
            };

            string serviceName = Constantes.Tramas.SIMULADOR_AHORRO_PROGRAMADO;
            Log.Information($"ConectorBancoBLL/SimuladorAhorroProgramado: {serviceName} -> REQUEST API BANCO");
            SimuladorAhorroProgramadoResponse result = _apiConnector.PostApi<SimuladorAhorroProgramadoResponse, SimuladorAhorroProgramadoRequest>(serviceName, simuladorAhorroProgramadoRequest, usuario,
               ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/SimuladorAhorroProgramado: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0)
                {
                    Log.Error("ConectorBancoBLL / SimuladorAhorroProgramado: ERROR => " + (result.MensajeRetorno));
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            SimuladorAhorroProgramadoResponse simuladorAhorroProgramadoResponse = new();
            /*if (result != null)
            {
                simuladorAhorroProgramadoResponse = result;
            }*/
            if (result != null ) {
                //SimuladorAhorroProgramadoResponse obj = new();
                //obj.FechaApertura = (item.FechaApertura.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(item.FechaApertura.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                //obj.FechaVencimiento = (item.FechaVencimiento.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(item.FechaVencimiento.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                //obj.FechaProximoDebito = (item.FechaProximoDebito.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(item.FechaProximoDebito.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                //obj.FechaULTRenovacion = (item.FechaULTRenovacion.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(item.FechaULTRenovacion.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                simuladorAhorroProgramadoResponse.MetaAhorro = result.MetaAhorro;
                simuladorAhorroProgramadoResponse.DepositoInicial = result.DepositoInicial;
                simuladorAhorroProgramadoResponse.MontoAhorro = result.MontoAhorro;
                simuladorAhorroProgramadoResponse.Tasa = result.Tasa;
                simuladorAhorroProgramadoResponse.Interes = result.Interes;
                simuladorAhorroProgramadoResponse.TotalAhorro = result.TotalAhorro;
                simuladorAhorroProgramadoResponse.CodigoRetorno = result.CodigoRetorno;
                simuladorAhorroProgramadoResponse.MensajeRetorno = result.MensajeRetorno;
                simuladorAhorroProgramadoResponse.FechaVcto = (result.FechaVcto.ToString().Length < 10) ? "00/00/0000" : DateTime.ParseExact(result.FechaVcto.ToString().Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                //resultadoDatos.EsCliente = true;
            }
            return simuladorAhorroProgramadoResponse;
        }

        public SolicitarContratoResponse SolicitudContrato(int codigoAgencia, string tipoDocumento, string documento, decimal cuentaDebitar, decimal cuentaAhorro, string canal, decimal servicio, 
            decimal montoMeta, decimal cuotaAhorro, string codMetaAhorro, string motivoAhorro, string oficial, decimal plazo, decimal depositoInicial, decimal diaDebito, string userAS, string correoElectronico, 
            string nutCliente, string usuario, string ipStation, 
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();
            SolicitarContratoRequest solicitarContratoRequest = new() {
                CodAgencia = codigoAgencia,
                TipoDocumento = tipoDocumento,
                Documento = documento,
                CuentaDebitar = cuentaDebitar,
                CuentaAhorro = cuentaAhorro,
                Canal = canal,
                Servicio = servicio,
                MontoMeta = montoMeta,
                CuotaAhorro = cuotaAhorro,
                CodMetaAhorro = codMetaAhorro,
                MotivoAhorro = motivoAhorro,
                Oficial = oficial,
                Plazo = plazo,
                DepositoInicial = depositoInicial,
                DiaDebito = diaDebito,
                UserAS = userAS,
                CorreoElectronico = correoElectronico
            };
            string serviceName = Constantes.Tramas.Solicitud_Contratos;
            Log.Information($"ConectorBancoBLL/SolicitudContratoAP: {serviceName} -> REQUEST API BANCO");
            SolicitarContratoResponse result = _apiConnector.PostApi<SolicitarContratoResponse, SolicitarContratoRequest>(serviceName, solicitarContratoRequest, usuario,
               ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);            
            Log.Information($"ConectorBancoBLL/SolicitudContratoAP: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL / SolicitudContratoAP: ERROR => " + (result.MensajeRetorno));
                }
            } else if (result == null) {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            SolicitarContratoResponse solicitarContratoResponse = new();
            
            if (result != null && result.CodigoRetorno == 0) {
                solicitarContratoResponse = result;
            } else {
                solicitarContratoResponse.CodigoRetorno = result.CodigoRetorno;
                solicitarContratoResponse.MensajeRetorno = result.MensajeRetorno;
            }
            return solicitarContratoResponse;
        }

        public SimulaCancelacionAPResponse SimulaCancelacionAP(decimal contrato, 
            string nutCliente, string usuario, string ipStation, 
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();
            SimulaCancelacionAPRequest simulaCancelacionAPRequest = new() {
                Contrato = contrato
            };

            string serviceName = Constantes.Tramas.SimulaCancelacionAP;
            Log.Information($"ConectorBancoBLL/SimulaCancelacionAP: {serviceName} -> REQUEST API BANCO");
            SimulaCancelacionAPResponse result = _apiConnector.PostApi<SimulaCancelacionAPResponse, SimulaCancelacionAPRequest>(serviceName, simulaCancelacionAPRequest, usuario,
               ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/SimulaCancelacionAP: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL / SimulaCancelacionAP: ERROR => " + (result.MensajeRetorno));
                }
            } else if (result == null) {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            SimulaCancelacionAPResponse simulaCancelacionAPResponse = new();
            if (result != null && result.CodigoRetorno == 0) {
                simulaCancelacionAPResponse = result;
            }
            return simulaCancelacionAPResponse;
        }

        public List<CatalogoAhorroProgramado> CatalogoAhorroProgramado(string Argumento, int Tabla,
            string nutCliente, string usuario, string ipStation, 
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();
            CatalogoAhorroProgramadoRequest CatalogoRequest = new() { Argumento = Argumento, Tabla = Tabla };
            string serviceName = Constantes.Tramas.CatalogoAhorroProgramado;

            Log.Information($"ConectorBancoBLL/CatalogoAhorroProgramado: {serviceName} -> REQUEST API BANCO");
            CatalogoAhorroProgramadoResponse result = _apiConnector.PostApi<CatalogoAhorroProgramadoResponse, CatalogoAhorroProgramadoRequest>(serviceName, CatalogoRequest, usuario,
               ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/CatalogoAhorroProgramado: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL/CatalogoAhorroProgramado: ERROR => " + (result.MensajeRetorno));
                }
            } else if (result == null) {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }
            List<CatalogoAhorroProgramado> catalogoResponse = new();
            if (result != null && result.CodigoRetorno == 0) {
                catalogoResponse = result.ListaCatalogoAP;
            }
            return catalogoResponse;
        }

        public ValidaCuentaResponse ValidaCuentaAhorroProgramado(string tipoDocumento, string documento, decimal cuenta,
            string nutCliente, string usuario, string ipStation, 
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();
            ValidaCuentaRequest validaCuentaRequest = new() {
                TipoIdentificacion = tipoDocumento,
                Identificacion = documento,
                Cuenta = cuenta
            };
            string serviceName = Constantes.Tramas.ValidaCuentaAhorroProgramado;
            Log.Information($"ConectorBancoBLL/SimulaCancelacionAP: {serviceName} -> REQUEST API BANCO");
            ValidaCuentaResponse result = _apiConnector.PostApi<ValidaCuentaResponse, ValidaCuentaRequest>(serviceName, validaCuentaRequest, usuario,
               ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/SimulaCancelacionAP: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0) {
                if (result.CodigoRetorno != 0) {
                    Log.Error("ConectorBancoBLL / SimulaCancelacionAP: ERROR => " + (result.MensajeRetorno));
                }
            } else if (result == null) {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT) {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }
            ValidaCuentaResponse validaCuentaResponse = new();
            if (result != null ) {
                validaCuentaResponse = result;
            }
            return validaCuentaResponse;
        }


        public List<Plazos> ConsultarPlazo(string producto, string nutCliente, string usuario, string ipStation,
           string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje) {
            mensaje = new ErrorMapeoMensaje();
            string tipprd = producto.Substring(0, 1);
            string prdduc = producto.Substring(1, 2);
            string subprd = producto.Substring(3, 2);
            PlazosRequest PlazosRequest = new() {
                TipoProducto = decimal.Parse(tipprd),
                Producto = decimal.Parse(prdduc),
                SubProducto = decimal.Parse(subprd),
            };
            string serviceName = Constantes.Tramas.ConsultaPlazosAP;
            Log.Information($"ConectorBancoBLL/SimulaCancelacionAP: {serviceName} -> REQUEST API BANCO");
            PlazosResponse result = _apiConnector.PostApi<PlazosResponse, PlazosRequest>(serviceName, PlazosRequest, usuario,
               ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/SimulaCancelacionAP: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0)
            {
                if (result.CodigoRetorno != 0)
                {
                    Log.Error("ConectorBancoBLL / SimulaCancelacionAP: ERROR => " + (result.MensajeRetorno));
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }
            List<Plazos> PlazosResponse = new();
            if (result != null)
            {
                PlazosResponse = result.ListaPlazos;
            }
            return PlazosResponse;
        }

        public SecuencialAhorroProgramado ObtenerSecuencial(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            mensaje = new ErrorMapeoMensaje();

            ObtenerSecuencialRequest envelope = new ObtenerSecuencialRequest
            {
                TipoIdentificacion = tipoIdentificacion,
                Identificacion = identificacion,
                Usuario = usuario,
                PuntoAcceso = ipStation
            };
            string serviceName = Constantes.Tramas.ObtenerSecuencialAP;
            Log.Information($"ConectorBancoBLL/ObtenerSecuencial: {serviceName} -> REQUEST API BANCO");
            ObtenerSecuencialResponse result = _apiConnector.PostApi<ObtenerSecuencialResponse, ObtenerSecuencialRequest>(serviceName, envelope, usuario,
                ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/ObtenerSecuencial: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0)
            {
                if (result.CodigoRetorno != 0)
                {
                    Log.Error("ConectorBancoBLL / ObtenerSecuencial: ERROR => " + (result.MensajeRetorno));
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }
            SecuencialAhorroProgramado resultadoDatos = new SecuencialAhorroProgramado();
            if (result != null && result.Identificacion != null && result.CodigoRetorno == 0)
            {
                //foreach (var item in result)
                //{
                //    item.Identificacion = _Common.convertirDecimalString(item.Identificacion);
                //}
                resultadoDatos.Identificacion = result.Identificacion;
            }
            return resultadoDatos;
        }
		
		public SimuladorModificaContratoAPResponse SimuladorModificaContratoAP(decimal contrato, decimal plazo, decimal monto,
            string nutCliente, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje)
        {
            SimuladorModificaContratoAPRequest simuladorModificaContratoAPRequest = new()
            {
                Contrato = contrato,
                Plazo = plazo,
                Monto = monto,
            };
            string serviceName = Constantes.Tramas.SimuladorModificaContratoAP;
            Log.Information($"ConectorBancoBLL/SimuladorModificaContratoAP: {serviceName} -> REQUEST API BANCO");
            SimuladorModificaContratoAPResponse result = _apiConnector.PostApi<SimuladorModificaContratoAPResponse, SimuladorModificaContratoAPRequest>(serviceName, simuladorModificaContratoAPRequest, usuario,
               ipStation, tipoConfirmacion, fechaLlamada, idTransaccion, ref mensaje);
            Log.Information($"ConectorBancoBLL/SimuladorModificaContratoAP: {serviceName} -> RESPONSE API BANCO");

            if (result != null && result.CodigoRetorno != 0)
            {
                if (result.CodigoRetorno != 0)
                {
                    Log.Error("ConectorBancoBLL / SimuladorModificaContratoAP: ERROR => " + (result.MensajeRetorno));
                }
            }
            else if (result == null)
            {
                string errorMessage = "Error en el servicio central. Comunicarse con sistemas.";
                if (mensaje.CodigoOrigen == icCommon.Utils.Constantes.MappingCode.SERVICIO_TIMEOUT)
                {
                    errorMessage = "Servicio no disponible. Por favor intente más tarde.";
                }
                ErrorUtil.ThrowAppException(serviceName, mensaje.CodigoOrigen, errorMessage);
            }

            SimuladorModificaContratoAPResponse simuladorModificaContratoAPResponse = new();
            if (result != null && result.CodigoRetorno == 0)
            {
                simuladorModificaContratoAPResponse = result;
            }
            return simuladorModificaContratoAPResponse;
        }
		
        #endregion
    }
}
