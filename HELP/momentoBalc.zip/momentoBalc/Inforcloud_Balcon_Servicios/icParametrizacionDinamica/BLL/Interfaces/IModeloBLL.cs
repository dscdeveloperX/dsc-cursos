﻿using icParametrizacionDinamica.DTOs.API.Request.Modelos;
using icParametrizacionDinamica.DTOs.API.Response.Modelos;

namespace icParametrizacionDinamica.BLL.Interfaces
{
    public interface IModeloBLL
    {
        ConsultaModeloResponse ObtenerModeloPorId(ConsultaModeloRequest request);
        ListaModelosResponse ListarModelos(ListaModelosRequest request);
        CreacionModeloResponse CrearModelo(CreacionModeloRequest request);
        EdicionModeloResponse ActualizarModelo(EdicionModeloRequest request);
        EliminacionModeloResponse EliminarModelo(EliminacionModeloRequest request);
        ConsultaCamposResponse ObtenerListaCamposPorModeloId(ConsultaModeloRequest request);
    }
}
