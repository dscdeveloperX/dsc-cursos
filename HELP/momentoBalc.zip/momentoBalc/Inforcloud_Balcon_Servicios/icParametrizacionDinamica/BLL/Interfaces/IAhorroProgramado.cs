﻿using icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado;
using icParametrizacionDinamica.DTOs.API.Response.AhorroProgramado;

namespace icParametrizacionDinamica.BLL.Interfaces
{
    public interface IAhorroProgramado {
        AhorroProgramadoResponse SolicitudContratoAP(SolicitudAhorroProgramadoRequest request);
        AhorroProgramadoResponse CancelarContrato(CancelarContratoRequest request);
        AhorroProgramadoResponse SimuladorCancelacionContrato(SimuladorCancelacionContratoRequest request);
        AhorroProgramadoResponse SimuladorContrato(SimuladorContratoRequest request);
        AhorroProgramadoResponse CatalogoAhorroProgramado(CatalogoAhorroProgramadoRequest request);
        AhorroProgramadoResponse SimuladorModificaContrato(SimuladorModificaContratoRequest request);
    }
}
