﻿using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;

namespace icParametrizacionDinamica.BLL.Interfaces
{
    public interface IFormatoBLL
    {
        ConsultaFormatoResponse ObtenerFormatoPorId(ConsultaFormatoRequest request);
        ListaFormatosResponse ListarFormatos(ListaFormatosRequest request);
        CreacionFormatoResponse CrearFormato(CreacionFormatoRequest request);
        EdicionFormatoResponse ActualizarFormato(EdicionFormatoRequest request);
        EliminacionFormatoResponse EliminarFormato(EliminacionFormatoRequest request);

        ObtenerCamposFormatoResponse ObtenerCamposFormato(ObtenerCamposFormatoRequest request);        
    }
}
