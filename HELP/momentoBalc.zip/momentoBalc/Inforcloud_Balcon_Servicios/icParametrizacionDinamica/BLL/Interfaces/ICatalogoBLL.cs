﻿using icParametrizacionDinamica.DTOs.API.Request.Catalogos;
using icParametrizacionDinamica.DTOs.API.Response.Catalogos;

namespace icParametrizacionDinamica.BLL.Interfaces
{
    public interface ICatalogoBLL
    {
        ConsultaCatalogoResponse ObtenerCatalogoPorId(ConsultaCatalogoRequest request);
        ListaCatalogosResponse ListarCatalogos(ListaCatalogosRequest request);
        ListaNombreCatalogosResponse ListarNombresCatalogos(ListaNombreCatalogosRequest request);
        CreacionCatalogoResponse CrearCatalogo(CreacionCatalogoRequest request);
        EdicionCatalogoResponse ActualizarCatalogo(EdicionCatalogoRequest request);
        EliminacionCatalogoResponse EliminarCatalogo(EliminacionCatalogoRequest request);
    }
}
