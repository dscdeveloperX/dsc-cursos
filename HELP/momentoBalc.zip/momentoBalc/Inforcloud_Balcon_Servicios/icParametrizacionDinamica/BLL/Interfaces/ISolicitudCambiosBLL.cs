﻿using icCommon.Modelos;
using icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios;
using System.Collections.Generic;

namespace icParametrizacionDinamica.BLL.Interfaces
{
    public interface ISolicitudCambiosBLL
    {
        long CrearSolicitudCambio(SolicitudCambio solicitudCambio);
        bool RechazarSolicitudCambio(long cambioId, string usuarioAprobador, string razon, string ipstation);
        bool AprobarSolicitudCambio(long cambioId, string usuarioAprobador, string nutCliente, string userName, string stationIp, ref Dictionary<string, dynamic> resultados, ref List<ValoresDetalleResumen> detalles);

        EnviarFormularioResponse AprobarFormulario(AprobarFormularioRequest request);
        EnviarFormularioResponse RechazarFormulario(RechazarFormularioRequest request);
        ListaSolicitudCambiosResponse ListarSolicitudesCambios(ListaSolicitudCambiosRequest request);
        ConsultaSolicitudCambioResponse ConsultarSolicitudCambioPorId(ConsultaSolicitudCambioRequest request);
    }
}
