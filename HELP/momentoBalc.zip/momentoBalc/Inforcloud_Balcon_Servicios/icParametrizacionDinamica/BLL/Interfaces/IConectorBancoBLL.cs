﻿using icCommon.Modelos;
using icParametrizacionDinamica.DTOs.EXT;
using icParametrizacionDinamica.DTOs.EXT.Request.EnvioCorreo;
using icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaNatural;
using System;
using icParametrizacionDinamica.DTOs.EXT.Response.EnvioCorreo;
using icParametrizacionDinamica.DTOs.EXT.Response.ASPersonaJuridica;
using System.Collections.Generic;
using icParametrizacionDinamica.DTOs.EXT.Response.AhorroProgramado;

namespace icParametrizacionDinamica.BLL.Interfaces
{
    public interface IConectorBancoBLL
    {
        //DSC: CONSULTAR NOMBRE EMPRESA
        DatosEmpresa ConsultarNombreEmpresa(string rucEmpresa, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);



        //PERSONA NATURAL
        DatosPersonaNatural ConsultarClienteNatural(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        bool CreacionClienteNatural(DatosPersonaNatural clienteNatural,
           string nutCliente, string usuario, string ipStation, //campos audit
           string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        bool EdicionClienteNatural(DatosPersonaNatural clienteNatural,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);


        public bool EdicionClienteNaturalFallecido(DatosPersonaNaturalFallecido clienteNaturalFallecido, 
            string nutCliente, string usuario, string ipStation, string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);


        //PRODUCTOS PERSONA NATURAL

        CreacionPNCuentaAhorroResponse CreacionCuentaAhorroClienteNatural(DatosCuentaAhorro cuentaAhorro,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        CreacionPNCuentaCorrienteResponse CreacionCuentaCorrienteClienteNatural(DatosCuentaCorriente cuentaCorriente,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);


        //PERSONA JURIDICA 
        DatosPersonaJuridica ConsultarClienteJuridica(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);        
        bool EdicionClienteJuridica(DatosPersonaJuridica clienteNatural,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        bool CreacionClienteJuridico(DatosPersonaJuridica valoreJuridico, 
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        //PRODUCTOS PERSONA JURIDICA
        CreacionPJCuentaAhorroResponse CreacionCuentaAhorroClienteJuridica(DatosCuentaAhorro clienteNatural,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        CreacionPJCuentaCorrienteResponse CreacionCuentaCorrienteClienteJuridica(DatosCuentaCorriente valoresCuentaCorriente,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        //SERVICIOS BANCO PERSONA

        DatosPersonaNatural ConsultarDatosRegistroCivil(string canal, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        bool ValidarListasNegras(string nombre, string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        bool ValidarPersonaExpuestaPoliticamente(string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        //SERVICIOS CORREO

        EnvioExternoResponse.EnvioExternoResult EnviarCorreoExterno(Correo correo, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        EnvioInternoResponse.EnvioInternoResult EnviarCorreoInterno(Correo correo, //campos consulta
           string nutCliente, string usuario, string ipStation, //campos audit
           string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        //CONTACTABILIDAD
        public Contactabilidad ConsultarContactabilidad(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
        public bool EdicionContactabilidad(Contactabilidad clienteNatural,
            string nutCliente, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);


        //Metodos de Ahorro Programado
        List<CuentaActivaAhorroProgramado> ConsultarCuentasActivas(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        public List<CuentaCliente> ConsultarCuentasCliente(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        List<DatosContratoExt> ConsultarClienteContratos(string contrato, string tipoIdentificacion, string identificacion, Decimal cuenta, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        CancelarContratoResponse CancelarContrato(decimal contrato, string tipoIdentificacion, string identificacion,
            Decimal cuenta, string canal, string oficial, string motivoCancelacion, string userAS, string correo, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        SimuladorAhorroProgramadoResponse SimuladorAhorroProgramado(string producto, decimal MetaAhorro, decimal DepositoInicial, decimal MontoAhorro, int DiaDebito, int Plazo,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        SolicitarContratoResponse SolicitudContrato(int codigoAgencia, string tipoDocumento, string documento, decimal cuentaDebitar, decimal cuentaAhorro, string canal,
            decimal servicio, decimal montoMeta, decimal cuotaAhorro, string codMetaAhorro, string motivoAhorro, string oficial, decimal plazo, decimal depositoInicial,
            decimal diaDebito, string userAS, string correoElectronico,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        SimulaCancelacionAPResponse SimulaCancelacionAP(decimal contrato,
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        List<CatalogoAhorroProgramado> CatalogoAhorroProgramado(string Argumento, int Tabla,
            string nutCliente, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        ValidaCuentaResponse ValidaCuentaAhorroProgramado(string tipoDocumento, string documento, decimal cuenta,
            string nutCliente, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        List<Plazos> ConsultarPlazo(string producto, string nutCliente, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);

        SecuencialAhorroProgramado ObtenerSecuencial(string tipoIdentificacion, string identificacion, //campos consulta
            string nutCliente, string usuario, string ipStation, //campos audit
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
			
		SimuladorModificaContratoAPResponse SimuladorModificaContratoAP(decimal contrato, decimal plazo, decimal monto,
            string nutCliente, string usuario, string ipStation,
            string tipoConfirmacion, DateTime fechaLlamada, string idTransaccion, ref ErrorMapeoMensaje mensaje);
    }
}
