﻿using icParametrizacionDinamica.DTOs.API.Request.ContactabilidadCliente;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.ContactabilidadCliente;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;

namespace icParametrizacionDinamica.BLL.Interfaces
{
    public interface IBalconServicios
    {
        //BALCON
        EnviarFormularioResponse CalcularCampoEnLinea(CalcularCampoRequest request);
        ObtenerFormularioResponse ObtenerFormulario(ObtenerFormularioRequest request);
        EnviarFormularioResponse EnviarFormularioPersona(EnviarFormularioRequest request);
        EnviarFormularioResponse EnviarFormularioProducto(EnviarFormularioRequest request);
        //CONTACTABILIDAD
        ConsultarContactResponse ConsultarContactabilidad(ConsultarContactRequest request);
        EditarContactResponse EditarContactabilidad(EditarContactRequest request);
    }
}
