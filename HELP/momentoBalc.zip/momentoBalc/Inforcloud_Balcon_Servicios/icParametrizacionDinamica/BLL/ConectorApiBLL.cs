﻿using icAuth.DLL.Interfaces;
using icCommon.ConexionApi;
using icCommon.ManejoErrores;
using icCommon.Modelos;
using Newtonsoft.Json;
using System;

namespace icParametrizacionDinamica.BLL
{
    public class ConectorApiBLL : ConectorApi
    {
        private readonly IProveedorTrama _proveedorTrama;
        public ConectorApiBLL(IProveedorRutas routeHelper, IMapeoMensajesError errorHelper, ITokenCache tokenCache, IGeneradorToken generadorToken, IProveedorTrama proveedorTrama) : base(routeHelper, errorHelper, tokenCache, generadorToken)
        {
            _routeHelper = routeHelper;
            _errorHelper = errorHelper;
            _proveedorTrama = proveedorTrama;
            _tokenCache = tokenCache;
            _tokenGenerator = generadorToken;
        }

        public override GenericTokenResponse ParseTokenResponse(string serviceName, string apiResponse)
        {
            GenericTokenResponse res = null;
            switch (serviceName)
            {
                case "SECURITY_JWT":
                    res = JsonConvert.DeserializeObject<ExternalTokenResponse>(apiResponse);
                    break;
            }

            return res;
        }

        public override long RegistrarRequest(string serviceName, string content, string user, string ipStation, string type, DateTime callDatetime, string valueId, int thread = 1)
        {
            Trama traceLog = new Trama
            {
                Ip = ipStation,
                TramaRequest = content,
                FechaRequest = callDatetime,
                Servicio = serviceName,
                Hilo = thread,
                Estado = "REQUEST",
                Usuario = user,
                Valor = valueId,
                TipoValor = type
            };
            long traceId = _proveedorTrama.CrearTrama(traceLog);
            return traceId;
        }

        public override void RegistrarResponse(long dispatchId, string content)
        {
            Trama traceLog = new Trama
            {
                TramaId = dispatchId,
                TramaResponse = content,
                Estado = "RESPONSE"
            };
            _proveedorTrama.ActualizarTrama(traceLog);
        }
    }
}
