﻿using icCommon.DTOs.API;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Modelos;
using icParametrizacionDinamica.DTOs.API.Response.Modelos;
using icParametrizacionDinamica.DTOs.DB.Response.Modelos;
using icParametrizacionDinamica.Models;
using Serilog;
using System;

namespace icParametrizacionDinamica.BLL
{
    public class ModeloBLL : IModeloBLL
    {
        private readonly IModeloDLL _clHelper;
        public ModeloBLL(IModeloDLL dHelper)
        {
            _clHelper = dHelper;
        }

        public EdicionModeloResponse ActualizarModelo(EdicionModeloRequest request)
        {
            EdicionModeloResponse response = new EdicionModeloResponse();
            EdicionModeloResponseBody bodyResponse = new EdicionModeloResponseBody();
            int ModeloId;
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                EdicionModeloRequestBody body = request.BodyRequest;

                Log.Information("ModeloBLL/ActualizarModelo: Consulta DB -> INICIO");
                ModeloId = _clHelper.ActualizarModelo(header, body);
                Log.Information("ModeloBLL/ActualizarModelo: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.ModelosEditados = ModeloId;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("ModeloBLL/ActualizarModelo: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public CreacionModeloResponse CrearModelo(CreacionModeloRequest request)
        {
            CreacionModeloResponse response = new CreacionModeloResponse();
            CreacionModeloResponseBody bodyResponse = new CreacionModeloResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                CreacionModeloRequestBody body = request.BodyRequest;

                //int itemsPerPage = header.PageSize;

                //Create Modelo
                Log.Information("ModeloBLL/CrearModelo: Consulta DB -> INICIO");
                long Modelos = _clHelper.CrearModelo(header, body);
                Log.Information("ModeloBLL/CrearModelo: Consulta DB -> RESPUESTA");
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.ModeloId = Modelos;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("ModeloBLL/CrearModelo: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public EliminacionModeloResponse EliminarModelo(EliminacionModeloRequest request)
        {
            EliminacionModeloResponse response = new EliminacionModeloResponse();
            EliminacionModeloResponseBody bodyResponse = new EliminacionModeloResponseBody();
            HeaderResponse headerResponseDto = new HeaderResponse();
            try
            {
                HeaderRequest header = request.HeaderRequest;
                EliminacionModeloRequestBody body = request.BodyRequest;

                Log.Information("ModeloBLL/EliminarModelo: Consulta DB -> INICIO");
                int ModelosDeleted = _clHelper.EliminarModelos(header, body);
                Log.Information("ModeloBLL/EliminarModelo: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = 1;
                headerResponseDto.pageSize = 1;
                headerResponseDto.totalRecords = 1;
                headerResponseDto.totalPages = 1;
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.ModelosEliminados = ModelosDeleted;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("ModeloBLL/EliminarModelo: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ListaModelosResponse ListarModelos(ListaModelosRequest request)
        {
            ListaModelosResponse response = new ListaModelosResponse();
            ListaModelosResponseBody bodyResponse = new ListaModelosResponseBody();
            QueryModelosResponse Modelos;
            HeaderResponse headerResponseDto = new HeaderResponse();
            int page = request.HeaderRequest.PageRequested;
            int itemsPerPage = request.HeaderRequest.PageSize;

            try
            {
                Log.Information("ModeloBLL/ListarModelos: Consulta DB -> INICIO");
                Modelos = _clHelper.ListarModelos(request.HeaderRequest, request.BodyRequest);
                Log.Information("ModeloBLL/ListarModelos: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = Modelos.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Modelos = Modelos.Modelos;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("ModeloBLL/ListarModelos: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaCamposResponse ObtenerListaCamposPorModeloId(ConsultaModeloRequest request)
        {
            ConsultaCamposResponse response = new ConsultaCamposResponse();
            ConsultaCamposResponseBody bodyResponse = new ConsultaCamposResponseBody();
            QueryCamposResponse Modelos;
            HeaderResponse headerResponseDto = new HeaderResponse();
            int page = request.HeaderRequest.PageRequested;
            int itemsPerPage = request.HeaderRequest.PageSize;

            try
            {
                Log.Information("ModeloBLL/ObtenerListaCamposPorModeloId: Consulta DB -> INICIO");
                Modelos = _clHelper.ObtenerListaCamposPorModeloId(request.HeaderRequest, request.BodyRequest);
                Log.Information("ModeloBLL/ObtenerListaCamposPorModeloId: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                headerResponseDto.currentPage = page;
                headerResponseDto.pageSize = itemsPerPage;
                headerResponseDto.totalRecords = Modelos.Total;
                headerResponseDto.totalPages = (int)Math.Ceiling((double)headerResponseDto.totalRecords / (double)headerResponseDto.pageSize);
                //Create Body Response
                response.HeaderResponse = headerResponseDto;
                bodyResponse.Campos = Modelos.Campos;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("ModeloBLL/ObtenerListaCamposPorModeloId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }

        public ConsultaModeloResponse ObtenerModeloPorId(ConsultaModeloRequest request)
        {
            try
            {
                ConsultaModeloResponse response = new ConsultaModeloResponse();
                HeaderResponse headerResponseDto = new HeaderResponse();
                ConsultaModeloResponseBody bodyResponse = new ConsultaModeloResponseBody();
                ModeloDto Modelo = new ModeloDto();

                int itemsPerPage = request.HeaderRequest.PageSize;

                Log.Information("ModeloBLL/ObtenerModeloPorId: Consulta DB -> INICIO");
                Modelo = _clHelper.ObtenerModeloPorId(request.HeaderRequest, request.BodyRequest);
                Log.Information("ModeloBLL/ObtenerModeloPorId: Consulta DB -> RESPUESTA");
                //Create Header response
                headerResponseDto.returnCode = "OK";
                headerResponseDto.returnMessage = "OK";
                if (Modelo != null)
                {
                    headerResponseDto.currentPage = 1;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 1;
                    headerResponseDto.totalPages = 1;
                }
                else
                {
                    headerResponseDto.currentPage = 0;
                    headerResponseDto.pageSize = itemsPerPage;
                    headerResponseDto.totalRecords = 0;
                    headerResponseDto.totalPages = 0;
                }
                //Create Body Response
                bodyResponse.Modelo = Modelo;

                response.HeaderResponse = headerResponseDto;
                response.BodyResponse = bodyResponse;
                return response;
            }
            catch (ArgumentOutOfRangeException e)
            {
                Log.Error("ModeloBLL/ObtenerModeloPorId: ArgumentOutOfRangeException -> " + e.Message);
                throw;
            }
        }
    }
}
