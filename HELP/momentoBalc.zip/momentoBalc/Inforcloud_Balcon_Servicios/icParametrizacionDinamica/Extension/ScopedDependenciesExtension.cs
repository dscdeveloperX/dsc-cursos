﻿using icCommon.Extensiones;
using icParametrizacionDinamica.BLL;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DLL;
using icParametrizacionDinamica.DLL.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace icParametrizacionDinamica.Extension
{
    public static class ScopedDependenciesExtension
    {
        public static void AddInforcloudScopedDependencies(this IServiceCollection services)
        {
            #region Agregar DLL Helpers
            services.AddScoped<ICatalogoDLL, CatalogoDLL>();
            services.AddScoped<IModeloDLL, ModeloDLL>();
            services.AddScoped<IFormatoDLL, FormatoDLL>();
            services.AddScoped<ICorreoDLL, CorreoDLL>();
            #endregion

            #region Agregar BLL Repositories
            services.AddScoped<ICatalogoBLL, CatalogoBLL>();
            services.AddScoped<IModeloBLL, ModeloBLL>();
            services.AddScoped<IFormatoBLL, FormatoBLL>();
            services.AddScoped<IBalconServicios, BalconServicios>();
            services.AddScoped<ISolicitudCambiosBLL, SolicitudCambiosBLL>();
            #endregion

            services.AddScoped<IConectorBancoBLL, ConectorBancoBLL>();
            services.AddScoped<IAhorroProgramado, AhorroProgramado>();

            services.AddInforcloudCommonUse();
            services.AddInforcloudExternalConnector<ConectorApiBLL>();
        }
    }
}
