﻿using FluentValidation.Results;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.ContactabilidadCliente;
using icParametrizacionDinamica.DTOs.API.Response.ContactabilidadCliente;
using icParametrizacionDinamica.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace icParametrizacionDinamica.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/parametrizacion/contactabilidad")]
    [ApiController]
    [Authorize]
    public class ContactabilidadController : ControllerBase
    {
        private readonly IBalconServicios _clRepository;
        public ContactabilidadController(IBalconServicios dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Consultar")]
        [ProducesResponseType(200, Type = typeof(ConsultarContactResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultarContactResponse> ConsultarContactabilidad([FromBody] ConsultarContactRequest catalogueRequestDto)
        {
            ConsultarContactResponse response = new();
            ConsultarContactValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ContactabilidadController/ConsultarContactabilidad: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ContactabilidadController/ConsultarContactabilidad -> Request: " + reqStr);
                response = _clRepository.ConsultarContactabilidad(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ContactabilidadController/ConsultarContactabilidad -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("Editar")]
        [ProducesResponseType(200, Type = typeof(EditarContactResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EditarContactResponse> EditarContactabilidad([FromBody] EditarContactRequest catalogueRequestDto)
        {
            EditarContactResponse response = new();
            EditarContactValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ContactabilidadController/EditarContactabilidad: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ContactabilidadController/EditarContactabilidad -> Request: " + reqStr);
                response = _clRepository.EditarContactabilidad(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ContactabilidadController/EditarContactabilidad -> Response: " + resStr);
                return Ok(response);
            }
        }

    }
}
