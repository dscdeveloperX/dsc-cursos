﻿using FluentValidation.Results;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace icParametrizacionDinamica.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/parametrizacion/balcon")]
    [ApiController]
    [Authorize]
    public class BalconServiciosController : ControllerBase
    {
        private readonly IBalconServicios _clRepository;
        public BalconServiciosController(IBalconServicios dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("ObtenerFormulario")]
        [ProducesResponseType(200, Type = typeof(ObtenerFormularioResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ObtenerFormularioResponse> ObtenerFormulario([FromBody] ObtenerFormularioRequest catalogueRequestDto)
        {
            Log.Information("BalconServiciosController/ObtenerFormulario");
            ObtenerFormularioResponse response = new();
            ObtenerFormularioValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("BalconServiciosController/ObtenerFormulario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "DEBE INDICAR EL NÚMERO DE IDENTIFICACIÓN.";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                Log.Information("BalconServiciosController/ObtenerFormulario -> Request: ");
                response = _clRepository.ObtenerFormulario(catalogueRequestDto);
                Log.Information("BalconServiciosController/ObtenerFormulario -> Response: ");
                return Ok(response);
            }
        }

        [HttpPost("EnviarFormularioPersona")]
        [ProducesResponseType(200, Type = typeof(EnviarFormularioResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EnviarFormularioResponse> EnviarFormularioPersona([FromBody] EnviarFormularioRequest catalogueRequestDto)
        {
            Log.Information("BalconServiciosController/EnviarFormularioPersona");
            EnviarFormularioResponse response = new();
            EnviarFormularioValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("BalconServiciosController/EnviarFormularioPersona: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                Log.Information("BalconServiciosController/EnviarFormularioPersona -> Request: ");
                response = _clRepository.EnviarFormularioPersona(catalogueRequestDto);
                Log.Information("BalconServiciosController/EnviarFormularioPersona -> Response: ");
                return Ok(response);
            }
        }

        [HttpPost("EnviarFormularioProducto")]
        [ProducesResponseType(200, Type = typeof(EnviarFormularioResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EnviarFormularioResponse> EnviarFormularioProducto([FromBody] EnviarFormularioRequest catalogueRequestDto)
        {
            Log.Information("BalconServiciosController/EnviarFormularioProducto");
            EnviarFormularioResponse response = new();
            EnviarFormularioValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("BalconServiciosController/EnviarFormularioProducto: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }

                Log.Information("BalconServiciosController/EnviarFormularioProducto -> Request: " );
                response = _clRepository.EnviarFormularioProducto(catalogueRequestDto);
                Log.Information("BalconServiciosController/EnviarFormularioProducto -> Response: ");
                return Ok(response);
            }
        }

        [HttpPost("CalcularCampoEnLinea")]
        [ProducesResponseType(200, Type = typeof(EnviarFormularioResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EnviarFormularioResponse> CalcularCampoEnLinea([FromBody] CalcularCampoRequest catalogueRequestDto)
        {
            EnviarFormularioResponse response = new();
            CalcularCampoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("BalconServiciosController/CalcularCampoEnLinea: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;

                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("BalconServiciosController/CalcularCampoEnLinea -> Request: " + reqStr);
                response = _clRepository.CalcularCampoEnLinea(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("BalconServiciosController/CalcularCampoEnLinea -> Response: " + resStr);
                return Ok(response);
            }
        }


    }
}
