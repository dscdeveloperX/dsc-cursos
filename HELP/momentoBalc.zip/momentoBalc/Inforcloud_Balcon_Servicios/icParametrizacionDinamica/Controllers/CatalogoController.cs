﻿using FluentValidation.Results;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.Catalogos;
using icParametrizacionDinamica.DTOs.API.Response;
using icParametrizacionDinamica.DTOs.API.Response.Catalogos;
using icParametrizacionDinamica.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;

namespace icParametrizacionDinamica.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/parametrizacion/catalogos")]
    [ApiController]
    [Authorize]
    public class CatalogoController : ControllerBase
    {
        private readonly ICatalogoBLL _clRepository;
        public CatalogoController(ICatalogoBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaCatalogosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaCatalogosResponse> ListarCatalogos([FromBody] ListaCatalogosRequest catalogueRequestDto)
        {
            ListaCatalogosResponse response = new();
            ListaCatalogosValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ListarCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("CatalogoController/ListarCatalogos -> Request: " + reqStr);
                response = _clRepository.ListarCatalogos(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("CatalogoController/ListarCatalogos -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("ListarNombres")]
        [ProducesResponseType(200, Type = typeof(ListaNombreCatalogosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaNombreCatalogosResponse> ListarNombresCatalogos([FromBody] ListaNombreCatalogosRequest catalogueRequestDto)
        {
            ListaNombreCatalogosResponse response = new();
            ListaNombreCatalogosValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ListarNombresCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("CatalogoController/ListarNombresCatalogos -> Request: " + reqStr);
                response = _clRepository.ListarNombresCatalogos(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("CatalogoController/ListarNombresCatalogos -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaCatalogoResponse> ObtenerCatalogoPorId([FromBody] ConsultaCatalogoRequest catalogueRequestDto)
        {
            ConsultaCatalogoResponse response = new();
            ConsultaCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ObtenerCatalogoPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("CatalogoController/ObtenerCatalogoPorId -> Request: " + reqStr);
                response = _clRepository.ObtenerCatalogoPorId(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("CatalogoController/ObtenerCatalogoPorId -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("Crear")]
        [ProducesResponseType(200, Type = typeof(CreacionCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionCatalogoResponse> CrearCatalogos([FromBody] CreacionCatalogoRequest catalogueRequestDto)
        {
            CreacionCatalogoResponse response = new();
            CreacionCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/CrearCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("CatalogoController/CrearCatalogos -> Request: " + reqStr);
                response = _clRepository.CrearCatalogo(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("CatalogoController/CrearCatalogos -> Response: " + resStr);

                return Ok(response);
            }
        }

        [HttpPost("Eliminar")]
        [ProducesResponseType(200, Type = typeof(EliminacionCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EliminacionCatalogoResponse> EliminarCatalogos([FromBody] EliminacionCatalogoRequest catalogueRequestDto)
        {
            EliminacionCatalogoResponse response = new();
            EliminacionCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/EliminarCatalogos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("CatalogoController/EliminarCatalogos -> Request: " + reqStr);
                response = _clRepository.EliminarCatalogo(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("CatalogoController/EliminarCatalogos -> Response: " + resStr);

                return Ok(response);
            }
        }

        [HttpPost("Actualizar")]
        [ProducesResponseType(200, Type = typeof(EdicionCatalogoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EdicionCatalogoResponse> ActualizarCatalogo([FromBody] EdicionCatalogoRequest catalogueRequestDto)
        {
            EdicionCatalogoResponse response = new();
            EdicionCatalogoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("CatalogoController/ActualizarCatalogo: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("CatalogoController/ActualizarCatalogo -> Request: " + reqStr);
                response = _clRepository.ActualizarCatalogo(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("CatalogoController/ActualizarCatalogo -> Response: " + resStr);

                return Ok(response);
            }
        }
    }
}
