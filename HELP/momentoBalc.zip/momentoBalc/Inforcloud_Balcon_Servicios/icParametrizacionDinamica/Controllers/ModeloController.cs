﻿using FluentValidation.Results;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.Modelos;
using icParametrizacionDinamica.DTOs.API.Response.Modelos;
using icParametrizacionDinamica.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace icParametrizacionDinamica.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/parametrizacion/modelos")]
    [ApiController]
    [Authorize]
    public class ModeloController : ControllerBase
    {
        private readonly IModeloBLL _clRepository;
        public ModeloController(IModeloBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaModelosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaModelosResponse> ListarModelos([FromBody] ListaModelosRequest catalogueRequestDto)
        {
            ListaModelosResponse response = new();
            ListaModelosValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ModeloController/ListarModelos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ModeloController/ListarModelos -> Request: " + reqStr);
                response = _clRepository.ListarModelos(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ModeloController/ListarModelos -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaModeloResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaModeloResponse> ObtenerModeloPorId([FromBody] ConsultaModeloRequest catalogueRequestDto)
        {
            ConsultaModeloResponse response = new();
            ConsultaModeloValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ModeloController/ObtenerModeloPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ModeloController/ObtenerModeloPorId -> Request: " + reqStr);
                response = _clRepository.ObtenerModeloPorId(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ModeloController/ObtenerModeloPorId -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("Crear")]
        [ProducesResponseType(200, Type = typeof(CreacionModeloResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionModeloResponse> CrearModelos([FromBody] CreacionModeloRequest catalogueRequestDto)
        {
            CreacionModeloResponse response = new();
            CreacionModeloValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ModeloController/CrearModelos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ModeloController/CrearModelos -> Request: " + reqStr);
                response = _clRepository.CrearModelo(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ModeloController/CrearModelos -> Response: " + resStr);

                return Ok(response);
            }
        }

        [HttpPost("Eliminar")]
        [ProducesResponseType(200, Type = typeof(EliminacionModeloResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EliminacionModeloResponse> EliminarModelos([FromBody] EliminacionModeloRequest catalogueRequestDto)
        {
            EliminacionModeloResponse response = new();
            EliminacionModeloValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ModeloController/EliminarModelos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ModeloController/EliminarModelos -> Request: " + reqStr);
                response = _clRepository.EliminarModelo(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ModeloController/EliminarModelos -> Response: " + resStr);

                return Ok(response);
            }
        }

        [HttpPost("Actualizar")]
        [ProducesResponseType(200, Type = typeof(EdicionModeloResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EdicionModeloResponse> ActualizarModelo([FromBody] EdicionModeloRequest catalogueRequestDto)
        {
            EdicionModeloResponse response = new();
            EdicionModeloValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ModeloController/ActualizarModelo: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ModeloController/ActualizarModelo -> Request: " + reqStr);
                response = _clRepository.ActualizarModelo(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ModeloController/ActualizarModelo -> Response: " + resStr);

                return Ok(response);
            }
        }

        [HttpPost("ListarCampos")]
        [ProducesResponseType(200, Type = typeof(ListaModelosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaCamposResponse> ObtenerListaCamposPorModeloId([FromBody] ConsultaModeloRequest catalogueRequestDto)
        {
            ConsultaCamposResponse response = new();
            ConsultaModeloValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ModeloController/ObtenerListaCamposPorModeloId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("ModeloController/ObtenerListaCamposPorModeloId -> Request: " + reqStr);
                response = _clRepository.ObtenerListaCamposPorModeloId(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("ModeloController/ObtenerListaCamposPorModeloId -> Response: " + resStr);
                return Ok(response);
            }
        }
    }
}
