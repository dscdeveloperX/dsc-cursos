﻿using FluentValidation.Results;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace icParametrizacionDinamica.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/parametrizacion/formatos")]
    [ApiController]
    [Authorize]
    public class FormatoController : ControllerBase
    {
        private readonly IFormatoBLL _clRepository;
        public FormatoController(IFormatoBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaFormatosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaFormatosResponse> ListarFormatos([FromBody] ListaFormatosRequest catalogueRequestDto)
        {
            ListaFormatosResponse response = new();
            ListaFormatosValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("FormatoController/ListarFormatos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("FormatoController/ListarFormatos -> Request: " + reqStr);
                response = _clRepository.ListarFormatos(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("FormatoController/ListarFormatos -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaFormatoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaFormatoResponse> ObtenerFormatoPorId([FromBody] ConsultaFormatoRequest catalogueRequestDto)
        {
            ConsultaFormatoResponse response = new();
            ConsultaFormatoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("FormatoController/ObtenerFormatoPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("FormatoController/ObtenerFormatoPorId -> Request: " + reqStr);
                response = _clRepository.ObtenerFormatoPorId(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("FormatoController/ObtenerFormatoPorId -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("ObtenerCamposFormato")]
        [ProducesResponseType(200, Type = typeof(ObtenerCamposFormatoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ObtenerCamposFormatoResponse> ObtenerCamposFormato([FromBody] ObtenerCamposFormatoRequest catalogueRequestDto)
        {
            ObtenerCamposFormatoResponse response = new();
            ObtenerCamposFormatoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("FormatoController/ObtenerCamposFormato: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("FormatoController/ObtenerCamposFormato -> Request: " + reqStr);
                response = _clRepository.ObtenerCamposFormato(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("FormatoController/ObtenerCamposFormato -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("Crear")]
        [ProducesResponseType(200, Type = typeof(CreacionFormatoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<CreacionFormatoResponse> CrearFormatos([FromBody] CreacionFormatoRequest catalogueRequestDto)
        {
            CreacionFormatoResponse response = new();
            CreacionFormatoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("FormatoController/CrearFormatos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("FormatoController/CrearFormatos -> Request: " + reqStr);
                response = _clRepository.CrearFormato(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("FormatoController/CrearFormatos -> Response: " + resStr);

                return Ok(response);
            }
        }

        [HttpPost("Eliminar")]
        [ProducesResponseType(200, Type = typeof(EliminacionFormatoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EliminacionFormatoResponse> EliminarFormatos([FromBody] EliminacionFormatoRequest catalogueRequestDto)
        {
            EliminacionFormatoResponse response = new();
            EliminacionFormatoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("FormatoController/EliminarFormatos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("FormatoController/EliminarFormatos -> Request: " + reqStr);
                response = _clRepository.EliminarFormato(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("FormatoController/EliminarFormatos -> Response: " + resStr);

                return Ok(response);
            }
        }

        [HttpPost("Actualizar")]
        [ProducesResponseType(200, Type = typeof(EdicionFormatoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EdicionFormatoResponse> ActualizarFormato([FromBody] EdicionFormatoRequest catalogueRequestDto)
        {
            EdicionFormatoResponse response = new();
            EdicionFormatoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("FormatoController/ActualizarFormato: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("FormatoController/ActualizarFormato -> Request: " + reqStr);
                response = _clRepository.ActualizarFormato(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("FormatoController/ActualizarFormato -> Response: " + resStr);

                return Ok(response);
            }
        }        
    }
}
