﻿using FluentValidation.Results;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.SolicitudCambios;
using icParametrizacionDinamica.DTOs.API.Response.Formatos;
using icParametrizacionDinamica.DTOs.API.Response.SolicitudCambios;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using icParametrizacionDinamica.DTOs.API.Validators;
using icCommon.Utils;

namespace icParametrizacionDinamica.Controllers
{
    [Produces("application/json")]
    [Route("api/v1/parametrizacion/solicitud")]
    [ApiController]
    [Authorize]
    public class SolicitudesController : ControllerBase
    {
        private readonly ISolicitudCambiosBLL _clRepository;
        public SolicitudesController(ISolicitudCambiosBLL dRepository)
        {
            _clRepository = dRepository;
        }

        [HttpPost("Listar")]
        [ProducesResponseType(200, Type = typeof(ListaSolicitudCambiosResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ListaSolicitudCambiosResponse> ListarSolicitudesCambios([FromBody] ListaSolicitudCambiosRequest catalogueRequestDto)
        {
            ListaSolicitudCambiosResponse response = new();
            ListaSolicitudCambiosValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("ModeloController/ListarModelos: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("SolicitudesController/ListarSolicitudesCambios -> Request: " + reqStr);
                response = _clRepository.ListarSolicitudesCambios(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("SolicitudesController/ListarSolicitudesCambios -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("ObtenerPorId")]
        [ProducesResponseType(200, Type = typeof(ConsultaSolicitudCambioResponse))]
        [ProducesResponseType(400)]
        public ActionResult<ConsultaSolicitudCambioResponse> ConsultarSolicitudCambioPorId([FromBody] ConsultaSolicitudCambioRequest catalogueRequestDto)
        {
            ConsultaSolicitudCambioResponse response = new();
            ConsultaSolicitudCambioValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("SolicitudesController/ConsultarSolicitudCambioPorId: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("SolicitudesController/ConsultarSolicitudCambioPorId -> Request: " + reqStr);
                response = _clRepository.ConsultarSolicitudCambioPorId(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("SolicitudesController/ConsultarSolicitudCambioPorId -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("AprobarSolicitud")]
        [ProducesResponseType(200, Type = typeof(EnviarFormularioResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EnviarFormularioResponse> AprobarFormulario([FromBody] AprobarFormularioRequest catalogueRequestDto)
        {
            EnviarFormularioResponse response = new();
            AprobarFormularioValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("SolicitudesController/AprobarFormulario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("SolicitudesController/AprobarFormulario -> Request: " + reqStr);
                response = _clRepository.AprobarFormulario(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("SolicitudesController/AprobarFormulario -> Response: " + resStr);
                return Ok(response);
            }
        }

        [HttpPost("RechazarSolicitud")]
        [ProducesResponseType(200, Type = typeof(EnviarFormularioResponse))]
        [ProducesResponseType(400)]
        public ActionResult<EnviarFormularioResponse> RechazarFormulario([FromBody] RechazarFormularioRequest catalogueRequestDto)
        {
            EnviarFormularioResponse response = new();
            RechazarFormularioValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("SolicitudesController/RechazarFormulario: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "Solicitud no válida";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                string reqStr = UtilGeneral.SerializedNeutralizedJson(catalogueRequestDto);
                Log.Information("SolicitudesController/RechazarFormulario -> Request: " + reqStr);
                response = _clRepository.RechazarFormulario(catalogueRequestDto);
                string resStr = UtilGeneral.SerializedNeutralizedJson(response);
                Log.Information("SolicitudesController/RechazarFormulario -> Response: " + resStr);
                return Ok(response);
            }
        }
    }
}
