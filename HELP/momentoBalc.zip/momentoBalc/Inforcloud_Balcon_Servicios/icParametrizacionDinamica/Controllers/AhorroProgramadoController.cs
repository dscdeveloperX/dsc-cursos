﻿using FluentValidation.Results;
using icCommon.Utils;
using icParametrizacionDinamica.BLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request.AhorroProgramado;
using icParametrizacionDinamica.DTOs.API.Response.AhorroProgramado;
using icParametrizacionDinamica.DTOs.API.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace icParametrizacionDinamica.Controllers
{

    [Produces("application/json")]
    [Route("api/v1/parametrizacion/balcon")]
    [ApiController]
    [Authorize]
    public class AhorroProgramadoController : ControllerBase {
        private readonly IAhorroProgramado _clRepository;
        public AhorroProgramadoController(IAhorroProgramado dRepository) {
            _clRepository = dRepository;
        }

        [HttpPost("SolicitarContratoAhorroProgramado")]
        [ProducesResponseType(200, Type = typeof(AhorroProgramadoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<AhorroProgramadoResponse> SolicitarContrato([FromBody] SolicitudAhorroProgramadoRequest solicitudRequestDto)
        {
            Log.Information("AhorroProgramadoController/SolicitarContrato");
            AhorroProgramadoResponse response = new();
            SolicitarContratoValidator validator = new();
            ValidationResult validationResults = validator.Validate(solicitudRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AhorroProgramadoController/SolicitarContrato: INVALID REQUEST");
                response.HeaderResponse = new();
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "REVISE LOS ERRORES POR CAMPOS FALTANTES";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    solicitudRequestDto.HeaderRequest.StationIp = clientIp;
                }
                Log.Information("AhorroProgramadoController/SolicitarContrato -> Request: ");
                response = _clRepository.SolicitudContratoAP(solicitudRequestDto);
                Log.Information("AhorroProgramadoController/SolicitarContrato -> Response: ");
                return Ok(response);
            }
        }

        [HttpPost("SimuladorCancelacionContratoAhorroProgramado")]
        [ProducesResponseType(200, Type = typeof(AhorroProgramadoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<AhorroProgramadoResponse> SimuladorCancelacionContrato([FromBody] SimuladorCancelacionContratoRequest catalogueRequestDto) {
            Log.Information("AhorroProgramadoController/SimuladorCancelacionContratoAhorroProgramado");
            AhorroProgramadoResponse response = new();
            SimuladorCancelacionContratoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid) {
                Log.Error("AhorroProgramadoController/SimuladorCancelacionContratoAhorroProgramado: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "DEBE INDICAR EL NÚMERO DE IDENTIFICACIÓN.";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            } else {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1") {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                Log.Information("AhorroProgramadoController/SimuladorCancelacionContratoAhorroProgramado -> Request: ");
                response = _clRepository.SimuladorCancelacionContrato(catalogueRequestDto);
                Log.Information("AhorroProgramadoController/SimuladorCancelacionContratoAhorroProgramado -> Response: ");
                return Ok(response);
            }
        }

        [HttpPost("CancelarContratoAhorroProgramado")]
        [ProducesResponseType(200, Type = typeof(AhorroProgramadoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<AhorroProgramadoResponse> CancelarContrato([FromBody] CancelarContratoRequest catalogueRequestDto) {
            Log.Information("AhorroProgramadoController/CancelarContrato");
            AhorroProgramadoResponse response = new();
            CancelarContratoValidator validator = new();
            ValidationResult validationResults = validator.Validate(catalogueRequestDto);

            if (!validationResults.IsValid) {
                Log.Error("AhorroProgramadoController/CancelarContrato: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "DEBE INDICAR EL NÚMERO DE IDENTIFICACIÓN.";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            } else {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1") {
                    catalogueRequestDto.HeaderRequest.StationIp = clientIp;
                }
                Log.Information("AhorroProgramadoController/CancelarContrato -> Request: ");
                response = _clRepository.CancelarContrato(catalogueRequestDto);
                Log.Information("AhorroProgramadoController/CancelarContrato -> Response: ");
                return Ok(response);
            }
        }

        [HttpPost("SimuladorContratoAhorroProgramado")]
        [ProducesResponseType(200, Type = typeof(AhorroProgramadoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<AhorroProgramadoResponse> SimuladorContrato([FromBody] SimuladorContratoRequest solicitudRequestDto)
        {
            Log.Information("AhorroProgramadoController/SimuladorContratoAhorroProgramado");
            AhorroProgramadoResponse response = new();
            SimuladorContratoValidator validator = new();
            ValidationResult validationResults = validator.Validate(solicitudRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AhorroProgramadoController/SimuladorContratoAhorroProgramado: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "REVISE LOS ERRORES POR CAMPOS FALTANTES";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    solicitudRequestDto.HeaderRequest.StationIp = clientIp;
                }
                Log.Information("AhorroProgramadoController/SimuladorContratoAhorroProgramado -> Request: ");
                response = _clRepository.SimuladorContrato(solicitudRequestDto);
                Log.Information("AhorroProgramadoController/SimuladorContratoAhorroProgramado -> Response: ");
                return Ok(response);
            }
        }

        [HttpPost("SimuladorModificaContratoAhorroProgramado")]
        [ProducesResponseType(200, Type = typeof(AhorroProgramadoResponse))]
        [ProducesResponseType(400)]
        public ActionResult<AhorroProgramadoResponse> SimuladorModificaContratoAhorroProgramado([FromBody] SimuladorModificaContratoRequest simuladorModificaContratoRequestDto)
        {
            Log.Information("AhorroProgramadoController/SimuladorModificaContrato");
            AhorroProgramadoResponse response = new();
            SimuladorModificaContratoValidator validator = new();
            ValidationResult validationResults = validator.Validate(simuladorModificaContratoRequestDto);

            if (!validationResults.IsValid)
            {
                Log.Error("AhorroProgramadoController/SimuladorModificaContrato: INVALID REQUEST");
                response.HeaderResponse.returnCode = "INFORCLOUD_INVALID_REQUEST";
                response.HeaderResponse.returnMessage = "REVISE LOS ERRORES POR CAMPOS FALTANTES";
                response.HeaderResponse.errors = validationResults.Errors;
                return BadRequest(response);
            }
            else
            {
                string clientIp = IpCliente.ObtenerIPCliente(HttpContext);
                if (!string.IsNullOrEmpty(clientIp) && clientIp != "::1")
                {
                    simuladorModificaContratoRequestDto.HeaderRequest.StationIp = clientIp;
                }
                Log.Information("AhorroProgramadoController/SimuladorModificaContrato -> Request: ");
                response = _clRepository.SimuladorModificaContrato(simuladorModificaContratoRequestDto);
                Log.Information("AhorroProgramadoController/SimuladorModificaContrato -> Response: ");
                return Ok(response);
            }
        }
    }
}
