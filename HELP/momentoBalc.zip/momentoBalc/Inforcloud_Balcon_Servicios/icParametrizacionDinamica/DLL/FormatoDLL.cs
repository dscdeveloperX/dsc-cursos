﻿using Dapper;
using icCommon.DB;
using icCommon.DTOs.DB;
using icCommon.Utils;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.DB.Response.Formatos;
using icParametrizacionDinamica.DTOs.DB.Response.Modelos;
using icParametrizacionDinamica.DTOs.EXT;
using icParametrizacionDinamica.DTOs.EXT.Response;
using icParametrizacionDinamica.Models;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace icParametrizacionDinamica.DLL
{
    public class FormatoDLL : IFormatoDLL
    {
        private readonly IProveedorConexion _config;

        private readonly string SCHEMA = "";

        //dsc: fecha registro auditoria (una sola fecha para todo el grupo de operaciones que se ejecutan de un solo golpe)
        private readonly string fechaHoraAuditoria = string.Empty;

        public FormatoDLL(IProveedorConexion proveedor)
        {
            _config = proveedor;
            SCHEMA = _config.ObtenerSchema();
            fechaHoraAuditoria = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public int ActualizarFormato(HeaderRequest header, EdicionFormatoRequestBody body)
        {
            DynamicParameters dbPara = new DynamicParameters();
            long formatoId = body.Formato.FormatoId;
            dbPara.Add("FormatoId", formatoId, DbType.Int64);
            dbPara.Add("Descripcion", body.Formato.Descripcion, DbType.String);
            dbPara.Add("Codigo", body.Formato.Codigo, DbType.String);
            dbPara.Add("Nombre", body.Formato.Nombre, DbType.String);
            dbPara.Add("TipoPersona", body.Formato.TipoPersona, DbType.String);
            dbPara.Add("TipoIdentificacion", body.Formato.TipoIdentificacion, DbType.String);
            dbPara.Add("TipoCliente", body.Formato.TipoCliente, DbType.String);
            dbPara.Add("PersonaId", body.Formato.Persona, DbType.String);

            
            string updateSQL = $"UPDATE [{SCHEMA}].[Formato] SET Descripcion=@Descripcion,Codigo=@Codigo,Nombre=@Nombre," +
                $"TipoPersona=@TipoPersona,TipoIdentificacion=@TipoIdentificacion, TipoCliente=@TipoCliente," +
                $"PersonaId = (SELECT ModeloId from [{SCHEMA}].[Modelo] WHERE Codigo=@PersonaId) ";

            if (body.Formato.Producto != null)
            {
                dbPara.Add("ProductoId", body.Formato.Producto, DbType.String);
                updateSQL += $",ProductoId = (SELECT ModeloId from [{SCHEMA}].[Modelo] WHERE Codigo=@ProductoId) ";
            }

            updateSQL += $"where FormatoId=@FormatoId;" +
                        $"SELECT @@ROWCOUNT; ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        //var eliminar = db.Query<long>($"SELECT FormatoDetalleId FROM [{SCHEMA}].[FormatoDetalle] WHERE FormatoId=@FormatoId", dbPara, tran, commandType: CommandType.Text).ToList();

                        //var result = db.Query<int>(updateSQL, dbPara, tran, commandType: CommandType.Text);
                        var result = new List<int>() { 0 } as IEnumerable<int>;

                      
                        //dsc: auditoria formato update
                        string auditoriaUpdateFormatoJson = @"SELECT '{""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ',""Codigo"":' + CONVERT(NVARCHAR, ISNULL(Codigo, 'null')) + ',""Nombre"":""' + CONVERT(NVARCHAR, ISNULL(Nombre, 'null')) + '"",""Descripcion"":""' + CONVERT(NVARCHAR, ISNULL(Descripcion,'null')) + '"",""TipoPersona"":""' + CONVERT(NVARCHAR, ISNULL(TipoPersona,'null')) + '"",""TipoIdentificacion"":""' + CONVERT(NVARCHAR, ISNULL(TipoIdentificacion,'null')) + '"",""TipoCliente"":""' + CONVERT(NVARCHAR, ISNULL(TipoCliente,'null')) + '"",""PersonaId"":""' + CONVERT(NVARCHAR, ISNULL(PersonaId,0)) + '"",""ProductoId"":""' + CONVERT(NVARCHAR, ISNULL(ProductoId,0)) + '"",""indicadorGraba"":""' + CONVERT(NVARCHAR, ISNULL(indicadorGraba,0)) + '"",""IndicadorGrabaPersona"":""' + CONVERT(NVARCHAR, ISNULL(IndicadorGrabaPersona,0)) + '"",""IndicadorGrabaProducto"":""' + CONVERT(NVARCHAR, ISNULL(IndicadorGrabaProducto,0)) + '""}' FROM Formato WHERE FormatoId = @FormatoId";

                        string auditoriaInsertFormatoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                           $" VALUES ('formato', @FormatoId, 'UPDATE', '{header.UserName}', '{header.StationIp}', '@@ValorAnterior' ,'@@ValorNuevo', '{fechaHoraAuditoria}');";
                        //json anterior
                        var jsonAnterior = db.Query<string>(auditoriaUpdateFormatoJson, dbPara, tran, commandType: CommandType.Text).FirstOrDefault();
                        if (jsonAnterior != null)
                        {
                            //actualizar formato
                            result = db.Query<int>(updateSQL, dbPara, tran, commandType: CommandType.Text);
                            
                            if (result.ToList().First<int>() > 0)
                            {
                                //json actual
                                var jsonNuevo = db.Query<string>(auditoriaUpdateFormatoJson, dbPara, tran, commandType: CommandType.Text).FirstOrDefault();
                                if (jsonNuevo != null && jsonAnterior != jsonNuevo)
                                {
                                    //auditoria formato actualizado
                                    string auditoriaSQL = auditoriaInsertFormatoSql.Replace("@@ValorAnterior", jsonAnterior).Replace("@@ValorNuevo", jsonNuevo);
                                    db.Execute(auditoriaSQL, dbPara, tran, commandType: CommandType.Text);
                                }
                            }
                        }


                        //formato persona
                        if (body.Formato.SeccionesPersona != null && body.Formato.SeccionesPersona.Count > 0)
                        {
                            List<FormatoDetalle> campos = ObtenerFormatoDetallesDeSecciones(body.Formato.SeccionesPersona);

                            List<FormatoDetalle> crear = campos.FindAll(x => x.FormatoDetalleId == 0);
                            List<FormatoDetalle> update = campos.FindAll(x => x.FormatoDetalleId != 0);

                            //List<long> updateIds = campos.FindAll(x => x.FormatoId != 0).Select(x => x.FormatoDetalleId).ToList();


                            


                            if (crear.Count > 0)
                            {
                                
                                //dsc: auditoria insertar formato
                                string auditoriaInsertFormatoDetalleJson = @"(SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId2)";

                                string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                              $" VALUES ('FormatoDetalle', @FormatoDetalleId2, 'INSERT', '{header.UserName}', '{header.StationIp}', '' , {auditoriaInsertFormatoDetalleJson}, '{fechaHoraAuditoria}');";


                                string insertFormatoDetallesSQL = $"INSERT INTO [{SCHEMA}].[FormatoDetalle](FormatoId,CampoId,Etiqueta,LongitudMinima," +
                                    $"LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido," +
                                    $"DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable," +
                                    $"ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex," +
                                    $"ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario," +
                                    $"AnchoEtiquetaFormulario,ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro," +
                                    $"TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto) " +
                                $"VALUES({formatoId},@CampoId,@Etiqueta,@LongitudMinima,@LongitudMaxima,@Enmascarar,@Visible,@DependenciaVisibilidad," +
                                $"@ReglaDependenciaVisibilidad,@ValoresDependenciaVisibilidad,@Requerido,@DependenciaRequerido,@ReglaDependenciaRequerido," +
                                $"@ValoresDependenciaRequerido,@Editable,@DependenciaEditable,@ReglaDependenciaEditable,@ValoresDependenciaEditable,@TipoValidacion," +
                                $"@DependenciaValidacion,@ReglaDependenciaValidacion,@ValoresDependenciaValidacion,@ValidacionRegex,@ValidacionReglas,@ValidacionRutina," +
                                $"@ValidacionRutinaCampos,@AnchoColumna,@FormularioVisible,@EtiquetaFormulario,@AnchoColumnaFormulario,@AnchoEtiquetaFormulario," +
                                $"@ComboboxPermiteNinguno,@TipoFiltro,@DependenciaFiltro,@ReglaDependenciaFiltro,@ValoresDependenciaFiltro,@TipoValorDefecto," +
                                $"@DependenciaValorDefecto,@ReglaDependenciaValorDefecto,@ValoresDependenciaValorDefecto);" +
                                $"DECLARE @FormatoDetalleId2 int = (SELECT CAST(SCOPE_IDENTITY() as int));" +
                                auditoriaInsertFormatoDetalleSql;

                                db.Execute(insertFormatoDetallesSQL, crear, tran, commandType: CommandType.Text);
                            }

                            if (update.Count > 0)
                            {
                                
                                //dsc: auditoria update formatoDetalle
                                string auditoriaInsertFormatoDetalleJson = @"SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId";
                                
                                string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora) " +
                                                                          $"VALUES ('FormatoDetalle', @FormatoDetalleId, 'UPDATE', '{header.UserName}', '{header.StationIp}', '@@ValorAnterior' ,'@@ValorNuevo', '{fechaHoraAuditoria}');";


                                string updateFormatoDetallesSQL = $"UPDATE [{SCHEMA}].[FormatoDetalle] SET " +
                                $"Etiqueta=@Etiqueta,LongitudMinima=@LongitudMinima," +
                                $"LongitudMaxima=@LongitudMaxima,Enmascarar=@Enmascarar,Visible=@Visible,DependenciaVisibilidad=@DependenciaVisibilidad," +
                                $"ReglaDependenciaVisibilidad=@ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad=@ValoresDependenciaVisibilidad," +
                                $"Requerido=@Requerido,DependenciaRequerido=@DependenciaRequerido,ReglaDependenciaRequerido=@ReglaDependenciaRequerido," +
                                $"ValoresDependenciaRequerido=@ValoresDependenciaRequerido,Editable=@Editable,DependenciaEditable=@DependenciaEditable," +
                                $"ReglaDependenciaEditable=@ReglaDependenciaEditable,ValoresDependenciaEditable=@ValoresDependenciaEditable,TipoValidacion=@TipoValidacion," +
                                $"DependenciaValidacion=@DependenciaValidacion,ReglaDependenciaValidacion=@ReglaDependenciaValidacion,ValoresDependenciaValidacion=@ValoresDependenciaValidacion," +
                                $"ValidacionRegex=@ValidacionRegex,ValidacionReglas=@ValidacionReglas,ValidacionRutina=@ValidacionRutina,ValidacionRutinaCampos=@ValidacionRutinaCampos," +
                                $"AnchoColumna=@AnchoColumna,FormularioVisible=@FormularioVisible,EtiquetaFormulario=@EtiquetaFormulario,AnchoColumnaFormulario=@AnchoColumnaFormulario," +
                                $"AnchoEtiquetaFormulario=@AnchoEtiquetaFormulario," +
                                $"ComboboxPermiteNinguno=@ComboboxPermiteNinguno,TipoFiltro=@TipoFiltro,DependenciaFiltro=@DependenciaFiltro,ReglaDependenciaFiltro=@ReglaDependenciaFiltro," +
                                $"ValoresDependenciaFiltro=@ValoresDependenciaFiltro,TipoValorDefecto=@TipoValorDefecto,DependenciaValorDefecto=@DependenciaValorDefecto," +
                                $"ReglaDependenciaValorDefecto=@ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto=@ValoresDependenciaValorDefecto " +
                                $" WHERE FormatoDetalleId = @FormatoDetalleId; SELECT @@ROWCOUNT;";


                                foreach (FormatoDetalle item in update)
                                {

                                    //json anterio
                                    var jsonAnterior1 = db.Query<string>(auditoriaInsertFormatoDetalleJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                    if (jsonAnterior1 != null)
                                    {
                                        var result1 = db.Query<int>(updateFormatoDetallesSQL, item, tran, commandType: CommandType.Text);
                                        if (result1.ToList().First<int>() > 0)
                                        {
                                            //json actual
                                            var jsonNuevo1 = db.Query<string>(auditoriaInsertFormatoDetalleJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                            if (jsonNuevo1 != null && jsonAnterior1 != jsonNuevo1)
                                            {
                                                //auditoria campo actualizado
                                                string auditoriaSQL = auditoriaInsertFormatoDetalleSql.Replace("@@ValorAnterior", jsonAnterior1).Replace("@@ValorNuevo", jsonNuevo1);
                                                db.Execute(auditoriaSQL, item, tran, commandType: CommandType.Text);
                                            }
                                        }
                                    }
                                }


                                //aaa:db.Execute(updateFormatoDetallesSQL, update, tran, commandType: CommandType.Text);
                            }

                        }

                        //formato producto
                        if (body.Formato.SeccionesProducto != null && body.Formato.SeccionesProducto.Count > 0)
                        {
                            List<FormatoDetalle> campos = ObtenerFormatoDetallesDeSecciones(body.Formato.SeccionesProducto);

                            List<FormatoDetalle> crear = campos.FindAll(x => x.FormatoDetalleId == 0);
                            List<FormatoDetalle> update = campos.FindAll(x => x.FormatoDetalleId != 0);

                            //List<long> updateIds = campos.FindAll(x => x.FormatoId != 0).Select(x => x.FormatoDetalleId).ToList();


                            if (crear.Count > 0)
                            {
                                //dsc: auditoria insertar formato
                                string auditoriaInsertFormatoDetalleJson = @"(SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId)";

                                string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                              $" VALUES ('FormatoDetalle', @FormatoDetalleId, 'INSERT', '{header.UserName}', '{header.StationIp}', '' , {auditoriaInsertFormatoDetalleJson}, '{fechaHoraAuditoria}');";


                                string insertFormatoDetallesSQL = $"INSERT INTO [{SCHEMA}].[FormatoDetalle](FormatoId,CampoId,Etiqueta,LongitudMinima," +
                                    $"LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido," +
                                    $"DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable," +
                                    $"ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex," +
                                    $"ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario,AnchoEtiquetaFormulario," +
                                    $"ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro,TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto) " +
                                $"VALUES({formatoId},@CampoId,@Etiqueta,@LongitudMinima,@LongitudMaxima,@Enmascarar,@Visible,@DependenciaVisibilidad," +
                                $"@ReglaDependenciaVisibilidad,@ValoresDependenciaVisibilidad,@Requerido,@DependenciaRequerido,@ReglaDependenciaRequerido," +
                                $"@ValoresDependenciaRequerido,@Editable,@DependenciaEditable,@ReglaDependenciaEditable,@ValoresDependenciaEditable,@TipoValidacion," +
                                $"@DependenciaValidacion,@ReglaDependenciaValidacion,@ValoresDependenciaValidacion,@ValidacionRegex,@ValidacionReglas,@ValidacionRutina," +
                                $"@ValidacionRutinaCampos,@AnchoColumna,@FormularioVisible,@EtiquetaFormulario,@AnchoColumnaFormulario,@AnchoEtiquetaFormulario," +
                                $"@ComboboxPermiteNinguno,@TipoFiltro,@DependenciaFiltro,@ReglaDependenciaFiltro,@ValoresDependenciaFiltro,@TipoValorDefecto," +
                                $"@DependenciaValorDefecto,@ReglaDependenciaValorDefecto,@ValoresDependenciaValorDefecto);" +
                                $"DECLARE @FormatoDetalleId int = (SELECT CAST(SCOPE_IDENTITY() as int));" +
                                auditoriaInsertFormatoDetalleSql;


                                db.Execute(insertFormatoDetallesSQL, crear, tran, commandType: CommandType.Text);
                            }

                            if (update.Count > 0)
                            {

                                
                                //dsc: auditoria update formatoDetalle
                                string auditoriaInsertFormatoDetalleJson = @"SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId";

                                string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora) " +
                                                                          $"VALUES ('FormatoDetalle', @FormatoDetalleId, 'UPDATE', '{header.UserName}', '{header.StationIp}', '@@ValorAnterior' ,'@@ValorNuevo', '{fechaHoraAuditoria}');";


                                string updateFormatoDetallesSQL = $"UPDATE [{SCHEMA}].[FormatoDetalle] SET " +
                                $"Etiqueta=@Etiqueta,LongitudMinima=@LongitudMinima," +
                                $"LongitudMaxima=@LongitudMaxima,Enmascarar=@Enmascarar,Visible=@Visible,DependenciaVisibilidad=@DependenciaVisibilidad," +
                                $"ReglaDependenciaVisibilidad=@ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad=@ValoresDependenciaVisibilidad," +
                                $"Requerido=@Requerido,DependenciaRequerido=@DependenciaRequerido,ReglaDependenciaRequerido=@ReglaDependenciaRequerido," +
                                $"ValoresDependenciaRequerido=@ValoresDependenciaRequerido,Editable=@Editable,DependenciaEditable=@DependenciaEditable," +
                                $"ReglaDependenciaEditable=@ReglaDependenciaEditable,ValoresDependenciaEditable=@ValoresDependenciaEditable,TipoValidacion=@TipoValidacion," +
                                $"DependenciaValidacion=@DependenciaValidacion,ReglaDependenciaValidacion=@ReglaDependenciaValidacion,ValoresDependenciaValidacion=@ValoresDependenciaValidacion," +
                                $"ValidacionRegex=@ValidacionRegex,ValidacionReglas=@ValidacionReglas,ValidacionRutina=@ValidacionRutina,ValidacionRutinaCampos=@ValidacionRutinaCampos," +
                                $"AnchoColumna=@AnchoColumna,FormularioVisible=@FormularioVisible,EtiquetaFormulario=@EtiquetaFormulario,AnchoColumnaFormulario=@AnchoColumnaFormulario," +
                                $"AnchoEtiquetaFormulario=@AnchoEtiquetaFormulario," +
                                $"ComboboxPermiteNinguno=@ComboboxPermiteNinguno,TipoFiltro=@TipoFiltro,DependenciaFiltro=@DependenciaFiltro,ReglaDependenciaFiltro=@ReglaDependenciaFiltro," +
                                $"ValoresDependenciaFiltro=@ValoresDependenciaFiltro,TipoValorDefecto=@TipoValorDefecto,DependenciaValorDefecto=@DependenciaValorDefecto," +
                                $"ReglaDependenciaValorDefecto=@ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto=@ValoresDependenciaValorDefecto " +
                                $" WHERE FormatoDetalleId = @FormatoDetalleId; SELECT @@ROWCOUNT;";


                                foreach (FormatoDetalle item in update)
                                {

                                    //json anterio
                                    var jsonAnterior1 = db.Query<string>(auditoriaInsertFormatoDetalleJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                    if (jsonAnterior1 != null)
                                    {
                                        var result1 = db.Query<int>(updateFormatoDetallesSQL, item, tran, commandType: CommandType.Text);
                                        if (result1.ToList().First<int>() > 0)
                                        {
                                            //json actual
                                            var jsonNuevo1 = db.Query<string>(auditoriaInsertFormatoDetalleJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                            if (jsonNuevo1 != null && jsonAnterior1 != jsonNuevo1)
                                            {
                                                //auditoria campo actualizado
                                                string auditoriaSQL = auditoriaInsertFormatoDetalleSql.Replace("@@ValorAnterior", jsonAnterior1).Replace("@@ValorNuevo", jsonNuevo1);
                                                db.Execute(auditoriaSQL, item, tran, commandType: CommandType.Text);
                                            }
                                        }
                                    }
                                }


                             /*******************************************************************************/





                            }

                        }

                        //formato secciones referencias
                        if (body.Formato.SeccionesReferencias != null && body.Formato.SeccionesReferencias.Count > 0)
                        {
                            foreach (var refer in body.Formato.SeccionesReferencias)
                            {
                                List<FormatoDetalle> campos = ObtenerFormatoDetallesDeSecciones(refer.SeccionesCampo);

                                List<FormatoDetalle> crear = campos.FindAll(x => x.FormatoDetalleId == 0);
                                List<FormatoDetalle> update = campos.FindAll(x => x.FormatoDetalleId != 0);

                                //List<long> updateIds = campos.FindAll(x => x.FormatoId != 0).Select(x => x.FormatoDetalleId).ToList();

                                if (crear.Count > 0)
                                {
                                    //dsc: auditoria insertar formato
                                    string auditoriaInsertFormatoDetalleJson = @"(SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId)";

                                    string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                  $" VALUES ('FormatoDetalle', @FormatoDetalleId, 'INSERT', '{header.UserName}', '{header.StationIp}', '' ,{auditoriaInsertFormatoDetalleJson}, '{fechaHoraAuditoria}');";



                                    string insertFormatoDetallesSQL = $"INSERT INTO [{SCHEMA}].[FormatoDetalle](FormatoId,CampoId,Etiqueta,LongitudMinima," +
                                        $"LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido," +
                                        $"DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable," +
                                        $"ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex," +
                                        $"ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario,AnchoEtiquetaFormulario," +
                                        $"ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro,TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto) " +
                                    $"VALUES({formatoId},@CampoId,@Etiqueta,@LongitudMinima,@LongitudMaxima,@Enmascarar,@Visible,@DependenciaVisibilidad," +
                                    $"@ReglaDependenciaVisibilidad,@ValoresDependenciaVisibilidad,@Requerido,@DependenciaRequerido,@ReglaDependenciaRequerido," +
                                    $"@ValoresDependenciaRequerido,@Editable,@DependenciaEditable,@ReglaDependenciaEditable,@ValoresDependenciaEditable,@TipoValidacion," +
                                    $"@DependenciaValidacion,@ReglaDependenciaValidacion,@ValoresDependenciaValidacion,@ValidacionRegex,@ValidacionReglas,@ValidacionRutina," +
                                    $"@ValidacionRutinaCampos,@AnchoColumna,@FormularioVisible,@EtiquetaFormulario,@AnchoColumnaFormulario,@AnchoEtiquetaFormulario," +
                                    $"@ComboboxPermiteNinguno,@TipoFiltro,@DependenciaFiltro,@ReglaDependenciaFiltro,@ValoresDependenciaFiltro,@TipoValorDefecto," +
                                    $"@DependenciaValorDefecto,@ReglaDependenciaValorDefecto,@ValoresDependenciaValorDefecto);" +
                                    $"DECLARE @FormatoDetalleId int = (SELECT CAST(SCOPE_IDENTITY() as int));" +
                                    auditoriaInsertFormatoDetalleSql;


                                    db.Execute(insertFormatoDetallesSQL, crear, tran, commandType: CommandType.Text);
                                }

                                if (update.Count > 0)
                                {



                                    //dsc: auditoria update formatoDetalle
                                    string auditoriaInsertFormatoDetalleJson = @"SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId";

                                    string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora) " +
                                                                              $"VALUES ('FormatoDetalle', @FormatoDetalleId, 'UPDATE', '{header.UserName}', '{header.StationIp}', '@@ValorAnterior' ,'@@ValorNuevo', '{fechaHoraAuditoria}');";


                                    string updateFormatoDetallesSQL = $"UPDATE [{SCHEMA}].[FormatoDetalle] SET " +
                                    $"Etiqueta=@Etiqueta,LongitudMinima=@LongitudMinima," +
                                    $"LongitudMaxima=@LongitudMaxima,Enmascarar=@Enmascarar,Visible=@Visible,DependenciaVisibilidad=@DependenciaVisibilidad," +
                                    $"ReglaDependenciaVisibilidad=@ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad=@ValoresDependenciaVisibilidad," +
                                    $"Requerido=@Requerido,DependenciaRequerido=@DependenciaRequerido,ReglaDependenciaRequerido=@ReglaDependenciaRequerido," +
                                    $"ValoresDependenciaRequerido=@ValoresDependenciaRequerido,Editable=@Editable,DependenciaEditable=@DependenciaEditable," +
                                    $"ReglaDependenciaEditable=@ReglaDependenciaEditable,ValoresDependenciaEditable=@ValoresDependenciaEditable,TipoValidacion=@TipoValidacion," +
                                    $"DependenciaValidacion=@DependenciaValidacion,ReglaDependenciaValidacion=@ReglaDependenciaValidacion,ValoresDependenciaValidacion=@ValoresDependenciaValidacion," +
                                    $"ValidacionRegex=@ValidacionRegex,ValidacionReglas=@ValidacionReglas,ValidacionRutina=@ValidacionRutina,ValidacionRutinaCampos=@ValidacionRutinaCampos," +
                                    $"AnchoColumna=@AnchoColumna,FormularioVisible=@FormularioVisible,EtiquetaFormulario=@EtiquetaFormulario,AnchoColumnaFormulario=@AnchoColumnaFormulario," +
                                    $"AnchoEtiquetaFormulario=@AnchoEtiquetaFormulario," +
                                    $"ComboboxPermiteNinguno=@ComboboxPermiteNinguno,TipoFiltro=@TipoFiltro,DependenciaFiltro=@DependenciaFiltro,ReglaDependenciaFiltro=@ReglaDependenciaFiltro," +
                                    $"ValoresDependenciaFiltro=@ValoresDependenciaFiltro,TipoValorDefecto=@TipoValorDefecto,DependenciaValorDefecto=@DependenciaValorDefecto," +
                                    $"ReglaDependenciaValorDefecto=@ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto=@ValoresDependenciaValorDefecto " +
                                    $" WHERE FormatoDetalleId = @FormatoDetalleId; SELECT @@ROWCOUNT;";


                                    foreach (FormatoDetalle item in update)
                                    {

                                        //json anterio
                                        var jsonAnterior1 = db.Query<string>(auditoriaInsertFormatoDetalleJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                        if (jsonAnterior1 != null)
                                        {
                                            var result1 = db.Query<int>(updateFormatoDetallesSQL, item, tran, commandType: CommandType.Text);
                                            if (result1.ToList().First<int>() > 0)
                                            {
                                                //json actual
                                                var jsonNuevo1 = db.Query<string>(auditoriaInsertFormatoDetalleJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                                if (jsonNuevo1 != null && jsonAnterior1 != jsonNuevo1)
                                                {
                                                    //auditoria campo actualizado
                                                    string auditoriaSQL = auditoriaInsertFormatoDetalleSql.Replace("@@ValorAnterior", jsonAnterior1).Replace("@@ValorNuevo", jsonNuevo1);
                                                    db.Execute(auditoriaSQL, item, tran, commandType: CommandType.Text);
                                                }
                                            }
                                        }
                                    }


                                    /*******************************************************************************/


                                }
                            }

                        }

                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("FormatoDLL/ActualizarFormato: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
         
        public long CrearFormato(HeaderRequest header, CreacionFormatoRequestBody body)
        {
            DynamicParameters dbPara = new DynamicParameters();
            dbPara.Add("Descripcion", body.Formato.Descripcion, DbType.String);
            dbPara.Add("Codigo", body.Formato.Codigo, DbType.String);
            dbPara.Add("Nombre", body.Formato.Nombre, DbType.String);
            dbPara.Add("TipoPersona", body.Formato.TipoPersona, DbType.String);
            dbPara.Add("TipoIdentificacion", body.Formato.TipoIdentificacion, DbType.String);
            dbPara.Add("TipoCliente", body.Formato.TipoCliente, DbType.String);
            dbPara.Add("PersonaId", body.Formato.Persona, DbType.String);

            //si es formato persona
            string insertSQL = $"INSERT INTO [{SCHEMA}].[Formato](Descripcion,Codigo,Nombre,TipoPersona,TipoIdentificacion,TipoCliente,PersonaId) " +
                        $"VALUES(@Descripcion,@Codigo,@Nombre,@TipoPersona,@TipoIdentificacion,@TipoCliente,(SELECT ModeloId from [{SCHEMA}].[Modelo] WHERE Codigo=@PersonaId));" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";

            //si es formato producto (se sobreescribe el commandText)
            if (body.Formato.Producto != null)
            {
                dbPara.Add("ProductoId", body.Formato.Producto, DbType.String);
                insertSQL = $"INSERT INTO [{SCHEMA}].[Formato](Descripcion,Codigo,Nombre,TipoPersona,TipoIdentificacion,TipoCliente,PersonaId,ProductoId) " +
                        $"VALUES(@Descripcion,@Codigo,@Nombre,@TipoPersona,@TipoIdentificacion,@TipoCliente,(SELECT ModeloId from [{SCHEMA}].[Modelo] WHERE Codigo=@PersonaId),(SELECT ModeloId from [{SCHEMA}].[Modelo] WHERE Codigo=@ProductoId));" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";



            }

            using (IDbConnection db = _config.ObtenerConexion())
            {
                

                //List<int> camposIds = new List<int>();

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = db.Query<long>(insertSQL, dbPara, tran, commandType: CommandType.Text).First();

                        //dsc: auditoria Formato insertado
                        if (result > 0)
                        {
                            string auditoriaInsertFormatoJson = @"(SELECT '{""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""Codigo"":' + CONVERT(NVARCHAR, ISNULL(Codigo, 'null')) + ', ""Nombre"":' + CONVERT(NVARCHAR, ISNULL(Nombre, 'null')) + ', ""Descripcion"":' + CONVERT(NVARCHAR, ISNULL(Descripcion, 'null')) + ', ""TipoPersona"":' + CONVERT(NVARCHAR, ISNULL(TipoPersona, 'null')) + ', ""TipoIdentificacion"":' + CONVERT(NVARCHAR, ISNULL(TipoIdentificacion, 'null')) + ', ""TipoCliente"":' + CONVERT(NVARCHAR, ISNULL(TipoCliente, 'null')) + ', ""PersonaId"":' + CONVERT(NVARCHAR, ISNULL(PersonaId, 0)) + ', ""ProductoId"":' + CONVERT(NVARCHAR, ISNULL(ProductoId, 0)) + ', ""indicadorGraba"":' + CONVERT(NVARCHAR, ISNULL(indicadorGraba, 0)) + ', ""IndicadorGrabaPersona"":' + CONVERT(NVARCHAR, ISNULL(IndicadorGrabaPersona, 0)) + ', ""IndicadorGrabaProducto"":' + CONVERT(NVARCHAR, ISNULL(IndicadorGrabaProducto, 0)) + '}' from Formato where FormatoId = " +
                                                                $" {result} )";

                            string auditoriaInsertFormatoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                               $" VALUES ('Formato', {result}, 'INSERT', '{header.UserName}', '{header.StationIp}', '' ,{auditoriaInsertFormatoJson}, '{fechaHoraAuditoria}');";
                            
                            db.Execute(auditoriaInsertFormatoSql, null, tran, commandType: CommandType.Text);

                        }


                        //ejecuta si es formato Persona
                        if (body.Formato.SeccionesPersona != null && body.Formato.SeccionesPersona.Count > 0)
                        {
                            List<FormatoDetalle> campos = ObtenerFormatoDetallesDeSecciones(body.Formato.SeccionesPersona);

                            //dsc: auditoria insertar formatoDetalle
                            string auditoriaInsertFormatoDetalleJson = @"(SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId2)";

                            string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                          $" VALUES ('FormatoDetalle', @FormatoDetalleId2, 'INSERT', '{header.UserName}', '{header.StationIp}', '' ,{auditoriaInsertFormatoDetalleJson}, '{fechaHoraAuditoria}');";


                            string insertFormatoDetallesSQL = $"INSERT INTO [{SCHEMA}].[FormatoDetalle](FormatoId,CampoId,Etiqueta,LongitudMinima," +
                                    $"LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido," +
                                    $"DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable," +
                                    $"ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex," +
                                    $"ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario,AnchoEtiquetaFormulario," +
                                    $"ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro,TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto) " +
                                $"VALUES({result},@CampoId,@Etiqueta,@LongitudMinima,@LongitudMaxima,@Enmascarar,@Visible,@DependenciaVisibilidad," +
                                $"@ReglaDependenciaVisibilidad,@ValoresDependenciaVisibilidad,@Requerido,@DependenciaRequerido,@ReglaDependenciaRequerido," +
                                $"@ValoresDependenciaRequerido,@Editable,@DependenciaEditable,@ReglaDependenciaEditable,@ValoresDependenciaEditable,@TipoValidacion," +
                                $"@DependenciaValidacion,@ReglaDependenciaValidacion,@ValoresDependenciaValidacion,@ValidacionRegex,@ValidacionReglas,@ValidacionRutina," +
                                $"@ValidacionRutinaCampos,@AnchoColumna,@FormularioVisible,@EtiquetaFormulario,@AnchoColumnaFormulario,@AnchoEtiquetaFormulario," +
                                $"@ComboboxPermiteNinguno,@TipoFiltro,@DependenciaFiltro,@ReglaDependenciaFiltro,@ValoresDependenciaFiltro,@TipoValorDefecto," +
                                $"@DependenciaValorDefecto,@ReglaDependenciaValorDefecto,@ValoresDependenciaValorDefecto);" +
                                $"DECLARE @FormatoDetalleId2 int = (SELECT CAST(SCOPE_IDENTITY() as int));" +
                                auditoriaInsertFormatoDetalleSql;


                            db.Execute(insertFormatoDetallesSQL, campos, tran, commandType: CommandType.Text);
                        }






                        //ejecuta si es formato producto
                        if (body.Formato.SeccionesProducto != null && body.Formato.SeccionesProducto.Count > 0)
                        {
                            List<FormatoDetalle> campos = ObtenerFormatoDetallesDeSecciones(body.Formato.SeccionesProducto);

                            //dsc: auditoria insertar formatoDetalle
                            string auditoriaInsertFormatoDetalleJson = @"(SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId2)";

                            string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                          $" VALUES ('FormatoDetalle', @FormatoDetalleId2, 'INSERT', '{header.UserName}', '{header.StationIp}', '' ,{auditoriaInsertFormatoDetalleJson}, '{fechaHoraAuditoria}');";

                            string insertFormatoDetallesSQL = $"INSERT INTO [{SCHEMA}].[FormatoDetalle](FormatoId,CampoId,Etiqueta,LongitudMinima," +
                                    $"LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido," +
                                    $"DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable," +
                                    $"ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex," +
                                    $"ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario,AnchoEtiquetaFormulario," +
                                    $"ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro,TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto) " +
                                $"VALUES({result},@CampoId,@Etiqueta,@LongitudMinima,@LongitudMaxima,@Enmascarar,@Visible,@DependenciaVisibilidad," +
                                $"@ReglaDependenciaVisibilidad,@ValoresDependenciaVisibilidad,@Requerido,@DependenciaRequerido,@ReglaDependenciaRequerido," +
                                $"@ValoresDependenciaRequerido,@Editable,@DependenciaEditable,@ReglaDependenciaEditable,@ValoresDependenciaEditable,@TipoValidacion," +
                                $"@DependenciaValidacion,@ReglaDependenciaValidacion,@ValoresDependenciaValidacion,@ValidacionRegex,@ValidacionReglas,@ValidacionRutina," +
                                $"@ValidacionRutinaCampos,@AnchoColumna,@FormularioVisible,@EtiquetaFormulario,@AnchoColumnaFormulario,@AnchoEtiquetaFormulario," +
                                $"@ComboboxPermiteNinguno,@TipoFiltro,@DependenciaFiltro,@ReglaDependenciaFiltro,@ValoresDependenciaFiltro,@TipoValorDefecto," +
                                $"@DependenciaValorDefecto,@ReglaDependenciaValorDefecto,@ValoresDependenciaValorDefecto);" +
                                $"DECLARE @FormatoDetalleId2 int = (SELECT CAST(SCOPE_IDENTITY() as int));" +
                                auditoriaInsertFormatoDetalleSql;


                            db.Execute(insertFormatoDetallesSQL, campos, tran, commandType: CommandType.Text);
                        }



                        if (body.Formato.SeccionesReferencias != null && body.Formato.SeccionesReferencias.Count > 0)
                        {
                            foreach (var refer in body.Formato.SeccionesReferencias)
                            {
                                List<FormatoDetalle> campos = ObtenerFormatoDetallesDeSecciones(refer.SeccionesCampo);

                                //dsc: auditoria insertar formatoDetalle
                                string auditoriaInsertFormatoDetalleJson = @"(SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId2)";

                                string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                              $" VALUES ('FormatoDetalle', @FormatoDetalleId2, 'INSERT', '{header.UserName}', '{header.StationIp}', '' ,{auditoriaInsertFormatoDetalleJson}, '{fechaHoraAuditoria}');";


                                string insertFormatoDetallesSQL = $"INSERT INTO [{SCHEMA}].[FormatoDetalle](FormatoId,CampoId,Etiqueta,LongitudMinima," +
                                        $"LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido," +
                                        $"DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable," +
                                        $"ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex," +
                                        $"ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario,AnchoEtiquetaFormulario," +
                                        $"ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro,TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto) " +
                                    $"VALUES({result},@CampoId,@Etiqueta,@LongitudMinima,@LongitudMaxima,@Enmascarar,@Visible,@DependenciaVisibilidad," +
                                    $"@ReglaDependenciaVisibilidad,@ValoresDependenciaVisibilidad,@Requerido,@DependenciaRequerido,@ReglaDependenciaRequerido," +
                                    $"@ValoresDependenciaRequerido,@Editable,@DependenciaEditable,@ReglaDependenciaEditable,@ValoresDependenciaEditable,@TipoValidacion," +
                                    $"@DependenciaValidacion,@ReglaDependenciaValidacion,@ValoresDependenciaValidacion,@ValidacionRegex,@ValidacionReglas,@ValidacionRutina," +
                                    $"@ValidacionRutinaCampos,@AnchoColumna,@FormularioVisible,@EtiquetaFormulario,@AnchoColumnaFormulario,@AnchoEtiquetaFormulario," +
                                    $"@ComboboxPermiteNinguno,@TipoFiltro,@DependenciaFiltro,@ReglaDependenciaFiltro,@ValoresDependenciaFiltro,@TipoValorDefecto," +
                                    $"@DependenciaValorDefecto,@ReglaDependenciaValorDefecto,@ValoresDependenciaValorDefecto);" +
                                    $"DECLARE @FormatoDetalleId2 int = (SELECT CAST(SCOPE_IDENTITY() as int));" +
                                    auditoriaInsertFormatoDetalleSql;


                                db.Execute(insertFormatoDetallesSQL, campos, tran, commandType: CommandType.Text);
                            }
                        }

                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("FormatoDLL/CrearFormato: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        private List<FormatoDetalle> ObtenerFormatoDetallesDeSecciones(List<Seccion<FormatoDetalleDto>> secciones)
        {
            //List<int> menu = new List<int>();
            List<FormatoDetalle> camposIns = new List<FormatoDetalle>();

            secciones.ForEach(child => {

                if (child.Campos != null && child.Campos.Count > 0)
                {
                    List<FormatoDetalle> campos = child.Campos.Select(x => new FormatoDetalle
                    {
                        FormatoDetalleId = x.FormatoDetalleId,
                        Etiqueta = x.Etiqueta,
                        LongitudMaxima = x.LongitudMaxima,
                        LongitudMinima = x.LongitudMinima,
                        CampoId = x.CampoId,
                        DependenciaEditable = x.DependenciaEditable,
                        DependenciaRequerido = x.DependenciaRequerido,
                        DependenciaValidacion = x.DependenciaValidacion,
                        DependenciaVisibilidad = x.DependenciaVisibilidad,
                        Editable = x.Editable,
                        Enmascarar = x.Enmascarar,                        
                        FormatoId = x.FormatoId,
                        ReglaDependenciaEditable = x.ReglaDependenciaEditable,
                        ReglaDependenciaRequerido = x.ReglaDependenciaRequerido,
                        ReglaDependenciaValidacion = x.ReglaDependenciaValidacion,
                        ReglaDependenciaVisibilidad = x.ReglaDependenciaVisibilidad,
                        Requerido = x.Requerido,
                        TipoValidacion = x.TipoValidacion,
                        ValidacionRegex = x.ValidacionRegex,
                        ValidacionReglas = x.ValidacionReglas != null ? JsonConvert.SerializeObject(x.ValidacionReglas) : null,
                        ValidacionRutina = x.ValidacionRutina,
                        ValidacionRutinaCampos = x.ValidacionRutinaCampos != null ? JsonConvert.SerializeObject(x.ValidacionRutinaCampos) : null,
                        ValoresDependenciaEditable = x.ValoresDependenciaEditable != null? JsonConvert.SerializeObject(x.ValoresDependenciaEditable) : null,
                        ValoresDependenciaRequerido = x.ValoresDependenciaRequerido != null ? JsonConvert.SerializeObject(x.ValoresDependenciaRequerido) : null,
                        ValoresDependenciaValidacion = x.ValoresDependenciaValidacion != null ? JsonConvert.SerializeObject(x.ValoresDependenciaValidacion) : null,
                        ValoresDependenciaVisibilidad = x.ValoresDependenciaVisibilidad != null ? JsonConvert.SerializeObject(x.ValoresDependenciaVisibilidad) : null,
                        ComboboxPermiteNinguno = x.ComboboxPermiteNinguno.HasValue ? x.ComboboxPermiteNinguno.Value : false,
                        TipoFiltro = x.TipoFiltro,
                        DependenciaFiltro = x.DependenciaFiltro,
                        DependenciaValorDefecto = x.DependenciaValorDefecto,
                        ReglaDependenciaFiltro = x.ReglaDependenciaFiltro,
                        ReglaDependenciaValorDefecto = x.ReglaDependenciaValorDefecto,
                        TipoValorDefecto = x.TipoValorDefecto,
                        ValoresDependenciaFiltro = x.ValoresDependenciaFiltro != null ? JsonConvert.SerializeObject(x.ValoresDependenciaFiltro) : null,
                        ValoresDependenciaValorDefecto = x.ValoresDependenciaValorDefecto != null ? JsonConvert.SerializeObject(x.ValoresDependenciaValorDefecto) : null,
                        AnchoColumna = x.AnchoColumna,
                        AnchoColumnaFormulario = x.AnchoColumnaFormulario,
                        AnchoEtiquetaFormulario = x.AnchoEtiquetaFormulario,
                        EtiquetaFormulario = x.EtiquetaFormulario,
                        FormularioVisible = x.FormularioVisible,
                        Visible = x.Visible
                        
                    }).ToList();
                    camposIns.AddRange(campos);
                }
                //SUBSECCIONES
                if (child.Secciones != null && child.Secciones.Count > 0)
                {
                    child.Secciones.ForEach(y => {
                        if (y.Campos != null && y.Campos.Count > 0) {
                            List<FormatoDetalle> campos = y.Campos.Select(x => new FormatoDetalle
                            {
                                FormatoDetalleId = x.FormatoDetalleId,
                                Etiqueta = x.Etiqueta,
                                LongitudMaxima = x.LongitudMaxima,
                                LongitudMinima = x.LongitudMinima,
                                CampoId = x.CampoId,
                                DependenciaEditable = x.DependenciaEditable,
                                DependenciaRequerido = x.DependenciaRequerido,
                                DependenciaValidacion = x.DependenciaValidacion,
                                DependenciaVisibilidad = x.DependenciaVisibilidad,
                                Editable = x.Editable,
                                Enmascarar = x.Enmascarar,
                                FormatoId = x.FormatoId,
                                ReglaDependenciaEditable = x.ReglaDependenciaEditable,
                                ReglaDependenciaRequerido = x.ReglaDependenciaRequerido,
                                ReglaDependenciaValidacion = x.ReglaDependenciaValidacion,
                                ReglaDependenciaVisibilidad = x.ReglaDependenciaVisibilidad,
                                Requerido = x.Requerido,
                                TipoValidacion = x.TipoValidacion,
                                ValidacionRegex = x.ValidacionRegex,
                                ValidacionReglas = x.ValidacionReglas != null ? JsonConvert.SerializeObject(x.ValidacionReglas) : null,
                                ValidacionRutina = x.ValidacionRutina,
                                ValidacionRutinaCampos = x.ValidacionRutinaCampos != null ? JsonConvert.SerializeObject(x.ValidacionRutinaCampos) : null,
                                ValoresDependenciaEditable = x.ValoresDependenciaEditable != null ? JsonConvert.SerializeObject(x.ValoresDependenciaEditable) : null,
                                ValoresDependenciaRequerido = x.ValoresDependenciaRequerido != null ? JsonConvert.SerializeObject(x.ValoresDependenciaRequerido) : null,
                                ValoresDependenciaValidacion = x.ValoresDependenciaValidacion != null ? JsonConvert.SerializeObject(x.ValoresDependenciaValidacion) : null,
                                ValoresDependenciaVisibilidad = x.ValoresDependenciaVisibilidad != null ? JsonConvert.SerializeObject(x.ValoresDependenciaVisibilidad) : null,
                                
                                ComboboxPermiteNinguno = x.ComboboxPermiteNinguno.HasValue ? x.ComboboxPermiteNinguno.Value : false,
                                TipoFiltro = x.TipoFiltro,
                                DependenciaFiltro = x.DependenciaFiltro,
                                DependenciaValorDefecto = x.DependenciaValorDefecto,
                                ReglaDependenciaFiltro = x.ReglaDependenciaFiltro,
                                ReglaDependenciaValorDefecto = x.ReglaDependenciaValorDefecto,
                                TipoValorDefecto = x.TipoValorDefecto,
                                ValoresDependenciaFiltro = x.ValoresDependenciaFiltro != null ? JsonConvert.SerializeObject(x.ValoresDependenciaFiltro) : null,
                                ValoresDependenciaValorDefecto = x.ValoresDependenciaValorDefecto != null ? JsonConvert.SerializeObject(x.ValoresDependenciaValorDefecto) : null,
                                AnchoColumna = x.AnchoColumna,
                                AnchoColumnaFormulario = x.AnchoColumnaFormulario,
                                AnchoEtiquetaFormulario = x.AnchoEtiquetaFormulario,
                                EtiquetaFormulario = x.EtiquetaFormulario,
                                FormularioVisible = x.FormularioVisible,
                                Visible = x.Visible

                            }).ToList();
                            camposIns.AddRange(campos);
                        }                        
                    });
                }
            });
            return camposIns;
        }

        public int EliminarFormatos(HeaderRequest request, EliminacionFormatoRequestBody body)
        {
            using (IDbConnection db = _config.ObtenerConexion())
            {
                string ids = "(" + string.Join(",", body.FormatosIds) + ")";
                string deleteSQL = $"DELETE FROM [{SCHEMA}].[FormatoDetalle] WHERE FormatoId in {ids};" +
                    $"DELETE FROM [{SCHEMA}].[Formato] WHERE FormatoId in {ids};" +
                    $"SELECT @@ROWCOUNT; ";


                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {

                        //dsc: auditoria eliminar formato y DormatoDetalle

                        //respalda Formato a eliminar
                        string auditoriaSelectFormatoSql = $"SELECT FormatoId,Codigo,Nombre,Descripcion,TipoPersona,TipoIdentificacion,TipoCliente,PersonaId,ProductoId,indicadorGraba,IndicadorGrabaPersona,IndicadorGrabaProducto " +
                                                           $"FROM [{SCHEMA}].[Formato] WHERE FormatoId IN ({ids});";
                        var listaFormatoEliminados = db.Query(auditoriaSelectFormatoSql, null, tran, commandType: CommandType.Text);

                        //respalda FormatoDetalle a eliminar
                        string auditoriaSelectFormatoDetalleSql = $"SELECT FormatoDetalleId,FormatoId,CampoId,Etiqueta,LongitudMinima,LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido,DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable,ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex,ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro,TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario,AnchoEtiquetaFormulario " +
                                                                  $"FROM [{SCHEMA}].[FormatoDetalle] WHERE FormatoId IN ({ids});";
                        var listaFormatoDetalleliminados = db.Query(auditoriaSelectFormatoDetalleSql, null, tran, commandType: CommandType.Text);

                        //aaa:elimina formato y formatoDetalle
                        var result = db.Query<int>(deleteSQL, transaction: tran, commandType: CommandType.Text);

                        //dsc: auditoria agregar a auditoria los campos fisicamente eliminados
                        if (result.ToList().First<int>() > 0)
                        {

                            //guarda formatos eliminados
                            foreach (var item in listaFormatoEliminados)
                            {
                                string auditoriaDeleteFormatoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                   $" VALUES ('Formato', {item.FormatoId}, 'DELETE', '{request.UserName}', '{request.StationIp}', '{UtilGeneral.SerializedNeutralizedJson(item)}', '', '{fechaHoraAuditoria}');";

                                db.Execute(auditoriaDeleteFormatoSql, null, tran, commandType: CommandType.Text);
                            }

                            //guarda formatos Detalle eliminados
                            foreach (var item in listaFormatoDetalleliminados)
                            {
                                string auditoriaDeleteFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                 $" VALUES ('FormatoDetalle', {item.FormatoDetalleId}, 'DELETE', '{request.UserName}', '{request.StationIp}', '{UtilGeneral.SerializedNeutralizedJson(item)}', '', '{fechaHoraAuditoria}');";
                                db.Execute(auditoriaDeleteFormatoDetalleSql, null, tran, commandType: CommandType.Text);
                            }
                        }


                       


                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("FormatoDLL/EliminarFormatos: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception sqlException)
                    {
                        Log.Error("FormatoDLL/EliminarFormatos: Transaccion Exception -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public QueryFormatosResponse ListarFormatos(HeaderRequest header, ListaFormatosRequestBody body)
        {
            string userName = header.UserName;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            string sortBy = body.OrdenarPor ?? string.Empty;
            string filterBy = body.FiltrarPor ?? string.Empty;
            string filterValue = body.ValorFiltro != null ? body.ValorFiltro.ToLower() : string.Empty;

            #region user dynamic parameter
            var dbParam = new DynamicParameters();
            dbParam.Add("Username", userName, DbType.String);
            dbParam.Add("Page", page, DbType.Int32);
            dbParam.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            dbParam.Add("SortBy", sortBy, DbType.String);
            dbParam.Add("SortDesc", body.OrdenDesc, DbType.Boolean);
            dbParam.Add("FilterBy", filterBy, DbType.String);
            dbParam.Add("FilterValue", '%' + filterValue.ToLower() + '%', DbType.String);
            #endregion

            string sql = $"Select  fo.[FormatoId],fo.[Codigo],fo.[Nombre],fo.[Descripcion], per.[Descripcion] as TipoPersona," +
                $"ide.[Descripcion] as TipoIdentificacion,cli.[Descripcion] as TipoCliente,persona.[Nombre] as Persona, COALESCE(producto.[Nombre],'') as Producto, COUNT(*) OVER() as TotalCount " +
                $"FROM [{SCHEMA}].[Formato] fo " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] per ON fo.[TipoPersona] = per.[Codigo] AND per.[Nombre] = 'CLASE_PERSONA' " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] ide ON fo.[TipoIdentificacion] = ide.[Codigo] AND ide.[Nombre] = 'TIPO_DOCUMENTO' " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] cli ON fo.[TipoCliente] = cli.[Codigo] AND cli.[Nombre] = 'TIPO_CLIENTE' " +
                $"LEFT JOIN [{SCHEMA}].[Modelo] persona ON fo.[PersonaId] = persona.[ModeloId] " +
                $"LEFT JOIN [{SCHEMA}].[Modelo] producto ON fo.[ProductoId] = producto.[ModeloId] " +
                $"WHERE 1=1 ";

            if (!string.IsNullOrEmpty(filterBy) && !string.IsNullOrEmpty(filterValue))
            {
                switch (filterBy.ToLower())
                {
                    case "code":
                        sql += "AND LOWER(fo.[Codigo]) like @FilterValue ";
                        break;
                    case "name": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST(fo.[Nombre] as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                    case "description": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST(fo.[Descripcion] as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                }
            }

            bool sortDesc = body.OrdenDesc;

            if (!string.IsNullOrEmpty(sortBy))
            {
                switch (sortBy.ToLower())
                {
                    case "code":
                        sql += "ORDER BY fo.[Codigo] ";
                        break;
                    case "description":
                        sql += "ORDER BY fo.[Descripcion] ";
                        break;
                    case "name":
                        sql += "ORDER BY fo.[Nombre] ";
                        break;
                    default:
                        sql += "ORDER BY fo.[Nombre] ";
                        break;
                }
            }
            else
            {
                sql += "ORDER BY fo.[Nombre] ";
            }
            sql += sortDesc ? "DESC " : "ASC ";

            sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                   "FETCH NEXT @ItemsPerPage ROWS ONLY; ";

            QueryFormatosResponse result = new QueryFormatosResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<FormatoQuery> queryResult = db.Query(sql, param: dbParam, commandType: CommandType.Text,
                        map: (FormatoQuery Model, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return Model;
                        }, splitOn: "TotalCount").ToList();

                    result.Formatos = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("FormatoDLL/ListarFormatos: SqlException -> " + e.Message);
                    throw;
                }
            }
        }

        public FormatoDto ObtenerFormatoPorId(HeaderRequest request, ConsultaFormatoRequestBody body)
        {
            long ModelId = body.FormatoId;

            #region user dynamic parameter
            var dbPara = new DynamicParameters();
            dbPara.Add("FormatoId", ModelId, DbType.Int64);
            #endregion

            string sqlformato = $"SELECT frm.*, 1 as sepForm, " +
                $"tp.Codigo, tp.Descripcion, 1 as sepTipoPersona," +
                $"tc.Codigo, tc.Descripcion, 1 as sepTipoCliente," +
                $"ti.Codigo, ti.Descripcion, 1 as sepTipoIden," +
                $"cli.ModeloId as Id, cli.Codigo, cli.Nombre as Descripcion, 1 as sepCli," +
                $"Coalesce(pro.ModeloId,0) as Id,Coalesce(pro.Codigo,'') as Codigo, Coalesce(pro.Nombre,'') as Descripcion " +
                $"FROM [{SCHEMA}].[Formato] frm " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] tp ON frm.TipoPersona = tp.Codigo AND tp.Nombre = 'CLASE_PERSONA' " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] tc ON frm.TipoCliente = tc.Codigo AND tc.Nombre = 'TIPO_CLIENTE' " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] ti ON frm.TipoIdentificacion = ti.Codigo AND ti.Nombre = 'TIPO_DOCUMENTO' " +
                $"LEFT JOIN [{SCHEMA}].[Modelo] cli ON frm.PersonaId = cli.ModeloId " +
                $"LEFT JOIN [{SCHEMA}].[Modelo] pro ON frm.ProductoId = pro.ModeloId " +
                $"WHERE FormatoId = @FormatoId; ";

            Dictionary<long, string> modelCodes = new Dictionary<long, string>();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    FormatoDto result = db.Query(sqlformato, param: dbPara, commandType: CommandType.Text,
                        map: ((Formato fm, CodigoDescriptor tipoPersona, CodigoDescriptor tipoCliente, CodigoDescriptor tipoIdentificacion,
                         CampoDescriptor persona, CampoDescriptor producto) =>
                        {

                            FormatoDto res = new FormatoDto();
                            res.Codigo = fm.Codigo;
                            res.FormatoId = fm.FormatoId;
                            res.Descripcion = fm.Descripcion;
                            res.Nombre = fm.Nombre;
                            res.TipoIdentificacion = tipoIdentificacion;
                            res.TipoPersona = tipoPersona;
                            res.TipoCliente = tipoCliente; 

                            res.Persona = persona;

                            if (producto != null && !string.IsNullOrEmpty(producto.Descripcion))
                            {
                                res.Producto = producto;
                            }
                            return res;
                        }), splitOn: "sepForm,sepTipoPersona,sepTipoCliente,sepTipoIden,sepCli").Single();


                    //OBTENER SECCIONES PERSONA
                    result.SeccionesPersona = ObtenerCamposConsultaFormato(ModelId, result.Persona.Id, db, ref modelCodes);

                    if (result.Producto != null) {
                        //OBTENER SECCIONES PRODUCTOS
                        result.SeccionesProducto = ObtenerCamposConsultaFormato(ModelId, result.Producto.Id, db, ref modelCodes);
                    }

                    Dictionary<long, string> codigoRefNull = new Dictionary<long, string>();

                    if (modelCodes.Keys.Count > 0)
                    {
                        result.SeccionesReferencias = new List<SeccionesCamposDinamicos>();
                        foreach (var modelCode in modelCodes)
                        {
                            var smodelSection = ObtenerCamposConsultaFormato(ModelId, modelCode.Key, db, ref codigoRefNull);

                            SeccionesCamposDinamicos secc = new SeccionesCamposDinamicos
                            {
                                Nombre = modelCode.Value,
                                SeccionesCampo = smodelSection
                            };
                            result.SeccionesReferencias.Add(secc);
                        }
                    }

                    return result;
                }
                catch (SqlException sqlException)
                {
                    Log.Error("FormatoDLL/ObtenerFormatoPorId: Transaccion SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }

        private List<Seccion<FormatoDetalleDto>> ObtenerCamposConsultaFormato(long formatoId, long modeloId, IDbConnection db, ref Dictionary<long, string> modelCodes)
        {
            string sql = $"SELECT *, det.LongitudMinima as LongitudMinimaDetalle, det.LongitudMaxima as LongitudMaximaDetalle, det.Etiqueta as EtiquetaDetalle " +
               $"FROM [{SCHEMA}].[FormatoDetalle] det INNER JOIN [{SCHEMA}].[Campo] cam ON det.CampoId = cam.CampoId " +
               $"WHERE FormatoId = @FormatoId and cam.ModeloId = @ModeloId order by OrdenSeccion,OrdenSubseccion,OrdenCampo;";
            sql += $"SELECT distinct Seccion, Subseccion, OrdenSeccion, OrdenSubseccion " +
                $"FROM [{SCHEMA}].[FormatoDetalle] det INNER JOIN [{SCHEMA}].[Campo] cam ON det.CampoId = cam.CampoId " +
                $"WHERE FormatoId = @FormatoId and cam.ModeloId = @ModeloId order by OrdenSeccion,OrdenSubseccion;";

            sql += $"SELECT * FROM [{SCHEMA}].[Modelo]";
            sql += $"SELECT cam.* " +
                $"FROM [{SCHEMA}].[Campo] cam " +
                $"INNER JOIN [{SCHEMA}].[Modelo] mod ON mod.ModeloId = cam.ModeloId " +
                $"WHERE mod.Codigo in (Select distinct TipoValor FROM [{SCHEMA}].[Campo]) Order by OrdenSeccion,OrdenSubseccion,OrdenCampo;";

            var dbPara = new DynamicParameters();
            dbPara.Add("ModeloId", modeloId, DbType.Int64);
            dbPara.Add("FormatoId", formatoId, DbType.Int64);

            var valoresSecciones = new List<Seccion<FormatoDetalleDto>>();

            Dictionary<long, string> codes = modelCodes;

            using (SqlMapper.GridReader multi = db.QueryMultiple(sql, param: dbPara, commandType: CommandType.Text))
            {
                List<FormatoDetalleCampo> campos = multi.Read<FormatoDetalleCampo>().ToList();
                List<QuerySeccionesResponse> secresponse = multi.Read<QuerySeccionesResponse>().ToList();

                List<Modelo> modelos = multi.Read<Modelo>().ToList();
                Dictionary<long, List<Campo>> campoModelos = multi.Read<Campo>().GroupBy(y => y.ModeloId, x => x).ToDictionary(y => y.Key, x => x.ToList());

                Dictionary<string, Seccion<FormatoDetalleDto>> secciones = new Dictionary<string, Seccion<FormatoDetalleDto>>();

                Dictionary<string, List<FormatoDetalleCampo>> camposDict = campos.GroupBy(y => y.Seccion + "-" + y.Subseccion, x => x).ToDictionary(y => y.Key, x => x.ToList());

                secresponse.ForEach(x =>
                {
                    Seccion<FormatoDetalleDto> seccion;
                    if (!secciones.TryGetValue(x.Seccion, out seccion))
                    {
                        seccion = new Seccion<FormatoDetalleDto>
                        {
                            Orden = x.OrdenSeccion,
                            Nombre = x.Seccion,
                            Secciones = new List<Seccion<FormatoDetalleDto>>()
                        };
                        secciones.Add(x.Seccion, seccion);
                    }

                    Seccion<FormatoDetalleDto> subseccion = new Seccion<FormatoDetalleDto>
                    {
                        Orden = x.OrdenSubseccion,
                        Nombre = x.Subseccion
                    };
                    seccion.Secciones.Add(subseccion);

                    if (camposDict.TryGetValue(x.Seccion + "-" + x.Subseccion, out List<FormatoDetalleCampo> camposSeccion))
                    {
                        List<FormatoDetalleDto> camposDtos = camposSeccion.Select(x =>
                        {
                            FormatoDetalleDto campoDt = new FormatoDetalleDto
                            {
                                Etiqueta = x.EtiquetaDetalle,
                                LongitudMaxima = x.LongitudMaximaDetalle,
                                LongitudMinima = x.LongitudMinimaDetalle,
                                ValoresDependenciaEditable = !string.IsNullOrEmpty(x.ValoresDependenciaEditable) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaEditable) : null,
                                ValoresDependenciaFiltro = !string.IsNullOrEmpty(x.ValoresDependenciaFiltro) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaFiltro) : null,
                                ValoresDependenciaRequerido = !string.IsNullOrEmpty(x.ValoresDependenciaRequerido) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaRequerido) : null,
                                ValoresDependenciaValidacion = !string.IsNullOrEmpty(x.ValoresDependenciaValidacion) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaValidacion) : null,
                                ValoresDependenciaValorDefecto = !string.IsNullOrEmpty(x.ValoresDependenciaValorDefecto) ? JsonConvert.DeserializeObject<Dictionary<string, string>>(x.ValoresDependenciaValorDefecto) : null,
                                ValoresDependenciaVisibilidad = !string.IsNullOrEmpty(x.ValoresDependenciaVisibilidad) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaVisibilidad) : null,
                                ValoresCalculo = !string.IsNullOrEmpty(x.ValoresCalculo) ? JsonConvert.DeserializeObject<List<string>>(x.ValoresCalculo) : null,
                                AnchoColumna = x.AnchoColumna,
                                TipoValor = x.TipoValor,
                                TipoDato = x.TipoDato,
                                TipoCampo = x.TipoCampo,
                                TipoCalculado = x.TipoCalculado,
                                OrigenValores = x.OrigenValores,
                                AnchoEtiquetaFormulario = x.AnchoEtiquetaFormulario,
                                AnchoColumnaFormulario = x.AnchoColumnaFormulario,
                                CampoId = x.CampoId,
                                Codigo = x.Codigo,
                                ComboboxPermiteNinguno = x.ComboboxPermiteNinguno,
                                DatoSensible = x.DatoSensible,
                                DependenciaEditable = x.DependenciaEditable,
                                DependenciaFiltro = x.DependenciaFiltro,
                                DependenciaRequerido = x.DependenciaRequerido,
                                DependenciaValidacion = x.DependenciaValidacion,
                                DependenciaValorDefecto = x.DependenciaValorDefecto,
                                DependenciaVisibilidad = x.DependenciaVisibilidad,
                                Editable = x.Editable,
                                Enmascarar = x.Enmascarar,
                                EtiquetaFormulario = x.EtiquetaFormulario,
                                FormatoDetalleId = x.FormatoDetalleId,  
                                FormatoId = x.FormatoId,
                                FormatoModeloLista = null,
                                FormularioVisible = x.FormularioVisible,
                                ModeloId = x.ModeloId,
                                NombreCalculo = x.NombreCalculo,    
                                Obligatorio = x.Obligatorio,
                                OrdenCampo = x.OrdenCampo,
                                OrigenCatalogo = x.OrigenCatalogo,
                                OrigenCombobox = x.OrigenCombobox,
                                OrigenEtiqueta = x.OrigenEtiqueta,
                                PermiteEnmascaramiento = x.PermiteEnmascaramiento,
                                ReglaDependenciaEditable = x.ReglaDependenciaEditable,
                                ReglaDependenciaFiltro = x.ReglaDependenciaFiltro,
                                ReglaDependenciaRequerido = x.ReglaDependenciaRequerido,
                                ReglaDependenciaValidacion = x.ReglaDependenciaValidacion,
                                ReglaDependenciaValorDefecto = x.ReglaDependenciaValorDefecto,
                                ReglaDependenciaVisibilidad = x.ReglaDependenciaVisibilidad,
                                Requerido = x.Requerido,
                                TipoFiltro = x.TipoFiltro,
                                TipoValidacion = x.TipoValidacion,
                                TipoValorDefecto = x.TipoValorDefecto,
                                ValidacionRegex = x.ValidacionRegex,
                                ValidacionReglas = !string.IsNullOrEmpty(x.ValidacionReglas) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValidacionReglas) : null,
                                ValidacionRutina = x.ValidacionRutina,
                                ValidacionRutinaCampos = !string.IsNullOrEmpty(x.ValidacionRutinaCampos) ? JsonConvert.DeserializeObject<List<string>>(x.ValidacionRutinaCampos) : null,
                                Visible = x.Visible                                
                            };
                        
                            
                            if (campoDt.TipoValor == "LISTA") {
                                Modelo mod = modelos.Find(x => x.Codigo == campoDt.TipoDato);
                                if (codes != null && !codes.ContainsKey(mod.ModeloId)) codes.Add(mod.ModeloId, mod.Nombre);
                                if (campoModelos.TryGetValue(mod.ModeloId, out List<Campo> camposModelos))
                                {
                                    campoDt.FormatoModeloLista = camposModelos;
                                }
                            }

                            return campoDt;
                        }).ToList();

                        if (string.IsNullOrEmpty(subseccion.Nombre))
                        {
                            seccion.Campos = camposDtos;
                        }
                        else
                        {
                            subseccion.Campos = camposDtos;
                        }
                    }
                });

                modelCodes = codes;

                valoresSecciones = secciones.Values.ToList();
            }
            return valoresSecciones;
        }

        public CamposFormatoDto ObtenerCamposFormato(HeaderRequest request, ObtenerCamposFormatoRequestBody body)
        {
            CamposFormatoDto result = new CamposFormatoDto();
            string productCode = body.Producto;
            string personCode = body.Persona;

            Dictionary<string, string> codigoRef = new Dictionary<string, string>();

            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    //OBTENER SECCIONES PERSONA
                    result.SeccionesPersona = ObtenerCamposXModeloFormato(personCode, db, ref codigoRef);
                    if (!string.IsNullOrEmpty((body.Producto))) {
                        //OBTENER SECCIONES PRODUCTO
                        result.SeccionesProducto = ObtenerCamposXModeloFormato(productCode, db, ref codigoRef);
                    }


                    Dictionary<string, string> codigoRefNull = new Dictionary<string, string>(); 

                    if (codigoRef.Keys.Count > 0) {
                        result.SeccionesReferencias = new List<SeccionesCamposDinamicos>(); 
                        foreach (var modelCode in codigoRef)
                        {
                            var smodelSection = ObtenerCamposXModeloFormato(modelCode.Key, db, ref codigoRefNull);

                            SeccionesCamposDinamicos secc = new SeccionesCamposDinamicos
                            {
                                Nombre = modelCode.Value,
                                SeccionesCampo = smodelSection
                            };
                            result.SeccionesReferencias.Add(secc);
                        }
                    }
                    return result;
                }
                catch (SqlException sqlException)
                {
                    Log.Error("FormatoDLL/ObtenerCamposFormato: Transaccion SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }

        private List<Seccion<FormatoDetalleDto>> ObtenerCamposXModeloFormato(string modelCode, IDbConnection db, ref Dictionary<string, string> refModelCodes)
        {
            DynamicParameters dbPara = new DynamicParameters();
            dbPara.Add("CodigoModelo", modelCode, DbType.String);

            string sql = $"SELECT cam.* " +
                $"FROM [{SCHEMA}].[Campo] cam INNER JOIN  [{SCHEMA}].[Modelo] mod ON cam.ModeloId = mod.ModeloId " +
                $"WHERE mod.Codigo = @CodigoModelo order by OrdenSeccion,OrdenSubseccion,OrdenCampo;";
            sql += $"SELECT distinct Seccion, Subseccion, OrdenSeccion, OrdenSubseccion " +
                $"FROM [{SCHEMA}].[Campo] cam INNER JOIN  [{SCHEMA}].[Modelo] mod ON cam.ModeloId = mod.ModeloId " +
                $"WHERE mod.Codigo = @CodigoModelo order by OrdenSeccion,OrdenSubseccion;";

            sql += $"SELECT * FROM [{SCHEMA}].[Modelo]";
            sql += $"SELECT cam.* " +
                $"FROM [{SCHEMA}].[Campo] cam " +
                $"INNER JOIN [{SCHEMA}].[Modelo] mod ON mod.ModeloId = cam.ModeloId " +
                $"WHERE mod.Codigo in (Select distinct TipoValor FROM [{SCHEMA}].[Campo]) Order by OrdenSeccion,OrdenSubseccion,OrdenCampo;";

            var valoresSecciones =  new List<Seccion<FormatoDetalleDto>>();
            using (SqlMapper.GridReader multi = db.QueryMultiple(sql, param: dbPara, commandType: CommandType.Text))
            {
                List<Campo> campos = multi.Read<Campo>().ToList();
                List<QuerySeccionesResponse> secresponse = multi.Read<QuerySeccionesResponse>().ToList();

                List<Modelo> modelos = multi.Read<Modelo>().ToList();
                Dictionary<long, List<Campo>> campoModelos = multi.Read<Campo>().GroupBy(y => y.ModeloId, x => x).ToDictionary(y => y.Key, x => x.ToList());

                Dictionary<string, Seccion<FormatoDetalleDto>> secciones = new Dictionary<string, Seccion<FormatoDetalleDto>>();

                Dictionary<string, List<Campo>> camposDict = campos.GroupBy(y => y.Seccion + "-" + y.Subseccion, x => x).ToDictionary(y => y.Key, x => x.ToList());

                Dictionary<string, string> codes = refModelCodes;

                secresponse.ForEach(x =>
                {
                    Seccion<FormatoDetalleDto> seccion;
                    if (!secciones.TryGetValue(x.Seccion, out seccion))
                    {
                        seccion = new Seccion<FormatoDetalleDto>
                        {
                            Orden = x.OrdenSeccion,
                            Nombre = x.Seccion,
                            Secciones = new List<Seccion<FormatoDetalleDto>>()
                        };
                        secciones.Add(x.Seccion, seccion);
                    }

                    Seccion<FormatoDetalleDto> subseccion = new Seccion<FormatoDetalleDto>
                    {
                        Orden = x.OrdenSubseccion,
                        Nombre = x.Subseccion
                    };
                    seccion.Secciones.Add(subseccion);

                    if (camposDict.TryGetValue(x.Seccion + "-" + x.Subseccion, out List<Campo> camposSeccion))
                    {
                        List<FormatoDetalleDto> camposDtos = new List<FormatoDetalleDto>();
                        camposSeccion.ForEach(x =>
                        {
                            FormatoDetalleDto campoDt = new FormatoDetalleDto
                            {
                                Etiqueta = x.Etiqueta,
                                LongitudMaxima = x.LongitudMaxima,
                                LongitudMinima = x.LongitudMinima,
                                ValoresCalculo = !string.IsNullOrEmpty(x.ValoresCalculo) ? JsonConvert.DeserializeObject<List<string>>(x.ValoresCalculo) : null,
                                TipoValor = x.TipoValor,
                                TipoDato = x.TipoDato,
                                TipoCampo = x.TipoCampo,
                                TipoCalculado = x.TipoCalculado,
                                OrigenValores = x.OrigenValores,
                                CampoId = x.CampoId,
                                Codigo = x.Codigo,
                                DatoSensible = x.DatoSensible,
                                FormatoModeloLista = null,
                                ModeloId = x.ModeloId,
                                NombreCalculo = x.NombreCalculo,
                                Obligatorio = x.Obligatorio,
                                OrdenCampo = x.OrdenCampo,
                                OrigenCatalogo = x.OrigenCatalogo,
                                OrigenCombobox = x.OrigenCombobox,
                                OrigenEtiqueta = x.OrigenEtiqueta,
                                PermiteEnmascaramiento = x.PermiteEnmascaramiento,
                                AnchoColumna = "12"
                            };
                            campoDt.Editable = x.TipoCampo != "CALCULADO";
                            campoDt.Visible = true;
                            campoDt.Requerido = true;
                            
                            if (x.TipoValor == "LISTA")
                            {
                                Modelo mod = modelos.Find(y => y.Codigo == campoDt.TipoDato);
                                if (codes != null && !codes.ContainsKey(mod.Codigo)) codes.Add(mod.Codigo, mod.Nombre);
                                if (campoModelos.TryGetValue(mod.ModeloId, out List<Campo> camposModelos))
                                {
                                    campoDt.FormatoModeloLista = camposModelos;
                                }
                            }

                            camposDtos.Add(campoDt);
                        });
                        if (string.IsNullOrEmpty(subseccion.Nombre))
                        {
                            seccion.Campos = camposDtos;
                        }
                        else
                        {
                            subseccion.Campos = camposDtos;
                        }
                    }
                });

                refModelCodes = codes;

                valoresSecciones = secciones.Values.ToList();
            }
            return valoresSecciones;
        }

        public FormatoClienteDto ObtenerFormulario(HeaderRequest request, ObtenerFormularioRequestBody body, object datos)
        {
            #region user dynamic parameter
            var dbPara = new DynamicParameters();
            dbPara.Add("TipoPersona", body.TipoPersona, DbType.String);
            dbPara.Add("TipoCliente", body.TipoCliente, DbType.String);
            dbPara.Add("TipoIdentificacion", body.TipoIdentificacion, DbType.String);
            #endregion

            string sqlformato = $"SELECT frm.*, 1 as sepForm, " +
                $"tp.Codigo, tp.Descripcion, 1 as sepTipoPersona," +
                $"tc.Codigo, tc.Descripcion, 1 as sepTipoCLiente," +
                $"ti.Codigo, ti.Descripcion, 1 as sepTipoIden," +
                $"cli.ModeloId as Id, cli.Codigo as Codigo, cli.Nombre as Descripcion, 1 as sepCli," +
                $"Coalesce(pro.ModeloId,0) as Id,Coalesce(pro.Codigo,'') as Codigo, Coalesce(pro.Nombre,'') as Descripcion " +               
                $"FROM [{SCHEMA}].[Formato] frm " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] tp ON frm.TipoPersona = tp.Codigo AND tp.Nombre = 'CLASE_PERSONA' " + 
                $"LEFT JOIN [{SCHEMA}].[Catalogo] tc ON frm.TipoCliente = tc.Codigo AND tc.Nombre = 'TIPO_CLIENTE' " +
                $"LEFT JOIN [{SCHEMA}].[Catalogo] ti ON frm.TipoIdentificacion = ti.Codigo AND ti.Nombre = 'TIPO_DOCUMENTO' " +
                $"LEFT JOIN [{SCHEMA}].[Modelo] cli ON frm.PersonaId = cli.ModeloId " +
                $"LEFT JOIN [{SCHEMA}].[Modelo] pro ON frm.ProductoId = pro.ModeloId " +
                $"WHERE frm.TipoPersona = @TipoPersona AND frm.TipoCliente = @TipoCliente AND frm.TipoIdentificacion=@TipoIdentificacion ";
            
            if (body.Producto > 0)
            {
                dbPara.Add("ProductoId", body.Producto, DbType.Int64);
                sqlformato += "AND ProductoId = @ProductoId";
            }
            else 
            {
                sqlformato += "AND ProductoId IS NULL";
            }        

            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    FormatoClienteDto? result = db.Query(sqlformato, param: dbPara, commandType: CommandType.Text,
                        map: ((Formato fm, CodigoDescriptor tipoPersona, CodigoDescriptor tipoCliente, CodigoDescriptor tipoIdentificacion,
                         CampoDescriptor persona, CampoDescriptor producto) =>
                        {

                            FormatoClienteDto res = new FormatoClienteDto();

                            res.Codigo = fm.Codigo;
                            res.FormatoId = fm.FormatoId;
                            res.Descripcion = fm.Descripcion;
                            res.Nombre = fm.Nombre;

                            res.TipoIdentificacion = tipoIdentificacion;
                            res.TipoPersona = tipoPersona;
                            res.TipoCliente = tipoCliente; 

                            res.Cliente = new PaginaForm<FormatoDetalleFormularioDto>
                            {
                                Id = persona.Id,
                                Descripcion = persona.Descripcion,
                                Codigo = persona.Codigo
                            };

                            if (producto != null && !string.IsNullOrEmpty(producto.Descripcion))
                            {
                                res.Producto = new PaginaForm<FormatoDetalleFormularioDto>
                                {
                                    Id = producto.Id,
                                    Descripcion = producto.Descripcion,
                                    Codigo = producto.Codigo
                                };
                            }
                            return res;
                        }), splitOn: "sepForm,sepTipoPersona,sepTipoCLiente,sepTipoIden,sepCli")?.FirstOrDefault();

                    if (result == null) return null;

                    Dictionary<string, ValorNombresCat> camposDtosDepend = new Dictionary<string, ValorNombresCat>();

                    //OBTENER SECCIONES PERSONA
                    result.Cliente.Secciones = ObtenerCamposFormulario(datos, result.FormatoId, result.Cliente.Id, db, ref camposDtosDepend);

                    //si no tiene producto o si no es titular
                    if (body.Producto <= 0 || body.TipoCliente != "01") return result;

                    //OBTENER SECCIONES PRODUCTO

                    result.Producto.Secciones = ObtenerCamposFormulario(null, result.FormatoId, result.Producto.Id, db, ref camposDtosDepend);

                    return result;
                }
                catch (SqlException sqlException)
                {
                    Log.Error("FormatoDLL/ObtenerFormatoPorId: Transaccion SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }

        private List<Seccion<FormatoDetalleFormularioDto>> ObtenerCamposFormulario(object datos, long formatoId, long modeloId, IDbConnection db, ref Dictionary<string, ValorNombresCat> camposDtosDepend)
        {
            string sql = $"SELECT *, det.LongitudMinima as LongitudMinimaDetalle, det.LongitudMaxima as LongitudMaximaDetalle, det.Etiqueta as EtiquetaDetalle " +
               $"FROM [{SCHEMA}].[FormatoDetalle] det INNER JOIN [{SCHEMA}].[Campo] cam ON det.CampoId = cam.CampoId " +
               $"WHERE FormatoId = @FormatoId and cam.ModeloId = @ModeloId order by OrdenSeccion,OrdenSubseccion,OrdenCampo;";
            sql += $"SELECT distinct Seccion, Subseccion, OrdenSeccion, OrdenSubseccion " +
                $"FROM [{SCHEMA}].[FormatoDetalle] det INNER JOIN [{SCHEMA}].[Campo] cam ON det.CampoId = cam.CampoId " +
                $"WHERE FormatoId = @FormatoId and cam.ModeloId = @ModeloId order by OrdenSeccion,OrdenSubseccion;";

            sql += $"SELECT * FROM [{SCHEMA}].[Modelo];";
            sql += $"SELECT det.*,cam.*, det.LongitudMinima as LongitudMinimaDetalle, det.LongitudMaxima as LongitudMaximaDetalle, det.Etiqueta as EtiquetaDetalle " +
               $"FROM [{SCHEMA}].[FormatoDetalle] det " +
               $"INNER JOIN [{SCHEMA}].[Campo] cam ON det.CampoId = cam.CampoId " +
               $"INNER JOIN [{SCHEMA}].[Modelo] mod ON mod.ModeloId = cam.ModeloId " +
               $"WHERE FormatoId = @FormatoId and mod.Codigo in (Select distinct TipoDato FROM [{SCHEMA}].[Campo] WHERE ModeloId = @ModeloId) " +
               $"order by OrdenSeccion,OrdenSubseccion,OrdenCampo;"; 
            sql += $"SELECT cat.* from [{SCHEMA}].[Catalogo] cat " +
                $"WHERE cat.Nombre in (SELECT REPLACE(OrigenCatalogo,' ','') FROM [{SCHEMA}].[Campo] WHERE ModeloId = @ModeloId " +
                $"OR ModeloId in (SELECT ModeloId from [{SCHEMA}].Modelo WHERE Codigo in (SELECT TipoDato FROM [{SCHEMA}].Campo WHERE TipoValor = 'LISTA' AND ModeloId = @ModeloId)))  " +
                //$"ORDER BY cat.Nombre, cat.Descripcion;";
                $";";

            var dbPara = new DynamicParameters();
            dbPara.Add("FormatoId", formatoId, DbType.Int64);
            dbPara.Add("ModeloId", modeloId, DbType.Int64);


            using (SqlMapper.GridReader multi = db.QueryMultiple(sql, param: dbPara, commandType: CommandType.Text))
            {
                List<FormatoDetalleCampo> campos = multi.Read<FormatoDetalleCampo>().ToList();
                List<QuerySeccionesResponse> secresponse = multi.Read<QuerySeccionesResponse>().ToList();
                List<Modelo> modelos = multi.Read<Modelo>().ToList();
                Dictionary<long, List<FormatoDetalleCampo>> campoModelos = multi.Read<FormatoDetalleCampo>().GroupBy(y => y.ModeloId, x => x).ToDictionary(y => y.Key, x => x.ToList());

                Dictionary<string, List<Catalogo>> catalogos = multi.Read<Catalogo>().GroupBy(y => y.Nombre, x => x).ToDictionary(y => y.Key, x => x.ToList());

                Dictionary<string, Seccion<FormatoDetalleFormularioDto>> secciones = new Dictionary<string, Seccion<FormatoDetalleFormularioDto>>();

                Dictionary<string, List<FormatoDetalleCampo>> camposDict = campos.GroupBy(y => y.Seccion + "-" + y.Subseccion, x => x).ToDictionary(y => y.Key, x => x.ToList());

                Dictionary<string, ValorNombresCat> camposDtosDependTemp = camposDtosDepend;

                secresponse.ForEach(x =>
                {
                    Seccion<FormatoDetalleFormularioDto> seccion;
                    if (!secciones.TryGetValue(x.Seccion, out seccion))
                    {
                        seccion = new Seccion<FormatoDetalleFormularioDto>
                        {
                            Orden = x.OrdenSeccion,
                            Nombre = x.Seccion,
                            Secciones = new List<Seccion<FormatoDetalleFormularioDto>>()
                        };
                        secciones.Add(x.Seccion, seccion);
                    }

                    Seccion<FormatoDetalleFormularioDto> subseccion = new Seccion<FormatoDetalleFormularioDto>
                    {
                        Orden = x.OrdenSubseccion,
                        Nombre = x.Subseccion
                    };
                    seccion.Secciones.Add(subseccion);

                    if (camposDict.TryGetValue(x.Seccion + "-" + x.Subseccion, out List<FormatoDetalleCampo> camposSeccion))
                    {

                        List<FormatoDetalleFormularioDto> camposDtos = camposSeccion.Select(x =>
                        {
                            FormatoDetalleFormularioDto campoDt = new FormatoDetalleFormularioDto
                            {
                                AnchoColumna = x.AnchoColumna,
                                AnchoColumnaFormulario = x.AnchoColumnaFormulario,
                                AnchoEtiquetaFormulario = x.AnchoEtiquetaFormulario,
                                CampoAS400 = x.CampoAS400,
                                CampoId = x.CampoId,
                                Codigo = x.Codigo,
                                ComboboxPermiteNinguno = x.ComboboxPermiteNinguno,
                                DatoSensible = x.DatoSensible,
                                ValoresDependenciaEditable = !string.IsNullOrEmpty(x.ValoresDependenciaEditable) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaEditable) : null,
                                ValoresDependenciaFiltro = !string.IsNullOrEmpty(x.ValoresDependenciaFiltro) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaFiltro) : null,
                                ValoresDependenciaRequerido = !string.IsNullOrEmpty(x.ValoresDependenciaRequerido) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaRequerido) : null,
                                ValoresDependenciaValidacion = !string.IsNullOrEmpty(x.ValoresDependenciaValidacion) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaValidacion) : null,
                                ValoresDependenciaValorDefecto = !string.IsNullOrEmpty(x.ValoresDependenciaValorDefecto) ? JsonConvert.DeserializeObject<Dictionary<string, string>>(x.ValoresDependenciaValorDefecto) : null,
                                ValoresDependenciaVisibilidad = !string.IsNullOrEmpty(x.ValoresDependenciaVisibilidad) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaVisibilidad) : null,
                                ValoresCalculo = !string.IsNullOrEmpty(x.ValoresCalculo) ? JsonConvert.DeserializeObject<List<string>>(x.ValoresCalculo) : null,
                                DependenciaEditable = x.DependenciaEditable,
                                DependenciaFiltro = x.DependenciaFiltro,
                                DependenciaRequerido = x.DependenciaRequerido,
                                DependenciaValidacion = x.DependenciaValidacion,
                                DependenciaValorDefecto = x.DependenciaValorDefecto,
                                DependenciaVisibilidad = x.DependenciaVisibilidad,
                                Editable = x.Editable,
                                Enmascarar = x.Enmascarar,
                                EtiquetaDetalle = x.EtiquetaDetalle,
                                EtiquetaFormulario = x.EtiquetaFormulario,
                                FormatoDetalleId = x.FormatoDetalleId,
                                FormatoId = x.FormatoId,
                                FormularioVisible = x.FormularioVisible,
                                LongitudMaximaDetalle = x.LongitudMaximaDetalle,
                                LongitudMinimaDetalle = x.LongitudMinimaDetalle,
                                ModeloId = x.ModeloId,
                                NombreCalculo = x.NombreCalculo,
                                OrdenCampo = x.OrdenCampo,
                                OrigenCatalogo = x.OrigenCatalogo,
                                OrigenCombobox = x.OrigenCombobox,
                                OrigenEtiqueta = x.OrigenEtiqueta,
                                OrigenValores = x.OrigenValores,
                                ReglaDependenciaEditable = x.ReglaDependenciaEditable,
                                ReglaDependenciaFiltro = x.ReglaDependenciaFiltro,
                                ReglaDependenciaRequerido = x.ReglaDependenciaRequerido,
                                ReglaDependenciaValidacion = x.ReglaDependenciaValidacion,
                                ReglaDependenciaValorDefecto = x.ReglaDependenciaValorDefecto,
                                ReglaDependenciaVisibilidad = x.ReglaDependenciaVisibilidad,
                                Requerido = x.Requerido,
                                TipoCalculado = x.TipoCalculado,
                                TipoCampo = x.TipoCampo,
                                TipoDato = x.TipoDato,
                                TipoFiltro = x.TipoFiltro,
                                TipoValidacion = x.TipoValidacion,
                                TipoValor = x.TipoValor,
                                TipoValorDefecto = x.TipoValorDefecto,
                                ValidacionRegex = x.ValidacionRegex,
                                ValidacionReglas = !string.IsNullOrEmpty(x.ValidacionReglas) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValidacionReglas) : null,
                                ValidacionRutina = x.ValidacionRutina,
                                ValidacionRutinaCampos = !string.IsNullOrEmpty(x.ValidacionRutinaCampos) ? JsonConvert.DeserializeObject<List<string>>(x.ValidacionRutinaCampos) : null,
                                Visible = x.Visible
                            };

                            return campoDt;
                        }).ToList();

                        AsignarValoresCampos(datos, modelos, campoModelos, camposDtos, catalogos, ref camposDtosDependTemp);

                        if (string.IsNullOrEmpty(subseccion.Nombre))
                        {
                            seccion.Campos = camposDtos;
                        }
                        else
                        {
                            subseccion.Campos = camposDtos;
                        }
                    }
                });

                camposDtosDepend = camposDtosDependTemp;

                return secciones.Values.ToList();
            }
        }

        private static string GetValorDependencia(FormatoDetalleFormularioDto campo, string valorDepen, Dictionary<string, ValorNombresCat> valores, Dictionary<string, List<Catalogo>> catalogos)
        {
            string valor = null;

            if (valorDepen == null) valorDepen = string.Empty;

            ValorNombresCat valorCampo = null;

            if (valores.TryGetValue(campo.DependenciaValorDefecto, out ValorNombresCat val))
            {
                valorCampo = val;
            }

            if (valorDepen == "${VALUE}")
            {
                valor = valorCampo.Valor?.ToString().Trim();
            }
            else if (valorDepen == "${CMPL}")
            {
                valor = string.Empty;

                valor = valorCampo.Catalogo?.Find(x => x.Codigo == valorCampo.Valor?.ToString().Trim())?.Complemento;
            }
            else if (valorDepen == "${DESCR}")
            {
                valor = string.Empty;

                valor = valorCampo.Catalogo?.Find(x => x.Codigo == valorCampo.Valor?.ToString().Trim())?.Descripcion;
            }
            else if (valorDepen == "${TODAY}")
            {
                valor = string.Empty;
            }
            else if (valorDepen == "${EMPTY}")
            {
                valor = string.Empty;
            }
            else if (valorDepen.StartsWith("[") && valorDepen.EndsWith("]"))
            {
                string code = valorDepen.Replace("[", "").Replace("]", "");

                if (valores.TryGetValue(code, out ValorNombresCat valorCampoDep))
                {
                    valor = valorCampoDep?.Valor?.ToString()?.Trim();
                }
            }
            else if (valorDepen.StartsWith("?"))
            {
                valor = string.Empty;
            }
            else
            {
                valor = valorDepen?.Trim();
            }

            if (valor == null)
            {
                valor = string.Empty;
            }

            return valor;
        }
        private static void AsignarValoresCampos<T>(T datos, List<Modelo> modelos, Dictionary<long, List<FormatoDetalleCampo>> campoModelos, List<FormatoDetalleFormularioDto> camposDtos, Dictionary<string, List<Catalogo>> catalogos, ref Dictionary<string, ValorNombresCat> camposDtosDepend)
        {
            Dictionary<string, dynamic>? dictValores = datos == null ? null : ObjectReflection.GetFieldValuesFromObject(datos);

            Dictionary<string, string> rutaDict = camposDtos.ToDictionary(x => x.Codigo, y => y.CampoAS400);

            foreach (FormatoDetalleFormularioDto campo in camposDtos)
            {
                if (campo.TipoValor == "VALOR")
                {
                    if (dictValores != null && dictValores.TryGetValue(campo.CampoAS400, out dynamic? valorCampo))
                    {
                        string valorCampostr = valorCampo.ToString();

                        if (valorCampostr.Replace("0", "") == string.Empty)
                        {
                            valorCampostr = string.Empty;
                        }
                        if (string.IsNullOrEmpty(valorCampostr))
                        {
                            dynamic valordefecto = string.Empty;

                            if (!string.IsNullOrEmpty(campo.TipoValorDefecto) && campo.TipoValorDefecto.Trim() == Constantes.TipoValorDefecto.INICIAL)
                            {
                                switch (campo.ReglaDependenciaValorDefecto.Trim())
                                {
                                    case Constantes.ReglaValorDefecto.VALOR:
                                        if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores))
                                        {
                                            valordefecto = valores;                                            
                                        }
                                        break;
                                    case Constantes.ReglaValorDefecto.CONDICIONAL:
                                        if (!string.IsNullOrEmpty(campo.DependenciaValorDefecto) && rutaDict.TryGetValue(campo.DependenciaValorDefecto.Trim(), out string rutaCampo))
                                        {
                                            if (dictValores.TryGetValue(rutaCampo, out dynamic valorDependencia))
                                            {
                                                string valorDependenciaStr = valorDependencia.ToString().Trim();
                                                if (campo.ValoresDependenciaValorDefecto.TryGetValue(valorDependenciaStr, out string valores3))
                                                {
                                                    valordefecto = valores3;
                                                }
                                                else if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores2))
                                                {
                                                    valordefecto = valores2;
                                                }
                                            }
                                        }
                                        break;
                                }
                            }
                            else if (!string.IsNullOrEmpty(campo.TipoValorDefecto) && campo.TipoValorDefecto.Trim() == Constantes.TipoValorDefecto.ONCHANGE)
                            {
                                switch (campo.ReglaDependenciaValorDefecto.Trim())
                                {
                                    case Constantes.ReglaValorDefecto.VALOR:
                                        if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores))
                                        {
                                            valordefecto = valores;
                                        }
                                        break;
                                    case Constantes.ReglaValorDefecto.CONDICIONAL:
                                        if (!string.IsNullOrEmpty(campo.DependenciaValorDefecto) && camposDtosDepend.TryGetValue(campo.DependenciaValorDefecto.Trim(), out ValorNombresCat valorDependencia))
                                        {
                                            string valorDependenciaStr = valorDependencia.Valor is null ? "" : valorDependencia.Valor.ToString().Trim();

                                            if (campo.ValoresDependenciaValorDefecto.TryGetValue(valorDependenciaStr, out string valores3))
                                            {
                                                valordefecto = GetValorDependencia(campo, valores3, camposDtosDepend, catalogos);
                                            }
                                            else if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores2))
                                            {
                                                valordefecto = GetValorDependencia(campo, valores2, camposDtosDepend, catalogos);
                                            }
                                        }
                                        break;
                                }
                            }

                            if (valordefecto == "${TODAY}") valordefecto = DateTime.Now;
                            camposDtosDepend.Add(campo.Codigo, new ValorNombresCat { Valor = valordefecto, Catalogo = null });
                            campo.Valor = valordefecto;
                            campo.ValorAnterior = valordefecto;
                        }
                        else
                        {
                            if (valorCampo.GetType() == typeof(string)) valorCampo = valorCampo.Trim();

                            if (valorCampo.GetType() == typeof(DateTime)) {
                                if (((DateTime)valorCampo).Year == 1)
                                {
                                    valorCampo = string.Empty;
                                }
                            }

                            camposDtosDepend.Add(campo.Codigo, new ValorNombresCat { Valor = valorCampo , Catalogo = null });
                            campo.Valor = valorCampo;
                            campo.ValorAnterior = valorCampo;
                        }

                    }
                    else {
                        dynamic valordefecto = string.Empty;
                        if (!string.IsNullOrEmpty(campo.TipoValorDefecto) && campo.TipoValorDefecto.Trim() == Constantes.TipoValorDefecto.INICIAL)
                        {
                            switch (campo.ReglaDependenciaValorDefecto.Trim())
                            {
                                case Constantes.ReglaValorDefecto.VALOR:
                                    if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores))
                                    {
                                        valordefecto = valores;
                                    }
                                    break;
                                case Constantes.ReglaValorDefecto.CONDICIONAL:
                                    if (!string.IsNullOrEmpty(campo.DependenciaValorDefecto) && rutaDict.TryGetValue(campo.DependenciaValorDefecto.Trim(), out string rutaCampo))
                                    {
                                        if (dictValores.TryGetValue(rutaCampo, out dynamic valorDependencia))
                                        {
                                            string valorDependenciaStr = valorDependencia.ToString().Trim();
                                            if (campo.ValoresDependenciaValorDefecto.TryGetValue(valorDependenciaStr, out string valores3))
                                            {
                                                valordefecto = valores3;
                                            }
                                            else if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores2))
                                            {
                                                valordefecto = valores2;
                                            }
                                        }
                                    }
                                    break;
                            }
                        }
                        else if (!string.IsNullOrEmpty(campo.TipoValorDefecto) && campo.TipoValorDefecto.Trim() == Constantes.TipoValorDefecto.ONCHANGE) 
                        {
                            switch (campo.ReglaDependenciaValorDefecto.Trim())
                            {
                                case Constantes.ReglaValorDefecto.VALOR:
                                    if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores))
                                    {
                                        valordefecto = valores;
                                    }
                                    break;
                                case Constantes.ReglaValorDefecto.CONDICIONAL:
                                    if (!string.IsNullOrEmpty(campo.DependenciaValorDefecto) && camposDtosDepend.TryGetValue(campo.DependenciaValorDefecto.Trim(), out ValorNombresCat valorDependencia))
                                    {
                                        string valorDependenciaStr = valorDependencia.Valor is null ? "" : valorDependencia.Valor.ToString().Trim();

                                        if (campo.ValoresDependenciaValorDefecto.TryGetValue(valorDependenciaStr, out string valores3))
                                        {
                                            valordefecto = GetValorDependencia(campo, valores3, camposDtosDepend, catalogos);
                                        }
                                        else if (campo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores2))
                                        {
                                            valordefecto = GetValorDependencia(campo, valores2, camposDtosDepend, catalogos);
                                        }
                                    }
                                    break;
                            }
                        }
                        
                        if (valordefecto == "${TODAY}") valordefecto = DateTime.Now;
                        camposDtosDepend.Add(campo.Codigo, new ValorNombresCat { Valor = valordefecto, Catalogo = null });
                        campo.Valor = valordefecto;
                        campo.ValorAnterior = valordefecto;
                    }

                    if (campo.OrigenCombobox == "CATALOGO")
                    {
                        campo.ValoresCombobox = new List<ValorCombobox>();

                        if (!string.IsNullOrEmpty(campo.OrigenCatalogo) && catalogos.TryGetValue(campo.OrigenCatalogo.Trim(), out List<Catalogo> catValor))
                        {
                            if (!string.IsNullOrEmpty(campo.TipoFiltro) && campo.TipoFiltro.Trim() == Constantes.TipoFiltro.INICIAL)
                            {
                                switch (campo.ReglaDependenciaFiltro.Trim())
                                {
                                    case Constantes.ReglaFiltro.VALOR:
                                        if (campo.ValoresDependenciaFiltro.TryGetValue("DEFAULT", out OperacionDependencia operacion))
                                        {
                                            campo.ValoresCombobox = ObtenerCatalogoFiltrados(operacion, catValor);
                                        }
                                        break;
                                    case Constantes.ReglaFiltro.CONDICIONAL:
                                        if (!string.IsNullOrEmpty(campo.DependenciaFiltro) && rutaDict.TryGetValue(campo.DependenciaFiltro.Trim(), out string rutaCampo))
                                        {
                                            if (dictValores.TryGetValue(rutaCampo, out dynamic valorDependencia))
                                            {
                                                string valorDependenciaStr = valorDependencia.ToString().Trim();
                                                if (campo.ValoresDependenciaFiltro.TryGetValue(valorDependenciaStr, out OperacionDependencia operacion1))
                                                {
                                                    campo.ValoresCombobox = ObtenerCatalogoFiltrados(operacion1, catValor);
                                                }
                                                else if (campo.ValoresDependenciaFiltro.TryGetValue("DEFAULT", out OperacionDependencia operacion2))
                                                {
                                                    campo.ValoresCombobox = ObtenerCatalogoFiltrados(operacion2, catValor);
                                                }
                                            }
                                        }
                                        break;
                                }
                            }
                            else {
                                campo.ValoresCombobox = catValor.Select(x =>
                                {
                                    return new ValorCombobox
                                    {
                                        Codigo = x.Codigo.Trim(),
                                        Descripcion = x.Descripcion.Trim(),
                                        Complemento = x.Complemento?.Trim()
                                    };
                               // }).OrderBy(p => int.Parse(p.Codigo)).ToList();
                                }).ToList();
                        }

                            if (camposDtosDepend.TryGetValue(campo.Codigo, out ValorNombresCat valoresNombre))
                            {
                                valoresNombre.Catalogo = campo.ValoresCombobox;
                                valoresNombre.Valor = valoresNombre.Valor?.ToString();
                            }

                            string valorCampoCat = string.Empty;

                            string valorStr = campo.Valor?.ToString();

                            if (!string.IsNullOrEmpty(valorStr) && campo.ValoresCombobox != null && campo.ValoresCombobox.Count > 0)
                            {
                                if (campo.ValoresCombobox.Exists(x => x.Codigo == valorStr)) valorCampoCat = valorStr;
                            }

                            campo.Valor = valorCampoCat;
                            campo.ValorAnterior = valorCampoCat;
                        }
                        campo.ValoresCombobox = OrdenarCatalogos(campo.OrigenEtiqueta, campo.ValoresCombobox);
                    }
                    else if (campo.OrigenCombobox == "VALORES" || campo.OrigenCombobox == "MODELOS") {
                        if (!string.IsNullOrEmpty(campo.OrigenValores)) {
                            try
                            {
                                campo.ValoresCombobox = JsonConvert.DeserializeObject<List<ValorCombobox>>(campo.OrigenValores);
                            }
                            catch (JsonException ex) {
                                Log.Error($"FormatoDLL/AsignarValoresCampos: No se puedo deserializar {campo.OrigenValores} JsonException -> " + ex.Message);
                            }                            
                        }
                        if (camposDtosDepend.TryGetValue(campo.Codigo, out ValorNombresCat valoresNombre))
                        {
                            valoresNombre.Catalogo = campo.ValoresCombobox;
                            valoresNombre.Valor = valoresNombre.Valor?.ToString();
                        }

                        string valorCampoCat = string.Empty;

                        string valorStr = campo.Valor?.ToString();

                        if (!string.IsNullOrEmpty(valorStr) && campo.ValoresCombobox != null && campo.ValoresCombobox.Count > 0)
                        {
                            if (campo.ValoresCombobox.Exists(x => x.Codigo == valorStr)) valorCampoCat = valorStr;
                        }

                        campo.Valor = valorCampoCat;
                        campo.ValorAnterior = valorCampoCat;

                        campo.ValoresCombobox = OrdenarCatalogos(campo.OrigenEtiqueta, campo.ValoresCombobox);
                    }
                }
                else if (campo.TipoValor == "LISTA") {

                    Modelo? mod = modelos.Find(x => x.Codigo == campo.TipoDato);

                    if (mod != null)
                    {
                        if (campoModelos.TryGetValue(mod.ModeloId, out List<FormatoDetalleCampo>? camposModelos))
                        {
                            campo.FormatoModeloLista = camposModelos.Select(x =>
                            {
                                FormatoDetalleFormularioDto campoDt = new FormatoDetalleFormularioDto
                                {
                                    AnchoColumna = x.AnchoColumna,
                                    AnchoColumnaFormulario = x.AnchoColumnaFormulario,
                                    AnchoEtiquetaFormulario = x.AnchoEtiquetaFormulario,
                                    CampoAS400 = x.CampoAS400,
                                    CampoId = x.CampoId,
                                    Codigo = x.Codigo,
                                    ComboboxPermiteNinguno = x.ComboboxPermiteNinguno,
                                    DatoSensible = x.DatoSensible,
                                    ValoresDependenciaEditable = !string.IsNullOrEmpty(x.ValoresDependenciaEditable) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaEditable) : null,
                                    ValoresDependenciaFiltro = !string.IsNullOrEmpty(x.ValoresDependenciaFiltro) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaFiltro) : null,
                                    ValoresDependenciaRequerido = !string.IsNullOrEmpty(x.ValoresDependenciaRequerido) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaRequerido) : null,
                                    ValoresDependenciaValidacion = !string.IsNullOrEmpty(x.ValoresDependenciaValidacion) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaValidacion) : null,
                                    ValoresDependenciaValorDefecto = !string.IsNullOrEmpty(x.ValoresDependenciaValorDefecto) ? JsonConvert.DeserializeObject<Dictionary<string, string>>(x.ValoresDependenciaValorDefecto) : null,
                                    ValoresDependenciaVisibilidad = !string.IsNullOrEmpty(x.ValoresDependenciaVisibilidad) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValoresDependenciaVisibilidad) : null,
                                    ValoresCalculo = !string.IsNullOrEmpty(x.ValoresCalculo) ? JsonConvert.DeserializeObject<List<string>>(x.ValoresCalculo) : null,
                                    DependenciaEditable = x.DependenciaEditable,
                                    DependenciaFiltro = x.DependenciaFiltro,
                                    DependenciaRequerido = x.DependenciaRequerido,
                                    DependenciaValidacion = x.DependenciaValidacion,
                                    DependenciaValorDefecto = x.DependenciaValorDefecto,
                                    DependenciaVisibilidad = x.DependenciaVisibilidad,
                                    Editable = x.Editable,
                                    Enmascarar = x.Enmascarar,
                                    EtiquetaDetalle = x.EtiquetaDetalle,
                                    EtiquetaFormulario = x.EtiquetaFormulario,
                                    FormatoDetalleId = x.FormatoDetalleId,
                                    FormatoId = x.FormatoId,
                                    FormularioVisible = x.FormularioVisible,
                                    LongitudMaximaDetalle = x.LongitudMaximaDetalle,
                                    LongitudMinimaDetalle = x.LongitudMinimaDetalle,
                                    ModeloId = x.ModeloId,
                                    NombreCalculo = x.NombreCalculo,
                                    OrdenCampo = x.OrdenCampo,
                                    OrigenCatalogo = x.OrigenCatalogo,
                                    OrigenCombobox = x.OrigenCombobox,
                                    OrigenEtiqueta = x.OrigenEtiqueta,
                                    OrigenValores = x.OrigenValores,
                                    ReglaDependenciaEditable = x.ReglaDependenciaEditable,
                                    ReglaDependenciaFiltro = x.ReglaDependenciaFiltro,
                                    ReglaDependenciaRequerido = x.ReglaDependenciaRequerido,
                                    ReglaDependenciaValidacion = x.ReglaDependenciaValidacion,
                                    ReglaDependenciaValorDefecto = x.ReglaDependenciaValorDefecto,
                                    ReglaDependenciaVisibilidad = x.ReglaDependenciaVisibilidad,
                                    Requerido = x.Requerido,
                                    TipoCalculado = x.TipoCalculado,
                                    TipoCampo = x.TipoCampo,
                                    TipoDato = x.TipoDato,
                                    TipoFiltro = x.TipoFiltro,
                                    TipoValidacion = x.TipoValidacion,
                                    TipoValor = x.TipoValor,
                                    TipoValorDefecto = x.TipoValorDefecto,
                                    ValidacionRegex = x.ValidacionRegex,
                                    ValidacionReglas = !string.IsNullOrEmpty(x.ValidacionReglas) ? JsonConvert.DeserializeObject<Dictionary<string, OperacionDependencia>>(x.ValidacionReglas) : null,
                                    ValidacionRutina = x.ValidacionRutina,
                                    ValidacionRutinaCampos = !string.IsNullOrEmpty(x.ValidacionRutinaCampos) ? JsonConvert.DeserializeObject<List<string>>(x.ValidacionRutinaCampos) : null,
                                    Visible = x.Visible
                                };

                                return campoDt;
                            }).ToList();

                           foreach (FormatoDetalleFormularioDto item in campo.FormatoModeloLista)
                           {                                
                                if (item.OrigenCombobox == "CATALOGO")
                                {
                                    item.ValoresCombobox = new List<ValorCombobox>();

                                    if (!string.IsNullOrEmpty(item.OrigenCatalogo) && catalogos.TryGetValue(item.OrigenCatalogo.Trim(), out List<Catalogo> catValor))
                                    {
                                        if (!string.IsNullOrEmpty(item.TipoFiltro) && item.TipoFiltro.Trim() == Constantes.TipoFiltro.INICIAL)
                                        {
                                            switch (item.ReglaDependenciaFiltro.Trim())
                                            {
                                                case Constantes.ReglaFiltro.VALOR:
                                                    if (item.ValoresDependenciaFiltro.TryGetValue("DEFAULT", out OperacionDependencia operacion))
                                                    {
                                                        item.ValoresCombobox = ObtenerCatalogoFiltrados(operacion, catValor);
                                                    }
                                                    break;
                                            }
                                        }
                                        else
                                        {
                                            item.ValoresCombobox = catValor.Select(x =>
                                            {
                                                return new ValorCombobox
                                                {
                                                    Codigo = x.Codigo.Trim(),
                                                    Descripcion = x.Descripcion.Trim(),
                                                    Complemento = x.Complemento?.Trim()
                                                };
                                            }).ToList();
                                        }
                                        
                                        string valorCampoCat = string.Empty;

                                        string valorStr = item.Valor?.ToString();

                                        if (!string.IsNullOrEmpty(valorStr) && item.ValoresCombobox != null && item.ValoresCombobox.Count > 0)
                                        {
                                            if (item.ValoresCombobox.Exists(x => x.Codigo == valorStr)) valorCampoCat = valorStr;
                                        }

                                        item.Valor = valorCampoCat;
                                        item.ValorAnterior = item.ValorAnterior?.ToString();
                                        item.ValoresCombobox = OrdenarCatalogos(item.OrigenEtiqueta, item.ValoresCombobox);
                                    }                                    
                                }
                                else if (item.OrigenCombobox == "VALORES" || item.OrigenCombobox == "MODELOS")
                                {
                                    if (!string.IsNullOrEmpty(item.OrigenValores))
                                    {
                                        try
                                        {
                                            item.ValoresCombobox = JsonConvert.DeserializeObject<List<ValorCombobox>>(item.OrigenValores);
                                        }
                                        catch (JsonException ex)
                                        {
                                            Log.Error($"FormatoDLL/AsignarValoresCampos: No se puedo deserializar {item.OrigenValores} JsonException -> " + ex.Message);
                                        }
                                    }                                    

                                    string valorCampoCat = string.Empty;

                                    string valorStr = item.Valor?.ToString();

                                    if (!string.IsNullOrEmpty(valorStr) && item.ValoresCombobox != null && item.ValoresCombobox.Count > 0)
                                    {
                                        if (item.ValoresCombobox.Exists(x => x.Codigo == valorStr)) valorCampoCat = valorStr;
                                    }

                                    item.Valor = valorCampoCat;
                                    item.ValorAnterior = item.ValorAnterior?.ToString();
                                    item.ValoresCombobox = OrdenarCatalogos(item.OrigenEtiqueta, item.ValoresCombobox);
                                }
                            }

                            campo.ValoresLista = new List<ValoresModeloDto>();

                            Dictionary<string, string> rutaDictCampos = campo.FormatoModeloLista.ToDictionary(x => x.Codigo, y => y.CampoAS400);

                            if (dictValores!= null && dictValores.TryGetValue(campo.CampoAS400, out dynamic? lista))
                            {
                                if (lista != null)
                                {
                                    Type type = lista.GetType();
                                    if (type.IsGenericType && (type.GetGenericTypeDefinition() == typeof(List<>)))
                                    {
                                        foreach (var item in lista)
                                        {
                                            Dictionary<string, dynamic> valoresCampos = ObjectReflection.GetFieldValuesFromObject(item);

                                            ValoresModeloDto valorItem = new ValoresModeloDto();
                                            List < ValorCampoModeloDto > valoresCamposLista = new List<ValorCampoModeloDto>();

                                            foreach (var camModelo in campo.FormatoModeloLista)
                                            {
                                                ValorCampoModeloDto temp = new ValorCampoModeloDto
                                                {
                                                    Codigo = camModelo.Codigo
                                                };

                                                if (valoresCampos.TryGetValue(camModelo.CampoAS400, out dynamic? valorCampo))
                                                {
                                                    temp.Valor = valorCampo;
                                                }
                                                else
                                                {
                                                    //valor defecto
                                                    string valordefecto = string.Empty;
                                                    if (!string.IsNullOrEmpty(camModelo.TipoValorDefecto) && camModelo.TipoValorDefecto.Trim() == Constantes.TipoValorDefecto.INICIAL)
                                                    {
                                                        switch (camModelo.ReglaDependenciaValorDefecto.Trim())
                                                        {
                                                            case Constantes.ReglaValorDefecto.VALOR:
                                                                if (camModelo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores))
                                                                {
                                                                    valordefecto = valores;
                                                                }
                                                                break;
                                                            case Constantes.ReglaValorDefecto.CONDICIONAL:
                                                                if (!string.IsNullOrEmpty(camModelo.DependenciaValorDefecto))
                                                                {
                                                                    if (rutaDictCampos.TryGetValue(camModelo.DependenciaValorDefecto.Trim(), out string rutaCampo) && valoresCampos.TryGetValue(rutaCampo, out dynamic valorDependencia))
                                                                    {
                                                                        string valorDependenciaStr = valorDependencia.ToString().Trim();
                                                                        if (camModelo.ValoresDependenciaValorDefecto.TryGetValue(valorDependenciaStr, out string valores3))
                                                                        {
                                                                            valordefecto = valores3;
                                                                        }
                                                                        else if (camModelo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores2))
                                                                        {
                                                                            valordefecto = valores2;
                                                                        }
                                                                    }
                                                                    else if (rutaDict.TryGetValue(camModelo.DependenciaValorDefecto.Trim(), out string rutaCampo2) && dictValores.TryGetValue(rutaCampo2, out dynamic valorDependencia2))
                                                                    {
                                                                        string valorDependenciaStr = valorDependencia2.ToString().Trim();
                                                                        if (camModelo.ValoresDependenciaValorDefecto.TryGetValue(valorDependenciaStr, out string valores3))
                                                                        {
                                                                            valordefecto = valores3;
                                                                        }
                                                                        else if (camModelo.ValoresDependenciaValorDefecto.TryGetValue("DEFAULT", out string valores2))
                                                                        {
                                                                            valordefecto = valores2;
                                                                        }
                                                                    }

                                                                }
                                                                break;
                                                        }
                                                    }
                                                    temp.Valor = valordefecto;
                                                }
                                                valoresCamposLista.Add(temp);
                                            }
                                            valorItem.Campos = valoresCamposLista;
                                            campo.ValoresLista.Add(valorItem);                                            
                                        }
                                        campo.ValorAnterior = JsonConvert.SerializeObject(campo.ValoresLista);
                                    }
                                }
                            }
                        }                        
                    }                    
                }
            }
        }

       

        private static  bool CatalogoEsValido(OperacionDependencia operacion, Catalogo catValor)
        {
            string valor = catValor.Codigo;

            bool res = false;
            switch (operacion.Operacion)
            {
                case Constantes.Operaciones.NONE:
                    res = true;
                    break;
                case Constantes.Operaciones.NOT_IN:
                    res = !operacion.Valores.Contains(valor);
                    break;
                case Constantes.Operaciones.IN:
                    res = operacion.Valores.Contains(valor);
                    break;
                case Constantes.Operaciones.STARTS_WITH:
                    operacion.Valores.ForEach(x => {
                        if (valor.Length >= x.Length && valor.Substring(0, x.Length) == x) res = true;
                    });
                    break;
                case Constantes.Operaciones.ENDS_WITH:
                    operacion.Valores.ForEach(x => {
                        if (valor.Length >= x.Length && valor.Substring(valor.Length - x.Length, valor.Length) == x) res = true;
                    });
                    break;
                case Constantes.Operaciones.CONTAINS:
                    operacion.Valores.ForEach(x => {
                        string val = valor.Replace(x, "");
                        if (val.Length == valor.Length) res = true;
                    });
                    break;
            }

            return res;
        }

        private static List<ValorCombobox> ObtenerCatalogoFiltrados(OperacionDependencia operacion, List<Catalogo> catValor)
        {
            List<ValorCombobox> resultado = new List<ValorCombobox>();

            foreach (var item in catValor)
            {
                if (CatalogoEsValido(operacion, item)) {
                    resultado.Add(new ValorCombobox
                    {
                        Codigo = item.Codigo.Trim(),
                        Descripcion = item.Descripcion.Trim(),
                        Complemento = item.Complemento?.Trim()
                    });
                }
            }

            return resultado;
        }


        private static List<ValorCombobox> OrdenarCatalogos(string tipoEtiqueta, List<ValorCombobox> valores)
        {
            if (valores == null || valores.Count == 0) return  new List<ValorCombobox>();

            if (tipoEtiqueta?.Trim() == "CODETIQUETA" || tipoEtiqueta?.Trim() == "CODIGO")
            {
                return valores.OrderBy(x => x.Codigo).ToList();
            }
            else if (tipoEtiqueta?.Trim() == "COMPLEMENTO")
            {
                return valores.OrderBy(x => x.Complemento).ToList();
            }

            return valores;
        }

        public class ValorNombresCat
        { 
            public dynamic Valor { get; set; }
            public List<ValorCombobox> Catalogo { get; set; }
        }




    }
}
