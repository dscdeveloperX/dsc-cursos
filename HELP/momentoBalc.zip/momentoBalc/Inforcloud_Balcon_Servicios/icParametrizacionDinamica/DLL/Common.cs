﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;

namespace icParametrizacionDinamica.DLL {
    public class Common {
        #region deserializa objetos y devuelve los atributos seteados en una clase Dictionary
        public Dictionary<string, dynamic> DeserializaObj(object content) {
            Dictionary<string, dynamic> Respuesta = new();
            DeserializaObj(content, ref Respuesta);
            return Respuesta;
        }
        public Dictionary<string, dynamic> DeserializaObj(List<object> content) {
            Dictionary<string, dynamic> Respuesta = new();
            foreach (object obj in content) {
                DeserializaObj(obj, ref Respuesta);
            }
            return Respuesta;
        }
        public void DeserializaObj(object content, ref Dictionary<string, dynamic> Respuesta) {
            //Dictionary<string, dynamic> Respuesta = new Dictionary<string, dynamic>();
            Type t = content.GetType();
            PropertyInfo[] properties = t.GetProperties();
            foreach (PropertyInfo property in properties) {
                //así obtenemos el nombre del atributo
                string NombreAtributo = property.Name;
                //así obtenemos el valor del atributo
                dynamic Valor = (dynamic)property.GetValue(content);
                Respuesta.Add(NombreAtributo, Valor);
            }
        }
        #endregion

        public string convertirDecimalString(decimal val) {
            return convertirDecimalString(val.ToString());
        }        
        public string convertirDecimalString(string val) {
            int valINT = val.IndexOf(".");
            if (valINT < 1) valINT = val.IndexOf(",");
            if (valINT < 1) return val;
            string resp = val.Substring(0,valINT);
            return resp;
        }

        public decimal StringDecimal(string val) {
            int valINT = (val.IndexOf(".") > 0) ? 1 : 0;
            if (valINT == 0) valINT = (val.IndexOf(",") > 0) ? 2 : 0;
            CultureInfo[] cultures = { new CultureInfo("en-US"), new CultureInfo("fr-FR") };
            return (valINT == 0) ? Convert.ToDecimal(val) : Convert.ToDecimal(val, cultures[valINT - 1]);
        }

        public byte[] ToByteArray(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using MemoryStream ms = new();
            int read;
            while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                ms.Write(buffer, 0, read);
            }
            return ms.ToArray();
        }
    }
}
