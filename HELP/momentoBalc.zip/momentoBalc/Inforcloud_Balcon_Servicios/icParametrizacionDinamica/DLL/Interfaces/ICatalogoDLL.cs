﻿using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Catalogos;
using icParametrizacionDinamica.DTOs.DB.Response.Catalogos;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DLL.Interfaces
{
    public interface ICatalogoDLL
    {
        Catalogo ObtenerCatalogoPorId(HeaderRequest request, ConsultaCatalogoRequestBody body);
        QueryCatalogosResponse ListarCatalogos(HeaderRequest header, ListaCatalogosRequestBody body);
        QueryNombreCatalogosResponse ListarNombresCatalogos(HeaderRequest header, ListaNombreCatalogosRequestBody dbParam);
        QueryCodigoCatalogosResponse ListarCodigoCatalogos(HeaderRequest header, ListaCodigoCatalogosRequestBody dbParam);
        long CrearCatalogo(HeaderRequest header, CreacionCatalogoRequestBody CatalogueCreateList);
        int EliminarCatalogos(HeaderRequest request, EliminacionCatalogoRequestBody body);
        int ActualizarCatalogo(HeaderRequest header, EdicionCatalogoRequestBody param);
    }
}
