﻿using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Modelos;
using icParametrizacionDinamica.DTOs.DB.Response.Modelos;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DLL.Interfaces
{
    public interface IModeloDLL
    {
        ModeloDto ObtenerModeloPorId(HeaderRequest request, ConsultaModeloRequestBody body);
        QueryModelosResponse ListarModelos(HeaderRequest header, ListaModelosRequestBody body);
        long CrearModelo(HeaderRequest header, CreacionModeloRequestBody CatalogueCreateList);
        int EliminarModelos(HeaderRequest request, EliminacionModeloRequestBody body);
        int ActualizarModelo(HeaderRequest header, EdicionModeloRequestBody param);
        QueryCamposResponse ObtenerListaCamposPorModeloId(HeaderRequest request, ConsultaModeloRequestBody body);
    }
}
