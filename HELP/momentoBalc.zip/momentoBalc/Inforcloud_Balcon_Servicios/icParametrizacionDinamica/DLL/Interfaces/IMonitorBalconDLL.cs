﻿using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.EXT;

namespace icParametrizacionDinamica.DLL.Interfaces
{
    public interface IMonitorBalconDLL
    {
        long CrearMonitorBalcon(HeaderRequest header, MonitorBalconRequestBody MonitorBalconCreateList);
    }
}
