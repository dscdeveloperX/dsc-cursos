﻿using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DLL.Interfaces
{
    public interface ICorreoDLL
    {
        Correo ObtenerCorreoPorCodigo(string codigo);
    }
}
