﻿using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.DB.Response.Formatos;
using icParametrizacionDinamica.DTOs.EXT.Response;
using icParametrizacionDinamica.Models;

namespace icParametrizacionDinamica.DLL.Interfaces
{
    public interface IFormatoDLL
    {
        FormatoDto ObtenerFormatoPorId(HeaderRequest request, ConsultaFormatoRequestBody body);
        QueryFormatosResponse ListarFormatos(HeaderRequest header, ListaFormatosRequestBody body);
        long CrearFormato(HeaderRequest header, CreacionFormatoRequestBody CatalogueCreateList);
        int EliminarFormatos(HeaderRequest request, EliminacionFormatoRequestBody body);
        int ActualizarFormato(HeaderRequest header, EdicionFormatoRequestBody param);
        CamposFormatoDto ObtenerCamposFormato(HeaderRequest request, ObtenerCamposFormatoRequestBody body);
        //BALCON
        FormatoClienteDto ObtenerFormulario(HeaderRequest request, ObtenerFormularioRequestBody body, object datos);
    }
}
