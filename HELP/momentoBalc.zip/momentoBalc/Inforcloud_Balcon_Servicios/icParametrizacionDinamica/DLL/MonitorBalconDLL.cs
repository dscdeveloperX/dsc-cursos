﻿using Dapper;
using icCommon.DB;
using icCommon.DTOs.DB;
using icCommon.Utils;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Formatos;
using icParametrizacionDinamica.DTOs.DB.Response.Formatos;
using icParametrizacionDinamica.DTOs.DB.Response.Modelos;
using icParametrizacionDinamica.DTOs.EXT;
using icParametrizacionDinamica.DTOs.EXT.Response;
using icParametrizacionDinamica.Models;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace icParametrizacionDinamica.DLL
{
    public class MonitorBalconDLL : IMonitorBalconDLL
    {
        private readonly IProveedorConexion _config;

        private readonly string SCHEMA = "";

        public MonitorBalconDLL(IProveedorConexion proveedor)
        {
            _config = proveedor;
            SCHEMA = _config.ObtenerSchema();
        }

        public long CrearMonitorBalcon(HeaderRequest header, MonitorBalconRequestBody body)
        {
            DynamicParameters dbPara = new DynamicParameters();
            dbPara.Add("CodPrd", body.CodigoProceso, DbType.String);
            dbPara.Add("Fecha", body.fecha, DbType.Date);
            dbPara.Add("Hora", body.Hora, DbType.Time);
            dbPara.Add("CodEve", body.CodigoEvento, DbType.String);
            dbPara.Add("TipDoc", body.TipoIdentificacion, DbType.String);
            dbPara.Add("DocCli", body.Identificacion, DbType.String);
            dbPara.Add("Cuenta", body.Cuenta, DbType.String);
            dbPara.Add("CodOfiLogin", body.Oficial, DbType.String);
            dbPara.Add("AgeOfiLogin", body.Agencia, DbType.String);
            dbPara.Add("Ip", header.StationIp, DbType.String);
            dbPara.Add("Referencia", body.Referencia, DbType.String);
            dbPara.Add("NumComp", body.Contrato, DbType.String);
            dbPara.Add("Canal", body.Canal, DbType.String);
            dbPara.Add("TarjCred", body.TarjetaCredito, DbType.String);
            dbPara.Add("TipPrd", body.TipoProducto, DbType.String);
            dbPara.Add("Produ", body.Producto, DbType.String);
            dbPara.Add("SubPrd", body.SubProducto, DbType.String);
            dbPara.Add("ValTran1", body.ValorTransaccion1, DbType.Decimal);
            dbPara.Add("ValTran2", body.ValorTransaccion2, DbType.Decimal);
            dbPara.Add("ValTran3", body.ValorTransaccion3, DbType.Decimal);
            dbPara.Add("Fecha1", header.DateTime, DbType.DateTime);
            dbPara.Add("Fecha2", header.DateTime, DbType.DateTime);
            dbPara.Add("Fecha3", header.DateTime, DbType.DateTime);
            dbPara.Add("Trama", body.Trama, DbType.String);
            dbPara.Add("TramaJson", body.TramaJSON, DbType.String);
            dbPara.Add("FecReg", header.DateTime, DbType.DateTime);
            dbPara.Add("UsrReg", header.UserName, DbType.String);
            dbPara.Add("IpReg", header.StationIp, DbType.String);

            string insertSQL = $"INSERT INTO [{SCHEMA}].[MonitorBalcon](CodPrd,Fecha,Hora,CodEve,TipDoc,DocCli,Cuenta,CodOfiLogin,AgeOfiLogin,Ip,Referencia,NumComp,Canal,TarjCred,TipPrd,Produ,SubPrd,ValTran1,ValTran2,ValTran3,Fecha1,Fecha2,Fecha3,Trama,TramaJson,FecReg,UsrReg,IpReg) " +
                        $"VALUES(@CodPrd,@Fecha,@Hora,@CodEve,@TipDoc,@DocCli,@Cuenta,@CodOfiLogin,@AgeOfiLogin,@Ip,@Referencia,@NumComp,@Canal,@TarjCred,@TipPrd,@Produ,@SubPrd,@ValTran1,@ValTran2,@ValTran3,@Fecha1,@Fecha2,@Fecha3,@Trama,@TramaJson,@FecReg,@UsrReg,@IpReg);" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";


            using (IDbConnection db = _config.ObtenerConexion())
            {


                //List<int> camposIds = new List<int>();

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = db.Query<long>(insertSQL, dbPara, tran, commandType: CommandType.Text).First();
                        

                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("MonitorBalconDLL/CrearMonitorBalcon: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }
    }
}
