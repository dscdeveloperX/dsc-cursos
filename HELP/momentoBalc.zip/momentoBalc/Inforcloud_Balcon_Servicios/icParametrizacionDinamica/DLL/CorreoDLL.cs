﻿using Dapper;
using icCommon.DB;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.Models;
using Serilog;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace icParametrizacionDinamica.DLL
{
    public class CorreoDLL : ICorreoDLL
    {
        private readonly IProveedorConexion _config;

        private readonly string SCHEMA = "";

        public CorreoDLL(IProveedorConexion proveedor)
        {
            _config = proveedor;
            SCHEMA = _config.ObtenerSchema();
        }
        public Correo ObtenerCorreoPorCodigo(string codigo)
        {
            #region user dynamic parameter
            var dbPara = new DynamicParameters();
            dbPara.Add("Codigo", codigo, DbType.String);
            #endregion

            string sql = $"SELECT * FROM [{SCHEMA}].[Correo] WHERE Codigo = @Codigo ";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    Correo result = db.Query<Correo>(sql, param: dbPara, commandType: CommandType.Text).FirstOrDefault();
                    return result;
                }
                catch (SqlException sqlException)
                {
                    Log.Error("CorreoDLL/ObtenerCorreoPorCodigo: Transaccion SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }
    }
}
