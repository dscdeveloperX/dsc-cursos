﻿using Dapper;
using icCommon.DB;
using icCommon.Utils;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.DTOs.API.Request;
using icParametrizacionDinamica.DTOs.API.Request.Modelos;
using icParametrizacionDinamica.DTOs.DB.Response.Modelos;
using icParametrizacionDinamica.Models;
using Microsoft.AspNetCore.Authentication.OAuth.Claims;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using static icParametrizacionDinamica.Constantes;

namespace icParametrizacionDinamica.DLL
{
    public class ModeloDLL : IModeloDLL
    {
        private readonly IProveedorConexion _config;
                
        private readonly string SCHEMA = "";

        //dsc: fecha registro auditoria (una sola fecha para todo el grupo de operaciones que se ejecutan de un solo golpe)
        private readonly string fechaHoraAuditoria = string.Empty;

        public ModeloDLL(IProveedorConexion proveedor)
        {
            _config = proveedor;
            SCHEMA = _config.ObtenerSchema();
            fechaHoraAuditoria = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public int ActualizarModelo(HeaderRequest header, EdicionModeloRequestBody body)
        {
            DynamicParameters dbPara = new DynamicParameters();
            dbPara.Add("ModeloId", body.Modelo.ModeloId, DbType.Int64);
            dbPara.Add("Descripcion", body.Modelo.Descripcion, DbType.String);
            dbPara.Add("Codigo", body.Modelo.Codigo, DbType.String);
            dbPara.Add("Nombre", body.Modelo.Nombre, DbType.String);
            dbPara.Add("TipoModelo", body.Modelo.TipoModelo, DbType.String);
            dbPara.Add("Estado", body.Modelo.Estado, DbType.String);

            

            using (IDbConnection db = _config.ObtenerConexion())
            {
                string updateSQL = $"UPDATE [{SCHEMA}].[Modelo] SET Descripcion=@Descripcion,Codigo=@Codigo,Nombre=@Nombre,TipoModelo=@TipoModelo,Estado=@Estado where ModeloId=@ModeloId;" +
                        $"SELECT @@ROWCOUNT; ";

                
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = new List<int>() {0} as IEnumerable<int>;

                        var eliminar = db.Query<long>($"SELECT CampoId FROM [{SCHEMA}].[Campo] WHERE ModeloId=@ModeloId", dbPara, tran, commandType: CommandType.Text).ToList();


                        //dsc: auditoria modelo update
                        string auditoriaUpdateModeloJson = @"SELECT '{""ModeloId"":' + CONVERT(NVARCHAR, ISNULL(ModeloId, 0)) + ',""Codigo"":' + CONVERT(NVARCHAR, ISNULL(Codigo, 'null')) + ',""Nombre"":""' + CONVERT(NVARCHAR, ISNULL(Nombre, 'null')) + '"",""Descripcion"":""' + CONVERT(NVARCHAR, ISNULL(Descripcion,'null')) + '"",""TipoModelo"":""' + CONVERT(NVARCHAR, ISNULL(TipoModelo,'null')) + '"",""Estado"":""' + CONVERT(NVARCHAR, ISNULL(Estado,'null'))  '}' FROM Modelo WHERE ModeloId = @ModeloId;";
                        
                        string auditoriaInsertModeloSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                          $" VALUES ('Modelo', @ModeloId, 'UPDATE', '{header.UserName}', '{header.StationIp}', '@@ValorAnterior' ,'@@ValorNuevo', '{fechaHoraAuditoria}');";
                        //json anterior
                        var jsonAnterior = db.Query<string>(auditoriaUpdateModeloJson, dbPara, tran, commandType: CommandType.Text).FirstOrDefault();
                        if (jsonAnterior != null)
                        {
                            //actualizar modelo
                            result = db.Query<int>(updateSQL, dbPara, tran, commandType: CommandType.Text);
                            
                            if (result.ToList().First<int>() > 0)
                            {
                                //json actual
                                var jsonNuevo = db.Query<string>(auditoriaUpdateModeloJson, dbPara, tran, commandType: CommandType.Text).FirstOrDefault();
                                if (jsonNuevo != null && jsonAnterior != jsonNuevo)
                                {
                                    //auditoria modelo actualizado
                                    string auditoriaSQL = auditoriaInsertModeloSql.Replace("@@ValorAnterior", jsonAnterior).Replace("@@ValorNuevo", jsonNuevo);
                                    db.Execute(auditoriaSQL, dbPara, tran, commandType: CommandType.Text);
                                }
                            }
                        }

 


                        if (body.Modelo.Secciones != null && body.Modelo.Secciones.Count > 0)
                        {
                            List<Campo> campos = ObtenerCamposDeSecciones(body.Modelo.Secciones);

                            List<Campo> crear = campos.FindAll(x => x.CampoId == 0);
                            List<Campo> update = campos.FindAll(x => x.CampoId != 0);

                            List<long> updateIds = campos.FindAll(x => x.CampoId != 0).Select(x => x.CampoId).ToList();
                            eliminar.RemoveAll(x => updateIds.Contains(x));

                            if (eliminar.Count > 0)
                            {
                                string eliminarIds = string.Join(",", eliminar);

                                //dsc: auditoria formatoDetale eliminados
                                string auditoriaSelectFormatoDetalleSql = $"SELECT FormatoDetalleId,FormatoId,CampoId,Etiqueta,LongitudMinima,LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido,DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable,ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex,ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro,TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario,AnchoEtiquetaFormulario " +
                                                                          $"FROM [{SCHEMA}].[FormatoDetalle] WHERE CampoId IN ({eliminarIds});";

                                var listaFormatoDetalleEliminados = db.Query(auditoriaSelectFormatoDetalleSql, null, tran, commandType: CommandType.Text);
                                
                                string auditoriaSelectCamposSql = $"SELECT CampoId,ModeloId,TipoValor,Etiqueta,Codigo,TipoCampo,TipoDato,TipoCalculado,NombreCalculo,ValoresCalculo,LongitudMinima,LongitudMaxima,OrdenSeccion,Seccion,OrdenSubseccion,Subseccion,OrdenCampo,OrigenCombobox,OrigenEtiqueta,OrigenValores,OrigenCatalogo,CampoAS400,Obligatorio,PermiteEnmascaramiento,DatoSensible " +
                                                                  $"FROM [{SCHEMA}].[Campo] WHERE CampoId in ({eliminarIds});";
                                
                                var listaCamposEliminados = db.Query(auditoriaSelectCamposSql, null, tran, commandType: CommandType.Text);
                                //dsc:fin


                                string eliminarCamposSQL = $"DELETE FROM [{SCHEMA}].[FormatoDetalle] WHERE CampoId in ({eliminarIds});" +
                                    $" DELETE FROM [{SCHEMA}].[Campo] WHERE CampoId in ({eliminarIds});";

                                db.Execute(eliminarCamposSQL,transaction: tran, commandType: CommandType.Text);




                                //dsc: auditoria formatodetalles eliminados
                                foreach (var item in listaFormatoDetalleEliminados)
                                {
                                    string auditoriaDeleteCampoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                     $" VALUES ('FormatoDetalle', {item.FormatoDetalleId}, 'DELETE', '{header.UserName}', '{header.StationIp}', '{UtilGeneral.SerializedNeutralizedJson(item)}', '', '{fechaHoraAuditoria}');";
                                    db.Execute(auditoriaDeleteCampoSql, null, tran, commandType: CommandType.Text);
                                }


                                //dsc: auditoria campos eliminados
                                foreach (var item in listaCamposEliminados)
                                {
                                    string auditoriaUpdateCampoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                     $" VALUES ('Campo', {item.CampoId}, 'DELETE', '{header.UserName}', '{header.StationIp}', '{UtilGeneral.SerializedNeutralizedJson(item)}', '','{fechaHoraAuditoria}');";
                                    db.Execute(auditoriaUpdateCampoSql, null, tran, commandType: CommandType.Text);
                                }




                            }

                            if (crear.Count > 0) {//crea cuando existe formato relacionado

                                
                                string insertCamposSQL =$"INSERT INTO [{SCHEMA}].[Campo](ModeloId,TipoValor,Etiqueta,Codigo,TipoCampo,TipoDato,NombreCalculo," +
                                $"TipoCalculado,LongitudMinima,LongitudMaxima,OrdenSeccion,Seccion,OrdenSubseccion,Subseccion,OrdenCampo,OrigenCombobox,OrigenEtiqueta," +
                                $"OrigenValores,OrigenCatalogo,CampoAS400,Obligatorio,PermiteEnmascaramiento,DatoSensible,ValoresCalculo) " +
                                $"VALUES(@ModeloId,@TipoValor,@Etiqueta,@Codigo,@TipoCampo,@TipoDato,@NombreCalculo," +
                                $"@TipoCalculado,@LongitudMinima,@LongitudMaxima,@OrdenSeccion,@Seccion,@OrdenSubseccion,@Subseccion,@OrdenCampo,@OrigenCombobox,@OrigenEtiqueta," +
                                $"@OrigenValores,@OrigenCatalogo,@CampoAS400,@Obligatorio,@PermiteEnmascaramiento,@DatoSensible,@ValoresCalculo);" +
                                $"SET @CampoId = (SELECT CAST(SCOPE_IDENTITY() as int));";

                                

                                //dsc: auditoria insertar campo
                                string auditoriaInsertCampoJson = @"(SELECT '{""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ',""ModeloId"":' + CONVERT(NVARCHAR, ISNULL(ModeloId, 0)) + ',""TipoValor"":""' + CONVERT(NVARCHAR, ISNULL(TipoValor, 'null')) + '"",""Etiqueta"":""' + CONVERT(NVARCHAR, ISNULL(Etiqueta,'null')) + '"",""Codigo"":""' + CONVERT(NVARCHAR, ISNULL(Codigo,'null')) + '"",""TipoCampo"":""' + CONVERT(NVARCHAR, ISNULL(TipoCampo,'null')) + '"",""TipoDato"":""' + CONVERT(NVARCHAR, ISNULL(TipoDato,'null')) + '"",""TipoCalculado"":' + CONVERT(NVARCHAR, ISNULL(TipoCalculado,'null')) + ',""NombreCalculo"":' + CONVERT(NVARCHAR, ISNULL(NombreCalculo,'null')) + ',""ValoresCalculo"":' + CONVERT(NVARCHAR, ISNULL(ValoresCalculo,'null')) + ',""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima,0)) + ',""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima,0)) + ',""OrdenSeccion"":' + CONVERT(NVARCHAR, ISNULL(OrdenSeccion,0)) + ',""Seccion"":""' + CONVERT(NVARCHAR, ISNULL(Seccion,'null')) + '"",""OrdenSubseccion"":' + CONVERT(NVARCHAR, ISNULL(OrdenSubseccion,0)) + ',""Subseccion"":""' + CONVERT(NVARCHAR, ISNULL(Subseccion,'null')) + '"",""OrdenCampo"":' + CONVERT(NVARCHAR, ISNULL(OrdenCampo,0)) + ',""OrigenCombobox"":' + CONVERT(NVARCHAR, ISNULL(OrigenCombobox,'null')) + ',""OrigenEtiqueta"":' + CONVERT(NVARCHAR, ISNULL(OrigenEtiqueta,'null')) + ',""OrigenValores"":' + CONVERT(NVARCHAR, ISNULL(OrigenValores,'null')) + ',""OrigenCatalogo"":' + CONVERT(NVARCHAR, ISNULL(OrigenCatalogo,'null')) + ',""CampoAS400"":""' + CONVERT(NVARCHAR, ISNULL(CampoAS400,'null')) + '"",""Obligatorio"":' + CONVERT(NVARCHAR, ISNULL(Obligatorio,0)) + ',""PermiteEnmascaramiento"":' + CONVERT(NVARCHAR, ISNULL(PermiteEnmascaramiento,0)) + ',""DatoSensible"":' + CONVERT(NVARCHAR, ISNULL(DatoSensible,0)) + '}' from Campo where CampoId = @CampoId)";

                                string auditoriaInsertCampoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                              $" VALUES ('Campo', @CampoId, 'INSERT', '{header.UserName}', '{header.StationIp}', '' ,{auditoriaInsertCampoJson}, '{fechaHoraAuditoria}');";

                                //dsc: auditoria insertar formato
                                string auditoriaInsertFormatoDetalleJson = @"(SELECT '{""FormatoDetalleId"":' + CONVERT(NVARCHAR, ISNULL(FormatoDetalleId, 0)) + ', ""FormatoId"":' + CONVERT(NVARCHAR, ISNULL(FormatoId, 0)) + ', ""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ', ""Etiqueta"":' + CONVERT(NVARCHAR, ISNULL(Etiqueta, 'null')) + ', ""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima, 0)) + ', ""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima, 0)) + ', ""Enmascarar"":' + CONVERT(NVARCHAR, ISNULL(Enmascarar, 0)) + ', ""Visible"":' + CONVERT(NVARCHAR, ISNULL(Visible, 0)) + ', ""DependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(DependenciaVisibilidad, 'null')) + ', ""ReglaDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaVisibilidad, 'null')) + ', ""ValoresDependenciaVisibilidad"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaVisibilidad, 'null')) + ', ""Requerido"":' + CONVERT(NVARCHAR, ISNULL(Requerido, 0)) + ', ""DependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(DependenciaRequerido, 'null')) + ', ""ReglaDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaRequerido, 'null')) + ', ""ValoresDependenciaRequerido"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaRequerido, 'null')) + ', ""Editable"":' + CONVERT(NVARCHAR, ISNULL(Editable, 0)) + ', ""DependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(DependenciaEditable, 'null')) + ', ""ReglaDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaEditable, 'null')) + ', ""ValoresDependenciaEditable"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaEditable, 'null')) + ', ""TipoValidacion"":' + CONVERT(NVARCHAR, ISNULL(TipoValidacion, 'null')) + ', ""DependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValidacion, 'null')) + ', ""ReglaDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValidacion, 'null')) + ', ""ValoresDependenciaValidacion"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValidacion, 'null')) + ', ""ValidacionRegex"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRegex, 'null')) + ', ""ValidacionReglas"":' + CONVERT(NVARCHAR, ISNULL(ValidacionReglas, 'null')) + ', ""ValidacionRutina"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutina, 'null')) + ', ""ValidacionRutinaCampos"":' + CONVERT(NVARCHAR, ISNULL(ValidacionRutinaCampos, 'null')) + ', ""ComboboxPermiteNinguno"":' + CONVERT(NVARCHAR, ISNULL(ComboboxPermiteNinguno, 0)) + ', ""TipoFiltro"":' + CONVERT(NVARCHAR, ISNULL(TipoFiltro, 'null')) + ', ""DependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(DependenciaFiltro, 'null')) + ', ""ReglaDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaFiltro, 'null')) + ', ""ValoresDependenciaFiltro"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaFiltro, 'null')) + ', ""TipoValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(TipoValorDefecto, 'null')) + ', ""DependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(DependenciaValorDefecto, 'null')) + ', ""ReglaDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ReglaDependenciaValorDefecto, 'null')) + ', ""ValoresDependenciaValorDefecto"":' + CONVERT(NVARCHAR, ISNULL(ValoresDependenciaValorDefecto, 'null')) + ', ""AnchoColumna"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumna, 'null')) + ', ""FormularioVisible"":' + CONVERT(NVARCHAR, ISNULL(FormularioVisible, 0)) + ', ""EtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(EtiquetaFormulario, 'null')) + ', ""AnchoColumnaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoColumnaFormulario, 'null')) + ', ""AnchoEtiquetaFormulario"":' + CONVERT(NVARCHAR, ISNULL(AnchoEtiquetaFormulario, 'null')) + '}' from FormatoDetalle where FormatoDetalleId = @FormatoDetalleId)";

                                string auditoriaInsertFormatoDetalleSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                              $" VALUES ('FormatoDetalle', @FormatoDetalleId, 'INSERT', '{header.UserName}', '{header.StationIp}', '' ,{auditoriaInsertFormatoDetalleJson}, '{fechaHoraAuditoria}');";


                                var formatosIds = db.Query<long>($"SELECT distinct f.FormatoId FROM [Formato] f INNER JOIN FormatoDetalle fd on f.FormatoId = fd.FormatoId" +
                                                                $" WHERE ProductoId = @ModeloId or PersonaId = @ModeloId or fd.CampoId = (SELECT CampoId FROM Campo WHERE TipoValor = 'LISTA'" +
                                                                $" and TipoDato = (SELECT Codigo from Modelo where ModeloId = @ModeloId))", dbPara, tran, commandType: CommandType.Text)?.ToList();

                                if (formatosIds != null && formatosIds.Count > 0) {
                                    foreach (var formatId in formatosIds)
                                    {
                                        //dsc: agrega formato 
                                        insertCamposSQL += $"INSERT INTO [{SCHEMA}].[FormatoDetalle](FormatoId,CampoId,Etiqueta,LongitudMinima," +
                                       $"LongitudMaxima,Enmascarar,Visible,DependenciaVisibilidad,ReglaDependenciaVisibilidad,ValoresDependenciaVisibilidad,Requerido," +
                                       $"DependenciaRequerido,ReglaDependenciaRequerido,ValoresDependenciaRequerido,Editable,DependenciaEditable,ReglaDependenciaEditable," +
                                       $"ValoresDependenciaEditable,TipoValidacion,DependenciaValidacion,ReglaDependenciaValidacion,ValoresDependenciaValidacion,ValidacionRegex," +
                                       $"ValidacionReglas,ValidacionRutina,ValidacionRutinaCampos,AnchoColumna,FormularioVisible,EtiquetaFormulario,AnchoColumnaFormulario," +
                                       $"AnchoEtiquetaFormulario,ComboboxPermiteNinguno,TipoFiltro,DependenciaFiltro,ReglaDependenciaFiltro,ValoresDependenciaFiltro," +
                                       $"TipoValorDefecto,DependenciaValorDefecto,ReglaDependenciaValorDefecto,ValoresDependenciaValorDefecto) " +
                                       $"VALUES({formatId},@CampoId,@Etiqueta,@LongitudMinima,@LongitudMaxima,0,0,null," +
                                       $"null,null,0,null,null," +
                                       $"null,0,null,null,null,null," +
                                       $"null,null,null,null,null,null," +
                                       $"null,'6',0,null,null,null," +
                                       $"null,null,null,null,null,null," +
                                       $"null,null,null);" +
                                       $"DECLARE @FormatoDetalleId int = (SELECT CAST(SCOPE_IDENTITY() as int));" +
                                       auditoriaInsertFormatoDetalleSql;

                                    }
                                }
                                //dsc: agrega campo 
                                insertCamposSQL += auditoriaInsertCampoSql;
                                db.Execute(insertCamposSQL, crear, tran, commandType: CommandType.Text);
                            }

                            if (update.Count > 0)//DELETE O INSERT de modelo se vuelve a UPDATE
                            {
                                
                                string auditoriaInsertCampoJson = @"SELECT '{""CampoId"":' + CONVERT(NVARCHAR, ISNULL(CampoId, 0)) + ',""ModeloId"":' + CONVERT(NVARCHAR, ISNULL(ModeloId, 0)) + ',""TipoValor"":""' + CONVERT(NVARCHAR, ISNULL(TipoValor, 'null')) + '"",""Etiqueta"":""' + CONVERT(NVARCHAR, ISNULL(Etiqueta,'null')) + '"",""Codigo"":""' + CONVERT(NVARCHAR, ISNULL(Codigo,'null')) + '"",""TipoCampo"":""' + CONVERT(NVARCHAR, ISNULL(TipoCampo,'null')) + '"",""TipoDato"":""' + CONVERT(NVARCHAR, ISNULL(TipoDato,'null')) + '"",""TipoCalculado"":' + CONVERT(NVARCHAR, ISNULL(TipoCalculado,'null')) + ',""NombreCalculo"":' + CONVERT(NVARCHAR, ISNULL(NombreCalculo,'null')) + ',""ValoresCalculo"":' + CONVERT(NVARCHAR, ISNULL(ValoresCalculo,'null')) + ',""LongitudMinima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMinima,0)) + ',""LongitudMaxima"":' + CONVERT(NVARCHAR, ISNULL(LongitudMaxima,0)) + ',""OrdenSeccion"":' + CONVERT(NVARCHAR, ISNULL(OrdenSeccion,0)) + ',""Seccion"":""' + CONVERT(NVARCHAR, ISNULL(Seccion,'null')) + '"",""OrdenSubseccion"":' + CONVERT(NVARCHAR, ISNULL(OrdenSubseccion,0)) + ',""Subseccion"":""' + CONVERT(NVARCHAR, ISNULL(Subseccion,'null')) + '"",""OrdenCampo"":' + CONVERT(NVARCHAR, ISNULL(OrdenCampo,0)) + ',""OrigenCombobox"":' + CONVERT(NVARCHAR, ISNULL(OrigenCombobox,'null')) + ',""OrigenEtiqueta"":' + CONVERT(NVARCHAR, ISNULL(OrigenEtiqueta,'null')) + ',""OrigenValores"":' + CONVERT(NVARCHAR, ISNULL(OrigenValores,'null')) + ',""OrigenCatalogo"":' + CONVERT(NVARCHAR, ISNULL(OrigenCatalogo,'null')) + ',""CampoAS400"":""' + CONVERT(NVARCHAR, ISNULL(CampoAS400,'null')) + '"",""Obligatorio"":' + CONVERT(NVARCHAR, ISNULL(Obligatorio,0)) + ',""PermiteEnmascaramiento"":' + CONVERT(NVARCHAR, ISNULL(PermiteEnmascaramiento,0)) + ',""DatoSensible"":' + CONVERT(NVARCHAR, ISNULL(DatoSensible,0)) + '}' from Campo where CampoId = @CampoId;";

                                string updateCamposSQL =$"UPDATE [{SCHEMA}].[Campo] SET " +
                                $"ModeloId=@ModeloId,TipoValor=@TipoValor,Etiqueta=@Etiqueta,Codigo=@Codigo,TipoCampo=@TipoCampo,TipoDato=@TipoDato,NombreCalculo=@NombreCalculo," +
                                $"TipoCalculado=@TipoCalculado,LongitudMinima=@LongitudMinima,LongitudMaxima=@LongitudMaxima,OrdenSeccion=@OrdenSeccion,Seccion=@Seccion,OrdenSubseccion=@OrdenSubseccion," +
                                $"Subseccion=@Subseccion,OrdenCampo=@OrdenCampo,OrigenCombobox=@OrigenCombobox,OrigenEtiqueta=@OrigenEtiqueta," +
                                $"OrigenValores=@OrigenValores,OrigenCatalogo=@OrigenCatalogo,CampoAS400=@CampoAS400,Obligatorio=@Obligatorio,PermiteEnmascaramiento=@PermiteEnmascaramiento,DatoSensible=@DatoSensible, ValoresCalculo=@ValoresCalculo " +
                                $"WHERE CampoId = @CampoId; SELECT @@ROWCOUNT;";
                                
                                string auditoriaInsertCampoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                 $" VALUES ('Campo', @CampoId, 'UPDATE', '{header.UserName}', '{header.StationIp}', '@@ValorAnterior' ,'@@ValorNuevo', '{fechaHoraAuditoria}');";

                                foreach (Campo item in update){

                                        //json anterio
                                        var jsonAnterior1 = db.Query<string>(auditoriaInsertCampoJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                    if (jsonAnterior1 != null) {
                                            var result1 = db.Query<int>(updateCamposSQL, item, tran, commandType: CommandType.Text);
                                            if (result1.ToList().First<int>() > 0)
                                            {
                                                //json actual
                                                var jsonNuevo1 = db.Query<string>(auditoriaInsertCampoJson, item, tran, commandType: CommandType.Text).FirstOrDefault();
                                                if (jsonNuevo1 != null && jsonAnterior1 != jsonNuevo1)
                                                {
                                                    //auditoria campo actualizado
                                                    string auditoriaSQL = auditoriaInsertCampoSql.Replace("@@ValorAnterior", jsonAnterior1).Replace("@@ValorNuevo", jsonNuevo1);
                                                    db.Execute(auditoriaSQL, item, tran, commandType: CommandType.Text);
                                                }
                                            }
                                    }
                                }

                            }

                        }

                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("ModeloDLL/ActualizarModelo: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public long CrearModelo(HeaderRequest header, CreacionModeloRequestBody body)
        {
            DynamicParameters dbPara = new DynamicParameters();
            dbPara.Add("Descripcion", body.Modelo.Descripcion, DbType.String);
            dbPara.Add("Codigo", body.Modelo.Codigo, DbType.String);
            dbPara.Add("Nombre", body.Modelo.Nombre, DbType.String);
            dbPara.Add("TipoModelo", body.Modelo.TipoModelo, DbType.String);
            dbPara.Add("Estado", body.Modelo.Estado, DbType.String);

            using (IDbConnection db = _config.ObtenerConexion())
            {
                
                string insertSQL = $"INSERT INTO [{SCHEMA}].[Modelo](Descripcion,Codigo,Nombre,TipoModelo,Estado) " +
                        $"VALUES(@Descripcion,@Codigo,@Nombre,@TipoModelo,@Estado);" +
                        "SELECT CAST(SCOPE_IDENTITY() as int);";
                
                //List<int> camposIds = new List<int>();

                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {
                        var result = db.Query<long>(insertSQL, dbPara, tran, commandType: CommandType.Text).First();

                        //dsc: auditoria modelo (insert)
                        
                        if (result > 0) {
                            body.Modelo.ModeloId = result;
                            string modeloJson = UtilGeneral.SerializedNeutralizedJson(body.Modelo);
                            string auditoriaInsertModeloSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                              $" VALUES ('Modelo', {result}, 'INSERT', '{header.UserName}', '{header.StationIp}', '', '{modeloJson}', '{fechaHoraAuditoria}');";
                            db.Execute(auditoriaInsertModeloSql, null, tran, commandType: CommandType.Text);
                        }
                        
                        


                        if (body.Modelo.Secciones != null && body.Modelo.Secciones.Count > 0) {
                            List<Campo> campos = ObtenerCamposDeSecciones(body.Modelo.Secciones);

                            string insertCamposSQL = $"INSERT INTO [{SCHEMA}].[Campo](ModeloId,TipoValor,Etiqueta,Codigo,TipoCampo,TipoDato,NombreCalculo,ValoresCalculo," +
                                $"TipoCalculado,LongitudMinima,LongitudMaxima,OrdenSeccion,Seccion,OrdenSubseccion,Subseccion,OrdenCampo,OrigenCombobox,OrigenEtiqueta," +
                                $"OrigenValores,OrigenCatalogo,CampoAS400,Obligatorio,PermiteEnmascaramiento,DatoSensible) " +
                                "OUTPUT INSERTED.CampoId " +
                                $"VALUES({result},@TipoValor,@Etiqueta,@Codigo,@TipoCampo,@TipoDato,@NombreCalculo,@ValoresCalculo," +
                                $"@TipoCalculado,@LongitudMinima,@LongitudMaxima,@OrdenSeccion,@Seccion,@OrdenSubseccion,@Subseccion,@OrdenCampo,@OrigenCombobox,@OrigenEtiqueta," +
                                $"@OrigenValores,@OrigenCatalogo,@CampoAS400,@Obligatorio,@PermiteEnmascaramiento,@DatoSensible);";

                            //dsc agregar campo
                            foreach (Campo campo in campos) {
                                //inserto un campo
                                campo.ModeloId = result;
                                campo.CampoId = db.QuerySingle<long>(insertCamposSQL, campo, tran, commandType: CommandType.Text);
                                //inserto campo y id en auditoria
                                string campoJson = UtilGeneral.SerializedNeutralizedJson(campo);
                                string auditoriaInsertCampoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                  $" VALUES ('Campo', @CampoId, 'INSERT', '{header.UserName}', '{header.StationIp}', '', '{campoJson}', '{fechaHoraAuditoria}');";
                                db.Execute(auditoriaInsertCampoSql, campo, tran, commandType: CommandType.Text);
                            }






                        }

                        tran.Commit();
                        return result;
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("ModeloDLL/CrearModelo: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        private List<Campo> ObtenerCamposDeSecciones(List<Seccion<CampoDto>> secciones)
        {
            //List<int> menu = new List<int>();
            List<Campo> camposIns = new List<Campo>();

            secciones.ForEach(child => {

                if (child.Campos != null && child.Campos.Count > 0) 
                {
                    List<Campo> campos = child.Campos.Select(x => new Campo { 
                        CampoAS400 = x.CampoAS400,
                        CampoId = x.CampoId,
                        Codigo = x.Codigo,
                        NombreCalculo = x.NombreCalculo,
                        ValoresCalculo = x.ValoresCalculo != null ? JsonConvert.SerializeObject(x.ValoresCalculo) : null,
                        Etiqueta = x.Etiqueta,
                        LongitudMaxima = x.LongitudMaxima,
                        LongitudMinima = x.LongitudMinima,
                        ModeloId = x.ModeloId,
                        Obligatorio = x.Obligatorio,
                        OrdenCampo = x.OrdenCampo,
                        OrdenSeccion = child.Orden,
                        OrdenSubseccion = 1,
                        OrigenCatalogo = x.OrigenCatalogo,
                        OrigenCombobox = x.OrigenCombobox,
                        OrigenEtiqueta = x.OrigenEtiqueta,
                        OrigenValores = x.OrigenValores,
                        PermiteEnmascaramiento = x.PermiteEnmascaramiento,
                        DatoSensible = x.DatoSensible,
                        Seccion = child.Nombre,
                        Subseccion = string.Empty,
                        TipoCalculado = x.TipoCalculado,
                        TipoCampo = x.TipoCampo,
                        TipoDato = x.TipoDato,
                        TipoValor = x.TipoValor
                    }).ToList();
                    camposIns.AddRange(campos);
                }
                //SUBSECCIONES
                if (child.Secciones != null && child.Secciones.Count > 0)
                {
                    child.Secciones.ForEach(y => {
                        if (y.Campos != null && y.Campos.Count > 0)
                        {
                            List<Campo> campos = y.Campos.Select(x => new Campo
                            {
                                CampoAS400 = x.CampoAS400,
                                CampoId = x.CampoId,
                                Codigo = x.Codigo,
                                NombreCalculo = x.NombreCalculo,
                                ValoresCalculo = x.ValoresCalculo != null ? JsonConvert.SerializeObject(x.ValoresCalculo) : null,
                                Etiqueta = x.Etiqueta,
                                LongitudMaxima = x.LongitudMaxima,
                                LongitudMinima = x.LongitudMinima,
                                ModeloId = x.ModeloId,
                                Obligatorio = x.Obligatorio,
                                OrdenCampo = x.OrdenCampo,
                                OrdenSeccion = child.Orden,
                                OrigenCatalogo = x.OrigenCatalogo,
                                OrdenSubseccion = y.Orden,
                                OrigenCombobox = x.OrigenCombobox,
                                OrigenEtiqueta = x.OrigenEtiqueta,
                                OrigenValores = x.OrigenValores,
                                PermiteEnmascaramiento = x.PermiteEnmascaramiento,
                                DatoSensible = x.DatoSensible,
                                Seccion = child.Nombre,
                                Subseccion = y.Nombre,
                                TipoCalculado = x.TipoCalculado,
                                TipoCampo = x.TipoCampo,
                                TipoDato = x.TipoDato,
                                TipoValor = x.TipoValor
                            }).ToList();
                            camposIns.AddRange(campos);
                        }
                        
                    });
                }
            });
            return camposIns;
        }

        public int EliminarModelos(HeaderRequest request, EliminacionModeloRequestBody body)
        {
            using (IDbConnection db = _config.ObtenerConexion())
            {
                string ids = "(" + string.Join(",", body.ModelosIds) + ")";
                string deleteSQL = $"DELETE FROM [{SCHEMA}].[Campo] WHERE ModeloId in {ids};"+
                    $"DELETE FROM [{SCHEMA}].[Modelo] WHERE ModeloId in {ids};" +
                    $"SELECT @@ROWCOUNT; ";


                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                {
                    try
                    {

                        //dsc: auditoria guardar modelo eliminado
                        string auditoriaSelectModeloSql = $"SELECT ModeloId,Codigo,Nombre,Descripcion,TipoModelo,Estado " +
                                                          $"FROM [{SCHEMA}].[Modelo] WHERE ModeloId IN ({ids});";
                        var listaModelosliminados = db.Query(auditoriaSelectModeloSql, null, tran, commandType: CommandType.Text);

                        string auditoriaSelectCamposSql = $"SELECT CampoId,ModeloId,TipoValor,Etiqueta,Codigo,TipoCampo,TipoDato,TipoCalculado,NombreCalculo,ValoresCalculo,LongitudMinima,LongitudMaxima,OrdenSeccion,Seccion,OrdenSubseccion,Subseccion,OrdenCampo,OrigenCombobox,OrigenEtiqueta,OrigenValores,OrigenCatalogo,CampoAS400,Obligatorio,PermiteEnmascaramiento,DatoSensible " +
                                                          $"FROM [{SCHEMA}].[Campo] WHERE ModeloId IN ({ids});";
                        var listaCamposliminados = db.Query(auditoriaSelectCamposSql, null, tran, commandType: CommandType.Text);

                        //dsc Eliminar fisicamente
                        var result = db.Query<int>(deleteSQL, transaction: tran, commandType: CommandType.Text);
                      

                        //dsc: auditoria agregar a auditoria los campos fisicamente eliminados
                        if (result.ToList().First<int>() > 0) {


                            //auditoria modelos eliminados
                            foreach (var item in listaModelosliminados)
                            {
                                    string auditoriaDeleteModeloSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                      $" VALUES ('Modelo', {item.ModeloId}, 'DELETE', '{request.UserName}', '{request.StationIp}', '{UtilGeneral.SerializedNeutralizedJson(item)}', '', '{fechaHoraAuditoria}');";

                                    db.Execute(auditoriaDeleteModeloSql, null, tran, commandType: CommandType.Text);
                            }
                            
                            //auditoria campos eliminados
                            foreach (var item in listaCamposliminados)
                            {
                                string auditoriaDeleteCampoSql = $"INSERT INTO [{SCHEMA}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                                                                 $" VALUES ('Campo', {item.CampoId}, 'DELETE', '{request.UserName}', '{request.StationIp}', '{UtilGeneral.SerializedNeutralizedJson(item)}', '', '{fechaHoraAuditoria}');";
                                db.Execute(auditoriaDeleteCampoSql, null, tran, commandType: CommandType.Text);
                            }
                        }


                        tran.Commit();
                        return result.ToList().First<int>();
                    }
                    catch (SqlException sqlException)
                    {
                        Log.Error("ModeloDLL/EliminarModelos: Transaccion SqlException -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                    catch (Exception sqlException)
                    {
                        Log.Error("ModeloDLL/EliminarModelos: Transaccion Exception -> " + sqlException.Message);
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public QueryModelosResponse ListarModelos(HeaderRequest header, ListaModelosRequestBody body)
        {
            string userName = header.UserName;
            int page = header.PageRequested;
            int itemsPerPage = header.PageSize;

            string state = body.Estado ?? string.Empty;
            string sortBy = body.OrdenarPor ?? string.Empty;
            string filterBy = body.FiltrarPor ?? string.Empty;
            string filterValue = body.ValorFiltro != null ? body.ValorFiltro.ToLower() : string.Empty;
            string tipo = body.Tipo != null ? body.Tipo.ToUpper() : string.Empty;
            string menuId = body.menuId != null ? body.menuId : string.Empty;

            #region user dynamic parameter
            var dbParam = new DynamicParameters();
            dbParam.Add("Username", userName, DbType.String);
            dbParam.Add("Page", page, DbType.Int32);
            dbParam.Add("ItemsPerPage", itemsPerPage, DbType.Int32);

            dbParam.Add("Estado", state.ToUpper(), DbType.String);
            dbParam.Add("SortBy", sortBy, DbType.String);
            dbParam.Add("SortDesc", body.OrdenDesc, DbType.Boolean);
            dbParam.Add("FilterBy", filterBy, DbType.String);
            dbParam.Add("FilterValue", '%' + filterValue.ToLower() + '%', DbType.String);
            dbParam.Add("TipoModelo", tipo, DbType.String);
            dbParam.Add("menuId", menuId, DbType.String);
            #endregion

            string sql = $"Select *, COUNT(*) OVER() as TotalCount from [{SCHEMA}].[Modelo] where 1=1 ";

            if (!string.IsNullOrEmpty(state))
            {
                sql += "AND UPPER([Estado]) = @Estado ";
            }

            if (!string.IsNullOrEmpty(tipo)) {
                sql += "AND UPPER([TipoModelo]) = @TipoModelo ";
            }

            if (!string.IsNullOrEmpty(menuId))
            {
                sql += "AND UPPER([menuId]) = @menuId ";
            }

            if (!string.IsNullOrEmpty(filterBy) && !string.IsNullOrEmpty(filterValue))
            {
                switch (filterBy.ToLower())
                {
                    case "code":
                        sql += "AND LOWER([Codigo]) like @FilterValue ";
                        break;
                    case "name": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST([Nombre] as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                    case "description": //para que la busqueda considere vocales con tildes
                        sql += "AND LOWER(CAST([Descripcion] as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS) like cast(@FilterValue as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS ";
                        break;
                }
            }

            bool sortDesc = body.OrdenDesc;

            if (!string.IsNullOrEmpty(sortBy))
            {
                switch (sortBy.ToLower())
                {
                    case "code":
                        sql += "ORDER BY [Codigo] ";
                        break;
                    case "description":
                        sql += "ORDER BY [Descripcion] ";
                        break;
                    case "name":
                        sql += "ORDER BY [Nombre] ";
                        break;
                    default:
                        sql += "ORDER BY [Nombre] ";
                        break;
                }
            }
            else
            {
                sql += "ORDER BY [Nombre] ";
            }
            sql += sortDesc ? "DESC " : "ASC ";

            sql += "OFFSET @ItemsPerPage * (@Page - 1) ROWS " +
                   "FETCH NEXT @ItemsPerPage ROWS ONLY; ";

            QueryModelosResponse result = new QueryModelosResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<Modelo> queryResult = db.Query(sql, param: dbParam, commandType: CommandType.Text,
                        map: (Modelo Model, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return Model;
                        }, splitOn: "TotalCount").ToList();

                    result.Modelos = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("ModeloDLL/ListarModelos: SqlException -> " + e.Message);
                    throw;
                }
            }
        }

        public ModeloDto ObtenerModeloPorId(HeaderRequest request, ConsultaModeloRequestBody body)
        {
            long ModelId = body.ModeloId;

            #region user dynamic parameter
            var dbPara = new DynamicParameters();
            dbPara.Add("ModeloId", ModelId, DbType.Int64);
            #endregion

            string sql = $"SELECT * FROM [{SCHEMA}].[Modelo] WHERE ModeloId = @ModeloId; ";
            sql += $"SELECT * FROM [{SCHEMA}].[Campo] WHERE ModeloId = @ModeloId order by OrdenSeccion,OrdenSubseccion,OrdenCampo;";
            sql += $"SELECT distinct Seccion, Subseccion, OrdenSeccion, OrdenSubseccion FROM [{SCHEMA}].[Campo] WHERE ModeloId = @ModeloId order by OrdenSeccion,OrdenSubseccion;";

            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    using (SqlMapper.GridReader multi = db.QueryMultiple(sql, param: dbPara, commandType: CommandType.Text))
                    {
                        ModeloDto result;

                        result = multi.Read<ModeloDto>().Single();
                        List<Campo> campos = multi.Read<Campo>().ToList();
                        List<QuerySeccionesResponse> secresponse = multi.Read<QuerySeccionesResponse>().ToList();

                        Dictionary<string, Seccion<CampoDto>> secciones = new Dictionary<string, Seccion<CampoDto>>();

                        Dictionary<string, List<Campo>> camposDict = campos.GroupBy(y => y.Seccion + "-" + y.Subseccion, x => x).ToDictionary(y => y.Key, x => x.ToList());

                        secresponse.ForEach(x => {
                            Seccion<CampoDto> seccion;
                            if (!secciones.TryGetValue(x.Seccion, out seccion))
                            {                                
                                seccion = new Seccion<CampoDto>
                                {
                                    Orden = x.OrdenSeccion,
                                    Nombre = x.Seccion,
                                    Secciones = new List<Seccion<CampoDto>>()
                                };
                                secciones.Add(x.Seccion, seccion);
                            }

                            Seccion<CampoDto> subseccion = new Seccion<CampoDto>
                            {
                                Orden = x.OrdenSubseccion,
                                Nombre = x.Subseccion
                            };
                            seccion.Secciones.Add(subseccion);

                            if (camposDict.TryGetValue(x.Seccion + "-" + x.Subseccion, out List<Campo> camposSeccion)) {

                                List<CampoDto> camposDtos = camposSeccion.Select(x =>
                                {
                                   CampoDto campoDt = new CampoDto { 
                                    CampoAS400 = x.CampoAS400.Trim(),
                                    CampoId = x.CampoId,
                                    Codigo = x.Codigo.Trim(),
                                    DatoSensible = x.DatoSensible,
                                    Etiqueta = x.Etiqueta.Trim(),
                                    LongitudMaxima = x.LongitudMaxima,
                                    LongitudMinima = x.LongitudMinima,
                                    ModeloId = x.ModeloId,
                                    NombreCalculo = x.NombreCalculo?.Trim(),
                                    Obligatorio = x.Obligatorio,
                                    OrdenCampo = x.OrdenCampo,
                                    OrigenCatalogo = x.OrigenCatalogo?.Trim(),
                                    OrigenCombobox = x.OrigenCombobox?.Trim(),
                                    OrigenEtiqueta = x.OrigenEtiqueta?.Trim(),
                                    OrigenValores = x.OrigenValores?.Trim(),
                                    PermiteEnmascaramiento = x.PermiteEnmascaramiento,
                                    TipoCalculado = x.TipoCalculado?.Trim(),
                                    TipoCampo = x.TipoCampo.Trim(),
                                    TipoDato = x.TipoDato.Trim(),
                                    TipoValor = x.TipoValor.Trim(),
                                    ValoresCalculo = !string.IsNullOrEmpty(x.ValoresCalculo) ? JsonConvert.DeserializeObject<List<string>>(x.ValoresCalculo) : null
                                };

                                    return campoDt;
                                }).ToList();


                                if (string.IsNullOrEmpty(subseccion.Nombre))
                                {
                                    seccion.Campos = camposDtos;
                                }
                                else {
                                    subseccion.Campos = camposDtos;
                                }
                            }
                        });
                        
                        result.Secciones = secciones.Values.ToList();

                        return result;
                    }
                }
                catch (SqlException sqlException)
                {
                    Log.Error("ModeloDLL/ObtenerModeloPorId: Transaccion SqlException -> " + sqlException.Message);
                    throw;
                }
            }
        }

        public QueryCamposResponse ObtenerListaCamposPorModeloId(HeaderRequest request, ConsultaModeloRequestBody body) 
        {

            #region user dynamic parameter
            var dbParam = new DynamicParameters();
            dbParam.Add("ModeloId", body.ModeloId, DbType.Int64);
            #endregion

            string sql = $"Select *, COUNT(*) OVER() as TotalCount from [{SCHEMA}].[Campo] WHERE ModeloId=@ModeloId ";

            sql += "ORDER BY Etiqueta DESC";

            QueryCamposResponse result = new QueryCamposResponse();
            using (IDbConnection db = _config.ObtenerConexion())
            {
                try
                {
                    int totalItems = 0;
                    List<Campo> queryResult = db.Query(sql, param: dbParam, commandType: CommandType.Text,
                        map: (Campo Model, int totalCount) =>
                        {
                            totalItems = totalCount;
                            return Model;
                        }, splitOn: "TotalCount").ToList();

                    result.Campos = queryResult;
                    result.Total = totalItems;
                    return result;
                }
                catch (SqlException e)
                {
                    Log.Error("ModeloDLL/ObtenerListaCamposPorModeloId: SqlException -> " + e.Message);
                    throw;
                }
            }
        }

         


}
}
