using icAuth.Extension;
using icCommon.ManejoErrores.Middlewares;
using icParametrizacionDinamica.DLL;
using icParametrizacionDinamica.DLL.Interfaces;
using icParametrizacionDinamica.Extension;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Events;
using System;
using System.IO;

var builder = WebApplication.CreateBuilder(args);

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
            .Enrich.FromLogContext()
    .WriteTo.File("logs/icParametrizacionDinamica.txt", LogEventLevel.Verbose,
                   "{NewLine}{Timestamp:HH:mm:ss} [{Level}] ({CorrelationToken}) {Message}{NewLine}{Exception}", rollingInterval: RollingInterval.Day)
    .CreateLogger();

// Add services to the container.
builder.Configuration.SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", true, true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", true, true)
    .AddJsonFile("icAppConfig.json")
    .AddJsonFile("icSecurityConfig.json")
    .AddJsonFile("icOriginConfig.json");

// Add scoped dependencies
builder.Services.AddInforcloudScopedDependencies();

builder.Services.AddScoped<IMonitorBalconDLL, MonitorBalconDLL>();

#region Configuracion JWT
builder.Services.AddInforcloudJWTGeneration(builder.Configuration);
builder.Services.AddInforcloudJWTAuthentication(builder.Configuration);
#endregion

builder.Services.AddMemoryCache();
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "Parametrizaci�n Din�mica para Balc�n de Servicios API",
        Description = "API para administraci�n din�mica de campos para productos del Balc�n de Servicios."
    });
    c.ConfigureInforcloudJwt();
});

var origins = builder.Configuration.GetSection("SiteOrigins").Get<string[]>();

builder.Services.AddCors(o => o.AddPolicy("AllowLocal", options =>
{
    //TEMPORAL
    //options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
    options.WithOrigins(origins).AllowAnyMethod().AllowAnyHeader();
}));

//TEMPORAL
/*builder.WebHost.UseKestrel(serverOptions =>
{
    serverOptions.ListenAnyIP(7010);
});*/

var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Parametrizaci�n Din�mica para Balc�n de Servicios API V1");
});

app.UseCors("AllowLocal");

// global error handler
app.UseMiddleware<ErrorHandlerMiddleware>();

app.UseAuthentication();

//app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

try
{
    Log.Information("------------------ INICIANDO API ----------------------");
    app.Run();
    return 0;
}
catch (Exception ex)
{
    Log.Fatal(ex, "------------------ FINALIZANDO API ----------------------");
    return 1;
    throw;
}
finally
{
    Log.Information("------------------ FINALIZANDO API ----------------------");
    Log.CloseAndFlush();
}

