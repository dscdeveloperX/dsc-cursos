﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.Models
{
    public class Campo
    {
        public long CampoId { get; set; }
        public long ModeloId { get; set; }
        public string TipoValor { get; set; }
        public string Etiqueta { get; set; }
        public string Codigo { get; set; }
        public string TipoCampo { get; set; }
        public string TipoDato { get; set; }
        public string TipoCalculado { get; set; }
        public string NombreCalculo { get; set; }
        public string ValoresCalculo { get; set; }
        public int LongitudMinima { get; set; }
        public int LongitudMaxima { get; set; }
        public int OrdenSeccion { get; set; }
        public string Seccion { get; set; }
        public int OrdenSubseccion { get; set; }
        public string Subseccion { get; set; }
        public int OrdenCampo { get; set; }
        public string OrigenCombobox { get; set; }
        public string OrigenEtiqueta { get; set; }
        public string OrigenValores { get; set; }
        public string OrigenCatalogo { get; set; }
        public string CampoAS400 { get; set; }
        public bool Obligatorio { get; set; }
        public bool PermiteEnmascaramiento { get; set; }
        public bool DatoSensible { get; set; }
    }

    public class CampoDto
    {
        public long CampoId { get; set; }
        public long ModeloId { get; set; }
        public string TipoValor { get; set; }
        public string Etiqueta { get; set; }
        public string Codigo { get; set; }
        public string TipoCampo { get; set; }
        public string TipoDato { get; set; }
        public string? TipoCalculado { get; set; }
        public string? NombreCalculo { get; set; }
        public List<string>? ValoresCalculo { get; set; }
        public int LongitudMinima { get; set; }
        public int LongitudMaxima { get; set; }
        public int OrdenCampo { get; set; }
        public string? OrigenCombobox { get; set; }
        public string? OrigenEtiqueta { get; set; }
        public string? OrigenValores { get; set; }
        public string? OrigenCatalogo { get; set; }
        public string CampoAS400 { get; set; }
        public bool Obligatorio { get; set; }
        public bool PermiteEnmascaramiento { get; set; }
        public bool DatoSensible { get; set; }
    }

    public class CampoCat
    {
        public long CampoId { get; set; }
        public long ModeloId { get; set; }
        public string TipoValor { get; set; }
        public string Etiqueta { get; set; }
        public string Codigo { get; set; }
        public string TipoCampo { get; set; }
        public string TipoDato { get; set; }
        public string? TipoCalculado { get; set; }
        public string? NombreCalculo { get; set; }
        public List<string>? ValoresCalculo { get; set; }
        public int LongitudMinima { get; set; }
        public int LongitudMaxima { get; set; }
        public int OrdenSeccion { get; set; }
        public string Seccion { get; set; }
        public int OrdenSubseccion { get; set; }
        public string Subseccion { get; set; }
        public int OrdenCampo { get; set; }
        public string? OrigenCombobox { get; set; }
        public List<ValorCombobox>? ValoresCombobox { get; set; }
        public string? OrigenEtiqueta { get; set; }
        public string? OrigenValores { get; set; }
        public string? OrigenCatalogo { get; set; }
        public string CampoAS400 { get; set; }
        public bool Obligatorio { get; set; }
        public bool PermiteEnmascaramiento { get; set; }
        public bool DatoSensible { get; set; }
    }
}
