﻿using System;

namespace icParametrizacionDinamica.Models
{
    public class Catalogo
    {
        public long CatalogoId { get; set; }
        public string Nombre { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string Complemento { get; set; }
        public string Estado { get; set; }
    }
}
