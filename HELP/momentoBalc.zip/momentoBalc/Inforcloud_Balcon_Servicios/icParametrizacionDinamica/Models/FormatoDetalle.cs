﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.Models
{
    public class FormatoDetalle
    {
        public long FormatoDetalleId { get; set; }
        public long FormatoId { get; set; }
        public long CampoId { get; set; }
        public string Etiqueta { get; set; }
        public int LongitudMinima { get; set; }
        public int LongitudMaxima { get; set; }
        public bool Enmascarar { get; set; }
        //VISIBILIDAD
        public bool Visible { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string DependenciaVisibilidad { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaVisibilidad { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaVisibilidad { get; set; }
        //OBLIGATORIO
        public bool Requerido { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string DependenciaRequerido { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaRequerido { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaRequerido { get; set; }
        //EDITABLE
        public bool Editable { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string DependenciaEditable { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaEditable { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaEditable { get; set; }
        //VALIDACION
        public string TipoValidacion { get; set; } //NINGUNO,REGEX,RUTINA,REGLA
        public string DependenciaValidacion { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaValidacion { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaValidacion { get; set; }
        public string ValidacionRegex { get; set; }
        public string ValidacionReglas { get; set; }
        public string ValidacionRutina { get; set; }
        public string ValidacionRutinaCampos { get; set; }
        //CAMPOS COMBOBOX
        public bool ComboboxPermiteNinguno { get; set; }
        public string TipoFiltro { get; set; }
        public string DependenciaFiltro { get; set; }
        public string ReglaDependenciaFiltro { get; set; }
        public string ValoresDependenciaFiltro { get; set; }
        //CAMPOS VALOR DEFECTO
        public string TipoValorDefecto { get; set; }
        public string DependenciaValorDefecto { get; set; }
        public string ReglaDependenciaValorDefecto { get; set; }
        public string ValoresDependenciaValorDefecto { get; set; }
        //VISTA HTML
        public string AnchoColumna { get; set; }
        //FORMULARIO
        public bool FormularioVisible { get; set; }
        public string EtiquetaFormulario { get; set; }
        public string AnchoColumnaFormulario { get; set; }
        public string AnchoEtiquetaFormulario { get; set; }
    }

    public class FormatoDetalleCampo
    {
        public long FormatoDetalleId { get; set; }
        public long FormatoId { get; set; }
        public long CampoId { get; set; }
        public long ModeloId { get; set; }
        public string TipoValor { get; set; }
        public string EtiquetaDetalle { get; set; }
        public string Codigo { get; set; }
        public string TipoCampo { get; set; }
        public string TipoDato { get; set; }
        public string TipoCalculado { get; set; }
        public string NombreCalculo { get; set; }
        public string ValoresCalculo { get; set; }
        public int LongitudMinimaDetalle { get; set; }
        public int LongitudMaximaDetalle { get; set; }
        public int OrdenSeccion { get; set; }
        public string Seccion { get; set; }
        public int OrdenSubseccion { get; set; }
        public string Subseccion { get; set; }
        public int OrdenCampo { get; set; }
        public string CampoAS400 { get; set; }
        public string OrigenCombobox { get; set; }
        public string OrigenEtiqueta { get; set; }
        public string OrigenValores { get; set; }
        public string OrigenCatalogo { get; set; }
        public bool DatoSensible { get; set; }
        public bool PermiteEnmascaramiento { get; set; }
        public bool Enmascarar { get; set; }
        public bool Obligatorio { get; set; }
        //OBLIGATORIO
        public bool Requerido { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string DependenciaRequerido { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaRequerido { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaRequerido { get; set; }
        //VISIBILIDAD
        public bool Visible { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string DependenciaVisibilidad { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaVisibilidad { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaVisibilidad { get; set; }
        //EDITABLE
        public bool Editable { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string DependenciaEditable { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaEditable { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaEditable { get; set; }
        //VALIDACION
        public string TipoValidacion { get; set; } //NINGUNO,REGEX,RUTINA,REGLA
        public string DependenciaValidacion { get; set; } //CAMPOS MODELO
        public string ReglaDependenciaValidacion { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public string ValoresDependenciaValidacion { get; set; }
        public string ValidacionRegex { get; set; }
        public string ValidacionReglas { get; set; }
        public string ValidacionRutina { get; set; }
        public string ValidacionRutinaCampos { get; set; }
        //CAMPOS COMBOBOX
        public bool ComboboxPermiteNinguno { get; set; }
        public string TipoFiltro { get; set; }
        public string DependenciaFiltro { get; set; }
        public string ReglaDependenciaFiltro { get; set; }
        public string ValoresDependenciaFiltro { get; set; }
        //CAMPOS VALOR DEFECTO
        public string TipoValorDefecto { get; set; }
        public string DependenciaValorDefecto { get; set; }
        public string ReglaDependenciaValorDefecto { get; set; }
        public string ValoresDependenciaValorDefecto { get; set; }
        //VISTA HTML
        public string AnchoColumna { get; set; }
        //FORMULARIO
        public bool FormularioVisible { get; set; }
        public string EtiquetaFormulario { get; set; }
        public string AnchoColumnaFormulario { get; set; }
        public string AnchoEtiquetaFormulario { get; set; }
    }

    public class FormatoDetalleDto
    {
        public long FormatoDetalleId { get; set; }
        public long FormatoId { get; set; }
        public long CampoId { get; set; }
        public long ModeloId { get; set; }
        public string TipoValor { get; set; }
        public string Etiqueta { get; set; }
        public string Codigo { get; set; }
        public string TipoCampo { get; set; }
        public string TipoDato { get; set; }
        public string? TipoCalculado { get; set; }
        public string? NombreCalculo { get; set; }
        public List<string>? ValoresCalculo { get; set; }
        public int LongitudMinima { get; set; }
        public int LongitudMaxima { get; set; }
        public int OrdenCampo { get; set; }
        public string? OrigenCombobox { get; set; }
        public string? OrigenEtiqueta { get; set; }
        public string? OrigenValores { get; set; }
        public string? OrigenCatalogo { get; set; }
        public bool DatoSensible { get; set; }
        public bool PermiteEnmascaramiento { get; set; }
        public bool Enmascarar { get; set; }
        public bool Obligatorio { get; set; }
        //OBLIGATORIO
        public bool Requerido { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string? DependenciaRequerido { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaRequerido { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaRequerido { get; set; }
        //VISIBILIDAD
        public bool Visible { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string? DependenciaVisibilidad { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaVisibilidad { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaVisibilidad { get; set; }
        //EDITABLE
        public bool Editable { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string? DependenciaEditable { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaEditable { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaEditable { get; set; }
        //VALIDACION
        public string? TipoValidacion { get; set; } //NINGUNO,REGEX,RUTINA,REGLA
        public string? DependenciaValidacion { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaValidacion { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaValidacion { get; set; }
        public string? ValidacionRegex { get; set; }
        public Dictionary<string, OperacionDependencia>? ValidacionReglas { get; set; }
        public string? ValidacionRutina { get; set; }
        public List<string>? ValidacionRutinaCampos { get; set; }
        //CAMPOS COMBOBOX
        public bool? ComboboxPermiteNinguno { get; set; }
        public string? TipoFiltro { get; set; } //INICIAL, ONCHANGE
        public string? DependenciaFiltro { get; set; } //CAMPO
        public string? ReglaDependenciaFiltro { get; set; } //VALOR, CONDICIONAL
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaFiltro { get; set; }
        //CAMPOS VALOR DEFECTO
        public string? TipoValorDefecto { get; set; } //INICIAL, ONCHANGE
        public string? DependenciaValorDefecto { get; set; } //CAMPO
        public string? ReglaDependenciaValorDefecto { get; set; } //VALOR, CONDICIONAL
        public Dictionary<string, string>? ValoresDependenciaValorDefecto { get; set; } //libre, CMPL, VALUE
        //VISTA HTML
        public string AnchoColumna { get; set; }
        //FORMULARIO
        public bool FormularioVisible { get; set; }
        public string? EtiquetaFormulario { get; set; }
        public string? AnchoColumnaFormulario { get; set; }
        public string? AnchoEtiquetaFormulario { get; set; }
        //CAMPOS LISTAS
        public List<Campo>? FormatoModeloLista { get; set; }
    }

    public class FormatoDetalleFormularioDto
    {       

        public long FormatoDetalleId { get; set; }
        public long FormatoId { get; set; }
        public long CampoId { get; set; }
        public long ModeloId { get; set; }
        public string TipoValor { get; set; }
        public string EtiquetaDetalle { get; set; }
        public string Codigo { get; set; }
        public string TipoCampo { get; set; }
        public string TipoDato { get; set; }
        public string? TipoCalculado { get; set; }
        public string? NombreCalculo { get; set; }
        public List<string>? ValoresCalculo { get; set; }
        public int LongitudMinimaDetalle { get; set; }
        public int LongitudMaximaDetalle { get; set; }
        public int OrdenCampo { get; set; }
        public string? OrigenCombobox { get; set; }
        public List<ValorCombobox>? ValoresCombobox { get; set; }
        public string? OrigenEtiqueta { get; set; }
        public string? OrigenValores { get; set; }
        public string? OrigenCatalogo { get; set; }
        public string CampoAS400 { get; set; }
        public bool DatoSensible { get; set; }
        public bool Enmascarar { get; set; }
        //OBLIGATORIO
        public bool Requerido { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string? DependenciaRequerido { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaRequerido { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaRequerido { get; set; }
        //VISIBILIDAD
        public bool Visible { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string? DependenciaVisibilidad { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaVisibilidad { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaVisibilidad { get; set; }
        //EDITABLE
        public bool Editable { get; set; }//SIEMPRE, NUNCA, CONDICIONAL
        public string? DependenciaEditable { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaEditable { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaEditable { get; set; }
        //VALIDACION
        public string? TipoValidacion { get; set; } //NINGUNO,REGEX,RUTINA,REGLA
        public string? DependenciaValidacion { get; set; } //CAMPOS MODELO
        public string? ReglaDependenciaValidacion { get; set; } //NOT EMPTY, OPERACION
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaValidacion { get; set; }
        public string? ValidacionRegex { get; set; }
        public Dictionary<string, OperacionDependencia>? ValidacionReglas { get; set; }
        public string? ValidacionRutina { get; set; }
        public List<string>? ValidacionRutinaCampos { get; set; }
        //CAMPOS COMBOBOX
        public bool? ComboboxPermiteNinguno { get; set; }
        public string? TipoFiltro { get; set; } //INICIAL, ONCHANGE
        public string? DependenciaFiltro { get; set; } //CAMPO
        public string? ReglaDependenciaFiltro { get; set; } //VALOR, CONDICIONAL
        public Dictionary<string, OperacionDependencia>? ValoresDependenciaFiltro { get; set; }
        //CAMPOS VALOR DEFECTO
        public string? TipoValorDefecto { get; set; } //INICIAL, ONCHANGE
        public string? DependenciaValorDefecto { get; set; } //CAMPO
        public string? ReglaDependenciaValorDefecto { get; set; } //VALOR, CONDICIONAL
        public Dictionary<string, string>? ValoresDependenciaValorDefecto { get; set; } //libre, CMPL, VALUE
        //VISTA HTML
        public string AnchoColumna { get; set; }
        //FORMULARIO
        public bool? FormularioVisible { get; set; }
        public string? EtiquetaFormulario { get; set; }
        public string? AnchoColumnaFormulario { get; set; }
        public string? AnchoEtiquetaFormulario { get; set; }
        //CAMPOS LISTAS
        public List<FormatoDetalleFormularioDto>? FormatoModeloLista { get; set; }
        public List<ValoresModeloDto>? ValoresLista { get; set; }
        //VALOR
        public dynamic? Valor { get; set; }
        public dynamic? ValorAnterior { get; set; }
    }

    public class ValoresModeloDto
    {
        public List<ValorCampoModeloDto> Campos { get; set; }
    }

    public class OperacionDependencia { 
        public string Operacion { get; set; } //=,!=,NOT IN,IN,>,<,>=,<=,INI,FIN,SUB
        public List<string> Valores { get; set; } //libre, CMPL, VALUE, DESCR
    }

    public class ValorCampoModeloDto
    {
        public string Codigo { get; set; }
        public dynamic? Valor { get; set; }
    }

    public class ValorCombobox { 
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public string? Complemento { get; set; }
    }
}
