﻿using icCommon.DTOs.DB;
using System.Collections.Generic;

namespace icParametrizacionDinamica.Models
{
    public class Formato
    {
        public long FormatoId { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string TipoPersona { get; set; }
        public string TipoIdentificacion { get; set; }
        public string TipoCliente { get; set; }
        public long PersonaId { get; set; }
        public long? ProductoId { get; set; } 
    }

    public class FormatoCreacionDto
    {
        public long FormatoId { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string TipoPersona { get; set; }
        public string TipoIdentificacion { get; set; }
        public string TipoCliente { get; set; }
        public string Persona { get; set; }
        public string Producto { get; set; }
        public List<Seccion<FormatoDetalleDto>> SeccionesPersona { get; set; }
        public List<Seccion<FormatoDetalleDto>> SeccionesProducto { get; set; }
        public List<SeccionesCamposDinamicos> SeccionesReferencias { get; set; }
    }

    public class FormatoDto { 
        public long FormatoId { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; } 
        public CodigoDescriptor TipoPersona { get; set; }
        public CodigoDescriptor TipoIdentificacion { get; set; }
        public CodigoDescriptor TipoCliente { get; set; }
        public CampoDescriptor Persona { get; set; }
        public CampoDescriptor Producto { get; set; }
        public List<Seccion<FormatoDetalleDto>> SeccionesPersona { get; set; }
        public List<Seccion<FormatoDetalleDto>> SeccionesProducto { get; set; }
        public List<SeccionesCamposDinamicos> SeccionesReferencias { get; set; }
    }

    public class CamposFormatoDto {
        public List<Seccion<FormatoDetalleDto>> SeccionesPersona { get; set; }
        public List<Seccion<FormatoDetalleDto>> SeccionesProducto { get; set; }
        public List<SeccionesCamposDinamicos> SeccionesReferencias { get; set; }
    }

    public class SeccionesCamposDinamicos {
        public string Nombre { get; set; }
        public List<Seccion<FormatoDetalleDto>> SeccionesCampo { get; set; }
    }

    public class FormatoClienteDto
    {
        public long FormatoId { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; } 
        public CodigoDescriptor TipoPersona { get; set; }
        public CodigoDescriptor TipoIdentificacion { get; set; }
        public CodigoDescriptor TipoCliente { get; set; }
        public PaginaForm<FormatoDetalleFormularioDto> Cliente { get; set; }
        public PaginaForm<FormatoDetalleFormularioDto> Producto { get; set; }        
    }

    public class FormatoSolicitudFormularioDto
    {
        public long FormatoId { get; set; }
        public string TipoPersona { get; set; }
        public string TipoIdentificacion { get; set; }
        public string TipoCliente { get; set; }
        public PaginaForm<FormatoDetalleFormularioDto> Formulario { get; set; }
    }

    public class PaginaForm<T> where T : class {
        public long Id { get; set; }
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public List<Seccion<T>> Secciones { get; set; }
    }
}
