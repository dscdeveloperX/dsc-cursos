﻿using System.Collections.Generic;

namespace icParametrizacionDinamica.Models
{
    public class Modelo
    {
        public long ModeloId { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string TipoModelo { get; set; } //CLIENTE, PRODUCTO, DINAMICO
        public string Estado { get; set; }
    }

    public class ModeloDto {
        public long ModeloId { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string TipoModelo { get; set; }
        public string Estado { get; set; }
        public List<Seccion<CampoDto>> Secciones { get; set; }
    }

    public class Seccion<T> where T : class { 
        public string Nombre { get; set; }
        public int Orden { get;set; }
        public List<Seccion<T>> Secciones { get; set; }
        public List<T> Campos { get; set; }
    }
}
