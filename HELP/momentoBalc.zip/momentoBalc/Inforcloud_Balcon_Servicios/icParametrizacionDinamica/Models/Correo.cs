﻿namespace icParametrizacionDinamica.Models
{
    public class Correo
    {
        public long CorreoId { get; set; }
        public string Codigo { get; set; }
        public string Asunto { get; set; }
        public string Body { get; set; }
        public bool IsHtml { get; set; }
        public int NumeroReitento { get; set; }
        public string Remitente { get; set; }
        public int CodigoProceso { get; set; }
    }
}
