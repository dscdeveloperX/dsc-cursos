﻿using icCommon.Utils;
using System.Collections.Generic;
using static icParametrizacionDinamica.Constantes;

namespace icParametrizacionDinamica
{
    public class Constantes
    {
        public static string ServiceName = "icParametrizacionDinamica";

        public const string CODIGO_SUCCESS_PN = "000000";

        public static List<NamespacePrefix> RequestNamespaces = new List<NamespacePrefix>
        {
            new NamespacePrefix{ Namespace = XmlNamespace.Envelope, Prefix = XmlRequestPrefix.Envelope},
            new NamespacePrefix{ Namespace = XmlNamespace.Tem, Prefix = XmlRequestPrefix.Tem},
            new NamespacePrefix{ Namespace = XmlNamespace.Bm, Prefix = XmlRequestPrefix.Bm},
            new NamespacePrefix{ Namespace = XmlNamespace.Bm1, Prefix = XmlRequestPrefix.Bm1}
        };

        public static List<NamespacePrefix> RequestCorreoNamespaces = new List<NamespacePrefix>
        {
            new NamespacePrefix{ Namespace = XmlNamespace.Envelope, Prefix = XmlRequestPrefix.Envelope},
            new NamespacePrefix{ Namespace = XmlNamespace.Tem, Prefix = XmlRequestPrefix.Tem},
            new NamespacePrefix{ Namespace = XmlNamespace.Cor, Prefix = XmlRequestPrefix.Cor}
        };

        public class XmlNamespace
        {
            public const string Envelope = "http://schemas.xmlsoap.org/soap/envelope/";
            public const string Tem = "http://tempuri.org/";
            public const string Bm = "http://schemas.datacontract.org/2004/07/Bm.RepositorioBase";
            public const string Bm1 = "http://schemas.datacontract.org/2004/07/Bm.Personas.Servicio.Contrato.Solicitud";
            public const string As = "";
            public const string Cor = "http://schemas.datacontract.org/2004/07/Correos.BM.Entidad";
        }

        public class XmlNamespaceResponse
        {
            public const string Envelope = "http://schemas.xmlsoap.org/soap/envelope/";
            public const string Tem = "http://tempuri.org/";
            public const string A = "http://schemas.datacontract.org/2004/07/Bm.Personas.Servicio.Contrato.Respuesta";
            public const string I = "http://www.w3.org/2001/XMLSchema-instance";
        }

        public class XmlResponsePrefix
        {
            public const string Envelope = "s";
            public const string Tem = "";
            public const string Bm = "a";
            public const string Bm1 = "i";
        }

        public class XmlRequestPrefix
        {
            public const string Envelope = "soapenv";
            public const string Tem = "tem";
            public const string Bm = "bm";
            public const string Bm1 = "bm1";
            public const string Cor = "cor";
        }

        public class ElementTag
        {
            public const string Datos = "datos";
            public const string Correo = "correo";
        }

        public class TipoFiltro
        {
            public const string INICIAL = "INICIAL";
            public const string ONCHANGE = "ONCHANGE";
        }

        public class ReglaFiltro
        {
            public const string VALOR = "VALOR";
            public const string CONDICIONAL = "CONDICIONAL";
        }

        public class TipoValorDefecto
        {
            public const string INICIAL  = "INICIAL";
            public const string ONCHANGE = "ONCHANGE";
        }

        public class ReglaValorDefecto
        {
            public const string VALOR = "VALOR";
            public const string CONDICIONAL = "CONDICIONAL";
        }

        public class Operaciones
        {
            //=,!=,NOT IN, IN,>,<,>=,<=, INI, FIN, SUB
            public const string NONE = "NONE";
            public const string EQUALS = "=";
            public const string NOT_EQUAL = "!=";
            public const string NOT_IN = "NOT IN";
            public const string IN = "IN";
            public const string MORE_THAN = ">";
            public const string LESS_THAN = "<";
            public const string MORE_THAN_EQUALS = ">=";
            public const string LESS_THAN_EQUALS = "<=";
            public const string STARTS_WITH = "INI";
            public const string ENDS_WITH = "FIN";
            public const string CONTAINS = "SUB";
        }

        public class Tramas
        {
            public const string ENVIAR_CORREO_EXTERNO = "ENVIAR_CORREO_EXTERNO";
            public const string ENVIAR_CORREO_INTERNO = "ENVIAR_CORREO_INTERNO";

            public const string CONSULTAR_DATOS_PERSONA = "CONSULTAR_DATOS_PERSONA";
            public const string CONSULTAR_DATOS_REGISTRO_CIVIL = "CONSULTAR_DATOS_REGISTRO_CIVIL";
            public const string VALIDAR_LISTAS_NEGRAS = "VALIDAR_LISTAS_NEGRAS";
            public const string VALIDAR_PERSONA_EXPUESTA_POLITICAMENTE = "VALIDAR_PERSONA_EXPUESTA_POLITICAMENTE";
            public const string CONSULTAR_NOMBRE_EMPRESA = "CONSULTAR_NOMBRE_EMPRESA";//DSC

            public const string CONSULTAR_CLIENTE_NATURAL = "CONSULTAR_CLIENTE_NATURAL";
            public const string EDITAR_CLIENTE_NATURAL = "EDITAR_CLIENTE_NATURAL";
            public const string EDITAR_CLIENTE_NATURAL_FALLECIDO = "EDITAR_CLIENTE_NATURAL_FALLECIDO";//DSC
            public const string CREAR_CLIENTE_NATURAL = "CREAR_CLIENTE_NATURAL";

            public const string CREAR_CUENTA_AHORRO_CLIENTE_NATURAL = "CREAR_CUENTA_AHORRO_CLIENTE_NATURAL";
            public const string CREAR_CUENTA_CORRIENTE_CLIENTE_NATURAL = "CREAR_CUENTA_CORRIENTE_CLIENTE_NATURAL";

            public const string CONSULTAR_CLIENTE_JURIDICO = "CONSULTAR_CLIENTE_JURIDICO";
            public const string CREAR_CLIENTE_JURIDICO = "CREAR_CLIENTE_JURIDICO";
            public const string EDITAR_CLIENTE_JURIDICO = "EDITAR_CLIENTE_JURIDICO";

            public const string CREAR_CUENTA_AHORRO_CLIENTE_JURIDICO = "CREAR_CUENTA_AHORRO_CLIENTE_JURIDICO";
            public const string CREAR_CUENTA_CORRIENTE_CLIENTE_JURIDICO = "CREAR_CUENTA_CORRIENTE_CLIENTE_JURIDICO";

            //CONTACTABILIDAD
            public const string EDICION_CONTACTABILIDAD = "EDICION_CONTACTABILIDAD";
            public const string CONSULTA_CONTACTABILIDAD = "CONSULTA_CONTACTABILIDAD";

            public const string LOGO_BANCO = "LOGO_BANCO";

            //Consultas para Ahorro programado
            public const string CONSULTA_CuentasActivas = "CONSULTA_CuentasActivas";
            public const string CONSULTA_CuentasCliente = "CONSULTA_CuentasCliente";
            public const string CONSULTA_ClienteContratos = "CONSULTA_ClienteContratos";
            public const string Cancelar_Contratos = "Cancelar_Contratos";
            public const string SIMULADOR_AHORRO_PROGRAMADO = "SIMULADOR_AHORRO_PROGRAMADO";
            public const string Solicitud_Contratos = "Solicitud_Contratos";
            public const string SimulaCancelacionAP = "SimulaCancelacionAP"; 
            public const string CatalogoAhorroProgramado = "CatalogoAhorroProgramado"; 
            public const string ValidaCuentaAhorroProgramado = "ValidaCuentaAhorroProgramado";
            public const string ConsultaPlazosAP = "ConsultaPlazosAP";
            public const string ObtenerSecuencialAP = "ObtenerSecuencial";
			public const string SimuladorModificaContratoAP = "SimuladorModificaContratoAP";
        }

        public const string USUARIO_AUTOMATICO = "NOAPLICA";

        public class EstadosAprobacion
        {
            public const string APROBADO = "APROBADO";
            public const string RECHAZADO = "RECHAZADO";
            public const string PROCESADO = "PROCESADO";
            public const string ELIMINADO = "ELIMINADO";
        }

        public class Correos {
            public const string CORREO_APROBACION_SOLICITUD_CAMBIO = "CORREO_APROBACION_SOLICITUD_CAMBIO";
            public const string CORREO_RECHAZO_SOLICITUD_CAMBIO = "CORREO_RECHAZO_SOLICITUD_CAMBIO";
            public const string CORREO_ACTUALIZACION_DATOS_SENSIBLES = "CORREO_ACTUALIZACION_DATOS_SENSIBLES";
        }

        /*public static class LogAuditoria {

            public static string TablaAuditoriaParametros((string schema, string tablaNombre, long tablaId, AditoriaOperacion operacion, string usuario, string ipOrigen, string valorAnterior, string valorNuevo, string fechaHora) item) {

                string ValorAnterior = string.Empty;
                string ValorNuevo = string.Empty;
                string ope = item.operacion switch { AditoriaOperacion.Insert => "INSERT", AditoriaOperacion.Update => "UPDATE", AditoriaOperacion.Delete => "DELETE", _=>"" };
               
                return $"INSERT INTO [{item.schema}].[AuditoriaParametros](TablaNombre, TablaId, Operacion, Usuario, IpOrigen, ValorAnterior, ValorNuevo, FechaHora)" +
                      $" VALUES ('{item.tablaNombre}', {item.tablaId}, '{ope}', '{item.usuario}', '{item.ipOrigen}', {item.valorAnterior}, {item.valorNuevo}, '{item.fechaHora}');";
            }

            public enum AditoriaOperacion { 
            Insert = 1,
            Update = 2,
            Delete = 3
            }
        //como usar metodo
        //string auditoriaDeleteModeloSql = Constantes.LogAuditoria.TablaAuditoriaParametros((schema:SCHEMA, tablaNombre: "Modelo", tablaId: item.ModeloId, operacion: LogAuditoria.AditoriaOperacion.Delete , usuario: request.UserName, ipOrigen: request.StationIp, valorAnterior: $"'{UtilGeneral.SerializedNeutralizedJson(item)}'", valorNuevo:$"''", fechaHora: fechaHoraAuditoria));

        }*/

    }
}
