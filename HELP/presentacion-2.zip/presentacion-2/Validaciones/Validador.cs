public class Validador
{

    private readonly string Servicio;


     public Validador(string servicio){
        Servicio = servicio;
     }


    public void ValidarDatosPersonales(string apenom, DateTime? fecNac, string sexo, string estCiv, string apenomCyg)
    {
        // Validación Apellido y Nombres
        if (string.IsNullOrEmpty(apenom))
        {
            ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.DatosPersonales.NombresYApellidos.Codigo, ValidacionMensajes.DatosPersonales.NombresYApellidos.Mensaje);
        }

        // Validación Fecha de Nacimiento
        if (!fecNac.HasValue)
        {
            ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.DatosPersonales.FechaDeNacimiento.Codigo, ValidacionMensajes.DatosPersonales.FechaDeNacimiento.Mensaje);
        }

        // Validación Sexo
        if (string.IsNullOrEmpty(sexo))
        {
            ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.DatosPersonales.Sexo.Codigo, ValidacionMensajes.DatosPersonales.Sexo.Mensaje);
        }

        // Validación Estado Civil
        if (string.IsNullOrEmpty(estCiv))
        {
            ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.DatosPersonales.EstadoCivil.Codigo, ValidacionMensajes.DatosPersonales.EstadoCivil.Mensaje);
        }

        // Validación Apellidos y Nombres de Cónyuge
        if (estCiv == "C" || estCiv == "U")
        {
            if (string.IsNullOrEmpty(apenomCyg))
            {
                ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.DatosPersonales.NombresYApellidosConyuge.Codigo, ValidacionMensajes.DatosPersonales.NombresYApellidosConyuge.Mensaje);
            }
        }
    }



    public void ValidarDireccionDomicilio(string dirDom)
    {
        if (string.IsNullOrEmpty(dirDom) || (dirDom.Length < 10 || dirDom.Length > 200))
        {
            ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.Direccion.Domicilio.Codigo, ValidacionMensajes.Direccion.Domicilio.Mensaje);
        }

        if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(dirDom))
        {
            ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.Direccion.Domicilio.Codigo, ValidacionMensajes.Direccion.Domicilio.CaracteresConsecutivosMensaje);
        }
    }



    public void ValidarDireccionOficina(string dirOfi)
    {
        if (!string.IsNullOrEmpty(dirOfi))
        {
            if (dirOfi.Length < 10 || dirOfi.Length > 200)
            {
                ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.Direccion.Oficina.Codigo, ValidacionMensajes.Direccion.Oficina.Mensaje);
            }

            if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(dirOfi))
            {
                ErrorUtil.ThrowAppException(Servicio, ValidacionMensajes.Direccion.Oficina.Codigo, ValidacionMensajes.Direccion.Oficina.CaracteresConsecutivosMensaje);
            }
        }
    }



    public void ValidarCelularDomicilio(string celDom)
    {
        if (string.IsNullOrEmpty(celDom))
        {
            ErrorUtil.ThrowAppException(Servicio, 
                                        ValidacionMensajes.Celular.Domicilio.Codigo, 
                                        ValidacionMensajes.Celular.Domicilio.NuloVacioMensaje);
        }

        if (!Validaciones.IniciaConCero(celDom))
        {
            ErrorUtil.ThrowAppException(Servicio, 
                                        ValidacionMensajes.Celular.Domicilio.Codigo, 
                                        ValidacionMensajes.Celular.Domicilio.IniciaConCeroMensaje);
        }

        if (Validaciones.TieneSeisCaracteresIgualesConsecutivosRegex(celDom))
        {
            ErrorUtil.ThrowAppException(Servicio, 
                                        ValidacionMensajes.Celular.Domicilio.Codigo, 
                                        ValidacionMensajes.Celular.Domicilio.ExcedeCantidadRepetidosMensaje);
        }
    }


    
}
