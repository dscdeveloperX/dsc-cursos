 
       Validador validador = new Validador("EnviarFormularioPersona");
        
        validador.ValidarDatosPersonales(ApellidoNombre, FechaNacimiento, Sexo, EstadoCivil, ApellidoNombreConyuge);
        validador.ValidarDireccionDomicilio(DireccionDomicilio);
        validador.ValidarDireccionOficina(DireccionOficina);
        validador.ValidarCelularDomicilio(CelularDomicilio);

        