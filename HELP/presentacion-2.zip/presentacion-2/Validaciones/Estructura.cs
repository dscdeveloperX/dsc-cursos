public static class ValidacionMensajes
{



    public static class DatosPersonales
    {


        public static class NombresYApellidos
        {
            public const string Codigo = "VALIDACION_NOMBRES_Y_APELLIDOS";
            public const string Mensaje = "FAVOR VALIDAR LOS DATOS INGRESADOS EN EL CAMPO NOMBRES Y APELLIDOS.";
        }

        public static class FechaDeNacimiento
        {
            public const string Codigo = "VALIDACION_FECHA_DE_NACIMIENTO";
            public const string Mensaje = "FAVOR VALIDAR LOS DATOS INGRESADOS EN EL CAMPO DE FECHA DE NACIMIENTO.";
        }

        public static class Sexo
        {
            public const string Codigo = "VALIDACION_SEXO";
            public const string Mensaje = "FAVOR VALIDAR LOS DATOS INGRESADOS EN EL CAMPO SEXO.";
        }

        public static class EstadoCivil
        {
            public const string Codigo = "VALIDACION_ESTADO_CIVIL";
            public const string Mensaje = "FAVOR VALIDAR LOS DATOS INGRESADOS EN EL CAMPO ESTADO CIVIL.";
        }

        public static class NombresYApellidosConyuge
        {
            public const string Codigo = "VALIDACION_NOMBRES_Y_APELLIDOS_DEL_CONYUGE";
            public const string Mensaje = "FAVOR VALIDAR LOS DATOS INGRESADOS EN EL CAMPO NOMBRES Y APELLIDOS DEL CONYUGE.";
        }

        
    }




    public static class Direccion
    {

        public static class Domicilio
        {
            public const string Codigo = "VALIDACION_DIRECCION_DOMICILIO";
            public const string Mensaje = "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE DOMICILIO.";
            public const string CaracteresConsecutivosMensaje = "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE DOMICILIO.";
        }

        public static class Oficina
        {
            public const string Codigo = "VALIDACION_DIRECCION_OFICINA";
            public const string Mensaje = "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE OFICINA.";
            public const string CaracteresConsecutivosMensaje = "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE OFICINA.";
        }


    }





    public static class Celular
    {

        public static class Domicilio
        {
            public const string Codigo = "VALIDACION_CELULAR_DOMICILIO";
            public const string NuloVacioMensaje = "FAVOR VALIDAR LOS DATOS INGRESADOS EN EL CAMPO CELULAR DOMICILIO.";
            public const string IniciaConCeroMensaje = "EL CAMPO CELULAR DOMICILIO DEBE INICIAR CON 0.";
            public const string ExcedeCantidadRepetidosMensaje = "EL CAMPO CELULAR DOMICILIO EXCEDE LA CANTIDAD DE CARACTERES REPETIDOS CONSECUTIVAMENTE.";
        }

    }



}
