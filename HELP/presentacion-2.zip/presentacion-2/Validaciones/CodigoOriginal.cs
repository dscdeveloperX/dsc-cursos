    #region VALIDACIONES PARA TODOS LOS CAMPOS OBTENIDOS DE REGISTRO CIVIL

        //validacion Apellido y Nombres
        if (String.IsNullOrEmpty(APENOM))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_Y_APELLIDOS", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRES Y APELLIDOS.");
        }

        //validacion Fecha de Nacimiento
        if (!FECNAC.HasValue)
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_FECHA_DE_NACIMIENTO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO DE FECHA DE NACIMIENTO.");
        }

        //validacion Sexo
        if (String.IsNullOrEmpty(SEXO))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_SEXO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO SEXO.");
        }

        //validacion Estado Civil
        if (String.IsNullOrEmpty(ESTCIV))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_ESTADO_CIVIL", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO ESTADO CIVIL.");
        }

        //validacion Apellidos y Nombres de Conyuge
        if (ESTCIV == "C" || ESTCIV == "U")
        {
            if (String.IsNullOrEmpty(APENOMCYG))
            {
                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_NOMBRES_Y_APELLIDOS_DEL_CONYUGE", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO NOMBRES Y APELLIDOS DEL CONYUGE.");
            }
        }


    #endregion

    #region Validacion Dirección de Domicilio
        if (String.IsNullOrEmpty(DIRDOM) || (DIRDOM.Length < 10 || DIRDOM.Length > 200))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_DOMICILIO", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE DOMICILIO.");
        }

        if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIRDOM))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_DOMICILIO", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE DOMICILIO.");
        }
    #endregion

    #region Validacion Dirección de Oficina
        if (!String.IsNullOrEmpty(DIROFI))
        {
            if (DIROFI.Length < 10 || DIROFI.Length > 200)
            {
                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_OFICINA", "FAVOR VALIDAR LA LONGITUD DEL CAMPO DIRECCION DE OFICINA.");
            }

            if (Validaciones.TieneCincoCaracteresIgualesConsecutivosRegex(DIROFI))
            {
                ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_DIRECCION_OFICINA", "NO SE PERMITE CARACTERES IGUALES CONSECUTIVAMENTE EN EL CAMPO DIRECCION DE OFICINA.");
            }
        }

    #endregion

    #region Validacion Celular Domicilio

        if (string.IsNullOrEmpty(CELDOM))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "FAVOR VALIDAR LOS DATOS INGRESADOS EL CAMPO CELULAR DOMICILIO.");
        }

        if (!Validaciones.IniciaConCero(CELDOM))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "EL CAMPO CELULAR DOMICILIO DEBE INICIAR CON 0.");
        }

        if (Validaciones.TieneSeisCaracteresIgualesConsecutivosRegex(CELDOM))
        {
            ErrorUtil.ThrowAppException("EnviarFormularioPersona", "VALIDACION_CELULAR_DOMICILIO", "EL CAMPO CELULAR DOMICILIO EXCEDE LA CANTIDAD DE CARACTERES REPETIDOS CONSECUTIVAMENTE.");
        }
    #endregion

    

#endregion